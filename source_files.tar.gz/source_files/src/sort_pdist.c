#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "sort_pdist.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
int         flag;
char        buff[BUFLEN];
FILE *infile;
int n_line = 0;
int thresh = 500;
double suma,sumb;

char outflnm[BUFLEN];
FILE *outfile;
sprintf(outflnm,"%s.pe",argv[1]);

int n_cluster = 0;
cluster_info *clusters;

int read_id,from,to;

infile = fopen(argv[1],"r");
if(infile == NULL)
 {
 printf("Failed to open the input file %s\n",argv[1]);
 exit(1);
 }

outfile = fopen(outflnm,"w");
if(outfile == NULL)
 {
 printf("Failed to open the outputfile file %s\n",outflnm);
 exit(1);
 }

while(fgets(buff,132,infile))  // $B%Z%"%U%!%$%k$N9T?t$r%+%&%s%H(B
 {
 n_line ++;
 }
printf("N_LINE in %s is %d\n",argv[1],n_line);
rewind(infile);

clusters = (cluster_info *)malloc(sizeof(cluster_info) * n_line);   // $B%Z%"$N?t$@$1%/%i%9%?9=B$BN$r3NJ](B
for(i=0;i<n_line;i++)                                               // $B$9$Y$F$N%/%i%9%?9=B$BN$N%Z%"?t$r#0$K(B
 {
 clusters[i].n_pair = 0;
 }


fgets(buff,132,infile);                                             // $B0l$DL\$N%Z%"$O:G=i$N%/%i%9%?$N%3%"$K(B
sscanf(buff,"%d %d %d",&read_id,&from,&to);
clusters[0].seed_a = from;
clusters[0].seed_b = to;
clusters[0].n_pair = 1;
n_cluster = 1;

while(fgets(buff,132,infile))                                       // $B%Z%"%U%!%$%k$N3F9T$K$D$$$F(B   $B%9%-%c%s#1(B
 {
 sscanf(buff,"%d %d %d",&read_id,&from,&to);                        // 
// printf("%10d %10d %10d\n",read_id,from,to);
 flag = 0;
 for(i=0;i<n_cluster;i++)                                           // $B4{@.%/%i%9%??t%k!<%W(B
  {
  if(((abs(abs(from - clusters[i].seed_a)+abs(to - clusters[i].seed_b))) < thresh) ||   // $B5/E@=*E@$,6a$1$l$P(B
     ((abs(abs(from - clusters[i].seed_b)+abs(to - clusters[i].seed_a))) < thresh))
   {
   flag = 1;
   clusters[i].n_pair ++;                                           // $B4{@.%/%i%9%?$K%a%s%P?t$rDI2C$7$F<!$N%Z%"%U%!%$%k9T$X(B
   break;
   }
  }
 if(flag == 0)                                                      // $B4{@.%/%i%9%?$K%^%C%A$7$J$1$l$P?7$7$/%/%i%9%?$r:n$k(B
  {
  clusters[n_cluster].seed_a = from;
  clusters[n_cluster].seed_b = to;
  clusters[n_cluster].n_pair = 1;
  n_cluster ++;
  }
 }                                                                  // $B%9%-%c%s#1=*(B

for(i=0;i<n_cluster;i++)                                            // $B%/%i%9%??t%k!<%W(B
 {
 clusters[i].as = (int *)malloc(sizeof(int) * (clusters[i].n_pair + 2));  // $B3F%a%s%P$N(Ba$B$NCM$N5-21NN0h3NJ](B
 clusters[i].bs = (int *)malloc(sizeof(int) * (clusters[i].n_pair + 2));  // $B3F%a%s%P$N(Bb$B$NCM$N5-21NN0h3NJ](B
 }
rewind(infile);                                                     // $B4,$-La$7(B

fgets(buff,132,infile);                                             // $B0l$DL\$N%Z%"$O:G=i$N%/%i%9%?$N%3%"$K(B
sscanf(buff,"%d %d %d",&read_id,&from,&to);
clusters[0].seed_a = from;
clusters[0].seed_b = to;
clusters[0].n_pair = 1;
clusters[0].as[0] = from;
clusters[0].bs[0] = to;
n_cluster = 1;

while(fgets(buff,132,infile))                                       // $B%Z%"%U%!%$%k$N3F9T$K$D$$$F!!%9%-%c%s#2(B
 {
 sscanf(buff,"%d %d %d",&read_id,&from,&to);                        // 
// printf("%10d %10d %10d\n",read_id,from,to);
 flag = 0;
 for(i=0;i<n_cluster;i++)                                           // $B4{@.%/%i%9%??t%k!<%W(B
  {
  if(((abs(abs(from - clusters[i].seed_a)+abs(to - clusters[i].seed_b))) < thresh) ||   // $B5/E@=*E@$,6a$1$l$P(B
     ((abs(abs(from - clusters[i].seed_b)+abs(to - clusters[i].seed_a))) < thresh))
   {
   flag = 1;
   if((abs(abs(from - clusters[i].seed_a)+abs(to - clusters[i].seed_b))) < thresh)    // a-from, b-to $B$NBP1~(B
    {
    clusters[i].as[clusters[i].n_pair] = from;
    clusters[i].bs[clusters[i].n_pair] = to;
    }
   else                                                                               // a-to, b-from $B$NBP1~(B
    {
    clusters[i].as[clusters[i].n_pair] = to;
    clusters[i].bs[clusters[i].n_pair] = from;
    }
   clusters[i].n_pair ++;                                           // $B4{@.%/%i%9%?$K%a%s%P?t$rDI2C$7$F<!$N%Z%"%U%!%$%k9T$X(B
   break;
   }
  }
 if(flag == 0)                                                      // $B4{@.%/%i%9%?$K%^%C%A$7$J$1$l$P?7$7$/%/%i%9%?$r:n$k(B
  {
  clusters[n_cluster].seed_a = from;
  clusters[n_cluster].seed_b = to;
  clusters[i].as[0] = from;
  clusters[i].bs[0] = to;
  clusters[n_cluster].n_pair = 1;
  n_cluster ++;
  }
 }                                                                  // $B%9%-%c%s#2=*(B

for(i=0;i<n_cluster;i++)                                            // $B%/%i%9%?$4$H$N(Ba, b$B$NJ?6Q!&J,;6$N7W;;(B
 {
 suma = 0.0;
 sumb = 0.0;
 for(j=0;j<clusters[i].n_pair;j++)
  {
  suma += (double)clusters[i].as[j];
  sumb += (double)clusters[i].bs[j];
  }
 clusters[i].avea = suma / (double)clusters[i].n_pair;
 clusters[i].aveb = sumb / (double)clusters[i].n_pair;
 suma = 0.0;
 sumb = 0.0;
 for(j=0;j<clusters[i].n_pair;j++)
  {
  suma += ((clusters[i].avea - (double)clusters[i].as[j]) * (clusters[i].avea - (double)clusters[i].as[j]));
  sumb += ((clusters[i].aveb - (double)clusters[i].bs[j]) * (clusters[i].aveb - (double)clusters[i].bs[j]));
  }
 clusters[i].dista = sqrt(suma / (double)clusters[i].n_pair);
 clusters[i].distb = sqrt(sumb / (double)clusters[i].n_pair);
 }

for(i=0;i<n_cluster;i++)                                            // $B%/%i%9%??t%k!<%W(B
 {
 if(clusters[i].n_pair > 4)
  {
  fprintf(outfile,"p %10d %10d %10d %10d %15.4f  %15.4f\n",(int)clusters[i].avea,(int)clusters[i].aveb,clusters[i].n_pair,i+1,clusters[i].dista, clusters[i].distb);
//  fprintf(outfile,"p %10d %10d %10d %10d %15.4f  %15.4f  %15.4f  %15.4f \n",clusters[i].seed_a,clusters[i].seed_b,clusters[i].n_pair,i+1,clusters[i].avea, clusters[i].dista, clusters[i].aveb, clusters[i].distb);
//  fprintf(outfile,"p %10d %10d %10d %10d %15.4f  %15.4f  %15.4f  %15.4f \n",clusters[i].seed_a,clusters[i].seed_b,clusters[i].n_pair,i+1,clusters[i].avea, clusters[i].dista, clusters[i].aveb, clusters[i].distb);
//  for(j=0;j<clusters[i].n_pair;j++)
//   fprintf(outfile,"%d-%d  ",clusters[i].as[j],clusters[i].bs[j]);
//  fprintf(outfile,"\n");
  }
 }

printf("N_CLUSTER = %10d\n",n_cluster);
}
/////////////////////////////////////////////////////////////////////////MAIN END

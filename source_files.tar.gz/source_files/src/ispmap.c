#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "ispmap.h"

#define BUFLEN 512
#define BUFF_LEN  20000
#define MAX_POSS 100000

//void readargs(int argc, char **argv);
//void read_genbank(void);
typedef struct hit_position_info
 {
 int hit_position;
 struct hit_position_info *pointer;
 } hit_position_info;

hit_position_info *hpi_alloc(void)
{
return((hit_position_info *)malloc(sizeof(hit_position_info)));
};

////////////////////////////////////////////////////////////////////// GLOBAL VARIABLES

int read_pos_match[BUFLEN];
int read_pos_mismatch[BUFLEN];
float plot_value;

long long int totalpop=0;
long long int totalmatch=0;
long long int totalmismatch=0;
long long int totalfwpop=0;
long long int totalfwmatch=0;
long long int totalfwmismatch=0;
long long int totalbwpop=0;
long long int totalbwmatch=0;
long long int totalbwmismatch=0;
long long int totalfwqual=0;
long long int totalbwqual=0;
long long int mmm_bin[110];
double scale_factor;
int atoc = 0;
int atog = 0;
int atot = 0;
int ctog = 0;
int ctoa = 0;
int ctot = 0;
int ttoa = 0;
int ttog = 0;
int ttoc = 0;
int gtoa = 0;
int gtot = 0;
int gtoc = 0;
int mmmpop = 0;
int mmmratio = 0;
int mmmfwratio = 0;
int mmmbwratio = 0;
int qv = 0;
int offset = 64;
int region_width = 40;
double average_depth     =  0.0;
int quality_edge_threshold = 40.0;
float max_quality = 50.0;
long long int n_match = 0;
long long int n_mmatch= 0;
long long int n_match_quality = 0;
long long int n_mmatch_quality= 0;
int fw_edge_n_mmatch = 0;
int bw_edge_n_mmatch = 0;
int fw_edge_q_mmatch = 0;
int bw_edge_q_mmatch = 0;
int n_ggc = 0;
int n_gcc = 0;
int ps_from = -1;
int ps_to   = -1;
int n_thread        =  1;
char head4[MAX_INDEX_LEN+20];
int  index_length   =  8;
int  map_out        =  0;
int  rmap_out       =  1;
int  tag_count      =  1;
int  hmap_out       =  0;
int  refseq_len     =  0;
int  no_gene_caption=  0;
int  read_file_type =  0;
int  bit_exact      =  0;
int  left_caption   =  0;
int  use_multihit   =  0;
int  ps_out         =  1;
int  jobname        =  0;
int  show_quality   =  0;
int  show_exon      =  0;
int  ggc_marker     =  0;
int  comp_cyan      =  0;
int  no_histo_bar   =  0;
int  chop_limit     = 1400;
int  read_gb        =  0;
int  read_ge        =  0;
int  n_gene         =  0;
int  n_CDS          =  0;
int  n_tRNA         =  0;
int  n_mRNA         =  0;
int  n_tmRNA        =  0;
int  n_rRNA         =  0;
int  n_miscRNA      =  0;
int  n_misc_feature =  0;
int  n_pseudo       =  0;
int  show_pop       =  0;
int  gene_pop       =  0;
int  win_size       =  1;
int  base_per_pixel =  1;
int  fastaq_sq      =  0;
int  edge_check     =  0;
int  edge_check2    =  0;
int  query_len      =  0;
int  pop_every_bp   = -1;
int  ec_ratio       = 15;
int  quality_edge   =  0;
int  show_av_qual   =  0;
int  show_mm_ratio  =  0;
int  input_is_sam   =  0;
int  fw_prev_flag = 0;
int  bw_prev_flag = 0;
//////////////////int  max_height     =  300;
int  max_height     =  1400;
int  no_bin_hit = 0;
int  n_chromosomes = 0;
int  page_height = 1191;
int  page_width  = 842;
int  mismatchcolor     =  0;
int  mismatchcolor2    =  0;

int fw_before[20];
int bw_before[20];

double ps_height =           841.0;
double ps_width  =          1190.0;
double ps_head_cap_y  =       30.0;
double ps_head_cap_x  =      500.0;
double ps_font_size =          6.0;
double ps_left_margin =       30.0;
double ps_right_margin =      20.0;
double ps_top_margin   =      60.0;
double ps_a_a_gap  =          50.0;
double ps_q_q_gap  =           0.02;
double pixel_size =         0.4800;
double hist_ratio =         1.0000;
double ps_x,ps_y;

chromosome_info chromosomes[MAX_CHROMOSOME];

double mismatch_scale  =     0.1;

int log_scale  =     0;
double first_scale = 100.0;
double second_scale =  1.0;
double third_scale = 100.0;
double first_depth =  20.0;
double second_depth =  50.0;
double third_depth =  50.0;

char  job_name[128];
char  genbank_flnm[BUFLEN];

char  *refseq;
int   *reffwqual;
int   *reffwpop;
int   *refbwqual;
int   *refbwpop;
int   *reffwmatch;
int   *reffwmismatch;
int   *refbwmatch;
int   *refbwmismatch;
query_info *qs;
genbank_info *gbs;
int   *n_gene_variants;
int   *n_STSs;
int   *n_mRNAs;
int   *n_CDSs;
int   *n_miscRNAs;

int histogram_length=0;
int *count_per_pixel;
int *count_per_pixel_mm;
int *count_per_pixel_f;
int *count_per_pixel_c;

double w_origin_x      =    10.0;
double w_origin_y      =    10.0;
double w_width         =  2560.0;
double w_height        =  1520.0;
double g_width         =  2450.0;
double g_height        =  1500.0;
double g_top_margin    =    30.0;
double g_bottom_margin =    10.0;
double g_left_margin   =    30.0;
double g_right_margin  =    80.0;
double c_width         =   150.0;
double c_a_gap         =     5.0;
double a_right_margin  =     5.0;
double c_height        =    10.0;
double font_size       =    11.0;
double gene_font_size  =     9.0;
double head_cap_y      =    20.0;
double head_cap_x      =   700.0;
double head_cap_size   =    12.0;
double tic_height100   =     5.0;
double tic_height200   =     7.0;
double tic_height500   =    10.0;
double char_hw_ratio   =     0.6364;
double height_scale    =     1.0;
double max_histo_height=       0;

double a_a_gap         =    45.0;
double a_height[MAX_FOLD];

double min_a_height    =    10.0;
double a_left_margin   =   255.0;
double a_width         =  1720.0;

int    n_depth[MAX_FOLD];
double bit_height      =     1.0;
double bit_width       =     1.0;
double r_q_gap         =     3.0;
double q_q_gap         =     0.0;
double t_height        =  1000.0;
int    dmap_out_width  =    1000;                 // number of bit per fold //フォールドあたりのビット数
int    dmap_fold       =     100;                 // number of fold         //フォールド回数

double max_page_height    = 1500.0;
double thresh_page_height = 1450.0;

char comp_seq[512];
char orig_seq[512];
char arg1[256];
char arg2[256];
int  num_hit = 0;
int  num_lqh = 0;
//int  hit_position[MAX_QUERY];
//int  lqh_position[MAX_QUERY];
//int  num_hits[MAX_QUERY];                           // multiple hit data // ヒット位置ヒット箇所が複数ある場合のリスト形式での保存
//struct hit_position_info *hit_positions[MAX_QUERY]; // multiple hit data // ヒット位置ヒット箇所が複数ある場合のリスト形式での保存
int  *hit_position;
int  *lqh_position;
int  *num_hits;                           // multiple hit data // ヒット位置ヒット箇所が複数ある場合のリスト形式での保存
struct hit_position_info **hit_positions; // multiple hit data // ヒット位置ヒット箇所が複数ある場合のリスト形式での保存
int  n_order = 0;
int  box[MAX_BOX];
int  box_hit[MAX_BOX];
int  box_cnt[MAX_BOX];
position_hit_info *position_hits;
int max_depth_of_the_fold=0;

int  initial_fold_of_page[MAX_PAGE];
int  n_page = 0;
int  page   = 0;
int  match_thresh = 1;
int min_hit;
int max_box_num = 0;

char refseq_flnm[256];

////////////////////////////////////////////////////////////////////// GLOBAL VARIABLES END
char qs_ceq(int qnum,int pos)          // return reverse complement of query:qnum position:pos
{
if((query_len-pos-2) < 0)
 return 'N';
switch(qs[qnum].seq[query_len-pos-2])
 {
 case 'A':
   return 'T';
 case 'T':
   return 'A';
 case 'G':
   return 'C';
 case 'C':
   return 'G';
 case 'N':
   return 'N';
 case '.':
   return 'N';
 case '\0':
   return '\0';
 default :
   return 'N';
 }
}

int insert_num(char *cigar_string)
 {
 int i;
 int val=0;
 char numchar[10];
 int digit = 0;
 char com;
 char current_char;
 for(i=0;i<strlen(cigar_string);i++)
  {
  if((cigar_string[i] <= 'z') && (cigar_string[i] >= 'A'))
   {
   if(cigar_string[i] == 'I') 
    {
    val = val + atoi(numchar);
    }
   digit = 0;
   }
  if((cigar_string[i] <= '9') && (cigar_string[i] >= '0'))
   {
   numchar[digit] = cigar_string[i];
   digit++;
   numchar[digit] = '\0';
   }
  }
 return val;
 }

int func_position_quality(int pos)
{
int i,j,k;
int num=0;
for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] > 0)
   {
   num += qs[position_hits[i].hits[j]].quality[pos-i] - offset;
   }
  }
 }
return num;
}

int func_position_cuality(int pos)
{
int i,j,k;
int num=0;
for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] < 0)
   {
   num += qs[abs(position_hits[i].hits[j])].cuality[pos-i+1] - offset;
   }
  }
 }
return num;
}


int func_position_hits_n_match(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] >= 0)
   {
   if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos])
    num ++;
   }
  else
   {
   if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos])
    num ++;
   }
  }
 }
return num;
}

int func_position_hits_n_mismatch(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] >= 0)
   {
   if(qs[position_hits[i].hits[j]].seq[pos-i] != refseq[pos])
    num ++;
   }
  else
   {
   if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) != refseq[pos])
    num ++;
   }
  }
 }
return num;
}

int func_position_hits_f_match(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] >= 0)
   {
   if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos])
    {
    num ++;
    }  
   }
  }
 }
return num;
}

int func_position_hits_r_match(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] < 0)
   {
   if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos])
    {
    num ++;
    }
   }
  }
 }
return num;
}

int func_position_hits_f_mismatch(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] >= 0)
   {
   if(qs[position_hits[i].hits[j]].seq[pos-i] != refseq[pos])
    {
    num ++;
    }
   }
  }
 }
return num;
}

int func_position_hits_f_mismatch2(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] >= 0)
   {
   if(qs[position_hits[i].hits[j]].seq[pos-i] != refseq[pos])
    {
    num ++;
    fw_before[0] ++;
    if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-1])
     fw_before[1] ++;
    else
     if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-2])
      fw_before[2] ++;
     else
      if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-3])
       fw_before[3] ++;
      else
       if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-4])
        fw_before[4] ++;
       else
        if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-5])
         fw_before[5] ++;
        else
         if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-6])
          fw_before[6] ++;
         else
          if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-7])
           fw_before[7] ++;
          else
           if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-8])
            fw_before[8] ++;
           else
            if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-9])
             fw_before[9] ++;
            else
             if(qs[position_hits[i].hits[j]].seq[pos-i] == refseq[pos-10])
              fw_before[10] ++;
             else
              fw_before[11] ++;
    }
   }
  }
 }
return num;
}

int func_position_hits_r_mismatch(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] < 0)
   {
   if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) != refseq[pos])
    {
    num ++;
    }
   }
  }
 }
return num;
}


int func_position_hits_r_mismatch2(int pos)
{
int i,j,k;
int num=0;

for(i=pos-query_len+1;i<=pos;i++)
 {
 if(i<0)
  continue;
 for(j=0;j<position_hits[i].n_hit;j++)
  {
  if(position_hits[i].hits[j] < 0)
   {
   if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) != refseq[pos])
    {
    num ++;
    bw_before[0] ++;
    if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+1])
     bw_before[1] ++;
    else
     if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+2])
      bw_before[2] ++;
     else
      if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+3])
       bw_before[3] ++;
      else
       if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+4])
        bw_before[4] ++;
       else
        if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+5])
         bw_before[5] ++;
        else
         if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+6])
          bw_before[6] ++;
         else
          if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+7])
           bw_before[7] ++;
          else
           if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+8])
            bw_before[8] ++;
           else
            if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+9])
             bw_before[9] ++;
            else
             if(qs_ceq(abs(position_hits[i].hits[j]),pos-i) == refseq[pos+10])
              bw_before[10] ++;
             else
              bw_before[11] ++;
    }
   }
  }
 }
return num;
}

/* read integer value from a region of string */
int read_int (char *str,int start,int width)
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}

/* read double value from a region of string */
double read_double (char *str,int start,int width)
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return (double)atof (buf);
}

char* reverse_seq(char* source_seq)
{
int i,j,k,l,m;
int seq_len;
seq_len = strlen(source_seq);
for(i=0;i<seq_len;i++)
 {
 comp_seq[seq_len-i-1] = source_seq[i];
 }
comp_seq[seq_len] = '\0';
return comp_seq;
}

char* complement_seq(char* source_seq)
{
int i,j,k,l,m;
int seq_len;
seq_len = strlen(source_seq);
//printf("%d_%s\n",seq_len,source_seq);
for(i=0;i<seq_len;i++)
 {
 if(source_seq[i] == 'A')
  comp_seq[seq_len-i-1] = 'T';
 if(source_seq[i] == 'T')
  comp_seq[seq_len-i-1] = 'A';
 if(source_seq[i] == 'G')
  comp_seq[seq_len-i-1] = 'C';
 if(source_seq[i] == 'C')
  comp_seq[seq_len-i-1] = 'G';
 if(source_seq[i] == 'N')
  comp_seq[seq_len-i-1] = 'N';
 if(source_seq[i] == '.')
  comp_seq[seq_len-i-1] = 'N';
 }
comp_seq[seq_len] = '\0';
return comp_seq;
}

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int    i,j,k,l,m,n;
int    val1,val2;
int    tempcount;
int    p_id;
int    flag;
int    from,to;
char   buff[BUFF_LEN+1];
char   temp[BUFF_LEN+1];
char   tempseq[BUFF_LEN+1];
char   tempseq2[BUFF_LEN+1];
int  n_query;
char refseq_header[512];
char tempc;
int  exceed_depth=0;
int  csp;
int  cap_space;
int  current_chr;
int  pos_in_chr;
int  forward_hit;
int  reverse_hit;
int  f_ma,f_mm;
int  r_ma,r_mm;
int p_from,p_to;
int npos;

int fw_region_pop;
int bw_region_pop;
float fw_region_depth;
float bw_region_depth;

float fw_av_q;
float bw_av_q;
float prev_fw_av_q;
float prev_bw_av_q;
float pre2_fw_av_q;
float pre2_bw_av_q;
float pre3_fw_av_q;
float pre3_bw_av_q;
float pre4_fw_av_q;
float pre4_bw_av_q;
float pre5_fw_av_q;
float pre5_bw_av_q;
float pre6_fw_av_q;
float pre6_bw_av_q;
float pre7_fw_av_q;
float pre7_bw_av_q;
float pre8_fw_av_q;
float pre8_bw_av_q;
float pre9_fw_av_q;
float pre9_bw_av_q;

double pox,poy;
double pbx,pby;

//thread_arg_t targ[MAX_THREAD_NUM];
//pthread_t handle[MAX_THREAD_NUM];

struct hit_position_info *p;

int mAA=0;
int mAG=0;
int mAC=0;
int mAT=0;
int mAN=0;
int mTT=0;
int mTG=0;
int mTC=0;
int mTA=0;
int mTN=0;
int mGG=0;
int mGA=0;
int mGT=0;
int mGC=0;
int mGN=0;
int mCC=0;
int mCA=0;
int mCT=0;
int mCG=0;
int mCN=0;

int n_sam_line = 0;
sam_line_info *samlines;
int n_sam_header;
word_info sam_header[100];
int n_sam_tab;
int tab_pos[100];
int max_CIGAR_len = 0;
int max_SEQ_len   = 0;
int max_QUAL_len  = 0;
int max_ALIGN_len = 0;

int num16 = 16;

for(i=0;i<20;i++)
 {
 fw_before[i] = 0;
 bw_before[i] = 0;
 }

//***************************************
//* CHECK PROCESS ID                    *
//***************************************
p_id = getpid();
strcpy(job_name,"");
//***************************************
//* CHECK ARGUMENTS                     *
//***************************************
readargs(argc,argv);
max_height = chop_limit;

printf("GENE_POP      = %d\n",gene_pop);
printf("TAGCOUNT      = %d\n",tag_count);
//printf("MISMATCHCOLOR = %d\n",mismatchcolor);
if(left_caption == 0)
 {
 c_width = 0.0;
 c_a_gap = 0.0;
 }

min_a_height    = c_height;
a_left_margin   = c_width + c_a_gap;
a_width         = g_width - g_left_margin - g_right_margin - a_left_margin - a_right_margin;

char queryseq[512];
FILE *refseq_file;
char query_flnm[256];
FILE *query_file;
char sq_query_flnm[256];
FILE *sq_query_file;
char hit_flnm[256];
FILE *hit_file;
char ps_flnm[256];
FILE *psfile;
char binhit_flnm[256];
FILE *binhit_file;
char hits_flnm[256];
FILE *hits_file;
char lqh_flnm[256];
FILE *lqh_file;
int  no_lqh = 0;
char mapout_flnm[256];
FILE *mapout_file;
char genepop_flnm[256];
FILE *genepop_file;
char tagcount_flnm[256];
FILE *tagcount_file;
char summary_flnm[256];
FILE *summary_file;
char edge_flnm[256];
FILE *edge_file;
char qedge_flnm[256];
FILE *qedge_file;
char pop_every_bp_flnm[256];
FILE *pop_every_bp_file;
char peb_tile_flnm[256];
FILE *peb_tile_file;
char in_sam_flnm[256];
FILE *in_sam_file;

sprintf(refseq_flnm,"%s",arg1);

sprintf(query_flnm,"%s",arg2);
sprintf(in_sam_flnm,"%s",arg2);
sprintf(sq_query_flnm,"%s_sq",arg2);
sprintf(hit_flnm,"%s_%s.hit",arg2,job_name);
sprintf(binhit_flnm,"%s_%s.bhit",arg2,job_name);
sprintf(hits_flnm,"%s_%s.hits",arg2,job_name);
if(hmap_out == 1)
 sprintf(ps_flnm,"%s_%s_hg.ps",arg2,job_name);
else
 sprintf(ps_flnm,"%s_%s_bw.ps",arg2,job_name);
sprintf(lqh_flnm,"%s_%s.lqh",arg2,job_name);
sprintf(mapout_flnm,"%s_%s.map",arg2,job_name);
sprintf(genepop_flnm,"%s_%s.gpop",arg2,job_name);
sprintf(tagcount_flnm,"%s_%s.tag",arg2,job_name);
sprintf(summary_flnm,"%s_%s.sum",arg2,job_name);
sprintf(edge_flnm,"%s_%s.edg",arg2,job_name);
sprintf(qedge_flnm,"%s_%s.qed",arg2,job_name);
sprintf(pop_every_bp_flnm,"%s_%s.peb",arg2,job_name);
sprintf(peb_tile_flnm,"%s_%s.ptf",arg2,job_name);

if(!(refseq_file = fopen(refseq_flnm,"r")))
 {
 printf("Failed to open input refseq file: %s\n",refseq_flnm);
 exit(1);
 }
if(input_is_sam == 1)                               // INPUT FILE IS SAM FORMAT
 {
 if(!(in_sam_file = fopen(in_sam_flnm,"r")))
  {
  printf("Failed to open input sam file: %s\n",in_sam_flnm);
  exit(1);
  }
 }
else                                                // INPUT FILE IS REGULAR FASTQ FORMAT
 {
 if((sq_query_file = fopen(sq_query_flnm,"r")))
  {
  fastaq_sq = 1;
  }
 else
  {
  if(!(query_file = fopen(query_flnm,"r")))
   {
   printf("Failed to open input query file: %s\n",query_flnm);
   exit(1);
   }
  }
 if(!(hit_file = fopen(hit_flnm,"r")))
  {
  printf("Failed to open hit file: %s\n",hit_flnm);
  exit(1);
  }
 }

if(ps_out == 1)
 {
 if(!(psfile = fopen(ps_flnm,"w")))
  {
  printf("Failed to open hit file: %s\n",ps_flnm);
  exit(1);
  }
 }

if(!(binhit_file = fopen(binhit_flnm,"r")))
 {
 printf("Failed to open binhit file: %s\n",binhit_flnm);
 no_bin_hit = 1;
// exit(1);
 }

if(use_multihit == 1)
 {
 if(!(hits_file = fopen(hits_flnm,"r")))
  {
  printf("Failed to open hits file: %s\n",hits_flnm);
  exit(1);
  }
 }

if(input_is_sam == 0)
 {
 if(!(lqh_file = fopen(lqh_flnm,"r")))
  {
  printf("Failed to open low quality hits file: %s\n",lqh_flnm);
  no_lqh = 1;
//  exit(1);
  }
 }

if(map_out == 1)
 {
 if(!(mapout_file = fopen(mapout_flnm,"w")))
  {
  printf("Failed to open map output file: %s\n",mapout_flnm);
  exit(1);
  }
 }

if((gene_pop == 1) || (gene_pop == 2))
 {
 if(!(genepop_file = fopen(genepop_flnm,"w")))
  {
  printf("Failed to open gene population output file: %s\n",genepop_flnm);
  exit(1);
  }
 }

if((tag_count == 1) || (tag_count == 2))
 {
 if(!(tagcount_file = fopen(tagcount_flnm,"w")))
  {
  printf("Failed to open tagcount file: %s\n",tagcount_flnm);
  exit(1);
  }
 }

if(!(summary_file = fopen(summary_flnm,"w")))
 {
 printf("Failed to open summary output file: %s\n",summary_flnm);
 exit(1);
 }

if(edge_check == 1)
 {
 if(!(edge_file = fopen(edge_flnm,"w")))
  {
  printf("Failed to open edge output file: %s\n",edge_flnm);
  exit(1);
  }
 }

if(quality_edge == 1)
 {
 if(!(qedge_file = fopen(qedge_flnm,"w")))
  {
  printf("Failed to open quality edge output file: %s\n",qedge_flnm);
  exit(1);
  }
 }

if(pop_every_bp != -1)
 {
 if(!(pop_every_bp_file = fopen(pop_every_bp_flnm,"w")))
  {
  printf("Failed to open pop_every_bp output file: %s\n",pop_every_bp_flnm);
  exit(1);
  }
 if(!(peb_tile_file = fopen(peb_tile_flnm,"w")))
  {
  printf("Failed to open peb_tile output file: %s\n",peb_tile_flnm);
  exit(1);
  }
 }

if(read_ge==1)
 {
 n_gene_variants = (int *)malloc(sizeof(int)*(MAX_GENE));
 n_STSs = (int *)malloc(sizeof(int)*(MAX_GENE));
 n_mRNAs = (int *)malloc(sizeof(int)*(MAX_GENE));
 n_CDSs = (int *)malloc(sizeof(int)*(MAX_GENE));
 n_miscRNAs = (int *)malloc(sizeof(int)*(MAX_GENE));
 }

///////////////////////////////////////////////////////// COUNT REFERENCE LENGTH //Refference 配列の文字数カウント
refseq_len = 0;
fgets(buff,500,refseq_file);
strcpy(refseq_header,buff);
refseq_header[strlen(refseq_header)-1] = '\0';

while((tempc=fgetc(refseq_file)))
 {
 if(tempc != '\n')
  {
  refseq_len ++;
  }
 if(tempc == EOF)
  {
  break;
  }
 }
///////////////////////////////////////////////////////// END COUNT REFERENCE LENGTH //Refference 配列の文字数カウント 終
refseq = (char *)malloc(sizeof(char)*(refseq_len + 100));
if((quality_edge == 1) || (mmmpop == 1))
 {
 reffwqual = (int *)malloc(sizeof(int)*(refseq_len + 200));
 reffwpop  = (int *)malloc(sizeof(int)*(refseq_len + 200));
 refbwqual = (int *)malloc(sizeof(int)*(refseq_len + 200));
 refbwpop  = (int *)malloc(sizeof(int)*(refseq_len + 200));
 reffwmatch  = (int *)malloc(sizeof(int)*(refseq_len + 200));
 reffwmismatch  = (int *)malloc(sizeof(int)*(refseq_len + 200));
 refbwmatch  = (int *)malloc(sizeof(int)*(refseq_len + 200));
 refbwmismatch  = (int *)malloc(sizeof(int)*(refseq_len + 200));
 }
printf("Allocated memory for refseq %10zd bytes\n",sizeof(char)*(refseq_len+100));
for(i=0;i<refseq_len+50;i++)
 refseq[i]  = 'A';
if((quality_edge == 1) || (mmmpop == 1))
 for(i=0;i<refseq_len+50;i++)
  {
  reffwqual[i] = 0;
  refbwqual[i] = 0;
  reffwpop[i]  = 0;
  refbwpop[i]  = 0;
  reffwmatch[i]  = 0;
  reffwmismatch[i]  = 0;
  refbwmatch[i]  = 0;
  refbwmismatch[i]  = 0;
  }

if(hmap_out == 1)
 {
 histogram_length = refseq_len / base_per_pixel + 1;
 if(refseq_len % base_per_pixel == 0)
  histogram_length --;
 count_per_pixel = (int *)malloc(sizeof(int)*(histogram_length + 100));
 count_per_pixel_f = (int *)malloc(sizeof(int)*(histogram_length + 100));
 count_per_pixel_c = (int *)malloc(sizeof(int)*(histogram_length + 100));
 count_per_pixel_mm = (int *)malloc(sizeof(int)*(histogram_length + 100));
 printf("HISTOGRAM OUTPUT. HISTOGRAM LENGTH = %10d\n",histogram_length);
 }

rewind(refseq_file);
refseq_len = 0;
n_chromosomes = 0;
////////////////////////////////////////MULTIFASTA MODIFICATION
while((tempc=fgetc(refseq_file)))
 {
 if(tempc == '>')
  {
  fgets(buff,500,refseq_file);
  strcpy(chromosomes[n_chromosomes].title,buff);
  chromosomes[n_chromosomes].title[strlen(chromosomes[n_chromosomes].title)-1] = '\0';
  chromosomes[n_chromosomes].start_position = refseq_len;
  n_chromosomes ++;
  continue;
  }
 if(tempc != '\n')
  {
  refseq[refseq_len] = tempc;
  refseq_len ++;
  }
 if((tempc == EOF) || (tempc =='\0'))
  {
  refseq[refseq_len-1] = '\0';
  break;
  }
 }
refseq_len = refseq_len -1;
////////////////////////////////////////MULTIFASTA MODIFICATION END

printf("REFERENCE SEQUENCE LENGTH:  %10d\n",refseq_len);
printf("NUMBER OF CHROMOSOMES    :  %10d\n",n_chromosomes);
for(i=0;i<n_chromosomes;i++)
 printf("START POSITION   :  %10d   %s\n",chromosomes[i].start_position,chromosomes[i].title);

if(read_gb == 1)
 read_genbank();
if(read_ge == 1)
 read_genbank_e();

if(input_is_sam == 1)                                                           // READ SAM FORMAT INPUT
 {
 read_file_type = 0;

 n_sam_line = 0;
 while(fgets(buff,BUFF_LEN,in_sam_file))
 {
 n_sam_line ++;
 }
 samlines = (sam_line_info *)malloc(sizeof(sam_line_info)*n_sam_line);
 if(samlines == NULL)
  {
  printf("Failed to allocate memory for samlines\n");
  exit(1);
  }
 rewind(in_sam_file);

 n_sam_line = 0;
 n_sam_header = 0;
 while(fgets(buff,BUFF_LEN,in_sam_file))
  {
  if(buff[0] == '@')
   {
   if(n_sam_header < 100)
    strcpy(sam_header[n_sam_header].word,buff);
   n_sam_header ++;
   continue;
   }
  else
   {
   n_sam_tab = 0;
   for(i=0;i<strlen(buff);i++)
    {
    if(buff[i] == '\t')
     {
     tab_pos[n_sam_tab++] = i;
     }
    }
  // strncpy(samlines[n_sam_line].FNAME,buff,tab_pos[0]);
   strncpy(temp,&buff[tab_pos[0]+1],tab_pos[1]-tab_pos[0]-1);
   temp[tab_pos[1]-tab_pos[0]-1] = '\0';
   samlines[n_sam_line].FLAG = atoi(temp);
  // strncpy(samlines[n_sam_line].RNAME,&buff[tab_pos[1]+1],tab_pos[2]-tab_pos[1]-1);
   temp[tab_pos[2]-tab_pos[1]-1] = '\0';
   strncpy(temp,&buff[tab_pos[2]+1],tab_pos[3]-tab_pos[2]-1);
   temp[tab_pos[3]-tab_pos[2]-1] = '\0';
   samlines[n_sam_line].POS = atoi(temp);
   strncpy(temp,&buff[tab_pos[3]+1],tab_pos[4]-tab_pos[3]-1);
   temp[tab_pos[4]-tab_pos[3]-1] = '\0';
   samlines[n_sam_line].MAPQ = atoi(temp);
 //  strncpy(samlines[n_sam_line].CIGAR,&buff[tab_pos[4]+1],tab_pos[5]-tab_pos[4]-1);
   strncpy(temp,&buff[tab_pos[4]+1],tab_pos[5]-tab_pos[4]-1);
   temp[tab_pos[5]-tab_pos[4]-1] = '\0';
   if(max_CIGAR_len < strlen(temp))
    max_CIGAR_len = strlen(temp);
  // strncpy(samlines[n_sam_line].RNEXT,&buff[tab_pos[5]+1],tab_pos[6]-tab_pos[5]-1);
   temp[tab_pos[6]-tab_pos[5]-1] = '\0';
   strncpy(temp,&buff[tab_pos[6]+1],tab_pos[7]-tab_pos[6]-1);
   temp[tab_pos[7]-tab_pos[6]-1] = '\0';
   samlines[n_sam_line].PNEXT = atoi(temp);
   strncpy(temp,&buff[tab_pos[7]+1],tab_pos[8]-tab_pos[7]-1);
   temp[tab_pos[8]-tab_pos[7]-1] = '\0';
   samlines[n_sam_line].TLEN = atoi(temp);

 // // strncpy(samlines[n_sam_line].SEQ,&buff[tab_pos[8]+1],tab_pos[9]-tab_pos[8]-1);
   strncpy(temp,&buff[tab_pos[8]+1],tab_pos[9]-tab_pos[8]-1);
   temp[tab_pos[9]-tab_pos[8]-1] = '\0';
   if(max_SEQ_len < strlen(temp))
    max_SEQ_len = strlen(temp);

 // // strncpy(samlines[n_sam_line].QUAL,&buff[tab_pos[9]+1],tab_pos[10]-tab_pos[9]-1);
   strncpy(temp,&buff[tab_pos[9]+1],tab_pos[10]-tab_pos[9]-1);
   temp[tab_pos[10]-tab_pos[9]-1] = '\0';
   if(max_QUAL_len < strlen(temp))
    max_QUAL_len = strlen(temp);
   strcpy(temp,&buff[tab_pos[10]+1]);
   temp[strlen(temp)-1] = '\0';
   if(max_ALIGN_len < strlen(temp))
    max_ALIGN_len = strlen(temp);
 //  samlines[n_sam_line].ALIGN[strlen(samlines[n_sam_line].ALIGN)-1] = '\0';
  // printf("%s# %d# %s# %d# %d# %s# %s# %d# %d# %s# %s# %s#\n",
  //         samlines[n_sam_line].FNAME,samlines[n_sam_line].FLAG,samlines[n_sam_line].RNAME,
  //         samlines[n_sam_line].POS,samlines[n_sam_line].MAPQ,samlines[n_sam_line].CIGAR,
  //         samlines[n_sam_line].RNEXT,samlines[n_sam_line].PNEXT,samlines[n_sam_line].TLEN,
  //         samlines[n_sam_line].SEQ,samlines[n_sam_line].QUAL,samlines[n_sam_line].ALIGN);
   n_sam_line ++;
   }
  }
 printf("N_LINE in SAM file %s is %d\n",in_sam_flnm,n_sam_line);
 for(i=0;i<n_sam_line;i++)
  {
  samlines[i].CIGAR = (char *)malloc(sizeof(char)*(max_CIGAR_len+3));
  if(samlines[i].CIGAR == NULL)
   {
   printf("Failed to malloc samlines[%d].CIGAR\n",n_sam_line);
   exit(1);
   }
  samlines[i].SEQ   = (char *)malloc(sizeof(char)*(max_SEQ_len+3));
  if(samlines[i].SEQ == NULL)
   {
   printf("Failed to malloc samlines[%d].SEA\n",n_sam_line);
   exit(1);
   }
  samlines[i].QUAL  = (char *)malloc(sizeof(char)*(max_QUAL_len+3));
  if(samlines[i].QUAL == NULL)
   {
   printf("Failed to malloc samlines[%d].QUAL\n",n_sam_line);
   exit(1);
   }
  samlines[i].ALIGN = (char *)malloc(sizeof(char)*(max_ALIGN_len+3));
  if(samlines[i].ALIGN == NULL)
   {
   printf("Failed to malloc samlines[%d].ALIGN\n",n_sam_line);
   exit(1);
   }
  }

 rewind(in_sam_file);
 n_sam_line = 0;
 while(fgets(buff,BUFF_LEN,in_sam_file))
  {
  if(buff[0] != '@')
   {
   n_sam_tab = 0;
   for(i=0;i<strlen(buff);i++)
    {
    if(buff[i] == '\t')
     {
     tab_pos[n_sam_tab++] = i;
     }
    }
   strncpy(samlines[n_sam_line].CIGAR,&buff[tab_pos[4]+1],tab_pos[5]-tab_pos[4]-1);
   samlines[n_sam_line].CIGAR[tab_pos[5]-tab_pos[4]-1] = '\0';

   strncpy(samlines[n_sam_line].SEQ,&buff[tab_pos[8]+1],tab_pos[9]-tab_pos[8]-1);
   samlines[n_sam_line].SEQ[tab_pos[9]-tab_pos[8]-1] = '\0';

   strncpy(samlines[n_sam_line].QUAL,&buff[tab_pos[9]+1],tab_pos[10]-tab_pos[9]-1);
   samlines[n_sam_line].QUAL[tab_pos[10]-tab_pos[9]-1] = '\0';

   strcpy(samlines[n_sam_line].ALIGN,&buff[tab_pos[10]+1]);
   samlines[n_sam_line].ALIGN[strlen(samlines[n_sam_line].ALIGN)-1] = '\0';

//   printf("%d# %d# %d# %s# %d# %d# %s# %s# %s#\n",
//           samlines[n_sam_line].FLAG,samlines[n_sam_line].POS,samlines[n_sam_line].MAPQ,samlines[n_sam_line].CIGAR,
//           samlines[n_sam_line].PNEXT,samlines[n_sam_line].TLEN,samlines[n_sam_line].SEQ,samlines[n_sam_line].QUAL,
//           samlines[n_sam_line].ALIGN);
   n_sam_line ++;
   }
  }

 n_query = n_sam_line;                                                              // move SAM data to Query data
 qs = (query_info *) malloc(sizeof(query_info) * n_query + 10);
 if(qs == NULL)
  {
  printf("Failed to allocate memory for read sequence\n");
  exit(1);
  }
 for(i=0;i<n_query;i++)                                                             // allocate READ space
  {
  qs[i].seq = (char *)malloc(sizeof(char)*(strlen(samlines[i].SEQ)+3));
  if((show_quality == 1) || (quality_edge == 1) || (mmmpop == 1) || (show_av_qual != 0) || (ps_out == 0))
   {
   qs[i].quality = (char *)malloc(sizeof(char)*(strlen(samlines[i].QUAL)+3));
   }
  }
 printf("ALLOCATED READ SPACE\n");

 for(i=0;i<n_query;i++)                                                             // copy SAM READ SEQ to READ space
  { 
  strcpy(qs[i].seq,samlines[i].SEQ);
  query_len = strlen(qs[i].seq);
  if((show_quality == 1) || (quality_edge == 1) || (mmmpop == 1) || (show_av_qual != 0) || (ps_out == 0))
   strcpy(qs[i].quality,samlines[i].QUAL);
  }
// MARK
 }                                                                                  // END READ SAM format
else
 {
 if(fastaq_sq == 1)
 {
 fgets(buff,500,sq_query_file);
 query_len = atoi(buff);
 fgets(buff,500,sq_query_file);
 n_query = atoi(buff);
 printf("NUMBER OF QUERY SEQUENCE IS:%10d\n",n_query);
 qs = (query_info *)malloc(sizeof(query_info)*(n_query + 10));
 printf("Allocated memory for query  %10zd bytes\n",sizeof(query_info)*(n_query+10));
 for(i=0;i<n_query+10;i++)
  {
  qs[i].seq = (char *)malloc(sizeof(char)*(query_len+2));
 // qs[i].seq = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
 // qs[i].seq = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
 // qs[i].ceq = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
  }
 if((show_quality == 1) || (quality_edge == 1 ))
  {
  printf("ERROR: CANNOT USE squeezed QUERY INFO TO SHOW QUERY\n");
  exit(0);
  }
 
 int q_count=0;
 while(fgets(buff,500,sq_query_file))
  {
  strcpy(qs[q_count].seq,buff);
 // strcpy(qs[q_count].ceq,complement_seq(buff));
  q_count ++;
  }
 }
 else
 {
 ///////////////////////////////////////////////////////// COUNT QUERY READ SEQUENCES //Query 配列カウント
 fgets(buff,500,query_file);
 if(buff[0] == '@')
  read_file_type = 0;           // fastq format
 else
  if(buff[0] == '>')
   read_file_type = 1;          // fasta format
 rewind(query_file);
 
 if(read_file_type == 0)        // fastq
  {
 //while(fgets(buff,500,query_file))
 // {
 // if(buff[0] == '@')
 //  {
 //  n_query ++;
 //  fgets(buff,500,query_file);
 ////  printf("%s",buff);
 //  }
 // }
  fgets(buff,500,query_file);
  fgets(buff,500,query_file);
  query_len = strlen(buff)-1;
  fgets(buff,500,query_file);
  fgets(buff,500,query_file);
  n_query = 1;
  while(fgets(buff,500,query_file))
   {
   fgets(buff,500,query_file);
   fgets(buff,500,query_file);
   fgets(buff,500,query_file);
   n_query ++;
   }
  } 
 else
  if(read_file_type == 1)     // fasta
   {
   fgets(buff,500,query_file);
   fgets(buff,500,query_file);
   query_len = strlen(buff)-1;
   n_query = 1;
   while(fgets(buff,500,query_file))
    {
    fgets(buff,500,query_file);
    n_query ++;
    }
   }
 ///////////////////////////////////////////////////////// END COUNT QUERY READ SEQUENCES // Query 配列カウント終
 printf("NUMBER OF QUERY SEQUENCE IS:%10d\n",n_query);
 qs = (query_info *)malloc(sizeof(query_info)*(n_query + 10));
 printf("Allocated memory for query  %10zd bytes\n",sizeof(query_info)*(n_query+10));
 
 for(i=0;i<n_query+10;i++)
  {
  qs[i].seq = (char *)malloc(sizeof(char)*(query_len+2));
 // qs[i].seq = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
 // qs[i].ceq = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
  if((show_quality == 1) || (quality_edge == 1) || (mmmpop == 1) || (show_av_qual != 0) || (ps_out == 0))
   {
   qs[i].quality = (char *)malloc(sizeof(char)*(query_len+2));
   qs[i].cuality = (char *)malloc(sizeof(char)*(query_len+2));
   if(quality_edge == 1)
    qs[i].quality_edge = (char *)malloc(sizeof(char)*(query_len+2));
 //  qs[i].quality = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
 //  qs[i].cuality = (char *)malloc(sizeof(char)*(MAX_QUERY_LEN));
   }
  }
 
 printf("ALLOCATED QUERY SPACE\n");
 rewind(query_file);
 ///////////////////////////////////////////////////////// READ QUERY SEQUENCES //Query 配列読み込み
 if(read_file_type == 0)                           // fastq
  {
  n_query = 0;
  while(fgets(buff,500,query_file))
   {
   // if(buff[0] == '@')
    {
    fgets(buff,500,query_file);
    tempcount= strlen(buff);
    buff[tempcount-1] = '\0';
    if(n_query == 0)
     {
     query_len = tempcount;
     if(query_len > MAX_QUERY_LEN)
      {
      printf("TOO LONG QUERY: MAX_QUERY_LENGTH = %d while the read query counts %d\n",MAX_QUERY_LEN,query_len);
      exit(1);
      }
     }
  //  printf("%s\n",buff);
    strcpy(qs[n_query].seq,buff);
  //  strcpy(qs[n_query].ceq,complement_seq(buff));
    n_query ++;
    }
  // if(buff[0] == '+')
    {
    fgets(buff,500,query_file);
    tempcount= strlen(buff);
    buff[tempcount-1] = '\0';
   fgets(buff,500,query_file);
   if((show_quality == 1) || (quality_edge == 1) || (mmmpop ==1) || (show_av_qual != 0) || (ps_out == 0)) // keep quality if show_quality 
     {
     strcpy(qs[n_query-1].quality,buff);
     strcpy(qs[n_query-1].cuality,reverse_seq(buff));
     }
    }
   }
  }
 else
  if(read_file_type == 1)                      // fasta
   {
   n_query = 0;
   while(fgets(buff,500,query_file))
    {
    fgets(buff,500,query_file);
    tempcount= strlen(buff);
    buff[tempcount-1] = '\0';
    if(n_query == 0)
     query_len = tempcount;
    strcpy(qs[n_query].seq,buff);
    n_query ++;
    }
   }
 
 ////////////////////////////////////////////////////////////////////////////
 }
}
printf("DONE READ QUERY \n");
//printf("QUERY SEQUENCE IS: %s\n",queryseq);
//printf("QUERY SEQUENCE LENGTH IS: %d\n",(int)strlen(queryseq));
//for(k=0;k<n_query;k++)
// {
// printf("%s\n",qs[k].seq);
// }
///////////////////////////////////////////////////////// END READ QUERY SEQUENCES // Query 配列読み込み終
 hit_position = (int *)malloc((sizeof(int)*(n_query+10)));
 lqh_position = (int *)malloc((sizeof(int)*(n_query+10)));
 num_hits     = (int *)malloc((sizeof(int)*(n_query+10)));
 hit_positions = (hit_position_info **)malloc((sizeof(hit_position_info*)*(n_query+10)));
////////////////////////////////////////////////////////// INITIALIZE MATRIX //配列初期化
for(i=0;i<n_query;i++)
 {
 hit_position[i] = MAX_INT;
 lqh_position[i] = MAX_INT;

 hit_positions[i] = hpi_alloc();
 hit_positions[i]->hit_position = MAX_INT;
 hit_positions[i]->pointer = NULL;
 num_hits[i] = 0;
 }
for(i=0;i<MAX_BOX;i++)
 {
 box[i] = 0;
 box_hit[i] = MAX_INT;
 box_cnt[i] = 0;
 }
printf("DONE INITIALIZE MATRIX \n");
////////////////////////////////////////////////////////// END INITIALIZE MATRIX //配列初期化終
///////////////////////////////////////////////////////// READ HIT LIST //Hit_list 読み込み
///////////////////////////////////////////////////MARK
if(input_is_sam == 1)
 {
 num_hit = 0;
 for(i=0;i<n_query;i++)                                                             // copy SAM READ SEQ to READ space
  {
  if(samlines[i].POS != 0)
   {
   if((samlines[i].FLAG & num16) == num16)
    {
    npos = insert_num(samlines[i].CIGAR);
    hit_position[i] = -(samlines[i].POS)+npos+1;                              // Reverse Complement
    strcpy(tempseq,samlines[i].SEQ);
    strcpy(samlines[i].SEQ,complement_seq(tempseq));
    }
   else
    {
    hit_position[i] = samlines[i].POS-1;                                       // Forward
    }
   strncpy(tempseq,&refseq[abs(hit_position[i])],76);
   tempseq[76] = '\0';
   printf("POS %10d\n",hit_position[i]);
   printf("%s\n",tempseq);
   printf("%s\n",samlines[i].SEQ);
//printf("POS %10d %s\n",hit_position[i],samlines[i].SEQ);
   num_hit ++;
   }
  }
 tempcount = num_hit;
 scale_factor = 10000000.0 / (double)num_hit;
 }
else
 {
 if(no_bin_hit == 0)
  {
  num_hit = fread(hit_position,sizeof(int),MAX_QUERY,binhit_file);
  }
 else
  {
  num_hit = 0;
  while(fgets(buff,500,hit_file))
   {
   num_hit ++;
   }
  rewind(hit_file);
  tempcount = 0;
  while(fgets(buff,500,hit_file))                     // MARKHIT
   {
   val1 = read_int(buff,1,10);
   val2 = read_int(buff,12,10);
  // printf("#%10d %10d %10d \n",tempcount,val1,val2);
  // hit_position[val1] = val2-1;         //MARKHIT
   if(val2 > 0)
    hit_position[val1] = val2-1;
   else
    hit_position[val1] = val2+1;
  
   tempcount ++;
   }
  }
 printf("DONE READ HITLIST \n");
 scale_factor = 10000000.0 / (double)num_hit;
 printf("SCALE_FACTOR %20.10f\n",scale_factor);
 }
///////////////////////////////////////////////////////// READ HIT LIST //Hit_list 読み込み


if(input_is_sam == 0)
 {
 num_lqh = 0;

 if(no_lqh == 0)    // lqh fileなければ読まない
  {
  while(fgets(buff,500,lqh_file))
   {
   num_lqh ++;
   }
  rewind(lqh_file);
  while(fgets(buff,500,lqh_file))
   {
   val1 = read_int(buff,1,10);
   val2 = read_int(buff,11,10);
  //printf("#%10d %10d %10d \n",tempcount,val1,val2);
   lqh_position[val1] = val2;
  
   tempcount ++;
  }
 
 printf("DONE READ LQH \n");
  }
 
 if(use_multihit == 1)
  {
  while(fgets(buff,500,hits_file))
   {
   val1 = read_int(buff,1,10);         // QUERY NUMBER //Query 番号
   val2 = read_int(buff,12,10);        // POSITION ON REFERENCE (NEGATIVE FOR COMPLEMENT)レファレンス上の位置（負値はコンプリメント)

//if(val2 < 0)                   ///////// ごまかし
// val2 = val2-1;                ///////// ０始まりを１始まりを

   p = hit_positions[val1];
   hit_positions[val1] = hpi_alloc();
   hit_positions[val1]->hit_position = val2;
   hit_positions[val1]->pointer = p;
   num_hits[val1] ++;
   }
  }
 
 //for(i=0;i<n_query;i++)
 // {
 // p = hit_positions[i];
 // while(p->pointer != NULL)
 //  {
 //  printf("## %10d %10d\n",i,p->hit_position);
 //  p = p->pointer;
 //  }
 // }

 ///////////////////////////////////////////////////////// END READ HIT LIST //Hit_list 読み込み終
 printf("NUM_HIT        %10d\n",num_hit);
 printf("NUM_LQH        %10d\n",num_lqh);
 }
else
 {
 num_lqh = 0;
 }

////////////////////////////////////////// FILL position_hits list
//////////////////////////////////////////////////////////////////                                  
position_hits = (position_hit_info *)malloc(sizeof(position_hit_info) * (refseq_len + 10000));
printf("Allocated memory for position_hits  %10zd bytes\n",sizeof(position_hit_info)*(refseq_len+10000));
for(i=0;i<refseq_len;i++)
 {
 position_hits[i].n_hit = 0;
// position_hits[i].n_order      = 0;
// position_hits[i].n_complement = 0;
 }

if(use_multihit == 1)                    // USE MULTIHIT INFO (FOR REPEAT SEQUENCE ) //multihit情報を使う　（リピート対策）
 {
//for(i=0;i<refseq_len;i++)
// {
// p = hit_positions[i];
// while(p->pointer != NULL)
//  {
//  printf("## %10d %10d\n",i,p->hit_position);
//  p = p->pointer;
//  }
// }
 for(i=0;i<n_query;i++)
  {
  p=hit_positions[i];
  while(p->pointer != NULL)
   {
   position_hits[abs(p->hit_position)].n_hit ++;
   p=p->pointer;
   }
  }
 for(i=0;i<refseq_len+10000;i++)
  {
 // if(position_hits[i].n_hit >= 1)
 //  {
   position_hits[i].hits = (int *)malloc(sizeof(int) * (position_hits[i].n_hit+0));
   position_hits[i].boxs = (int *)malloc(sizeof(int) * (position_hits[i].n_hit+0));
 //  }
  }
 for(i=0;i<refseq_len;i++)
  position_hits[i].n_hit = 0;
 for(i=0;i<n_query;i++)
  {
  p=hit_positions[i];
  while(p->pointer != NULL)
   {
   position_hits[abs(p->hit_position)].boxs[position_hits[abs(p->hit_position)].n_hit] = 0;
   if(p->hit_position > 0)
    position_hits[abs(p->hit_position)].hits[position_hits[abs(p->hit_position)].n_hit ++] = i;
   else
    position_hits[abs(p->hit_position)].hits[position_hits[abs(p->hit_position)].n_hit ++] = -i;
   p=p->pointer;
   }
  }
//for(i=0;i<refseq_len;i++)
// for(j=0;j<position_hits[i].n_hit;j++)
//  printf("%d %d %d\n",i,j,position_hits[i].hits[j]);
 }
else                                      // DONOt USE MULtiHIt INFO (CONVENTIONAL) //multihit 情報を使わない（従来）
 {
 for(i=0;i<n_query;i++)
  {
  if(hit_position[i] != MAX_INT)
   {
   position_hits[abs(hit_position[i])].n_hit ++;
   if(hit_position[i] >= 0)
    position_hits[abs(hit_position[i])].n_f_hit ++;
   else
    position_hits[abs(hit_position[i])].n_r_hit ++;
   }
  }
 for(i=0;i<refseq_len+10000;i++)
  {
  if(position_hits[i].n_hit >= 0)
   {
   position_hits[i].hits = (int *)malloc(sizeof(int) * (position_hits[i].n_hit + 0));
   position_hits[i].boxs = (int *)malloc(sizeof(int) * (position_hits[i].n_hit + 0));
   }
  }
 for(i=0;i<refseq_len;i++)
  position_hits[i].n_hit = 0;
 for(i=0;i<n_query;i++)
  {
  if(hit_position[i] != MAX_INT)
   {
   position_hits[abs(hit_position[i])].boxs[position_hits[abs(hit_position[i])].n_hit] = 0;
   if(hit_position[i] > 0)
    position_hits[abs(hit_position[i])].hits[position_hits[abs(hit_position[i])].n_hit ++] = i;
   else
    position_hits[abs(hit_position[i])].hits[position_hits[abs(hit_position[i])].n_hit ++] = -i;
   }
  }
 }
////////////////////////////////////////// FILL position_hits list END 
//for(i=0;i<refseq_len;i++)
// {
// if(position_hits[i].n_hit >= 1)
//  {
//  printf("REFSEQ_POSITION%10d Position_nhit%10d\n",i,position_hits[i].n_hit);
//  for(j=0;j<position_hits[i].n_hit;j++)
//   printf("%10d ",position_hits[i].hits[j]);
//  printf("\n");
//  }
// }

if(pop_every_bp != -1)
 {
 reverse_hit = 0;
 for(i=0;i<refseq_len;i++)
  {
  reverse_hit += position_hits[i].n_r_hit;
  if((i%pop_every_bp == 0) && (i != 0))
   {
   fprintf(pop_every_bp_file,"%10d\t%10d\t+\t%10d\n",i-pop_every_bp+1,i,(int)((float)reverse_hit*scale_factor));
   reverse_hit = 0;
   }
  }

 forward_hit = 0;
 for(i=0;i<refseq_len;i++)
  {
  forward_hit += position_hits[i].n_f_hit;
  if((i%pop_every_bp == 0) && (i != 0))
   { 
   fprintf(pop_every_bp_file,"%10d\t%10d\t-\t%10d\n",i-pop_every_bp+1,i,(int)((float)forward_hit*scale_factor));
   forward_hit = 0;
   }
  }

 for(i=0;i<refseq_len;i++)
  {
  if((i%pop_every_bp == 0) && (i != 0))
   {
   fprintf(peb_tile_file,"TilingArray\t%10d\t%10d\t-\n",i-pop_every_bp+1,i);
   fprintf(peb_tile_file,"TilingArray\t%10d\t%10d\t+\n",i-pop_every_bp+1,i);
   }
  }
 fclose(peb_tile_file);
 fclose(pop_every_bp_file);
 }

if(tag_count == 1)
 {
 for(i=0;i<n_gene;i++)
  {
  for(j=gbs[i].from;j<gbs[i].to;j++)
   {
   gbs[i].tag_count += position_hits[j].n_hit;
   }
  }
 }

if(tag_count == 2)
 {
 for(i=0;i<n_gene;i++)
  {
  if(i != 0)
   {
   for(j=gbs[i-1].to+1;j<gbs[i].from-1;j++)
    {
    gbs[i].pre_tag_count += position_hits[j].n_hit;
    }
   }
  else
   {
   for(j=0;j<gbs[i].from-1;j++)
    {
    gbs[i].pre_tag_count += position_hits[j].n_hit;
    }
   }
  for(j=gbs[i].from;j<gbs[i].to;j++)
   {
   gbs[i].tag_count += position_hits[j].n_hit;
   }
//  if(i < n_gene-1)
//   {
//   for(j=gbs[i].to+1;j<gbs[i+1].from-1;j++)
//    {
//    gbs[i].post_tag_count += position_hits[j].n_hit;
//    }
//   }
  }
 }

/////////////////////////////////////////////////////////////////  PREPARE BOX
if((map_out == 1) || (rmap_out == 1))
{
printf("START PREPAREING MAP LAYOUT, THIS MAY TAKE A WHILE...\n");

//for(k=0;k<n_thread;k++)
// {
// pthread_create(&handle[k],NULL,(void *)thread_func,(void *)&targ[k]);
// }
//for(k=0;k<n_thread;k++)
// {
// pthread_join(handle[k],NULL);
// }

for(i=0;i<refseq_len;i++)
 {
 if(position_hits[i].n_hit >= 0)
  {
  for(j=0;j<position_hits[i].n_hit;j++)
   {
   min_hit = 0;
   flag = 0;
   for(k=0;k<MAX_BOX;k++)
//   for(k=0;k<(max_box_num+2);k++)
    {
    if(box[k] == 0)
     {
     position_hits[i].boxs[j] = k;
     box[k] = query_len+1;
     if(k > max_box_num)
      max_box_num = k;
     //printf("%10d %10d %10d %10d\n",i,position_hits[i].n_hit,j,k);
     flag = 1;
     break;
     }
    }
   if(flag == 0)
    {
    position_hits[i].boxs[j] = -1;
//    printf("BOX FULL at %10d: increase MAX_BOX %10d\n",i,MAX_BOX);
//    exit(1);
    }
   }
  }
// for(j=0;j<MAX_BOX;j++)
 for(j=0;j<(max_box_num+2);j++)
  {
  if(box[j] >= 1)
   box[j] --;
  }
 }

printf("DONE PREPAREING MAP LAYOUT!\n");
/////////////////////////////////////////////////////////////////  PREPARE BOX
printf("MAX_DEPTH       %10d\n",max_box_num);
}

//////////////////////////////////////////////////////////// COUNT number of HIT for hmap_out
/*
//if(hmap_out == 1)
// {
// for(i=0;i<num_hit;i++)
//  {
//  if(hit_position[i] != MAX_INT)
//   {
//   if(hit_position[i] >= 0)       // SENCE HIT
//    {
//    for(j=0;j<query_len;j++)
//     {
//     if(qs[i].seq[j] == refseq[hit_position[i]+j])
//      {
//      position_hits[hit_position[i]+j].n_match ++;
//      position_hits[hit_position[i]+j].f_match ++;
//      }
//     else
//      {
//      position_hits[hit_position[i]+j].n_mismatch ++;
//      position_hits[hit_position[i]+j].f_mismatch ++;
//      }
//     }
//    }
//   else                           // REVERSE COMPLEMENT
//    {
//    for(j=0;j<query_len;j++)
//     {
//     if(qs_ceq(i,j) == refseq[abs(hit_position[i])+j])
//      {
//      position_hits[abs(hit_position[i])+j].n_match ++;
//      position_hits[abs(hit_position[i])+j].r_match ++;
//      }
//     else
//      {
//      position_hits[abs(hit_position[i])+j].n_mismatch ++;
//      position_hits[abs(hit_position[i])+j].r_mismatch ++;
//      }
//     }
//    }
//   }
//  }
// }
*/
//////////////////////////////////////////////////////////// COUNT number of HIT for hmap_out

printf("%d\n",query_len);
for(i=0;i<query_len-1;i++)
 printf("%c",qs[0].seq[i]);
printf("\n");
for(i=0;i<query_len-1;i++)
 printf("%c",qs_ceq(0,i));
printf("\n");
 
average_depth = ((double)(num_hit) / (double) refseq_len)*(double)query_len;

if(edge_check == 1) 
 {
int window_width         =   40;
int print_width          =   40;
int max_less_window_pop  =   60;
int min_more_window_pop  =  300;
int min_edge_pop         =   40;

double max_less_ratio    =  0.020;
double min_more_ratio    =  0.10;

double min_pos_ratio     =  0.10;

//double tall_ratio1 =0.09;
double tall_ratio1 =0.05;
double tall_ratio2 =0.05;
double tall_ratio3;
double tall_ratio4;
tall_ratio3 = ((double)ec_ratio)/100.0;
tall_ratio4 = ((double)ec_ratio)/100.0;

int left_pop =0;
int left_tot =0;
int left_full =0;
double left_ratio =0.0;
int right_pop=0;
int right_tot=0;
int right_full =0;
double right_ratio =0.0;
double point_ratio =0.0;
double region_depth = 0.0;
int na,nt,ng,nc;
int left_tall  = 0;
int right_tall = 0;
int n_edge = 0;

int n_fw_poss=0;
int n_bw_poss=0;
int fw_poss[MAX_POSS];
int bw_poss[MAX_POSS];
 printf("EDGE_CHECK  average_depth = %10.5f num_hit%5d query_len%5d refseq_len %8d\n",average_depth,num_hit,query_len,refseq_len);

 for(i=0+window_width+50;i<refseq_len-window_width-50;i++)
  {

  flag = 0;
  for(j=0;j<n_gene;j++)
   {
   if((gbs[j].type == 2) || (gbs[j].type == 3) || (gbs[j].type == 4) || (gbs[j].type == 5))   // The gene is RNA
    {
    if((i > (gbs[j].from - 100)) && (i < (gbs[j].to   + 100)) )                               // Within 100 bases from RNA
     {
     flag = 1;
     break;
     }
    }
   }
  if(flag == 1)
   continue;

  left_pop =0;
  left_tot =0;
  left_full =0;
  right_pop=0;
  right_tot=0;
  right_full=0;
  left_tall =0;
  right_tall =0;
  for(j=-window_width;j<0;j++)
   {
   f_ma = func_position_hits_f_match(i+j);
   f_mm = func_position_hits_f_mismatch(i+j);
   r_ma = func_position_hits_r_match(i+j);
   r_mm = func_position_hits_r_mismatch(i+j);
   left_pop  += f_mm;
   left_tot  += f_mm;
   left_tot  += f_ma;
   left_full  += f_mm;
   left_full  += f_ma;
   left_full  += r_mm;
   left_full  += r_ma;
   }
  left_ratio = (double)left_pop / (double)left_tot;
  for(j=1;j<=window_width;j++)
   {
   f_ma = func_position_hits_f_match(i+j);
   f_mm = func_position_hits_f_mismatch(i+j);
   r_ma = func_position_hits_r_match(i+j);
   r_mm = func_position_hits_r_mismatch(i+j);
   right_pop += f_mm;
   right_tot += f_mm;
   right_tot += f_ma;
   right_full += f_mm;
   right_full += f_ma;
   right_full += r_mm;
   right_full += r_ma;
   }
  right_ratio = (double)right_pop / (double)right_tot;
  region_depth = (double)(right_full + left_full) / (double)(window_width * 2);

  for(j=-window_width;j<0;j++)
   {
   f_ma = func_position_hits_f_match(i+j);
   f_mm = func_position_hits_f_mismatch(i+j);
   if((((double)(f_mm))/((double)(f_ma+f_mm))) > tall_ratio3)
    left_tall  ++;
   }
  for(j=1;j<=window_width;j++)
   {
   f_ma = func_position_hits_f_match(i+j);
   f_mm = func_position_hits_f_mismatch(i+j);
   if((((double)f_mm)/((double)(f_ma+f_mm))) > tall_ratio3)
    right_tall  ++;
   }

  f_ma = func_position_hits_f_match(i);
  f_mm = func_position_hits_f_mismatch(i);
//  r_ma = func_position_hits_r_match(i);
//  r_mm = func_position_hits_r_mismatch(i);
  point_ratio = (double)f_mm/ (double)(f_ma+ f_mm);
  
//CHECK1_POINT
//printf("POS:%6d LEFT_TALL %3d RIGHT_TALL %3d MATCH:%5d MISMATCH:%5d P_RATIO %8.4f R_DEPTH:%8.4f A_DEPTH:%8.4f left_full %5d right_full %5d r_ma %5d r_mm %5d\n",
//        i,left_tall,right_tall,f_ma,f_mm,point_ratio,region_depth,average_depth,left_full,right_full,r_ma,r_mm);

  if((region_depth > (average_depth * 0.5)) && ((region_depth < average_depth * 2.0)) &&  (f_mm >= 3) &&
     (left_tall == 0) && (right_tall >= 5) && (point_ratio > tall_ratio4))
   {
   n_edge++;
   fprintf(edge_file,"FW:%10d ",i+1);
   for(j=-print_width;j<=print_width;j++)
    {
    fprintf(edge_file,"%c",refseq[i+j]);
    if(j==-1)
     fprintf(edge_file," ");
    }
   fprintf(edge_file,"\n");
//   fprintf(edge_file,
//   "edge_pop:%5d less_pop:%5d more_pop:%5d LEFT_RATIO %10.4f RIGHT_RATIO %10.4f REGION_DEPTH %10.4f POSITION_RATIO %10.4f LEFT_TALL %5d RIGHT_TALL %5d AVE_DEPTH %10.4f\n",
//                func_position_hits_f_mismatch(i),left_pop,right_pop,left_ratio,right_ratio,region_depth,point_ratio,left_tall,right_tall,average_depth);
   fw_poss[n_fw_poss++] = i;
   if(n_fw_poss > MAX_POSS)
    {
    printf("number of edge exceeded MAX_POSS %d\n",n_fw_poss);
    exit(1);
    }
   fflush(edge_file);

   //////////////////////////////////////////////// COUNT FW_BEFORE[] ///////////
    for(k=i-query_len+1;k<=i;k++)
     {
     if((k<0) || (k>refseq_len))
      continue;
     for(l=0;l<position_hits[k].n_hit;l++)
      {
      if(position_hits[k].hits[l] >= 0)
       {
       for(m=i;m<k+query_len;m++)
        {
        if(qs[position_hits[k].hits[l]].seq[m-k-1] != refseq[m-1])
         {

         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'G') && (refseq[m-1] == 'A'))
          atog++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'C') && (refseq[m-1] == 'A'))
          atoc++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'T') && (refseq[m-1] == 'A'))
          atot++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'C') && (refseq[m-1] == 'G'))
          gtoc++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'T') && (refseq[m-1] == 'G'))
          gtot++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'A') && (refseq[m-1] == 'G'))
          gtoa++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'A') && (refseq[m-1] == 'T'))
          ttoa++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'C') && (refseq[m-1] == 'T'))
          ttoc++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'G') && (refseq[m-1] == 'T'))
          ttog++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'A') && (refseq[m-1] == 'C'))
          ctoa++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'T') && (refseq[m-1] == 'C'))
          ctot++;
         if((qs[position_hits[k].hits[l]].seq[m-k-1] == 'G') && (refseq[m-1] == 'C'))
          ctog++;
 
         fw_edge_n_mmatch ++;
//         fw_edge_q_mmatch += qs[abs(position_hits[k].hits[l])].quality[m-k-1]-offset;

         fw_before[0]++;
         if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-2])
          fw_before[1]++;
         else
          if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-3])
           fw_before[2]++;
          else
           if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-4])
            fw_before[3]++;
           else
            if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-5])
             fw_before[4]++;
            else
             if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-6])
              fw_before[5]++;
             else
              if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-7])
               fw_before[6]++;
              else
               if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-8])
                fw_before[7]++;
               else
                if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-9])
                 fw_before[8]++;
                else
                 if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-10])
                  fw_before[9]++;
                 else
                  if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-11])
                   fw_before[10]++;
                  else
                   fw_before[11]++;
         }
        }
       }
      }
     }
   //////////////////////////////////////////////// COUNT FW_BEFORE[] ///////////
   }
  }
printf("EC_1_COMPLETE %6d\n",n_edge);
fprintf(edge_file,"EC_1_COMPLETE %6d\n",n_edge);

printf("FW_TOTAL        = %10d\n",fw_before[0]);
printf("FW_ONE_BEFORE   = %10d\n",fw_before[1]);
printf("FW_TWO_BEFORE   = %10d\n",fw_before[2]);
printf("FW_THREE_BEFORE = %10d\n",fw_before[3]);
printf("FW_FOUR_BEFORE  = %10d\n",fw_before[4]);
printf("FW_FIVE_BEFORE  = %10d\n",fw_before[5]);
printf("FW_SIX _BEFORE  = %10d\n",fw_before[6]);
printf("FW_SEVEN_BEFORE = %10d\n",fw_before[7]);
printf("FW_EIGHT_BEFORE = %10d\n",fw_before[8]);
printf("FW_NINE_BEFORE  = %10d\n",fw_before[9]);
printf("FW_TEN _BEFORE  = %10d\n",fw_before[10]);
printf("FW_MORE_BEFORE  = %10d\n",fw_before[11]);
fprintf(edge_file,"FW_TOTAL        = %10d\n",fw_before[0]);
fprintf(edge_file,"FW_ONE_BEFORE   = %10d\n",fw_before[1]);
fprintf(edge_file,"FW_TWO_BEFORE   = %10d\n",fw_before[2]);
fprintf(edge_file,"FW_THREE_BEFORE = %10d\n",fw_before[3]);
fprintf(edge_file,"FW_FOUR_BEFORE  = %10d\n",fw_before[4]);
fprintf(edge_file,"FW_FIVE_BEFORE  = %10d\n",fw_before[5]);
fprintf(edge_file,"FW_SIX _BEFORE  = %10d\n",fw_before[6]);
fprintf(edge_file,"FW_SEVEN_BEFORE = %10d\n",fw_before[7]);
fprintf(edge_file,"FW_EIGHT_BEFORE = %10d\n",fw_before[8]);
fprintf(edge_file,"FW_NINE_BEFORE  = %10d\n",fw_before[9]);
fprintf(edge_file,"FW_TEN _BEFORE  = %10d\n",fw_before[10]);
fprintf(edge_file,"FW_MORE_BEFORE  = %10d\n",fw_before[11]);

n_edge = 0;
 for(i=0+window_width+50;i<refseq_len-window_width-50;i++)
  {

  flag = 0;
  for(j=0;j<n_gene;j++)
   {
   if((gbs[j].type == 2) || (gbs[j].type == 3) || (gbs[j].type == 4) || (gbs[j].type == 5))   // The gene is RNA
    {
    if((i > (gbs[j].from - 100)) && (i < (gbs[j].to   + 100)) )                               // Within 100 bases from RNA
     {
     flag = 1;
     break;
     }
    }
   }
  if(flag == 1)
   continue;


  left_pop =0;
  right_pop=0;
  left_tot =0;
  left_full =0;
  right_tot=0;
  right_full=0;
  left_tall =0;
  right_tall =0;
  for(j=-window_width;j<0;j++)
   {
   f_ma = func_position_hits_f_match(i+j);
   f_mm = func_position_hits_f_mismatch(i+j);
   r_ma = func_position_hits_r_match(i+j);
   r_mm = func_position_hits_r_mismatch(i+j);
   left_pop  += r_mm;

   left_tot  += r_mm;
   left_tot  += r_ma;

   left_full  += r_mm;
   left_full  += r_ma;
   left_full  += f_mm;
   left_full  += f_ma;
   }
  left_ratio = (double)left_pop / (double)left_tot;
  for(j=1;j<=window_width;j++)
   {
   f_ma = func_position_hits_f_match(i+j);
   f_mm = func_position_hits_f_mismatch(i+j);
   r_ma = func_position_hits_r_match(i+j);
   r_mm = func_position_hits_r_mismatch(i+j);
   right_pop += r_mm;

   right_tot += r_mm;
   right_tot += r_ma;

   right_full += r_mm;
   right_full += r_ma;
   right_full += f_mm;
   right_full += f_ma;
   }
  right_ratio = (double)right_pop / (double)right_tot;

  region_depth = (double)(right_full + left_full) / (double)(window_width * 2);

  for(j=-window_width;j<0;j++)
   {
   r_ma = func_position_hits_r_match(i+j);
   r_mm = func_position_hits_r_mismatch(i+j);
   if((((double)r_mm) / ((double)(r_mm + r_ma))) > tall_ratio3)
    left_tall  ++;
   }
  for(j=1;j<=window_width;j++)
   {
   r_ma = func_position_hits_r_match(i+j);
   r_mm = func_position_hits_r_mismatch(i+j);
   if((((double)r_mm) / ((double)(r_mm + r_ma))) > tall_ratio3)
    right_tall  ++;
   }

//  f_ma = func_position_hits_f_match(i);
//  f_mm = func_position_hits_f_mismatch(i);
  r_ma = func_position_hits_r_match(i);
  r_mm = func_position_hits_r_mismatch(i);
  point_ratio = ((double)r_mm)/ ((double)(r_mm + r_ma));

//CHECK2_POINT
//printf("POS:%6d LEFT_TALL %3d RIGHT_TALL %3d MATCH:%5d MISMATCH:%5d P_RATIO %8.4f R_DEPTH:%8.4f A_DEPTH:%8.4f left_full %5d right_full %5d f_ma %5d f_mm %5d\n",
//        i,left_tall,right_tall,r_ma,r_mm,point_ratio,region_depth,average_depth,left_full,right_full,f_ma,f_mm);

  if((region_depth > (average_depth * 0.5)) && (region_depth < (average_depth * 2.0)) && (r_mm >= 3) &&
     (left_tall >= 5) && (right_tall == 0) && (point_ratio > tall_ratio4))
   {
   n_edge ++;
   fprintf(edge_file,"BW:%10d ",i+1);
   for(j=-print_width;j<=print_width;j++)
    {
    fprintf(edge_file,"%c",refseq[i+j]);
    if(j==0)
     fprintf(edge_file," ");
    }
   fprintf(edge_file,"\n");
//   fprintf(edge_file,"edge_pop:%5d less_pop:%5d more_pop:%5d region_depth %10.4f average_depth %10.4f left_tall %5d right_tall %5d\n",
//           func_position_hits_r_mismatch(i),right_pop,left_pop,region_depth,average_depth,left_tall,right_tall);
   bw_poss[n_bw_poss++] = i;
  if(n_bw_poss > MAX_POSS)
   {
   printf("number of edge exceeded MAX_POSS %d\n",n_bw_poss);
   exit(1);
   }
   fflush(edge_file);

   //////////////////////////////////////////////// COUNT BW_BEFORE[] ///////////
    for(k=i-query_len+1;k<=i;k++)
     {
     if((k<0) || (k>refseq_len))
      continue;
     for(l=0;l<position_hits[k].n_hit;l++)
      {
      if(position_hits[k].hits[l] < 0)
       {
       for(m=i;m>k;m--)
        {
        if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1) != refseq[m-1])
         {

         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'G') && (refseq[m-1] == 'A'))
          atog++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'C') && (refseq[m-1] == 'A'))
          atoc++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'T') && (refseq[m-1] == 'A'))
          atot++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'C') && (refseq[m-1] == 'G'))
          gtoc++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'T') && (refseq[m-1] == 'G'))
          gtot++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'A') && (refseq[m-1] == 'G'))
          gtoa++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'A') && (refseq[m-1] == 'T'))
          ttoa++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'C') && (refseq[m-1] == 'T'))
          ttoc++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'G') && (refseq[m-1] == 'T'))
          ttog++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'A') && (refseq[m-1] == 'C'))
          ctoa++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'T') && (refseq[m-1] == 'C'))
          ctot++;
         if((qs_ceq(abs(position_hits[k].hits[l]),m-k-1) == 'G') && (refseq[m-1] == 'C'))
          ctog++;

         bw_edge_n_mmatch ++;
//         bw_edge_q_mmatch += qs[abs(position_hits[k].hits[l])].cuality[m-k]-offset;

//printf("I=%5d M=%5d K=%5d L=%5d REF= %c QUERY = %c\n",i,m,k,l,refseq[m-1],qs_ceq(abs(position_hits[k].hits[l]),m-k-1));
         bw_before[0]++;
         if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m])
          bw_before[1]++;
         else
          if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+1])
           bw_before[2]++;
          else
           if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+2])
            bw_before[3]++;
           else
            if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+3])
             bw_before[4]++;
            else
             if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+4])
              bw_before[5]++;
             else
              if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+5])
               bw_before[6]++;
              else
               if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+6])
                bw_before[7]++;
               else
                if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+7])
                 bw_before[8]++;
                else
                 if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+8])
                  bw_before[9]++;
                 else
                  if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+9])
                   bw_before[10]++;
                  else
                   bw_before[11]++;
         }
        }
       }
      }
     }
   //////////////////////////////////////////////// COUNT FW_BEFORE[] ///////////
   }
  }
printf("EC_2_COMPLETE %6d\n",n_edge);
fprintf(edge_file,"EC_2_COMPLETE %6d\n",n_edge);
 
printf("BW_TOTAL        = %10d\n",bw_before[0]);
printf("BW_ONE_BEFORE   = %10d\n",bw_before[1]);
printf("BW_TWO_BEFORE   = %10d\n",bw_before[2]);
printf("BW_THREE_BEFORE = %10d\n",bw_before[3]);
printf("BW_FOUR_BEFORE  = %10d\n",bw_before[4]);
printf("BW_FIVE_BEFORE  = %10d\n",bw_before[5]);
printf("BW_SIX_BEFORE   = %10d\n",bw_before[6]);
printf("BW_SEVEN_BEFORE = %10d\n",bw_before[7]);
printf("BW_EIGHT_BEFORE = %10d\n",bw_before[8]);
printf("BW_NINE_BEFORE  = %10d\n",bw_before[9]);
printf("BW_TEN _BEFORE  = %10d\n",bw_before[10]);
printf("BW_MORE_BEFORE  = %10d\n",bw_before[11]);
fprintf(edge_file,"BW_TOTAL        = %10d\n",bw_before[0]);
fprintf(edge_file,"BW_ONE_BEFORE   = %10d\n",bw_before[1]);
fprintf(edge_file,"BW_TWO_BEFORE   = %10d\n",bw_before[2]);
fprintf(edge_file,"BW_THREE_BEFORE = %10d\n",bw_before[3]);
fprintf(edge_file,"BW_FOUR_BEFORE  = %10d\n",bw_before[4]);
fprintf(edge_file,"BW_FIVE_BEFORE  = %10d\n",bw_before[5]);
fprintf(edge_file,"BW_SIX_BEFORE   = %10d\n",bw_before[6]);
fprintf(edge_file,"BW_SEVEN_BEFORe = %10d\n",bw_before[7]);
fprintf(edge_file,"BW_EIGHT_BEFORE = %10d\n",bw_before[8]);
fprintf(edge_file,"BW_NINE_BEFORE  = %10d\n",bw_before[9]);
fprintf(edge_file,"BW_TEN _BEFORE  = %10d\n",bw_before[10]);
fprintf(edge_file,"BW_MORE_BEFORE  = %10d\n",bw_before[11]);

printf("FB_TOTAL        = %10d  \n",fw_before[0]+bw_before[0]);
printf("FB_ONE_BEFORE   = %10d  %8.4f\n",fw_before[1]+bw_before[1],  (double)(fw_before[1]+bw_before[1])/(double)(fw_before[0]+bw_before[0]));
printf("FB_TWO_BEFORE   = %10d  %8.4f\n",fw_before[2]+bw_before[2],  (double)(fw_before[2]+bw_before[2])/(double)(fw_before[0]+bw_before[0]));
printf("FB_THREE_BEFORE = %10d  %8.4f\n",fw_before[3]+bw_before[3],  (double)(fw_before[3]+bw_before[3])/(double)(fw_before[0]+bw_before[0]));
printf("FB_FOUR_BEFORE  = %10d  %8.4f\n",fw_before[4]+bw_before[4],  (double)(fw_before[4]+bw_before[4])/(double)(fw_before[0]+bw_before[0]));
printf("FB_FIVE_BEFORE  = %10d  %8.4f\n",fw_before[5]+bw_before[5],  (double)(fw_before[5]+bw_before[5])/(double)(fw_before[0]+bw_before[0]));
printf("FB_SIX_BEFORE   = %10d  %8.4f\n",fw_before[6]+bw_before[6],  (double)(fw_before[6]+bw_before[6])/(double)(fw_before[0]+bw_before[0]));
printf("FB_SEVEN_BEFORE = %10d  %8.4f\n",fw_before[7]+bw_before[7],  (double)(fw_before[7]+bw_before[7])/(double)(fw_before[0]+bw_before[0]));
printf("FB_EIGHT_BEFORE = %10d  %8.4f\n",fw_before[8]+bw_before[8],  (double)(fw_before[8]+bw_before[8])/(double)(fw_before[0]+bw_before[0]));
printf("FB_NINE_BEFORE  = %10d  %8.4f\n",fw_before[9]+bw_before[9],  (double)(fw_before[9]+bw_before[9])/(double)(fw_before[0]+bw_before[0]));
printf("FB_TEN _BEFORE  = %10d  %8.4f\n",fw_before[10]+bw_before[10],(double)(fw_before[10]+bw_before[10])/(double)(fw_before[0]+bw_before[0]));
printf("FB_MORE_BEFORE  = %10d  %8.4f\n",fw_before[11]+bw_before[11],(double)(fw_before[11]+bw_before[11])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_TOTAL        = %10d  \n",fw_before[0]+bw_before[0]);
fprintf(edge_file,"FB_ONE_BEFORE   = %10d  %8.4f\n",fw_before[1]+bw_before[1],  (double)(fw_before[1]+bw_before[1])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_TWO_BEFORE   = %10d  %8.4f\n",fw_before[2]+bw_before[2],  (double)(fw_before[2]+bw_before[2])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_THREE_BEFORE = %10d  %8.4f\n",fw_before[3]+bw_before[3],  (double)(fw_before[3]+bw_before[3])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_FOUR_BEFORE  = %10d  %8.4f\n",fw_before[4]+bw_before[4],  (double)(fw_before[4]+bw_before[4])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_FIVE_BEFORE  = %10d  %8.4f\n",fw_before[5]+bw_before[5],  (double)(fw_before[5]+bw_before[5])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_SIX_BEFORE   = %10d  %8.4f\n",fw_before[6]+bw_before[6],  (double)(fw_before[6]+bw_before[6])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_SEVEN_BEFORe = %10d  %8.4f\n",fw_before[7]+bw_before[7],  (double)(fw_before[7]+bw_before[7])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_EIGHT_BEFORE = %10d  %8.4f\n",fw_before[8]+bw_before[8],  (double)(fw_before[8]+bw_before[8])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_NINE_BEFORE  = %10d  %8.4f\n",fw_before[9]+bw_before[9],  (double)(fw_before[9]+bw_before[9])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_TEN _BEFORE  = %10d  %8.4f\n",fw_before[10]+bw_before[10],(double)(fw_before[10]+bw_before[10])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_MORE_BEFORE  = %10d  %8.4f\n",fw_before[11]+bw_before[11],(double)(fw_before[11]+bw_before[11])/(double)(fw_before[0]+bw_before[0]));

 /*
 printf("EDGE_CHECK\n");
int window_width         =   50;
int print_width          =   50;
int max_less_window_pop  =  200;
int min_more_window_pop  =  600;
int min_edge_pop         =   90;
int left_pop =0;
int right_pop=0;
int na,nt,ng,nc;
int temp_val;

 for(i=0+window_width+10;i<refseq_len-window_width-10;i++)
  {
  left_pop =0;
  right_pop=0;
  temp_val = func_position_hits_f_mismatch(i);
  for(j=-window_width;j<0;j++)
   left_pop  += func_position_hits_f_mismatch(i+j);
  for(j=0;j<=window_width;j++)
   right_pop += func_position_hits_f_mismatch(i+j);
  if((temp_val > min_edge_pop) && (left_pop < max_less_window_pop) && (right_pop > min_more_window_pop))
   {
   na=0;nt=0;nc=0;ng=0;
   for(j=-print_width;j<=print_width*3;j++)
    {
    if(refseq[i+j] == 'A')  na++;
    if(refseq[i+j] == 'T')  nt++;
    if(refseq[i+j] == 'G')  ng++;
    if(refseq[i+j] == 'C')  nc++;
    printf("%c",refseq[i+j]);
    if(j==-1)
     printf(" ");
    }
   printf("   ");
   printf("FORWARD  WINDOW POSITION %10d    edge_pop:%5d less_pop:%5d more_pop:%5d A:%3d T:%3d G:%3d C:%3d\n",
                i+1,temp_val,left_pop,right_pop,na,nt,ng,nc);
   }
  }

 for(i=0+window_width+10;i<refseq_len-window_width-10;i++)
  {
  left_pop =0;
  right_pop=0;
  temp_val = func_position_hits_r_mismatch(i);
  for(j=-window_width;j<=0;j++)
   left_pop  += func_position_hits_r_mismatch(i+j);
  for(j=1;j<=window_width;j++)
   right_pop  += func_position_hits_r_mismatch(i+j);
  if((temp_val> min_edge_pop) && (right_pop < max_less_window_pop) && (left_pop > min_more_window_pop))
   {
   na=0;nt=0;nc=0;ng=0;
   for(j=-print_width;j<=print_width;j++)
    {
    if(refseq[i+j] == 'A')  na++;
    if(refseq[i+j] == 'T')  nt++;
    if(refseq[i+j] == 'G')  ng++;
    if(refseq[i+j] == 'C')  nc++;
    printf("%c",refseq[i+j]);
    if(j==0)
     printf(" ");
    }
   printf("   ");
   printf("BACKWARD WINDOW POSITION %10d    edge_pop:%5d less_pop:%5d more_pop:%5d A:%3d T:%3d G:%3d C:%3d\n",
           i+1,temp_val,right_pop,left_pop,na,nt,ng,nc);
   }
  }
 */
 }

/////////////////////////////////////////////////////////////////  PRINT OUT TEXT MAP OUTPUT 
if(map_out == 1) 
{
int map_out_width = 300;
int map_fold = (refseq_len / map_out_width) + 1;
int map_depth = max_box_num;

printf("MAP_OUT_WIDTH   %10d\n",map_out_width);
printf("MAP_FOLD        %10d\n",map_fold);

////////////////////////////////////////////////////////// MAP  OUTPUT
for(i=0;i<map_fold;i++)
 {
 from = i * map_out_width;
 to   = (i+1) * map_out_width - 1;
 max_depth_of_the_fold = 0;
 fprintf(mapout_file,"%10d: ",from);

 if(to > refseq_len)
  to = refseq_len-1;
 for(j=from;j<=to;j++)
  {
  fprintf(mapout_file,"%c",refseq[j]);
  }

 for(j=from-query_len;j<=to;j++)
  {
  if(j<0)
   j= 0;
  for(l=0;l<position_hits[j].n_hit;l++)
   {
   if(position_hits[j].boxs[l]+1 > max_depth_of_the_fold)
    {
    max_depth_of_the_fold = position_hits[j].boxs[l]+1;
    }
   }
  }
 fprintf(mapout_file,"\n");
 fprintf(mapout_file,"            ");
 for(j=from;j<=to;j++)
  {
  if(j%10 == 0)
   fprintf(mapout_file,"%d",(j/10)%10);
  else
   fprintf(mapout_file," ");
  }
 fprintf(mapout_file,"\n");
// fprintf(mapout_file,"MAX_DEPTH_OF_THE_FOLD %10d\n",max_depth_of_the_fold);
// for(k=0;k<map_depth;k++)

 if(max_depth_of_the_fold >= MAX_BOX)
  max_depth_of_the_fold = MAX_BOX - 5;

 for(k=0;k<max_depth_of_the_fold + 2;k++)
  {
  fprintf(mapout_file,"          : ");
  for(j=from;j<=to;j++)
   {
   for(l=0;l<position_hits[j].n_hit;l++)
    {
    if(position_hits[j].boxs[l] == k)
     {
     box_hit[k] = position_hits[j].hits[l];
     box_cnt[k] = query_len;
     }
    }
   if(box_cnt[k] == 1)
    {
    box_hit[k] = MAX_INT;
    }
   if(box_cnt[k] >= 1)
    {
    box_cnt[k] --;
    }

   if(box_hit[k] != MAX_INT)
    {
    if(box_hit[k] > 0)
     {
     //position_hits[j].n_order ++;
     if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == refseq[j])
      {
      fprintf(mapout_file,"%c",qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1]);
//      position_hits[j].n_match ++;

      if(gene_pop == 1)
       {
       for(m=0;m<n_gene;m++)
        {
        if((j>=gbs[m].from) && (j<=gbs[m].to))
         gbs[m].intensity ++;
        }
       }

      if(gene_pop == 2)
       {
       for(m=0;m<n_gene;m++)
        {
        if((j>=gbs[m].from) && (j<=gbs[m].to))
         gbs[m].intensity ++;
        if(m != 0)
         {
         if((j>=gbs[m-1].to) && (j<=gbs[m].from))
          gbs[m].pre_intensity ++;
         }
        else
         {
         if((j>=0) && (j<=gbs[m].from))
          gbs[m].pre_intensity ++;
         }
//        if(m != n_gene-1)
//         if((j>=gbs[m].to) && (j<=gbs[m+1].from))
//          gbs[m].post_intensity ++;
        }
       }

      if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'A')
       {
       mAA++;
       }
      if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'T')
       {
       mTT++;
       }
      if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'G')
       {
       mGG++;
       }
      if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'C')
       {
       mCC++;
       }
      if((qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'N') || (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == '.'))
       {
       }
      }
     else
      {
      fprintf(mapout_file,"%c",qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1]+32);
//      position_hits[j].n_mismatch ++;

      if(refseq[j] == 'A')
       {
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'T')
        {
        mAT ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'G')
        {
        mAG ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'C')
        {
        mAC ++;
        }
       if((qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'N') || (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == '.'))
        {
        mAN ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'A')
        {
        mAA ++;
        }
       }
      if(refseq[j] == 'T')
       {
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'A')
        {
        mTA ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'G')
        {
        mTG ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'C')
        {
        mTC ++;
        }
       if((qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'N') || (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == '.'))
        {
        mTN ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'T')
        {
        mTT ++;
        }
       }
      if(refseq[j] == 'G')
       {
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'A')
        {
        mGA ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'T')
        {
        mGT ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'C')
        {
        mGC ++;
        }
       if((qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'N') || (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == '.'))
        {
        mGN ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'G')
        {
        mGG ++;
        }
       }
      if(refseq[j] == 'C')
       {
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'A')
        {
        mCA ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'G')
        {
        mCG ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'T')
        {
        mCT ++;
        }
       if((qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'N') || (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == '.'))
        {
        mCN ++;
        }
       if(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'C')
        {
        mCC ++;
        }
       }
      }
     }
    else
     {
     //position_hits[j].n_complement ++;
     if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == refseq[j])
      {
      fprintf(mapout_file,"%c",qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1));
//      position_hits[j].n_match ++;

      if(gene_pop == 1)
       {
       for(m=0;m<n_gene;m++)
        {
        if((j>=gbs[m].from) && (j<=gbs[m].to))
         gbs[m].intensity ++;
        }
       }

      if(gene_pop == 2)
       {
       for(m=0;m<n_gene;m++)
        {
        if((j>=gbs[m].from) && (j<=gbs[m].to))
         gbs[m].intensity ++;
        if(m != 0)
         {
         if((j>=gbs[m-1].to) && (j<=gbs[m].from))
          gbs[m].pre_intensity ++;
         }
        else
         {
         if((j>=0) && (j<=gbs[m].from))
          gbs[m].pre_intensity ++;
         }
//        if(m != n_gene-1)
//         {
//         if((j>=gbs[m].to) && (j<=gbs[m+1].from))
//          gbs[m].post_intensity ++;
//         }
        }  
       }

      if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'A')
       {
       mAA++;
       }
      if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'T')
       {
       mTT++;
       }
      if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'G')
       {
       mGG++;
       }
      if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'C')
       {
       mCC++;
       }
      if((qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'N') || (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == '.'))
       {
       }
      }
     else
      {
      fprintf(mapout_file,"%c",qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1)+32);
 //     position_hits[j].n_mismatch ++;

      if(refseq[j] == 'A')
       {
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'T')
        {
        mAT ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'G')
        {
        mAG ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'C')
        {
        mAC ++;
        }
       if((qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'N') || (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == '.'))
        {
        mAN ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'A')
        {
        mAA ++;
        }
       }
      if(refseq[j] == 'T')
       {
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'A')
        {
        mTA ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'G')
        {
        mTG ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'C')
        {
        mTC ++;
        }
       if((qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'N') || (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == '.'))
        {
        mTN ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'T')
        {
        mTT ++;
        }
       }
      if(refseq[j] == 'G')
       {
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'A')
        {
        mGA ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'T')
        {
        mGT ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'C')
        {
        mGC ++;
        }
       if((qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'N') || (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == '.'))
        {
        mGN ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'G')
        {
        mGG ++;
        }
       }
      if(refseq[j] == 'C')
       {
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'A')
        {
        mCA ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'G')
        {
        mCG ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'T')
        {
        mCT ++;
        }
       if((qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'N') || (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == '.'))
        {
        mCN ++;
        }
       if(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'C')
        {
        mCC ++;
        }
       }
      }
     }
    }
   else
    {
    fprintf(mapout_file," ");
    }
   }
  fprintf(mapout_file,"\n");
  }
// for(i=1;i<=refseq_len;i++)
//  {
//  fprintf(mapout_file,"%c",refseq[i-1]);
//  if(i % map_out_width == 0)
//   {
//   fprintf(mapout_file,"\n");
//   }
//  }
 }

printf("mAG = %10d, mAC = %10d, mAT = %10d mAA = %10d mAN = %10d\n",mAG,mAC,mAT,mAA,mAN);
printf("mTG = %10d, mTC = %10d, mTA = %10d mTT = %10d mTN = %10d\n",mTG,mTC,mTA,mTT,mTN);
printf("mGA = %10d, mGC = %10d, mGT = %10d mGG = %10d mGN = %10d\n",mGA,mGC,mGT,mGG,mGN);
printf("mCG = %10d, mCG = %10d, mCT = %10d mCC = %10d mCN = %10d\n",mCG,mCG,mCT,mCC,mCN);
}
/////////////////////////////////////////////////////////////////  PRINT OUT TEXT MAP OUTPUT END


//////  ///  ANALYSYS OMITTED FOR A MOMENT    POSITION_HITS[].n_matches should be converted to func_position_hits_n_matches etc
//if(map_out == 1)
// {
// flag = 0;
// from = 0;
// for(i=0;i<refseq_len;i++)
//  {
//  if((func_position_hits_n_mismatch(i) >= 3) && 
//    (((double)func_position_hits_n_mismatch(i)/(double)(func_position_hits_n_mismatch(i)+func_position_hits_n_match(i))* 100.0) > 95.0))
//   
//   printf("POSITION:%8d  MISMATCH:%3d MATCH %3d  RATIO:%8.4f\n",
//           i+1,func_position_hits_n_mismatch(i),func_position_hits_n_match(i),
//               (double)func_position_hits_n_mismatch(i)/(double)(func_position_hits_n_mismatch(i)+func_position_hits_n_match(i))* 100.0);
////   printf("%8d  %3d %3d  %8.4f %c %3d %3d %3d %3d %3d\n", i+1, position_hits[i].n_mismatch, position_hits[i].n_match,
////          (double)position_hits[i].n_mismatch/(double)(position_hits[i].n_mismatch+position_hits[i].n_match) * (double)100.0,
////          refseq[i],position_hits[i].n_a,position_hits[i].n_t,position_hits[i].n_g,position_hits[i].n_c,position_hits[i].n_n);
//   }
// //printf("%10d-%10d\n",i+1,func_position_hits_n_match(i));
//  if(flag == 0)
//   {
//   if(func_position_hits_n_match(i) <= match_thresh)
//    {
// //   fprintf(summary_file,"STARTS GAP from %d\n",i+1);
//    from = i+1;
//    flag = 1;
//    }
//   else
//    {
//    }
//   }
//  else
//   {
//   if(func_position_hits_n_match(i) <= match_thresh)
//    {
//    }
//   else
//    {
// //   fprintf(summary_file,"ENDS   GAP at   %d\n",i+1);
//    fprintf(summary_file,"GAP FROM %10d TO %10d   LENGTH %10d\n",from,i+1,i+1-from);
//    flag = 0;
//    }
//   }
//  }
// }

/////////////////////////////////////////////////////////////////  Prepare Display map on screen
////////////////////////////////////////////////////////HISTOGRAM TYPE MAP
//////////////////////////////////////////////////////// MARKMARK             
if(hmap_out == 1)
 {
//printf("QUERY_LEN = %d\n",query_len);
 double temp_height;
 for(i=0;i<histogram_length;i++)
  {
  count_per_pixel[i]      = 0;
  count_per_pixel_f[i]    = 0;
  count_per_pixel_c[i]    = 0;
  count_per_pixel_mm[i]   = 0;
  }
 for(i=0;i<refseq_len;i++)
  {
//printf("HISTOGRAM_LENGTH %10d POSI %10d POS %10d\n",histogram_length,i,i/base_per_pixel);
//TEST  count_per_pixel[i/base_per_pixel]    +=  position_hits[i].n_match;
  count_per_pixel[i/base_per_pixel]    +=  func_position_hits_n_match(i);
//TEST  count_per_pixel_f[i/base_per_pixel]  +=  position_hits[i].f_match;
  count_per_pixel_f[i/base_per_pixel]  +=  func_position_hits_f_match(i);
//TEST  count_per_pixel_c[i/base_per_pixel]  +=  position_hits[i].r_match;
  count_per_pixel_c[i/base_per_pixel]  +=  func_position_hits_r_match(i);
//TEST  count_per_pixel_mm[i/base_per_pixel] +=  position_hits[i].n_mismatch;
  count_per_pixel_mm[i/base_per_pixel] +=  func_position_hits_n_mismatch(i);
  }
// for(i=0;i<histogram_length;i++)
//  printf("%10d %10d\n",i,count_per_pixel[i]);

 min_a_height    =  c_height;
 a_left_margin   = c_width + c_a_gap;
 a_width         = g_width - g_left_margin - g_right_margin - a_left_margin - a_right_margin;

 dmap_out_width  = a_width / bit_width;                 // BIT NUM PER FOLD // フォールドあたりのビット数
 dmap_fold       = histogram_length / dmap_out_width + 1;     // NUMBER OF FOLD //フォールド回数
 if(histogram_length%dmap_out_width == 0)
     dmap_fold --;                                         // -1 IF EXACT MATCH // ぴったりなら -1
 printf("DMAP_OUT_WIDTH     %10d\n",dmap_out_width);
 printf("DMAP_FOLD          %10d\n",dmap_fold);

 n_page = 0;
 initial_fold_of_page[n_page++] = 0;
 t_height = 0.0;

 for(i=0;i<dmap_fold;i++)                                 // CALCULATE DEPTH AND HEIGHT OF EACH FOLD // 各フォールドの深さ、高さを計算
  {
  from = i     * dmap_out_width;
  to   = (i+1) * dmap_out_width - 1;
  if(to > histogram_length)
   to = histogram_length - 1;
  n_depth[i] = 0;
  if(log_scale == 0)
   {
   for(j=from;j<=to;j++)
    {
    if(((double)(count_per_pixel[j]+count_per_pixel_mm[j])/(double)base_per_pixel*height_scale) > (double)n_depth[i])
     {
     n_depth[i] = (int)((double)(count_per_pixel[j]+count_per_pixel_mm[j])/(double)base_per_pixel*height_scale);
     if(n_depth[i] > max_height)
      n_depth[i] =max_height;
     }
    if(((double)(count_per_pixel_f[j])/(double)base_per_pixel*height_scale) > (double)n_depth[i])
     {
     n_depth[i] = (int)((double)(count_per_pixel_f[j])/(double)base_per_pixel*height_scale);
     if(n_depth[i] > max_height)
      n_depth[i] =max_height;
     }
    if(((double)(count_per_pixel_c[j])/(double)base_per_pixel*height_scale) > (double)n_depth[i])
     {
     n_depth[i] = (int)((double)(count_per_pixel_c[j])/(double)base_per_pixel*height_scale);
     if(n_depth[i] > max_height)
      n_depth[i] =max_height;
     }
    }
   }
  else
   {
   for(j=from;j<=to;j++)
    {
    if((int)(log((double)(count_per_pixel[j]))*height_scale) > n_depth[i])
     {
     n_depth[i] = (int)(log((double)count_per_pixel[j])*height_scale);
     if(n_depth[i] > max_height)
      n_depth[i] =max_height;
     }
    if((int)(log((double)(count_per_pixel_f[j]))*height_scale) > n_depth[i])
     {
     n_depth[i] = (int)(log((double)count_per_pixel_f[j])*height_scale);
     if(n_depth[i] > max_height)
      n_depth[i] =max_height;
     }
    if((int)(log((double)(count_per_pixel_c[j]))*height_scale) > n_depth[i])
     {
     n_depth[i] = (int)(log((double)count_per_pixel_c[j])*height_scale);
     if(n_depth[i] > max_height)
      n_depth[i] =max_height;
     }
    }
   }
  temp_height = bit_height * (n_depth[i]+1) + r_q_gap + q_q_gap * (n_depth[i] -1);
  a_height[i] = min_a_height;
  if(temp_height > min_a_height)
   a_height[i] = temp_height;
  t_height += a_height[i] + a_a_gap;
  if(t_height > thresh_page_height)
   {
   exceed_depth ++;
   t_height = 0.0;
   initial_fold_of_page[n_page++] = i--;
   }
  }
 initial_fold_of_page[n_page] = dmap_fold;
 printf("N_PAGE       %10d\n",n_page);
 }
////////////////////////////////////////////////////////HISTOGRAM TYPE MAP END

////////////////////////////////////////////////////////SHOW READ TYPE MAP
if(rmap_out == 1)
 {
 double temp_height;
 min_a_height    =  c_height;
 a_left_margin   = c_width + c_a_gap;
 a_width         = g_width - g_left_margin - g_right_margin - a_left_margin - a_right_margin;

 dmap_out_width = a_width / bit_width;                 // BIT NUM PER FOLD // フォールドあたりのビット数
 dmap_fold      = refseq_len / dmap_out_width + 1;     // NUMBER OF FOLD //フォールド回数
 if(refseq_len%dmap_out_width == 0)
     dmap_fold --;                                         // -1 IF EXACT MATCH // ぴったりなら -1
 int map_depth = max_box_num;                              // TEMPORARY VALUE   //暫定値

 printf("RMAP_OUT_WIDTH     %10d\n",dmap_out_width);
 printf("RMAP_FOLD          %10d\n",dmap_fold);

 n_page = 0;
 initial_fold_of_page[n_page++] = 0;
 t_height = 0.0;
 for(i=0;i<dmap_fold;i++)                                 // CALCULATE DEPTH AND HEIGHT OF EACH FOLD // 各フォールドの深さ、高さを計算
  {
  from = i     * dmap_out_width;
  to   = (i+1) * dmap_out_width - 1;
  if(to > refseq_len)
   to = refseq_len - 1;
  n_depth[i] = 0;
  for(j=from-query_len;j<=to;j++)
   {
   if(j<0)
    j=0;
   for(l=0;l<position_hits[j].n_hit;l++)
    {
    if(position_hits[j].boxs[l]+1 > n_depth[i])
     {
     n_depth[i] = position_hits[j].boxs[l]+1;
     }
    }
   }
  temp_height = bit_height * (n_depth[i]+1) + r_q_gap + q_q_gap * (n_depth[i] -1);
  a_height[i] = min_a_height;
  if(temp_height > min_a_height)
   a_height[i] = temp_height;
  t_height += a_height[i] + a_a_gap;
  if(t_height > thresh_page_height)
   {
   exceed_depth ++;
//   printf("The depth exceed page height\n");
//   exit (1);
   t_height = 0.0;
   initial_fold_of_page[n_page++] = i--;
   }

//  printf("%10d %10f\n",n_depth[i],a_height[i]);
  }                                                      // END CALCULATE DEPTH AND HEIGHT OF EACH FOLD //各フォールドの深さ、高さを計算 終
 initial_fold_of_page[n_page] = dmap_fold;
// g_height = t_height + g_top_margin + g_bottom_margin;
 g_height = max_page_height;
 printf("G_HEIGHT     %10f\n",g_height);
 printf("N_PAGE       %10d\n",n_page);
 for(i=0;i<n_page;i++)
  {
//  printf("PAGE %5d Starts from fold %10d\n",i+1,initial_fold_of_page[i]);
  }
// for(i=0;i<dmap_fold;i++)
//  {
//  }
 }
////////////////////////////////////////////////////////SHOW READ TYPE MAP END
//printf("The depth exceeded the page height %d times\n",exceed_depth);
/////////////////////////////////////////////////////////////////  Prepare Display map on screen END
char gname[512];
if(gene_pop == 1)
 {
 for(i=0;i<n_gene;i++)
  {
  sprintf(gname,"%s_%s",gbs[i].locus_tag,gbs[i].product_name);
  fprintf(genepop_file,"%10.5f %10d %10d %s\n",(double)gbs[i].intensity/(double)(gbs[i].to-gbs[i].from+1),gbs[i].intensity,gbs[i].to-gbs[i].from+1,gname);
  }
 }
if(gene_pop == 2)
 {
 for(i=0;i<n_gene;i++)
  {
  if(i==0)
   {
   if((gbs[i].from) >= 1)
    {
    sprintf(gname,"PRE_%s_%s",gbs[i].locus_tag,gbs[i].product_name);
    fprintf(genepop_file,"%10.5f %10d %10d %s\n",(double)gbs[i].pre_intensity/(double)(gbs[i].from),gbs[i].pre_intensity,gbs[i].from,gname);
    }
   }
  else
   {
   if((gbs[i].from-gbs[i-1].to+1) >= 1)
    {
    sprintf(gname,"PRE_%s_%s",gbs[i].locus_tag,gbs[i].product_name);
    fprintf(genepop_file,"%10.5f %10d %10d %s\n",(double)gbs[i].pre_intensity/(double)(gbs[i].from-gbs[i-1].to+1),gbs[i].pre_intensity,gbs[i].from-gbs[i-1].to+1,gname);
    }
   }
 
  sprintf(gname,"%s_%s",gbs[i].locus_tag,gbs[i].product_name);
  fprintf(genepop_file,"%10.5f %10d %10d %s\n",(double)gbs[i].intensity/(double)(gbs[i].to-gbs[i].from+1),gbs[i].intensity,gbs[i].to-gbs[i].from+1,gname);
  }
 }

if(tag_count == 1)
 {
 for(i=0;i<n_gene;i++)
  {
  sprintf(gname,"%s_%s",gbs[i].locus_tag,gbs[i].product_name);
  fprintf(tagcount_file,"%10.5f %10.5f %10d %10d %s\n",(double)gbs[i].tag_count/(double)(gbs[i].to-gbs[i].from+1)*scale_factor,
                                                       (double)gbs[i].tag_count/(double)(gbs[i].to-gbs[i].from+1),gbs[i].tag_count,gbs[i].to-gbs[i].from+1,gname);
  }
 }
if(tag_count == 2)
 {
 for(i=0;i<n_gene;i++)
  {
  sprintf(gname,"PRE_%s_%s",gbs[i].locus_tag,gbs[i].product_name);
  fprintf(tagcount_file,"%10.5f %10.5f %10d %10d %s\n",(double)gbs[i].pre_tag_count/(double)(gbs[i].to-gbs[i].from+1)*scale_factor,
                                                       (double)gbs[i].pre_tag_count/(double)(gbs[i].to-gbs[i].from+1),gbs[i].pre_tag_count,gbs[i].to-gbs[i].from+1,gname);
  sprintf(gname,"%s_%s",gbs[i].locus_tag,gbs[i].product_name);
  fprintf(tagcount_file,"%10.5f %10.5f %10d %10d %s\n",(double)gbs[i].tag_count/(double)(gbs[i].to-gbs[i].from+1)*scale_factor,
                                                       (double)gbs[i].tag_count/(double)(gbs[i].to-gbs[i].from+1),gbs[i].tag_count,gbs[i].to-gbs[i].from+1,gname);
  }
 }

fclose(refseq_file);
if(input_is_sam == 1)
 fclose(in_sam_file);
else
 {
 fclose(query_file);
 fclose(hit_file);
 fclose(lqh_file);
 }
if(no_bin_hit == 0)
 fclose(binhit_file);
if(use_multihit == 1)
 {
 fclose(hits_file);
 }

if(map_out == 1)
 {
 fclose(mapout_file);
 }
if(gene_pop >= 1)
 {
 fclose(genepop_file);
 }
if(tag_count >= 1) 
 {
 fclose(tagcount_file);
 }
fclose(summary_file);


if(ps_out == 1)                                // PS OUTPUT START
 {
 printf("ALL DATA FILES READ IN!\n");
 printf("NOW CREATING a PostScript FILE.\n");
 int sfrom,sto;
 int ffrom,fto;
 double x_pos,y_pos;
 double x_poss,y_poss;
 double hor_pos,vert_pos;
 double line_width,line_height;
 char ps_buff[100000];
 int pp;
 time_t timeval;
 char datestamp[80];
 (void) time(&timeval);
 strcpy(datestamp,ctime(&timeval));

 strcpy(buff,"%!PS-Adobe-"); fprintf(psfile,"%s\n",buff);                                                       // Global Header
 strcpy(buff,"%%Creator: "); fprintf(psfile,"%s%s\n",buff,getenv("USER"));                                      // Global Header
 strcpy(buff,"%%CreationDate: "); fprintf(psfile,"%s%s",buff,datestamp);                                        // Global Header
 strcpy(buff,"%%DocumentFonts: (atend)"); fprintf(psfile,"%s\n",buff);                                          // Global Header
 strcpy(buff,"%%Pages: (atend)"); fprintf(psfile,"%s\n",buff);                                                  // Global Header
 strcpy(buff,"%%EndComments"); fprintf(psfile,"%s\n",buff);                                                     // Global Header
 strcpy(buff,"/mv {moveto} def"); fprintf(psfile,"%s\n",buff);                                                  // Global Header
 strcpy(buff,"%%EndProlog"); fprintf(psfile,"%s\n",buff);                                                       // Global Header

 strcpy(buff,"<< /PageSize [1190 841]"); fprintf(psfile,"%s\n",buff);                                           // A3
 strcpy(buff,"   /Policies << /PageSize 6 >>"); fprintf(psfile,"%s\n",buff);                                    // A3
 strcpy(buff,">> setpagedevice"); fprintf(psfile,"%s\n",buff);                                                  // A3

 if((ps_from == -1) && (ps_to == -1))
  {
  p_from = 0;
  p_to   = n_page;
  }
 else
  {
  if(ps_from == -1) 
   {
   p_from = 0;
   p_to = ps_to;
   }
  else
   if(ps_to == -1) 
    {
    p_from = ps_from-1;
    p_to = n_page;
    }
   else
    {
    p_from = ps_from-1;
    p_to = ps_to;
    }
  }

printf("PS from page %d to page %d of %d\n",p_from,p_to,n_page);

 for(pp=p_from;pp<p_to;pp++)
// for(pp=0;pp<n_page;pp++)
  {
  strcpy(buff,"%%Page: "); fprintf(psfile,"%s%d\n",buff,pp+1);                                                   // Page Header 1
  strcpy(buff,"<< /PageSize [1190 841]"); fprintf(psfile,"%s\n",buff);                                          // A3
  strcpy(buff,"   /Policies << /PageSize 6 >>"); fprintf(psfile,"%s\n",buff);                                   // A3
  strcpy(buff,">> setpagedevice"); fprintf(psfile,"%s\n",buff);                                                 // A3
  strcpy(buff,"/pg save def"); fprintf(psfile,"%s\n",buff);                                                     // Page Header 1
  sprintf(buff,"/Courier-Bold findfont %5.2f scalefont setfont",ps_font_size); fprintf(psfile,"%s\n",buff);     // Page Header 1

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if(rmap_out == 1)                                                                                             // Regular display
   {
   ////////////////////////////////////////////////////////////////////////////////////////  CAPTION page # etc
   sfrom = initial_fold_of_page[pp]*dmap_out_width;
   sto   = initial_fold_of_page[pp+1]*dmap_out_width;
   vert_pos = ps_height - ps_head_cap_y;
   hor_pos  = ps_width  - ps_head_cap_x;
   sprintf(buff,"PAGE   %d of %d      FOLD   %d-%d of %d     SEQUENCE  %d-%d of %d   ",
                pp+1,n_page, initial_fold_of_page[pp],initial_fold_of_page[pp+1],dmap_fold,sfrom,sto,refseq_len);
   sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
   sprintf(ps_buff,"%f %f mv (%s)show",hor_pos,vert_pos,buff); fprintf(psfile,"%s\n",ps_buff);
   sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
   //printf("%s\n",buff);
   /////////////////////////////////////////////////////////////////////////////////////////  CAPTION page # etc
   vert_pos = ps_height - (ps_top_margin);
   for(i=initial_fold_of_page[pp];i<initial_fold_of_page[pp+1];i++)                                             // PFL = Page Fold Loop 
    {
    sfrom = i * dmap_out_width;
    sto   = (i+1) * dmap_out_width -1;
    if(sto > refseq_len)
     sto = refseq_len;

    line_width = a_width * pixel_size;
    line_height = pixel_size;
    hor_pos  = ps_left_margin + (c_width + c_a_gap) * pixel_size;
    
///////////////////////////////// DRAW BASELINE ///////////////////////////////////////////
    sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"%f %f moveto",hor_pos,vert_pos); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"%f 0.0 rlineto",line_width); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
///////////////////////////////// Draw baseline \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

///////////////////////////////// DRAW TIC & POSITION /////////////////////////////////////
    for(j=sfrom;j<sto;j++)
     {
     if(j%100 == 0)
      {
      sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"0.0 %f rlineto",tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);  // GLAY   
      sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

      sprintf(buff,"%d",j);
      sprintf(ps_buff,"%f %f mv (%s)show",hor_pos+((j-sfrom)*pixel_size)+1.0,vert_pos+1.5,buff); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
      }
     if(ggc_marker == 1)
      {
      if((refseq[j-3] == 'G') && (refseq[j-2] == 'G') && (refseq[j-1] == 'C'))
       {
       sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
//       if((refseq[j-4] == 'C') || (refseq[j-4] == 'T'))
        {
        if(
           ((refseq[j] == 'A') && (refseq[j-4] == 'C')) ||
           ((refseq[j] == 'G') && (refseq[j-4] == 'C')) ||
           ((refseq[j] == 'T') && (refseq[j-4] == 'C')) ||
           ((refseq[j] == 'G') && (refseq[j-4] == 'T')) ||
           ((refseq[j] == 'T') && (refseq[j-4] == 'T')))
//           ((refseq[j] == 'G') && (refseq[j+1] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'C') && (refseq[j+2] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'G') && (refseq[j+2] == 'C')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'T') && (refseq[j+2] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'A') && (refseq[j+2] == 'C')) ||
//           ((refseq[j] == 'A') && (refseq[j+1] == 'G') && (refseq[j+2] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'G') && (refseq[j+2] == 'G')) ||
//           ((refseq[j] == 'G') && (refseq[j+1] == 'A') && (refseq[j+2] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'C') && (refseq[j+2] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'G') && (refseq[j+2] == 'G') && (refseq[j+3] == 'G')) ||
//           ((refseq[j] == 'A') && (refseq[j+1] == 'G') && (refseq[j+2] == 'G') && (refseq[j+3] == 'G')) ||
//           ((refseq[j] == 'G') && (refseq[j+1] == 'C') && (refseq[j+2] == 'G') && (refseq[j+3] == 'G')) ||
//           ((refseq[j] == 'T') && (refseq[j+1] == 'C') && (refseq[j+2] == 'G') && (refseq[j+3] == 'G') && (refseq[j+4] == 'G')) ||
//           ((refseq[j] == 'G') && (refseq[j+1] == 'A') && (refseq[j+2] == 'G') && (refseq[j+3] == 'C') && (refseq[j+4] == 'G')) ||
//           ((refseq[j] == 'G') && (refseq[j+1] == 'A') && (refseq[j+2] == 'A') && (refseq[j+3] == 'A') && (refseq[j+4] == 'A') && (refseq[j+5] == 'G')))
         {sprintf(ps_buff,"0.0 %f rlineto",2.0*tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);}
        else
         {sprintf(ps_buff,"0.0 %f rlineto",1.0*tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);}
        }
//       else
//        {sprintf(ps_buff,"0.0 %f rlineto",1.0*tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);}
       sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"1.0 0.0 1.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);  // MAGENTA
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       n_ggc ++;
       }
      if((refseq[j+1] == 'G') && (refseq[j+2] == 'C') && (refseq[j+3] == 'C'))
       {
       sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
       if((refseq[j+4] == 'G') || (refseq[j+4] == 'A'))
        {
        if(
           ((refseq[j] == 'C') && (refseq[j-1] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'G') && (refseq[j-2] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'C') && (refseq[j-2] == 'G')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'A') && (refseq[j-2] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'T') && (refseq[j-2] == 'G')) ||
           ((refseq[j] == 'T') && (refseq[j-1] == 'C') && (refseq[j-2] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'C') && (refseq[j-2] == 'C')) ||
           ((refseq[j] == 'C') && (refseq[j-1] == 'T') && (refseq[j-2] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'G') && (refseq[j-2] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'C') && (refseq[j-2] == 'C') && (refseq[j-3] == 'C')) ||
           ((refseq[j] == 'T') && (refseq[j-1] == 'C') && (refseq[j-2] == 'C') && (refseq[j-3] == 'C')) ||
           ((refseq[j] == 'C') && (refseq[j-1] == 'G') && (refseq[j-2] == 'C') && (refseq[j-3] == 'C')) ||
           ((refseq[j] == 'A') && (refseq[j-1] == 'G') && (refseq[j-2] == 'C') && (refseq[j-3] == 'C') && (refseq[j-4] == 'C')) ||
           ((refseq[j] == 'C') && (refseq[j-1] == 'T') && (refseq[j-2] == 'C') && (refseq[j-3] == 'G') && (refseq[j-4] == 'C')) ||
           ((refseq[j] == 'C') && (refseq[j-1] == 'T') && (refseq[j-2] == 'T') && (refseq[j-3] == 'T') && (refseq[j-4] == 'T') && (refseq[j-5] == 'C')))
         {sprintf(ps_buff,"0.0 %f rlineto",2.0*tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);}
        else
         {sprintf(ps_buff,"0.0 %f rlineto",1.0*tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);}
        }
       else
        {sprintf(ps_buff,"0.0 %f rlineto",1.0*tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);}
       sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"0.0 1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);  // LIME GREEN
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       n_gcc ++;
       }
      }
     }
///////////////////////////////// Draw tic & position \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

///////////////////////////////// DRAW GENES //////////////////////////////////////////////
    if((read_gb == 1) || (read_ge == 1))
     {
     for(j=0;j<n_gene;j++)
      {
      csp = chromosomes[gbs[j].chr_id].start_position;
      if((gbs[j].from == 0) || (gbs[j].to == 0))
       continue;
      if(((gbs[j].from + csp) >= sfrom) && ((gbs[j].from + csp) <= sto))
       {
////////////////// GENE NAME ///////////////
       cap_space = gbs[j].to - gbs[j].from;
       if(sto < (gbs[j].to+csp))
        cap_space = sto - ((gbs[j].from+csp)-sfrom);

        if(cap_space > (strlen(gbs[j].locus_tag) + strlen(gbs[j].product_name)) * (gene_font_size*char_hw_ratio) / bit_width)
         sprintf(buff,">%s_%s",gbs[j].locus_tag,gbs[j].product_name);
        else
         sprintf(buff,">%s",gbs[j].locus_tag);

       for(k=0;k<strlen(buff);k++)                                  // Remove Parentheses from the text
        {
        if(buff[k] == ')')
         buff[k] = '}';                                             // Remove Parentheses from the text
        if(buff[k] == '(')
         buff[k] = '{';                                             // Remove Parentheses from the text
        }
       sprintf(ps_buff,"0.5   0.5   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // gray
       sprintf(ps_buff,"%f %f mv (%s)show",hor_pos+(((gbs[j].from+csp)-sfrom)*pixel_size)+1.0,
                                           vert_pos+ps_font_size*1.5+((double)(j%2)*ps_font_size),buff); 
       fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
////////////////// Gene name \\\\\\\\\\\\\\\

       switch (gbs[j].type)
        {
        case 1:
         sprintf(ps_buff,"0.0   1.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Cyan
         break;
        case 2:
         sprintf(ps_buff,"1.0   0.65  0.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Orange
         break;
        case 3:
         sprintf(ps_buff,"1.0   0.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Magenta
         break;
        case 4:
         sprintf(ps_buff,"0.5   0.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Purple
         break;
        case 5:
         sprintf(ps_buff,"0.0   1.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Green 
         break;
        default:
         sprintf(ps_buff,"0.65  0.165 0.165 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Brown
         break;
        }
       if(gbs[j].complement == 0)
         { sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff); }
       else
         { sprintf(ps_buff,"%f setlinewidth",pixel_size/2.0); fprintf(psfile,"%s\n",ps_buff); }
       sprintf(ps_buff,"%f %f moveto",hor_pos+(((gbs[j].from+csp)-sfrom)*pixel_size), vert_pos+ps_font_size+1.5+((double)(j%2)*ps_font_size)); 
       fprintf(psfile,"%s\n",ps_buff);
       if((gbs[j].to + csp) <= sto)
        { sprintf(ps_buff,"%f 0.0 rlineto",(gbs[j].to-gbs[j].from)*pixel_size); fprintf(psfile,"%s\n",ps_buff); }
       else
        { sprintf(ps_buff,"%f 0.0 rlineto",(sto-(gbs[j].from+csp))*pixel_size); fprintf(psfile,"%s\n",ps_buff); }
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }

      if(((gbs[j].to + csp) >= sfrom) && ((gbs[j].to + csp) <= sto))
       {
       if((gbs[j].from + csp) <= sfrom)
        {
        switch (gbs[j].type)
         {
         case 1:
          sprintf(ps_buff,"0.0   1.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Cyan
          break;
         case 2:
          sprintf(ps_buff,"1.0   0.65  0.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Orange
          break;
         case 3:
          sprintf(ps_buff,"1.0   0.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Magenta
          break;
         case 4:
          sprintf(ps_buff,"0.5   0.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Purple
          break;
         case 5:
          sprintf(ps_buff,"0.0   1.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Green
          break;
         default:
          sprintf(ps_buff,"0.65  0.165 0.165 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Brown
          break;
         }
        if(gbs[j].complement == 0)
          { sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff); }
        else
          { sprintf(ps_buff,"%f setlinewidth",pixel_size/2.0); fprintf(psfile,"%s\n",ps_buff); }
        sprintf(ps_buff,"%f %f moveto",hor_pos, vert_pos+ps_font_size+1.5+((double)(j%2)*ps_font_size));
        fprintf(psfile,"%s\n",ps_buff);
        sprintf(ps_buff,"%f 0.0 rlineto",(gbs[j].to+csp-sfrom)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
        sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
        }
       }

      if(((gbs[j].from + csp) <= sfrom) && ((gbs[j].to + csp) >= sto))    // THROUGH GENE (HUGE)
       {
       switch (gbs[j].type)
        {
        case 1:
         sprintf(ps_buff,"0.0   1.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Cyan
         break;
        case 2:
         sprintf(ps_buff,"1.0   0.65  0.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Orange
         break;
        case 3:
         sprintf(ps_buff,"1.0   0.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Magenta
         break;
        case 4:
         sprintf(ps_buff,"0.5   0.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Purple
         break;
        case 5:
         sprintf(ps_buff,"0.0   1.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Green
         break;
        default:
         sprintf(ps_buff,"0.65  0.165 0.165 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Brown
         break;
        }
       if(gbs[j].complement == 0)
        { sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff); }
       else
        { sprintf(ps_buff,"%f setlinewidth",pixel_size/2.0); fprintf(psfile,"%s\n",ps_buff); }
       sprintf(ps_buff,"%f %f moveto",hor_pos, vert_pos+ps_font_size+1.5+((double)(j%2)*ps_font_size));
       fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f 0.0 rlineto",(sto-sfrom)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }
   
      if(show_exon == 1)
       {
       for(k=0;k<gbs[j].n_mrna;k++)
        {
        for(l=0;l<gbs[j].mrnas[k].n_segment;l++)
         {
         if(((gbs[j].mrnas[k].froms[l]+csp)>=sfrom)&&((gbs[j].mrnas[k].froms[l]+csp)<=sto))
          {
          if((gbs[j].mrnas[k].tos[l]+csp) <= sto)
           {
           sprintf(ps_buff,"0.0  1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Lime green
           sprintf(ps_buff,"%f setlinewidth",0.4*pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           sprintf(ps_buff,"%f %f moveto",hor_pos+((gbs[j].mrnas[k].froms[l]+csp)-sfrom)*pixel_size, vert_pos+((2*k+2)*pixel_size));
           fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",(gbs[j].mrnas[k].tos[l]-gbs[j].mrnas[k].froms[l])*pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          else
           {
           sprintf(ps_buff,"0.0  1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Lime green
           sprintf(ps_buff,"%f setlinewidth",0.4*pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           sprintf(ps_buff,"%f %f moveto",hor_pos+((gbs[j].mrnas[k].froms[l]+csp)-sfrom)*pixel_size, vert_pos+((2*k+2)*pixel_size));
           fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",(sto-(gbs[j].mrnas[k].froms[l]+csp))*pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          }
         else
          {
          if(((gbs[j].mrnas[k].tos[l]+csp) >= sfrom) && ((gbs[j].mrnas[k].tos[l]+csp) <= sto))
           {
           sprintf(ps_buff,"0.0  1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Lime green
           sprintf(ps_buff,"%f setlinewidth",0.4*pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           sprintf(ps_buff,"%f %f moveto",hor_pos, vert_pos+((2*k+2)*pixel_size));
           fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",((gbs[j].mrnas[k].tos[l]+csp)-sfrom)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          }
         }
        }
       }
      }
     }

///////////////////////////////// Draw genes \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

///////////////////////////////// DRAW ALLIGNMENTS ////////////////////////////////////////
    if(bit_exact == 1)
     {
     max_depth_of_the_fold = 0;
     for(j=sfrom-query_len;j<=sto;j++)
      {
      if(j<0)
       j=0;
      for(l=0;l<position_hits[j].n_hit;l++)
       {
       if(position_hits[j].boxs[l]+1 > max_depth_of_the_fold)
        max_depth_of_the_fold = position_hits[j].boxs[l]+1;
       }
      }
     if(max_depth_of_the_fold >= MAX_BOX)
      max_depth_of_the_fold = MAX_BOX - 5;

     for(k=0;k<max_depth_of_the_fold + 2;k++)
      {
      ps_y = vert_pos - ((pixel_size*r_q_gap) +  (k * (pixel_size+ps_q_q_gap)));
      for(j=sfrom-query_len;j<=sto;j++)
       {
       if(j<0)
        j=0;
       ps_x = ps_left_margin + (c_width * c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
       for(l=0;l<position_hits[j].n_hit;l++)
        {
        if(position_hits[j].boxs[l] == k)
         {
         box_hit[k] = position_hits[j].hits[l];
         box_cnt[k] = query_len;
         }
        }
       if(box_cnt[k] == 1)
        {
        box_hit[k] = MAX_INT;
        }
       if(box_cnt[k] >= 1)
        {
        box_cnt[k] --;
        }
       if(show_quality == 1)                                // クォリティ表示
        {
        if(box_hit[k] != MAX_INT)
         {
         if(j>sfrom)
          {
          if(box_hit[k] > 0)                                 // 順方向ヒット
           {
           sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           qv = (int)qs[abs(box_hit[k])].quality[query_len-box_cnt[k]-1] - offset;
           {sprintf(ps_buff,"%f 0.0 0.0 setrgbcolor",(float)qv/max_quality); fprintf(psfile,"%s\n",ps_buff);}
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          else                                               // 逆方向ヒット
           {
           sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           qv = (int)qs[abs(box_hit[k])].cuality[query_len-box_cnt[k]] - offset;
           {sprintf(ps_buff,"0.0 %f 0.0 setrgbcolor",(float)qv/max_quality); fprintf(psfile,"%s\n",ps_buff);}
          sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          }
         }
        }
       else
        {
        if(box_hit[k] != MAX_INT)
         {
         if(box_hit[k] > 0)                                 // 順方向ヒット
          {
          if(box_cnt[k] == query_len-1)                     // マッチについてはとりあえず灰色線を引く　あとでミスマッチだけ赤点を打つ
           {
           if((j>sfrom)&&((sto - j) <= query_len))
            {
            sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
            sprintf(ps_buff,"%f 0.0 rlineto",pixel_size*(sto-j+1)); fprintf(psfile,"%s\n",ps_buff);
            sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
            sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
            sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
            n_match += sto-j+1;
            }
           else
            {
            if(j<sfrom)
             {
             sprintf(ps_buff,"%f %f moveto",ps_x-((j-sfrom)*pixel_size),ps_y); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f 0.0 rlineto",pixel_size*query_len-((sfrom-j-1)*pixel_size)); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
             sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
             n_match += query_len-(sfrom-j-1);
             }
            else
             {
             sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f 0.0 rlineto",pixel_size*query_len); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
             sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
             n_match += query_len;
             }
            }
           }
          else
           {
           if(!((qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == refseq[j]) ||
                (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == 'N') || (qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1] == '.')))
            {                                                 // ミスマッチ
            if(j>sfrom)
             {
             sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f 0.0 rlineto",pixel_size); fprintf(psfile,"%s\n",ps_buff);
              sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
             if(mismatchcolor == 1)
              {
              switch(qs[abs(box_hit[k])].seq[query_len-box_cnt[k]-1])
               {
               case 'T':
                sprintf(ps_buff,"0.8 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // red
               case 'A':
                sprintf(ps_buff,"0.8 0.6 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // orange
               case 'G':
                sprintf(ps_buff,"0.0 0.8 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // green
               case 'C':
                sprintf(ps_buff,"0.0 0.7 0.7 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // cyan
               default:
                sprintf(ps_buff,"0.8 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;
               }
              }
             else
               {sprintf(ps_buff,"0.8 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);}
             sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
             n_mmatch ++;
             }
            }
           }
          }
         else                                                 //逆方向ヒット
          {
          if(box_cnt[k] == query_len-1)                       //マッチについてはとりあえず灰色線を引き　あとでミスマッチだけ赤点を打つ
           {
           if((j>sfrom)&&((sto - j) <= query_len))
            {
            sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
            sprintf(ps_buff,"%f 0.0 rlineto",pixel_size*(sto-j+1)); fprintf(psfile,"%s\n",ps_buff);
            sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
            sprintf(ps_buff,"0.7 0.7 0.7 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
            sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
            n_match += sto-j+1;
            }
           else
            {
            if(j<sfrom)
             {
             sprintf(ps_buff,"%f %f moveto",ps_x-((j-sfrom)*pixel_size),ps_y); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f 0.0 rlineto",pixel_size*query_len-((sfrom-j-1)*pixel_size)); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
             sprintf(ps_buff,"0.7 0.7 0.7 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
             n_match += query_len-(sfrom-j-1);
             }
            else
             {
             sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f 0.0 rlineto",pixel_size*query_len); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
             sprintf(ps_buff,"0.7 0.7 0.7 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
             n_match += query_len;
             }
            }
           }
          else
           {
           if(!((qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == refseq[j]) ||
                (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == 'N') || (qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1) == '.')))
            {
            if(j>sfrom)
             {
             sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f 0.0 rlineto",pixel_size); fprintf(psfile,"%s\n",ps_buff);
             sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
             if(mismatchcolor == 1)
              {
              switch(qs_ceq(abs(box_hit[k]),query_len-box_cnt[k]-1))
               {
               case 'T':
                sprintf(ps_buff,"0.8 0.3 0.3 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // red
               case 'A':
                sprintf(ps_buff,"0.8 0.6 0.3 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // orange
               case 'G':
                sprintf(ps_buff,"0.3 0.8 0.3 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // green
               case 'C':
                sprintf(ps_buff,"0.3 0.7 0.7 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;  // cyan
               default:
                sprintf(ps_buff,"0.8 0.3 0.3 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff); break;
               }
              }
             else
              {sprintf(ps_buff,"0.8 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);}
             sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
             n_mmatch++;
             }
            }
           }
          }
       
         }
        }
       }
      }
     }
    else
     {

     }
///////////////////////////////// Draw allignments \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

///////////////////////////////// PIXEL CHECK /////////////////////////////////////////////
//    sprintf(ps_buff,"%f %f moveto",hor_pos,vert_pos+5.0); fprintf(psfile,"%s\n",ps_buff);
//    sprintf(ps_buff,"%f 0.0 rlineto",pixel_size); fprintf(psfile,"%s\n",ps_buff);
//    sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
//    sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
//
//    sprintf(ps_buff,"%f %f moveto",hor_pos,vert_pos+pixel_size); fprintf(psfile,"%s\n",ps_buff);
//    sprintf(ps_buff,"%f 0.0 rlineto",pixel_size); fprintf(psfile,"%s\n",ps_buff);
//    sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
//    sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
///////////////////////////////// PIXEL CHECK \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//    printf("SHOW_POP = %d\n",show_pop);
    if(show_av_qual !=0)
     {
     }

    if(show_mm_ratio !=0)
     {
     }

    if(show_pop==1)
     {
     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);                     // line width 0.7
       sprintf(ps_buff,"0.0 0.0 1.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                            // BLUE color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_order * pixel_size);
       if(func_position_hits_f_match(j)*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - (func_position_hits_f_match(j) * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - (chop_limit);
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_order * pixel_size);
       if(func_position_hits_f_match(j)*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - (func_position_hits_f_match(j) * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);                      // line width 0.7
       sprintf(ps_buff,"1.0 0.6 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                             // ORANGE color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_r_match(j)*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - (func_position_hits_r_match(j) * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_r_match(j)*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - (func_position_hits_r_match(j) * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
     }

    vert_pos -= (a_height[i] + ps_a_a_gap) * pixel_size;
    }                                                                                                           // END PFL Page Fold Loop

   }                                                                                                            // END Regular display
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if(hmap_out == 1)                                                                                             // Histogram display
   {                                       
   ////////////////////////////////////////////////////////////////////////////////////////  CAPTION page # etc
   sfrom = initial_fold_of_page[pp]*dmap_out_width;
   sto   = initial_fold_of_page[pp+1]*dmap_out_width;
   if(sto > histogram_length)
    sto=histogram_length;
   ffrom = initial_fold_of_page[pp]*dmap_out_width*base_per_pixel;
   fto = initial_fold_of_page[pp+1]*dmap_out_width*base_per_pixel-1;
   if(fto > refseq_len)
    fto = refseq_len;
   vert_pos = ps_height - ps_head_cap_y;
   hor_pos  = ps_width  - ps_head_cap_x;
   sprintf(buff,"PAGE   %d of %d      FOLD   %d-%d of %d     POSITION %d-%d of %d SEQUENCE  %d-%d of %d   ",
                pp+1,n_page, initial_fold_of_page[pp],initial_fold_of_page[pp+1],dmap_fold,sfrom,sto,histogram_length,ffrom,fto,refseq_len);
   sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
   sprintf(ps_buff,"%f %f mv (%s)show",hor_pos,vert_pos,buff); fprintf(psfile,"%s\n",ps_buff);
   sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
   //printf("%s\n",buff);
   /////////////////////////////////////////////////////////////////////////////////////////  CAPTION page # etc
   vert_pos = ps_height - (ps_top_margin);
   for(i=initial_fold_of_page[pp];i<initial_fold_of_page[pp+1];i++)                                             // PFL = Page Fold Loop
    {
    sfrom = i * dmap_out_width;
    sto   = (i+1) * dmap_out_width -1;
    if(sto > histogram_length)
     {
     sto = histogram_length;
     }
    ffrom = i*dmap_out_width * base_per_pixel;
    fto = i*dmap_out_width * base_per_pixel - 1;
    hor_pos  = ps_left_margin + (c_width + c_a_gap) * pixel_size;
    line_width = (sto-sfrom) * pixel_size;
    sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"%f %f moveto",hor_pos,vert_pos); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"%f 0.0 rlineto",line_width); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
    sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
    for(j=sfrom;j<sto;j++)
     {
     current_chr = 0;
     for(k=0;k<n_chromosomes;k++)
      if((j*base_per_pixel) > chromosomes[k].start_position)
       current_chr = k;
     pos_in_chr = j - (chromosomes[current_chr].start_position / base_per_pixel);
     if(pos_in_chr%100 == 0)
      {
      sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"0.0 %f rlineto",tic_height100*pixel_size); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"%f setlinewidth",pixel_size); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
      if(pos_in_chr != 0)
       {
       sprintf(buff,"%d",pos_in_chr*base_per_pixel);
       sprintf(ps_buff,"%f %f mv (%s)show",hor_pos+((j-sfrom)*pixel_size)+1.0,vert_pos+1.5,buff); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     if(pos_in_chr == 1)
      {
      sprintf(ps_buff,"1.0 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"0.0 %f rlineto",tic_height100*10.0*pixel_size); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"%f setlinewidth",pixel_size*5); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"0.3 0.3 0.3 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
      sprintf(buff,"%s",chromosomes[current_chr].title);
      sprintf(ps_buff,"%f %f mv (%s)show",hor_pos+((j-sfrom)*pixel_size)+1.0,vert_pos+tic_height100*8.0*pixel_size,buff); fprintf(psfile,"%s\n",ps_buff);
      sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
      }
     if(no_histo_bar == 0)
      {
      if(log_scale == 0)
       {
       //MATCH
       sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"0.0 %f rlineto",-(double)count_per_pixel[j]/(double)base_per_pixel*height_scale*pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f setlinewidth",pixel_size*hist_ratio); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       //MISMATCH
       sprintf(ps_buff,"1.0 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"0.0 %f rlineto",-(double)count_per_pixel_mm[j]/(double)base_per_pixel*height_scale*pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f setlinewidth",pixel_size*hist_ratio); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       //MATCH
       sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
//  if(count_per_pixel_f[j] > max_height)
//   ps_y = vert_pos - (double)max_height/(double)base_per_pixel*height_scale*pixel_size;
//  else
//   ps_y = vert_pos - (double)count_per_pixel_f[j]/(double)base_per_pixel*height_scale*pixel_size;

       sprintf(ps_buff,"0.0 %f rlineto",-(log((double)count_per_pixel[j]/(double)base_per_pixel))*height_scale*pixel_size); fprintf(psfile,"%s\n",ps_buff);

       sprintf(ps_buff,"%f setlinewidth",pixel_size*hist_ratio); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       //MISMATCH
       sprintf(ps_buff,"1.0 0.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f %f moveto",hor_pos+((j-sfrom)*pixel_size),vert_pos); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"0.0 %f rlineto",-(log((double)count_per_pixel_mm[j]/(double)base_per_pixel))*height_scale*pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f setlinewidth",pixel_size*hist_ratio); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     }

    if((read_gb == 1) || (read_ge == 1))
     {
     for(j=0;j<n_gene;j++)
      {
      csp = chromosomes[gbs[j].chr_id].start_position;

      if(((gbs[j].from+csp)/base_per_pixel >= sfrom) && ((gbs[j].from+csp)/base_per_pixel <= sto))
       {
       cap_space = (gbs[j].to+csp)/base_per_pixel - (gbs[j].from+csp)/base_per_pixel;
       if(sto < (gbs[j].to+csp)/base_per_pixel)
        cap_space = sto - ((gbs[j].from+csp)/base_per_pixel - sfrom);
       if(cap_space > (strlen(gbs[j].locus_tag) + strlen(gbs[j].product_name)) * (gene_font_size*char_hw_ratio) / bit_width)
        sprintf(buff,">%s_%s",gbs[j].locus_tag,gbs[j].product_name);
       else
        sprintf(buff,">%s",gbs[j].locus_tag);
       if(no_gene_caption == 0)
        {
       for(k=0;k<strlen(buff);k++)                                  // Remove Parentheses from the text
        {
        if(buff[k] == ')')
         buff[k] = '}';                                             // Remove Parentheses from the text
        if(buff[k] == '(')
         buff[k] = '{';                                             // Remove Parentheses from the text
        }
        sprintf(ps_buff,"0.5 0.5 0.5 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);
        sprintf(ps_buff,"%f %f mv (%s)show",
                hor_pos+(((double)(gbs[j].from+csp)/(double)base_per_pixel-(double)sfrom)*pixel_size)+1.0,
                vert_pos+ps_font_size*1.5+(j%2)*ps_font_size,buff); 
        fprintf(psfile,"%s\n",ps_buff);
        sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
        }
       switch (gbs[j].type)
        {
        case 1:
         sprintf(ps_buff,"0.0   1.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Cyan
         break;
        case 2:
         sprintf(ps_buff,"1.0   0.65  0.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Orange
         break;
        case 3:
         sprintf(ps_buff,"1.0   0.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Magenta
         break;
        case 4:
         sprintf(ps_buff,"0.5   0.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Purple
         break;
        case 5:
         sprintf(ps_buff,"0.0   1.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Green
         break;
        default:
         sprintf(ps_buff,"0.65  0.165 0.165 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Brown
         break;
        }
       if(gbs[j].complement == 0)
         { sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff); }
       else
         { sprintf(ps_buff,"%f setlinewidth",pixel_size/2.0); fprintf(psfile,"%s\n",ps_buff); }

       sprintf(ps_buff,"%f %f moveto",hor_pos+(((double)(gbs[j].from+csp)/(double)base_per_pixel-(double)sfrom)*pixel_size), 
               vert_pos+ps_font_size+1.5+((double)(j%2)*ps_font_size));
       fprintf(psfile,"%s\n",ps_buff);

       if(((gbs[j].to + csp)/base_per_pixel) <= sto)
        { sprintf(ps_buff,"%f 0.0 rlineto",(double)(gbs[j].to-gbs[j].from)/(double)base_per_pixel*pixel_size); fprintf(psfile,"%s\n",ps_buff); }
       else
        { sprintf(ps_buff,"%f 0.0 rlineto",(sto-(gbs[j].from+csp)/base_per_pixel)*pixel_size); fprintf(psfile,"%s\n",ps_buff); }
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }

      if(((gbs[j].to + csp)/base_per_pixel >= sfrom) && ((gbs[j].to + csp)/base_per_pixel <= sto))
       {
       if((gbs[j].from + csp)/base_per_pixel <= sfrom)
        {
        switch (gbs[j].type)
         {
         case 1:
          sprintf(ps_buff,"0.0   1.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Cyan
          break;
         case 2:
          sprintf(ps_buff,"1.0   0.65  0.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Orange
          break;
         case 3:
          sprintf(ps_buff,"1.0   0.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Magenta
          break;
         case 4:
          sprintf(ps_buff,"0.5   0.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Purple
          break;
         case 5:
          sprintf(ps_buff,"0.0   1.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Green
          break;
         default:
          sprintf(ps_buff,"0.65  0.165 0.165 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Brown
          break;
         }
        if(gbs[j].complement == 0)
          { sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff); }
        else
          { sprintf(ps_buff,"%f setlinewidth",pixel_size/2.0); fprintf(psfile,"%s\n",ps_buff); }

        sprintf(ps_buff,"%f %f moveto",hor_pos, vert_pos+ps_font_size+1.5+((double)(j%2)*ps_font_size));
        fprintf(psfile,"%s\n",ps_buff);
        sprintf(ps_buff,"%f 0.0 rlineto",((gbs[j].to+csp)/base_per_pixel-sfrom)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
        sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
        }
       }

      if(((gbs[j].from + csp)/base_per_pixel <= sfrom) && ((gbs[j].to + csp)/base_per_pixel >= sto))    // THROUGH GENE (HUGE)
       {
       switch (gbs[j].type)
        {
        case 1:
         sprintf(ps_buff,"0.0   1.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Cyan
         break;
        case 2:
         sprintf(ps_buff,"1.0   0.65  0.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Orange
         break;
        case 3:
         sprintf(ps_buff,"1.0   0.0   1.0   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Magenta
         break;
        case 4:
         sprintf(ps_buff,"0.5   0.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Purple
         break;
        case 5:
         sprintf(ps_buff,"0.0   1.0   0.5   setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Green
         break;
        default:
         sprintf(ps_buff,"0.65  0.165 0.165 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Brown
         break;
        }
       if(gbs[j].complement == 0)
        { sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff); }
       else
        { sprintf(ps_buff,"%f setlinewidth",pixel_size/2.0); fprintf(psfile,"%s\n",ps_buff); }
       sprintf(ps_buff,"%f %f moveto",hor_pos, vert_pos+ps_font_size+1.5+((double)(j%2)*ps_font_size));
       fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"%f 0.0 rlineto",(sto-sfrom)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
       sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
       }


      if(show_exon == 1)
       {
       for(k=0;k<gbs[j].n_mrna;k++)
        {
        for(l=0;l<gbs[j].mrnas[k].n_segment;l++)
         {
         if(((gbs[j].mrnas[k].froms[l]+csp)/base_per_pixel>=sfrom)&&((gbs[j].mrnas[k].froms[l]+csp)/base_per_pixel<=sto))
          {
          if((gbs[j].mrnas[k].tos[l]+csp)/base_per_pixel <= sto)
           {
           sprintf(ps_buff,"0.0  1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Lime green
           sprintf(ps_buff,"%f setlinewidth",0.2*pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           sprintf(ps_buff,"%f %f moveto",hor_pos+((gbs[j].mrnas[k].froms[l]+csp)/base_per_pixel-sfrom)*pixel_size, vert_pos+((2*k+2)*pixel_size));
           fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",(gbs[j].mrnas[k].tos[l]-gbs[j].mrnas[k].froms[l])/base_per_pixel*pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          else
           {
           sprintf(ps_buff,"0.0  1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Lime green
           sprintf(ps_buff,"%f setlinewidth",0.2*pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           sprintf(ps_buff,"%f %f moveto",hor_pos+((gbs[j].mrnas[k].froms[l]+csp)/base_per_pixel-sfrom)*pixel_size, vert_pos+((2*k+2)*pixel_size));
           fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",(sto-(gbs[j].mrnas[k].froms[l]+csp)/base_per_pixel)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          }
         else
          {
          if(((gbs[j].mrnas[k].tos[l]+csp)/base_per_pixel >= sfrom) && ((gbs[j].mrnas[k].tos[l]+csp)/base_per_pixel <= sto))
           {
           sprintf(ps_buff,"0.0  1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);   // Lime green
           sprintf(ps_buff,"%f setlinewidth",0.2*pixel_size); fprintf(psfile,"%s\n",ps_buff); // line width 1pixel
           sprintf(ps_buff,"%f %f moveto",hor_pos, vert_pos+((2*k+2)*pixel_size));
           fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"%f 0.0 rlineto",((gbs[j].mrnas[k].tos[l]+csp)/base_per_pixel-sfrom)*pixel_size); fprintf(psfile,"%s\n",ps_buff);
           sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
           }
          }
         }
        }
       }
      }
     }


    if(show_av_qual !=0)
     {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*2.0); fprintf(psfile,"%s\n",ps_buff);                      // line width 0.7
       sprintf(ps_buff,"0.0 1.0 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                             // BLUE   color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size-5.0;
       ps_y = vert_pos - (pixel_size*r_q_gap);
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)((float)show_av_qual)* pixel_size);
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size-2.5;
       ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)((float)show_av_qual)* pixel_size);
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)((float)show_av_qual)* pixel_size*2.0);
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);                      // line width 0.7
       sprintf(ps_buff,"0.0 0.4 0.8 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                             // BLUE   color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_f_match(j)+func_position_hits_f_mismatch(j) != 0)
        plot_value = ((float)(func_position_quality(j)) / (float)(func_position_hits_f_match(j) + func_position_hits_f_mismatch(j)) * (float)show_av_qual/40.0) + show_av_qual;
       else
        plot_value = 0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_f_match(j)+func_position_hits_f_mismatch(j) != 0)
        plot_value = ((float)(func_position_quality(j)) / (float)(func_position_hits_f_match(j) + func_position_hits_f_mismatch(j)) * (float)show_av_qual/40.0) + show_av_qual;
       else
        plot_value = 0.0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);                      // line width 0.7
       sprintf(ps_buff,"0.0 0.6 0.2 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                             // GREEN  color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_r_match(j)+func_position_hits_r_mismatch(j) != 0)
        plot_value = ((float)(func_position_cuality(j)) / (float)(func_position_hits_r_match(j) + func_position_hits_r_mismatch(j)) * (float)show_av_qual/40.0) + show_av_qual;
       else
        plot_value = 0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_r_match(j)+func_position_hits_r_mismatch(j) != 0)
        plot_value = ((float)(func_position_cuality(j)) / (float)(func_position_hits_r_match(j) + func_position_hits_r_mismatch(j)) * (float)show_av_qual/40.0) + show_av_qual;
       else
        plot_value = 0.0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

     }


    if(show_mm_ratio !=0)
     {
     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);                      // line width 0.7
       sprintf(ps_buff,"1.0 0.2 0.8 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                             // MAGENTA color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_f_match(j)+func_position_hits_f_mismatch(j) != 0)
        plot_value = (float)(func_position_hits_f_mismatch(j)) / (float)(func_position_hits_f_match(j) + func_position_hits_f_mismatch(j)) * (float)show_mm_ratio;
       else
        plot_value = 0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_f_match(j)+func_position_hits_f_mismatch(j) != 0)
        plot_value = (float)(func_position_hits_f_mismatch(j)) / (float)(func_position_hits_f_match(j) + func_position_hits_f_mismatch(j)) * (float)show_mm_ratio;
       else
        plot_value = 0.0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);                      // line width 0.7
       sprintf(ps_buff,"1.0 0.6 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);                             // ORANGE color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_r_match(j)+func_position_hits_r_mismatch(j) != 0)
        plot_value = (float)(func_position_hits_r_mismatch(j)) / (float)(func_position_hits_r_match(j) + func_position_hits_r_mismatch(j)) * (float)show_mm_ratio;
       else
        plot_value = 0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
//       ps_y = vert_pos - (pixel_size*r_q_gap) - (position_hits[j].n_complement * pixel_size);
       if(func_position_hits_r_match(j)+func_position_hits_r_mismatch(j) != 0)
        plot_value = (float)(func_position_hits_r_mismatch(j)) / (float)(func_position_hits_r_match(j) + func_position_hits_r_mismatch(j)) * (float)show_mm_ratio;
       else
        plot_value = 0.0;
       if((int)plot_value*pixel_size < chop_limit)
        ps_y = vert_pos - (pixel_size*r_q_gap) - ((int)plot_value * pixel_size);
       else
        ps_y = vert_pos - (pixel_size*r_q_gap) - chop_limit;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

     }


    if(show_pop==1)                                                                                   /////////// SHOW POPULATION LINE FORWARD vs REV_COMPLEMENT OSHIMASANs request
     {
     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);       // line width 0.7 
       sprintf(ps_buff,"0.0 0.0 1.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);              // BLUE color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
       if((double)count_per_pixel_f[j]/(double)base_per_pixel > (double)max_height)
        ps_y = vert_pos - (double)max_height*pixel_size;
       else
        ps_y = vert_pos - (double)count_per_pixel_f[j]/(double)base_per_pixel*height_scale*pixel_size;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
       if((double)count_per_pixel_f[j]/(double)base_per_pixel*height_scale > (double)max_height)
        ps_y = vert_pos - (double)max_height*pixel_size;
       else
        ps_y = vert_pos - (double)count_per_pixel_f[j]/(double)base_per_pixel*height_scale*pixel_size;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);

     for(j=sfrom;j<sto;j++)
      {
      if(j==sfrom)
       {
       sprintf(ps_buff,"%f setlinewidth",pixel_size*0.7); fprintf(psfile,"%s\n",ps_buff);       // line width 0.7 
       sprintf(ps_buff,"1.0 0.6 0.0 setrgbcolor"); fprintf(psfile,"%s\n",ps_buff);              // ORANGE Color
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
       if((double)count_per_pixel_c[j]/(double)base_per_pixel*height_scale > (double)max_height)
        ps_y = vert_pos - (double)max_height*pixel_size;
       else
        ps_y = vert_pos - (double)count_per_pixel_c[j]/(double)base_per_pixel*height_scale*pixel_size;
       sprintf(ps_buff,"%f %f moveto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      else
       {
       ps_x = ps_left_margin + (c_width + c_a_gap)*pixel_size + ((j-sfrom) * pixel_size);
       if((double)count_per_pixel_c[j]/(double)base_per_pixel*height_scale > (double)max_height)
        ps_y = vert_pos - (double)max_height*pixel_size;
       else
        ps_y = vert_pos - (double)count_per_pixel_c[j]/(double)base_per_pixel*height_scale*pixel_size;
       sprintf(ps_buff,"%f %f lineto",ps_x,ps_y); fprintf(psfile,"%s\n",ps_buff);
       }
      }
     sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
     }                                                                                              /////////////// END SHOW POPULATION

    vert_pos -= (a_height[i] + ps_a_a_gap) * pixel_size;
    }                                                                                               /////////////// END PFL
   }                                                                                                /////////////// END HMAP Histgram Map
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  sprintf(ps_buff,"stroke"); fprintf(psfile,"%s\n",ps_buff);
  strcpy(buff,"showpage pg restore"); fprintf(psfile,"%s\n",buff);                                              // Page Footer 1
  }                                                                                                 //////////////// END PAGE LOOP
 strcpy(buff,"%%Trailer"); fprintf(psfile,"%s\n",buff);                                                         // Global Footer
 strcpy(buff,"%%DocumentFonts: Courier Courier-Bold"); fprintf(psfile,"%s\n",buff);                             // Global Footer
 strcpy(buff,"%%Pages: "); fprintf(psfile,"%s%d\n",buff,n_page);                                                // Global Footer
 fclose(psfile);
 }                                                                            // PS OUTPUT END
else                                          // 2010 Dec 19   count match and mismatch
 {
  {
 for(i=0;i<num_hit;i++)
// for(i=0;i<15;i++)
   {
   if(hit_position[i] != MAX_INT)
    {
    if(hit_position[i] > 0)
     {
     for(j=0;j<query_len-1;j++)
      {
      if(refseq[hit_position[i]+j] == qs[i].seq[j])
       {
       n_match ++;
       n_match_quality += qs[i].quality[j]-offset;
// if((hit_position[i] > 700) && (hit_position[i] < 800))
//      printf("O %10d %c %c %c %d\n",hit_position[i],refseq[hit_position[i]+j], qs[i].seq[j],qs[i].quality[j],qs[i].quality[j]-offset);
       }
      else
       {
       n_mmatch ++;
       n_mmatch_quality += qs[i].quality[j]-offset;
// if((hit_position[i] > 700) && (hit_position[i] < 800))
//      printf("X %10d %c %c %c %d\n",hit_position[i],refseq[hit_position[i]+j], qs[i].seq[j],qs[i].quality[j],qs[i].quality[j]-offset);
       }
//      printf("%c %c %c %d\n",refseq[hit_position[i]+j], qs[i].seq[j],qs[i].quality[j],qs[i].quality[j]-offset);
      }
// if((hit_position[i] > 700) && (hit_position[i] < 800))
//     printf("\n");
     }
    if(hit_position[i] < 0)
     {
     for(j=0;j<query_len-1;j++)
      {
      if(refseq[abs(hit_position[i])+j] == qs_ceq(i,j))
       {
       n_match ++;
       n_match_quality += qs[i].cuality[j+1]-offset;
//      printf("o %c %c %c %d\n",refseq[abs(hit_position[i])+j], qs_ceq(i,j),qs[i].cuality[j+1],qs[i].cuality[j+1]-offset);
       }
      else
       {
       n_mmatch ++;
       n_mmatch_quality += qs[i].cuality[j+1]-offset;
//      printf("x %c %c %c %d\n",refseq[abs(hit_position[i])+j], qs_ceq(i,j),qs[i].cuality[j+1],qs[i].cuality[j+1]-offset);
       }
//      printf("%c %c %c %d\n",refseq[abs(hit_position[i])+j], qs_ceq(i,j),qs[i].cuality[j+1],qs[i].cuality[j+1]-offset);
      }
//    printf("\n");
     }
    }
   }
  }
 }

if(mmmpop == 1)   // Calculate match mismatch population ratio
 {
printf("QUERY_LEN %d\n",query_len);
 for(i=0;i<query_len;i++)
  {
  read_pos_match[i] = 0;
  read_pos_mismatch[i] = 0;
  }
 printf("Match-Mismatch Population Calc.\n");
 for(i=0;i<refseq_len;i++)
  {
  for(j=0;j<position_hits[i].n_hit;j++)
   {
   if(position_hits[i].hits[j] >= 0)                //forward direction
    {
    for(k=0;k<query_len-1;k++)
     {
     reffwqual[i+k] += qs[position_hits[i].hits[j]].quality[k]-offset;
//printf("%10d\n",qs[position_hits[i].hits[j]].quality[k]-offset);
     reffwpop[i+k] ++;
//if(i==200)
// printf("%c",qs[abs(position_hits[i].hits[j])].seq[k]);

     if(refseq[i+k] == qs[abs(position_hits[i].hits[j])].seq[k])
      {
      refbwmatch[i+k] ++;
      read_pos_match[k] ++;
      }
     else
      {
      refbwmismatch[i+k] ++;
      read_pos_mismatch[k] ++;
      }
     }
//if(i==200)
// printf("\n");
    }
   else                                             //reverse direction
    {
    for(k=0;k<query_len-1;k++)
     {
//printf("%10d\n",qs[abs(position_hits[i].hits[j])].cuality[k]);
     refbwqual[i+k] += qs[abs(position_hits[i].hits[j])].cuality[k]-offset;
     refbwpop[i+k] ++;
//if(i==100)
// printf("%c",qs_ceq(abs(position_hits[i].hits[j]),k));
// printf("%d",k);
// printf("%c",qs[abs(position_hits[i].hits[j])].cuality[k]);

     if(refseq[i+k] == qs_ceq(abs(position_hits[i].hits[j]),k))
      {
      refbwmatch[i+k] ++;
      read_pos_match[query_len-2-k] ++;
      }
     else
      {
      refbwmismatch[i+k] ++;
      read_pos_mismatch[query_len-2-k] ++;
      }
     }
//if(i==100)
// printf("\n");
    } 
   }
  }
 
 for(i=0;i<110;i++)
  mmm_bin[i]=0;

 for(i=0;i<refseq_len;i++)
  {
  totalfwpop         += reffwpop[i];
  totalbwpop         += refbwpop[i];
  totalfwmatch       += reffwmatch[i];
  totalfwmismatch    += reffwmismatch[i];
  totalbwmatch       += refbwmatch[i];
  totalbwmismatch    += refbwmismatch[i];
  totalfwqual        += reffwqual[i];
  totalbwqual        += refbwqual[i];

  if((reffwpop[i] < 5) || (refbwpop[i] < 5))
    continue;
  else
   {
//   mmmfwratio = (int)(100.0 * (float)reffwmismatch[i] / (float)(reffwpop[i]));
//   mmmbwratio = (int)(100.0 * (float)refbwmismatch[i] / (float)(refbwpop[i]));
//   if(mmmfwratio > mmmbwratio)
//    mmmratio = mmmfwratio;
//   else
//    mmmratio = mmmbwratio;
   mmmratio = (int)(100.0 * (float)(reffwmismatch[i]+refbwmismatch[i]) / (float)(reffwpop[i]+refbwpop[i]));
   }
  mmm_bin[mmmratio] ++;
  }
 printf("TOTALPOP = %15lld  TOTALMATCH = %15lld  TOTALMISMATCH = %15lld\n",totalfwpop+totalbwpop,totalfwmatch+totalbwmatch,totalfwmismatch+totalbwmismatch);
 printf("                  TOTALFWQUAL= %15lld  TOTALBWQUAL = %15lld\n",totalfwqual,totalbwqual);
 for(i=0;i<=110;i++)
  {
  printf("%5d %10lld %8.4f\n",i,mmm_bin[i],(float)mmm_bin[i]/(float)refseq_len);
  }

 for(i=0;i<query_len-1;i++)
  {
  printf("%5d   %10.6f %10.6f    %10d %10d\n",i+1,((float)read_pos_match[i])/((float)n_query),((float)read_pos_mismatch[i])/((float)n_query),read_pos_match[i],read_pos_mismatch[i]);
  }
 }

if(quality_edge == 1)
 {
 printf("Quality edge check\n");
// for(i=0;i<n_query;i++)
//  {
//  for(j=0;j<query_len;j++)
//   qs[i].quality_edge[j] = ' ';
//  }

 for(i=0;i<refseq_len;i++)
  {
  for(j=0;j<position_hits[i].n_hit;j++)
   {
   if(position_hits[i].hits[j] >= 0)
    {
    for(k=0;k<query_len;k++)
     {
     reffwqual[i+k] += qs[position_hits[i].hits[j]].quality[k]-offset;
     reffwpop[i+k] ++;
     }
    }
   else
    {
    for(k=0;k<query_len;k++)
     {
     refbwqual[i+k] += qs[abs(position_hits[i].hits[j])].cuality[k+1]-offset;
     refbwpop[i+k] ++;
     }
    }
   }
  }

 fw_prev_flag = 0;
 bw_prev_flag = 0;
 quality_edge_threshold = 40.0;

 for(i=80;i<refseq_len-80;i++)
  {
   fw_region_pop = 0;
   for(j=-region_width;j<=region_width;j++)
    fw_region_pop += reffwpop[i+j];
   fw_region_depth = (float)fw_region_pop / (float)(region_width*2+1);
//   printf("I %10d FW_REGION_DEPTH = %10.4f BW_REGION_DEPTH = %10.4f AVERAGE DEPTH = %10.4f\n",i,fw_region_depth,bw_region_depth,average_depth);



  if((fw_region_depth > average_depth/4.0) && (fw_region_depth < average_depth))
  if((reffwpop[i] != 0) && (refbwpop[i] != 0))
   {
   fw_av_q = (float)reffwqual[i]/(float)reffwpop[i];

   if((pre9_fw_av_q+pre8_fw_av_q+pre7_fw_av_q+pre6_fw_av_q+pre5_fw_av_q) - (pre4_fw_av_q+pre3_fw_av_q+pre2_fw_av_q+prev_fw_av_q+fw_av_q) > quality_edge_threshold)
    {
    if(fw_prev_flag == 0)
     {
     fprintf(qedge_file,"FW %10d  ",i);

     for(j=-46;j<=-6;j++)
      fprintf(qedge_file,"%c",refseq[i+j]);
     fprintf(qedge_file," ");
     for(j=-5;j<=36;j++)
      fprintf(qedge_file,"%c",refseq[i+j]);
     fprintf(qedge_file,"\n");
//////////////////////////////////////
     }
    fw_prev_flag = 1;
    }
   else
    {
    fw_prev_flag = 0;
    }
   pre9_fw_av_q = pre8_fw_av_q;
   pre8_fw_av_q = pre7_fw_av_q;
   pre7_fw_av_q = pre6_fw_av_q;
   pre6_fw_av_q = pre5_fw_av_q;
   pre5_fw_av_q = pre4_fw_av_q;
   pre4_fw_av_q = pre3_fw_av_q;
   pre3_fw_av_q = pre2_fw_av_q;
   pre2_fw_av_q = prev_fw_av_q;
   prev_fw_av_q = fw_av_q;



/*
    for(k=i-query_len+1;k<=i;k++)
     {
     if((k<0) || (k>refseq_len))
      continue;
     for(l=0;l<position_hits[k].n_hit;l++)
      {
      if(position_hits[k].hits[l] >= 0)
       {
       for(m=i;m<k+query_len;m++)
        {
        if(qs[position_hits[k].hits[l]].seq[m-k-1] != refseq[m-1])
         {
         fw_edge_n_mmatch ++;
         fw_edge_q_mmatch += qs[position_hits[k].hits[l]].quality[m-k-1]-offset;

         fw_before[0]++;
         if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-2])
          fw_before[1]++;
         else
          if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-3])
           fw_before[2]++;
          else
           if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-4])
            fw_before[3]++;
           else
            if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-5])
             fw_before[4]++;
            else
             if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-6])
              fw_before[5]++;
             else
              if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-7])
               fw_before[6]++;
              else
               if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-8])
                fw_before[7]++;
               else
                if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-9])
                 fw_before[8]++;
                else
                 if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-10])
                  fw_before[9]++;
                 else
                  if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-11])
                   fw_before[10]++;
                  else
                   fw_before[11]++;
         }
        }
       }
      }
     }
*/

   }
  }
printf("FW_TOTAL        = %10d\n",fw_before[0]);
printf("FW_ONE_BEFORE   = %10d\n",fw_before[1]);
printf("FW_TWO_BEFORE   = %10d\n",fw_before[2]);
printf("FW_THREE_BEFORE = %10d\n",fw_before[3]);
printf("FW_FOUR_BEFORE  = %10d\n",fw_before[4]);
printf("FW_FIVE_BEFORE  = %10d\n",fw_before[5]);
printf("FW_SIX _BEFORE  = %10d\n",fw_before[6]);
printf("FW_SEVEN_BEFORE = %10d\n",fw_before[7]);
printf("FW_EIGHT_BEFORE = %10d\n",fw_before[8]);
printf("FW_NINE_BEFORE  = %10d\n",fw_before[9]);
printf("FW_TEN _BEFORE  = %10d\n",fw_before[10]);
printf("FW_MORE_BEFORE  = %10d\n",fw_before[11]);
fprintf(qedge_file,"FW_TOTAL        = %10d\n",fw_before[0]);
fprintf(qedge_file,"FW_ONE_BEFORE   = %10d\n",fw_before[1]);
fprintf(qedge_file,"FW_TWO_BEFORE   = %10d\n",fw_before[2]);
fprintf(qedge_file,"FW_THREE_BEFORE = %10d\n",fw_before[3]);
fprintf(qedge_file,"FW_FOUR_BEFORE  = %10d\n",fw_before[4]);
fprintf(qedge_file,"FW_FIVE_BEFORE  = %10d\n",fw_before[5]);
fprintf(qedge_file,"FW_SIX _BEFORE  = %10d\n",fw_before[6]);
fprintf(qedge_file,"FW_SEVEN_BEFORE = %10d\n",fw_before[7]);
fprintf(qedge_file,"FW_EIGHT_BEFORE = %10d\n",fw_before[8]);
fprintf(qedge_file,"FW_NINE_BEFORE  = %10d\n",fw_before[9]);
fprintf(qedge_file,"FW_TEN _BEFORE  = %10d\n",fw_before[10]);
fprintf(qedge_file,"FW_MORE_BEFORE  = %10d\n",fw_before[11]);

 for(i=80;i<refseq_len-80;i++)
  {
  bw_region_pop = 0;
  for(j=-region_width;j<=region_width;j++)
   bw_region_pop += refbwpop[i+j];
  bw_region_depth = (float)bw_region_pop / (float)(region_width*2+1);

  if((bw_region_depth > average_depth/4.0) && (bw_region_depth < average_depth))
  if((reffwpop[i] != 0) && (refbwpop[i] != 0))
   {
   bw_av_q = (float)refbwqual[i]/(float)refbwpop[i];

   if((pre4_bw_av_q+pre3_bw_av_q+pre2_bw_av_q+prev_bw_av_q+bw_av_q) - (pre9_bw_av_q+pre8_bw_av_q+pre7_bw_av_q+pre6_bw_av_q+pre5_bw_av_q) > quality_edge_threshold)
    {
    if(bw_prev_flag == 0)
     {
     fprintf(qedge_file,"BW %10d  ",i);

     for(j=-46;j<=-6;j++)
      fprintf(qedge_file,"%c",refseq[i+j]);
     fprintf(qedge_file," ");
     for(j=-5;j<=36;j++)
      fprintf(qedge_file,"%c",refseq[i+j]);
     fprintf(qedge_file,"\n");
//////////////////////////////////////
     }
    bw_prev_flag = 1;
    }
   else
    {
    bw_prev_flag = 0;
    }
   pre9_bw_av_q = pre8_bw_av_q;
   pre8_bw_av_q = pre7_bw_av_q;
   pre7_bw_av_q = pre6_bw_av_q;
   pre6_bw_av_q = pre5_bw_av_q;
   pre5_bw_av_q = pre4_bw_av_q;
   pre4_bw_av_q = pre3_bw_av_q;
   pre3_bw_av_q = pre2_bw_av_q;
   pre2_bw_av_q = prev_bw_av_q;
   prev_bw_av_q = bw_av_q;
   }

/*
    for(k=i-query_len+1;k<=i;k++)
     {
     if((k<0) || (k>refseq_len))
      continue;
     for(l=0;l<position_hits[k].n_hit;l++)
      {
      if(position_hits[k].hits[l] < 0)
       {
       for(m=i;m>k;m--)
        {
        if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1) != refseq[m-1])
         {
         bw_edge_n_mmatch ++;
         bw_edge_q_mmatch += qs[abs(position_hits[k].hits[l])].cuality[m-k]-offset;

//printf("I=%5d M=%5d K=%5d L=%5d REF= %c QUERY = %c\n",i,m,k,l,refseq[m-1],qs_ceq(abs(position_hits[k].hits[l]),m-k-1));
         bw_before[0]++;
         if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m])
          bw_before[1]++;
         else
          if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+1])
           bw_before[2]++;
          else
           if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+2])
            bw_before[3]++;
           else
            if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+3])
             bw_before[4]++;
            else
             if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+4])
              bw_before[5]++;
             else
              if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+5])
               bw_before[6]++;
              else
               if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+6])
                bw_before[7]++;
               else
                if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+7])
                 bw_before[8]++;
                else
                 if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+8])
                  bw_before[9]++;
                 else
                  if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+9])
                   bw_before[10]++;
                  else
                   bw_before[11]++;
         }
        }
       }
      }
     }
*/

  }
printf("BW_TOTAL        = %10d\n",bw_before[0]);
printf("BW_ONE_BEFORE   = %10d\n",bw_before[1]);
printf("BW_TWO_BEFORE   = %10d\n",bw_before[2]);
printf("BW_THREE_BEFORE = %10d\n",bw_before[3]);
printf("BW_FOUR_BEFORE  = %10d\n",bw_before[4]);
printf("BW_FIVE_BEFORE  = %10d\n",bw_before[5]);
printf("BW_SIX_BEFORE   = %10d\n",bw_before[6]);
printf("BW_SEVEN_BEFORE = %10d\n",bw_before[7]);
printf("BW_EIGHT_BEFORE = %10d\n",bw_before[8]);
printf("BW_NINE_BEFORE  = %10d\n",bw_before[9]);
printf("BW_TEN _BEFORE  = %10d\n",bw_before[10]);
printf("BW_MORE_BEFORE  = %10d\n",bw_before[11]);
fprintf(qedge_file,"BW_TOTAL        = %10d\n",bw_before[0]);
fprintf(qedge_file,"BW_ONE_BEFORE   = %10d\n",bw_before[1]);
fprintf(qedge_file,"BW_TWO_BEFORE   = %10d\n",bw_before[2]);
fprintf(qedge_file,"BW_THREE_BEFORE = %10d\n",bw_before[3]);
fprintf(qedge_file,"BW_FOUR_BEFORE  = %10d\n",bw_before[4]);
fprintf(qedge_file,"BW_FIVE_BEFORE  = %10d\n",bw_before[5]);
fprintf(qedge_file,"BW_SIX_BEFORE   = %10d\n",bw_before[6]);
fprintf(qedge_file,"BW_SEVEN_BEFORe = %10d\n",bw_before[7]);
fprintf(qedge_file,"BW_EIGHT_BEFORE = %10d\n",bw_before[8]);
fprintf(qedge_file,"BW_NINE_BEFORE  = %10d\n",bw_before[9]);
fprintf(qedge_file,"BW_TEN _BEFORE  = %10d\n",bw_before[10]);
fprintf(qedge_file,"BW_MORE_BEFORE  = %10d\n",bw_before[11]);

 }

 
printf("n_match     = %10lld  n_mmatch     = %10lld\n",n_match,n_mmatch);
printf("n_match_q   = %10lld  n_mmatch_q   = %10lld\n",n_match_quality,n_mmatch_quality);
if((n_match != 0) && (n_mmatch != 0))
printf("n_match_q_a = %10lld  n_mmatch_q_a = %10lld\n",n_match_quality/n_match,n_mmatch_quality/n_mmatch);
if(edge_check == 1)
 {
 printf("fw_edge_n_mmatch     = %10d\n",fw_edge_n_mmatch);
 printf("fw_edge_n_mmatch_q   = %10d\n",fw_edge_q_mmatch);
 printf("fw_edge_n_mmatch_q_a = %10d\n",(fw_edge_q_mmatch) / (fw_edge_n_mmatch));
 printf("bw_edge_n_mmatch     = %10d\n",bw_edge_n_mmatch);
 printf("bw_edge_n_mmatch_q   = %10d\n",bw_edge_q_mmatch);
 printf("bw_edge_n_mmatch_q_a = %10d\n",(bw_edge_q_mmatch) / (bw_edge_n_mmatch));
 printf("edge_n_mmatch     = %10d\n",fw_edge_n_mmatch+bw_edge_n_mmatch);
 printf("edge_n_mmatch_q   = %10d\n",fw_edge_q_mmatch+bw_edge_q_mmatch);
 printf("edge_n_mmatch_q_a = %10d\n",(fw_edge_q_mmatch+bw_edge_q_mmatch) / (fw_edge_n_mmatch+bw_edge_n_mmatch));

 printf("A -> G = %10d\n",atog);
 printf("A -> C = %10d\n",atoc);
 printf("A -> T = %10d\n",atot);
 printf("G -> A = %10d\n",gtoa);
 printf("G -> C = %10d\n",gtoc);
 printf("G -> T = %10d\n",gtot);
 printf("C -> A = %10d\n",ctoa);
 printf("C -> G = %10d\n",ctog);
 printf("C -> T = %10d\n",ctot);
 printf("T -> A = %10d\n",ttoa);
 printf("T -> C = %10d\n",ttoc);
 printf("T -> G = %10d\n",ttog);
 }
if(ggc_marker == 1)
 printf("n_ggc = %d  n_gcc = %d\n",n_ggc,n_gcc);
}
//////////////////////////////////////////////////////////////////////////MAIN END

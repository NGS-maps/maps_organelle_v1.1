#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_QUERY_LEN      155
#define MAX_QUERY     45000000

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct query_info
 {
 char *seq;                 // リードの配列
 char *quality;
 } query_info;


void readargs(int argc, char **argv);

#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN        256

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct pal_info
 {
 int  start;
 int  end;
 int  sum;
 int  n_member;
 char seq[MAX_SEQ_LEN];
 } pal_info;

typedef struct pals_infos
 {
 int n_pal;
 pal_info *pinf;
 int *order;
 int *flag;
 } pals_infos;

void readargs(int argc, char **argv);

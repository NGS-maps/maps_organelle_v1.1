#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_KMER        3000000000      //MAX_KMER 
#define MAX_GRAPH           300000      //MAX_GRAPH
#define MAX_DEPTH          7000000      //MAX_GRAPH
#define MAX_EDGE_LEN       7000000

#define MAX_INDEX_LEN           50
#define MAX_READ_LEN           250
#define MAX_INT         2147483647
#define MIN_INT        -2147483648
#define MAX_THREAD_NUM          32
#define MAX_CONTIG         1000000

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct seq_info
 {
 char seq[600];
 } seq_info;

typedef struct contig_info
 {
 int length;
 char *seq;
 } contig_info;

//typedef struct terminal_sequence_info
// {
// seq_info *tss;
// } terminal_sequence_info;

typedef struct read_info
 {
 char *seq;                      //リードの配列
 char *quality;                  //リードの配列
 int  len;
 int  num_n;
 int  chit_id;
 int  chit_pos;
 int  chit_dir;
 int  chit_n_miss;
 int  thit_id;
 int  thit_pos;
 int  thit_dir;
 int  thit_n_miss;
 } read_info;

typedef struct index_list       // INDEX LIST   ils  //インデックスリスト　
 {
 char seq[MAX_INDEX_LEN+4];
 int n_pos;
 int *pos;
 int *ctg;
 } index_list;

typedef struct hit_info        // HIT INFO     hits  //ヒットリスト　
 {
 int fr;
 int to;
 int len;
 struct hit_info *next;
 } hit_info;

typedef struct hit_array_info        // HIT INFO     hits  //ヒットリスト　
 {
 int fr;
 int to;
 int len;
 int flag;
 } hit_array_info;

typedef struct k_index_list        //ケーマーを数え上げるときのリスト構造
 {
 int kmerid;                       //このノードのアイディー
 struct k_index_list *next;        //次のノードのアドレス
 struct k_index_list *prev;        //前のリードのアドレス
 } k_index_list;

typedef struct index_info        //ケーマーインデックスの情報
 {
 int n_pos;                      //インデックスのヒットするケーマーの数
 int *kmer_id;                   //インデックスのヒットするケーマーのリスト
 struct k_index_list *ils;         //インデックスのヒットするケーマーのリスト構造最初のアドレス
 } index_info;

typedef struct pkmer_info        //ケーマー情報カウント用
 {
 char *seq;
 int  n_appearance;
 } pkmer_info;

typedef struct kmer_info         //ケーマー情報
 {
 char *seq;                      //塩基配列
 int reverse_partner;
 int n_appearance;               //リード中出現回数
 int first_choise;
 int graph_id;
 int n_next;                     //次のケーマーの種類の数
 int n_f_next;                   //次のケーマーの種類の数
 int n_r_next;                   //次のケーマーの種類の数
 int next[8];                    //次のケーマーのアドレス
 int nexts[4];                   //次のケーマーのアドレス
 int fnext[4];                   //次のケーマーのアドレス
 int rnext[4];                   //次のケーマーのアドレス
 int n_prev;                     //前のケーマーの種類の数
 int n_f_prev;                   //次のケーマーの種類の数
 int n_r_prev;                   //次のケーマーの種類の数
 int prev[8];                    //前のケーマーのアドレス
 int prevs[4];                   //前のケーマーのアドレス
 int fprev[4];                   //次のケーマーのアドレス
 int rprev[4];                   //次のケーマーのアドレス
 int n_neighbor;
 int neighbor[8];
 int nflag[8];
 int kmer_type; 
 int direction;
 int use;
 } kmer_info;                    // ATGK

typedef struct terminal_info        //
 {
 int num_branch;
 int length;
 int counterpart_graph;
 int counterpart_terminal;
// char *sequence;
 int depth;
 int first_merge_depth;
 int merge_num;
 int n_seq;
 int  tseq_id;
 char gap_seq[500];
 } terminal_info;

typedef struct node_info        //
 {
 } node_info;

typedef struct edge_info        //
 {
 int fr;
 int to;
 int fr_dir;
 int to_dir;
 int length;
 int *kmer;
 int *dir;
 char *seq;
 } edge_info;

typedef struct graph_info       //
 {
 int init_kmer;
 int num_kmer;
 int num_loop;
 int num_normal_chain;
 int num_end_terminal;
 int num_start_terminal;
 int num_branch_forward;
 int num_branch_backward;
 int num_other_branch;
// int branch_mat[5][5];
 int *kmers;
// int num_nodes;
// node_info *nodes;
 int num_edge;
 edge_info *edges;
 int n_node;
 int *nodes;
 int n_rail;
 int *rails;
 int n_terminal;
 int *terminals;
 int n_branch;
 int *branches;
 int n_junction;
 int *junctions;
 terminal_info *terms;
 } graph_info;
//////////////////////////////////////FUNCTION PROTOTYPE

int seq2index_num(char *seq);
void readargs(int argc, char **argv);
int visit_terminal(int cur,int fr);
int visit_terminal2(int cur,int fr);
int visit_terminal3(int cur,int fr);


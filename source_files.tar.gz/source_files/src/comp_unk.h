#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN        256

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct unk_info
 {
 int  start;
 int  end;
 int  left;
 int  right;
 int  n_member;
 int  n_unk;
 } unk_info;

typedef struct unks_infos
 {
 int n_unk;
 unk_info *uinf;
 } unks_infos;

typedef struct share_info
 {
 int from;
 int to; 
 int *n_member;   // file$B?t@Z$C$F%j!<%I?t$rF~$l$k(B
 char *sequence;  // $BAjF1G[Ns!"$"$l$P(B
 } share_info;

void readargs(int argc, char **argv);

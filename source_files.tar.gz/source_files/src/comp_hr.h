#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN       1024

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct hr_info
 {
 int  start;
 int  end;
 int  left;
 int  right;
 int  n_member;
 int  n_hr;
 char sequence[MAX_SEQ_LEN];
 } hr_info;

typedef struct hrs_infos
 {
 int n_hr;
 hr_info *hinf;
 } hrs_infos;

typedef struct share_info
 {
 int from;
 int to; 
 int *n_member;   // file$B?t@Z$C$F%j!<%I?t$rF~$l$k(B
 char sequence[MAX_SEQ_LEN];  // $BAjF1G[Ns!"$"$l$P(B
 } share_info;

void readargs(int argc, char **argv);

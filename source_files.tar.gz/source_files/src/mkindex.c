#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_INDEX_LEN      50            // $B:GBg%$%s%G%C%/%9D9(B      50

////////////////////////////////STRUCTURE DEFINITION $B9=B$BNDj5A(B

typedef struct index_list                // $B9=B$BN(B index_list
 {
 char seq[MAX_INDEX_LEN+4];
 int n_pos;                              // $B%R%C%H0LCV$N?t(B
 int *pos;                               // $B%R%C%H0LCV$N%j%9%H(B
 } index_list;

////////////////////////////////STRUCTURE DEFINITION END

////////////////////////////////GLOBAL VARIABLE $B%0%m!<%P%kJQ?t(B
char temp_buff[MAX_INDEX_LEN+2];         // $B%F%s%]%i%j!<%P%C%U%!%9%H%j%s%0(B $B!'(Bmk_quart$B$H$NJ8;zNs<uEO$7MQ(B
int index_length  = 4;                   // $B%$%s%G%C%/%9D9!!(B     $B%G%U%)%k%H!'#4(B
int index_size    = 0;                   // $B%$%s%G%C%/%9%5%$%:(B $B!!#4$N%$%s%G%C%/%9D9>h(B
int cyclic_flag   = 0;                   // $B%5%$%/%j%C%/%U%i%C%0(B 0:$B%j%K%"%2%N%`(B 1:$B%5%$%/%j%C%/%2%N%`(B
////////////////////////////////GLOBAL VARIABLE END

////////////////////////////////FUNCTIONS    $B4X?tDj5A(B
int seq2index_num(char *seq)             // $B1v4pG[Ns$+$i%$%s%G%C%/%9HV9f$X$NJQ49(B A:0, C:1, G:2, T:3 $B$N#4?J?t(B
{                                        //                                      N$B$H(B.$B$O(BA(0)$B$H8+$J$9(B
int i;
int val;
int tempval;
int flag = 0;

val = 0;
for(i=0;i<index_length;i++)
 {
 tempval = 0;
 switch(seq[i])
  {
  case 'A':
   tempval = 0;
  break;
  case 'C':
   tempval = 1;
  break;
  case 'G':
   tempval = 2;
  break;
  case 'T':
   tempval = 3;
  break;
  case 'N':
   tempval = 0;
   flag = 1;
  break;
  break;
  case '.':
   tempval = 0;
   flag = 1;
  break;
  default:
   tempval = 0;
   flag = 1;
  }
 if(flag == 1)
  {
  val = -1;
  break;
  }
 val = val*4 + tempval;
 }
return val;
}
///////////////////////////////
char* mk_quart(int in)                   // $B%$%s%G%C%/%9HV9f$+$i1v4pG[Ns$X$NJQ49(B
 {
 int i,j,k,l;
 int mody;
 int rest;
 int c[MAX_INDEX_LEN+1];

 rest = in;
 for(i=0;i<index_length;i++)
  {
  mody = rest % 4;
  rest = rest / 4;
  c[i] = mody;
  }
 for(i=0;i<index_length;i++)
  {
  if(c[i] == 0)
   temp_buff[index_length-1-i] = 'A';
  if(c[i] == 1)
   temp_buff[index_length-1-i] = 'C';
  if(c[i] == 2)
   temp_buff[index_length-1-i] = 'G';
  if(c[i] == 3)
   temp_buff[index_length-1-i] = 'T';
  }
 
 temp_buff[index_length] = '\0';
// strcpy(temp_buff,"AAAA");
 return temp_buff;
 };

////////////////////////////////FUNCTIONS END

////////////////////////////////MAIN      $B%a%$%s4X?t(B    $B%G%U%)%k%H$G%5%$%/%j%C%/$H8+$J$9(B Jan.28 2015
////////////////////////////////          $B%7%s%0%k%(%s%H%j$N(Bfasta$B%U%!%$%k$N$_07$&(B
////////////////////////////////          $BJ#?t@w?'BN$O(Bmaps$BB&$GBP1~(B
int main(int argc, char **argv)
{
int i,j,k,l;
int  refseq_len;                 //$B;2>HG[NsD9(B
char *refseq;                    //$B;2>HG[Ns(B
char refseq_flnm[512];           //$B;2>HG[Ns%U%!%$%kL>(B
FILE *refseq_file;               //$B%U%!%$%k%O%s%I%k(B
char index_flnm[512];            //$B%$%s%G%C%/%9%U%!%$%kL>(B
FILE *index_file;                //$B%U%!%$%k%O%s%I%k(B
char arg1[256];                  //$B0z?t#1(B
char buff[512];                  //$BJ8;zNs%P%C%U%!(B
char refseq_header[512];         //fasta$B$N%X%C%@(B
char tempc;                      //$B%F%s%]%i%jJ8;zJQ?t(B
int flag;                        //$B%U%i%0(B
char temp_seq[256];
int  temp_num;
char len_word[80];

char *quartet;                   // $BJ8;zNs(B
int  *hits;                      // $B%R%C%H%j%9%H(B        $BG[Ns%]%$%s%?(B
index_list *ils;                 // $B%$%s%G%C%/%9%j%9%H!!G[Ns%]%$%s%?(B

if(argc != 3)
 {
 printf("Wrong number of arguments\n");
 printf("Usage: mkindex [-#] ref_file_name #specify size of index\n");
 exit(1);
 }
if(argv[1][0] == '-')
 {
 strcpy(len_word,&argv[1][1]);
 index_length = atoi(len_word);  // $B%$%s%G%C%/%9D9$r%"!<%.%e%a%s%H$+$i<h$k(B
 strcpy(arg1,argv[2]);
 }
else
 strcpy(arg1,argv[1]);

index_size = (int)pow(4,(double)index_length);  // $B%$%s%G%C%/%9%5%$%:(B 4 $B$N%$%s%G%C%/%9D9>h(B

quartet = (char *)malloc(sizeof(char)*(index_length+4));       // quartet = $BJ8;zNs$N$3$H(B
hits = (int *)malloc(sizeof(int)*(index_size+4));              // $B%R%C%H%j%9%H(B
ils = (index_list *)malloc(sizeof(index_list)*(index_size+4)); // $B%$%s%G%C%/%9%j%9%H(B

for(i=0;i<index_size;i++)                       // $B%R%C%H%j%9%H=i4|2=(B
 hits[i] = 0;

printf("Reference file name = %s INDEX_LENGTH%d\n",arg1,index_length); //$BF~NO%U%!%$%kL>I=<((B
sprintf(refseq_flnm,"%s",arg1);
sprintf(index_flnm,"%s.index%d",arg1,index_length);                     //$B=PNO%U%!%$%kL>:n@.(B

if(!(refseq_file = fopen(refseq_flnm,"r")))     // $BF~NO%U%!%$%k3+$/(B
 {
 printf("Failed to open input refseq file: %s\n",refseq_flnm);
 exit(1);
 }
if(!(index_file = fopen(index_flnm,"w")))       // $B=PNO%U%!%$%k3+$/(B
 {
 printf("Failed to open output index file: %s\n",index_flnm);
 exit(1);
 }

///////////////////////////////////////////////////////// Reference $BD9$5%+%&%s%H(B
refseq_len = 0;
fgets(buff,500,refseq_file);
strcpy(refseq_header,buff);
//while(fgets(buff,256,refseq_file))
while((tempc=fgetc(refseq_file)))
 {
 if(tempc != '\n')
  {
  refseq_len ++;
  }
 if(tempc == EOF)
  {
  break;
  }
 }
///////////////////////////////////////////////////////// Reference $BD9$5!a(Brefseq_len

refseq = (char *)malloc(sizeof(char)*(refseq_len + 100));  // Reference$B%a%b%j%"%m%1!<%H(B

rewind(refseq_file);

///////////////////////////////////////////////////////// Refference $BFI9~$_(B $B%a%b%j$X%m!<%I(B
refseq_len = 0;

fgets(buff,500,refseq_file);              // fasta $B$N%?%$%H%k9TFI9~$_(B

while((tempc=fgetc(refseq_file)))
 {
 if(tempc == '>')
  {
  printf("ERROR: MULTI-FASTA FILE NOT ALLOWED \n");  // $B%^%k%A%U%!%9%?$O%(%i!<(B
  exit(0);
  }
 if(tempc != '\n')                                   // $B2~9T$OFIHt$P$7$F0lJ8;z$E$DFI$`(B
  {
  if((tempc >= 97) && (tempc <= 122))
   refseq[refseq_len] = tempc - 32;
  else
   refseq[refseq_len] = tempc;
  refseq_len ++;
  }
 if((tempc == EOF) || (tempc =='\0'))
  {
  refseq[refseq_len-1] = '\0';
  break;
  }
 }

refseq_len = refseq_len - 1;

printf("INPUT REFSEQ FILE:\n%s\n",refseq_header);
printf("REFERENCE SEQUENCE LENGTH: %d\n",refseq_len);
//printf("%s\n",refseq);
///////////////////////////////////////////////////////// Refference $BFI9~$_=*N;(B
///////////////////////////////////////////////////////// $B%5%$%/%j%C%/%2%N%`BP1~$G$*?,$KF,$r(Bindex$BD9(B-1$B$@$1B-$7$F$*$/(B

for(i=0;i<index_length-1;i++)
 {
 refseq[refseq_len+i] = refseq[i];
 }

refseq_len = refseq_len + index_length -1;             // $B%l%U%!%l%s%9D9$K(Bindex$BD9(B-1$B$rB-$7$F$*$/!!(BCyclic$BBP1~(B
refseq[refseq_len] = '\0';


//printf("%s\n",refseq);  exit(0);   // refseq$B3NG'MQ(B
//////////////////////////////////////////////////////// Count number of hits
for(j=0;j<=refseq_len;j++)
 {
 for(i=0;i<index_length;i++)
  temp_seq[i] = refseq[j+i];
 temp_seq[index_length] = '\0';

 temp_num = seq2index_num(temp_seq);
 if(temp_num != -1)
  hits[temp_num] ++;
 }
//////////////////////////////////////////////////////// Count number of hits

//////////////////////////////////////////////////////// Allocate Memory     
for(i=0;i<index_size;i++)
 {
 strcpy(quartet,mk_quart(i));
 ils[i].pos = (int*)malloc(sizeof(int)*(hits[i]+2));
 ils[i].n_pos = 0;
 strcpy(ils[i].seq,quartet);
 }
//////////////////////////////////////////////////////// Allocate Memory     

//////////////////////////////////////////////////////// Fill the index list
for(j=0;j<=refseq_len;j++)
 {
 for(i=0;i<index_length;i++)
  temp_seq[i] = refseq[j+i];
 temp_seq[index_length] = '\0';

 temp_num = seq2index_num(temp_seq);
 if(temp_num != -1)
  ils[temp_num].pos[ils[temp_num].n_pos++] = j;
 }
//////////////////////////////////////////////////////// Fill the index list END

//////////////////////////////////////////////////////// $B%$%s%G%C%/%9%U%!%$%k=q=P$7(B
for(i=0;i<index_size;i++)
 {
 strcpy(quartet,mk_quart(i));
 fprintf(index_file,"%d\n",ils[i].n_pos);
 for(j=0;j<ils[i].n_pos;j++)
  fprintf(index_file,"%d\n",ils[i].pos[j]);
 }
//////////////////////////////////////////////////////// $B%$%s%G%C%/%9%U%!%$%k=q=P!!=*N;(B

//////////////////////////////////////////////////////// $B%a%b%j2rJ|(B
for(i=0;i<index_size;i++)
 {
 free(ils[i].pos);
 }
free(refseq);
//////////////////////////////////////////////////////// $B%a%b%j2rJ|(B
fclose(refseq_file);                                  // $B%U%!%$%k2rJ|(B
}
////////////////////////////////MAIN END

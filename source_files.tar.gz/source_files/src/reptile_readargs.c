#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern char arg1[];
extern int min_rep;
extern int max_rep;
extern int index_length;
extern int min_len;
extern int max_len;
extern int print_hit;
extern int print_seq;

void errorm(int en);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;
int flag = 0;

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'h'))    // -ph print hit :  print position and length of match
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    print_hit  = 1;
   }
  if((argv[arg][1] == 'p') && (argv[arg][2] == 's'))    // -ps print seq :  print match sequences
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    print_seq  = 1;
   }

//  if((argv[arg][1] == 'm') && (argv[arg][2] == 'i') && (argv[arg][3] == 'n'))   // -mms ##  show match sequence shorter thanthis
//   {
//   if(argv[arg][4] != '\0')
//    errorm(1);
//   else
//    {
//    arg ++;
//    if(argv[arg][0] == '-')
//     errorm(2);
//    min_rep  = atoi(argv[arg]);
//    }
//   }

  if((argv[arg][1] == 'i') && (argv[arg][2] == 'd') && (argv[arg][3] == 'x'))   // -idx ##  index length
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    index_length  = atoi(argv[arg]);
    }
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'i') && (argv[arg][3] == 'n'))   // -min ##  lower threshold  find repeat longer than this value
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    min_len  = atoi(argv[arg]);
    min_rep  = atoi(argv[arg]);
    }
   }
 
  if((argv[arg][1] == 'm') && (argv[arg][2] == 'a') && (argv[arg][3] == 'x'))   // -max ##  lower threshold  find repeat shorter than this value
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    max_len  = atoi(argv[arg]);
    max_rep  = atoi(argv[arg]);
    }
   }
/*
  if((argv[arg][1] == 'r') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'b'))    // -rgb genbank_flnm : read genbank file and show gene info on the map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_gb  = 1;
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
//printf("GENBANK_FILENAME %s\n",argv[arg]);
    strcpy(genbank_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'b') &&(argv[arg][3] == 'r'))    // -rbr blast6_flnm : read blast output for repeat detection
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_br  = 1;
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
//printf("GENBANK_FILENAME %s\n",argv[arg]);
    strcpy(blastrepeat_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 'b') &&(argv[arg][3] == '8'))    // -bo8 blast format 8 output : read genom self blast format 8 output 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_bo8  = 1;
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
//printf("GENBANK_FILENAME %s\n",argv[arg]);
    strcpy(bo8_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'e'))    // -rge genbank_flnm : read eukariote genbank file and show gene info on the map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_ge  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(genbank_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 's'))    // -ps ps_out : output post script file
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    ps_out  = 1;
   }

  if(argv[arg][1] == 'i')                                        // -a number (such as -a 4) as number of thread (multithread)
   {
   arg ++;
   index_length = atoi(argv[arg]);
   printf("INDEX_LENGTH %d\n",index_length);
   continue;
   }
  if((argv[arg][1] == 'p') && (argv[arg][2] == 'i') && (argv[arg][3] == 'l'))        // -pil Print index_list
   {
   print_index_list = 1;
   continue;
   }
  if((argv[arg][1] == 'c') && (argv[arg][2] == 't'))                                 // -ct number Chop tail  Make index for the first part of reads
   {
   arg ++;
   chop_tail = atoi(argv[arg]);
   printf("CHOP TAIL %d\n",chop_tail);
   continue;
   }
  if((argv[arg][1] == 's') && (argv[arg][2] == 'p') && (argv[arg][3] == 's'))       // -sps spit seed
   {
   printf("SPIT SEED 1\n");
   spit_seed = 1;
   continue;
   }
  if(argv[arg][1] == 'a')                                        // -a number (such as -a 4) as number of thread (multithread)
   {
   arg ++;
   n_thread = atoi(argv[arg]);
   printf("NTHREAD %d\n",n_thread);
   continue;
   }
  /////////////////////////////////////////////////////////
  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') && (argv[arg][3] == 'b'))             // -job jobname          reference.fasta.jobname.###
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    jobname = 1;
    arg ++;
    strcpy(job_name,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'w'))              // -mw number (such as -a 200) as width of map (text) with -map option
   {
   arg ++;
   map_out_width = atoi(argv[arg]);
   printf("MAP_OUT_WIDTH %d\n",map_out_width);
   continue;
   }
  if(argv[arg][1] == 'r')                                        // -r number (such as -r 5) as round cycle
   {
   arg ++;
   n_round = atoi(argv[arg]);
   printf("NROUND %d\n",n_round);
   continue;
   }
  /////////////////////////////////////////////////////////
*/
  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference fasta file name
   strcpy(arg1,argv[arg]);
   }
  flag ++;
  if(flag >= 2)
   errorm(2);
  }
 }
}

void errorm(int en)
 {
 printf("ERROR %d\n",en);
 printf("Usage: reptile [-options] ref.fasta query.fasta mummer.out\n");
 printf("               -ps      output postscript file\n");
 exit(1);
 }

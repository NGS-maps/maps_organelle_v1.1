#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "comp_hmr.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}
//////////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
FILE        *hmr_list;
FILE        *hmr_file;
FILE        *hmr_out;
char        hmr_out_flnm[512];
FILE        *hmr_out2;                                 ///
char        hmr_out2_flnm[512];                        ///
char        buff[512];
char        seq[512];
int         n_files = 0;
int         n_lines = 0;
word_info   files[MAX_FILE];
hmrs_infos  hmrs[MAX_FILE];
int         read_count[MAX_FILE];                      ///
double      bias_ratio[MAX_FILE];                      ///
int         pointer[MAX_FILE];
int         min;
int         temp;
int         temp_min;
int         temp_order;
int         bias_flag = 1;                             ///

readargs(argc,argv);

printf("INPUT HOMOROGOUS REARRANGEMENT LIST FILES NAME IS: %s\n",arg1);
hmr_list = fopen(arg1,"r");
if(hmr_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

printf("INPUT HOMOROGOUS REARRANGEMENT LIST FILES NAME IS: %s\n",arg1);
hmr_list = fopen(arg1,"r");
if(hmr_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

sprintf(hmr_out_flnm,"%s.out",arg1);                           // $B=PNO%U%!%$%kL>(B
hmr_out = fopen(hmr_out_flnm,"w");
if(hmr_out == NULL)
 {
 printf("Failed to open the output file %s\n",hmr_out_flnm);
 exit(1);
 }

sprintf(hmr_out2_flnm,"%s.out2",arg1);                           /// $BJd@5=PNO%U%!%$%kL>(B
hmr_out2 = fopen(hmr_out2_flnm,"w");                             ///
if(hmr_out2 == NULL)                                             ///
 {                                                               ///
 printf("Failed to open the output file %s\n",hmr_out2_flnm);    ///
 exit(1);                                                        ///
 }                                                               ///

while(fgets(buff,512,hmr_list))                                // hmr$B%U%!%$%kL>%j%9%HFI$_9~$_(B
 {
 sscanf(buff,"%s %d",files[n_files].word,&read_count[n_files]);  ///
// buff[strlen(buff)-1] = '\0';                                  ///
// printf("%s\n",buff);                                          ///
// strcpy(files[n_files].word,buff);
 n_files ++;
 }

for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 if(read_count[i] == 0)                           // $BFI$_9~$s$@%j!<%I%+%&%s%H$K0l$D$G$b(B0$B$N$b$N$,$"$l$P(B              ///
  {                                                                                                                 ///
  bias_flag = 0;                                  // $B%j!<%I?t%P%$%"%9$O9MN8$7$J$$(B                                   ///
  }                                                                                                                 ///
 }                                                                                                                  ///

if(bias_flag == 1)                                                                                                  ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  {                                                                                                                 ///
  bias_ratio[i] = (double)read_count[i] / (double)read_count[0];                                                    ///
  }                                                                                                                 ///
 }                                                                                                                  ///
else                                                                                                                ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  bias_ratio[i] = 1.0;                                                                                              ///
 }                                                                                                                  ///

for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 printf("%-55s %10d %10.5f\n",files[i].word,read_count[i],bias_ratio[i]*100.0);                                     ///
 }                                                                                                                  ///

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

for(i=0;i<n_files;i++)                                         // hmr$B%U%!%$%k$N?t$N%k!<%W(B
 {
 hmr_file = fopen(files[i].word,"r");                          // hmr$B%U%!%$%k3+$/(B
 if(hmr_file == NULL)
  {
  printf("Failed to open the input file %s\n",files[i].word);
  exit(1);
  }

 n_lines = 0;
 while(fgets(buff,512,hmr_file))
  {
  n_lines ++;
  }
 hmrs[i].n_hmr = n_lines;
 hmrs[i].hinf  = (hmr_info *)malloc(sizeof(hmr_info)*(n_lines + 2));
 
 rewind(hmr_file);

 n_lines = 0;
 while(fgets(buff,512,hmr_file))                              // hmr$B%U%!%$%k$NFI$_9~$_(B
  {
  hmrs[i].hinf[n_lines].L1       = read_int(buff, 3, 10);     // $BAjF1G[Ns0LCV#1!]:8(B
  hmrs[i].hinf[n_lines].R1       = read_int(buff,14, 10);     // $BAjF1G[Ns0LCV#1!]1&(B
  hmrs[i].hinf[n_lines].L2       = read_int(buff,25, 10);     // $BAjF1G[Ns0LCV#2!]:8(B
  hmrs[i].hinf[n_lines].R2       = read_int(buff,36, 10);     // $BAjF1G[Ns0LCV#2!]1&(B
  hmrs[i].hinf[n_lines].n_member1= read_int(buff,47, 10);     // $B%8%c%s%/%7%g%s%j!<%I?t(B
  hmrs[i].hinf[n_lines].n_member2= read_int(buff,58, 10);     // $B%8%c%s%/%7%g%s%j!<%I?t(B
  strcpy(hmrs[i].hinf[n_lines].seq,&buff[68]);
  hmrs[i].hinf[n_lines].seq[strlen(hmrs[i].hinf[n_lines].seq)-1] = '\0';
//  printf("%8d %8d %8d %8d %8d %8d %s\n",
//         hmrs[i].hinf[n_lines].L1, hmrs[i].hinf[n_lines].R1,
//         hmrs[i].hinf[n_lines].L2, hmrs[i].hinf[n_lines].R2,
//         hmrs[i].hinf[n_lines].n_member1, hmrs[i].hinf[n_lines].n_member2,
//         hmrs[i].hinf[n_lines].seq);
  n_lines ++;
  }
 printf("%5d %s\n",n_lines,files[i].word);
 fclose(hmr_file);
 pointer[i] = 0;
 }                                                            // hmr$B%U%!%$%k$N?t$N%k!<%W=*$o$j(B

/////MK1

/*
for(i=0;i<n_files;i++)
 {
 for(j=0;j<hmrs[i].n_hmr;j++)
  {
  if(hmrs[i].hinf[j].sum == hmrs[i].hinf[hmrs[i].order[j]].sum)
   printf("%8d %8d\n",hmrs[i].hinf[j].sum,hmrs[i].hinf[hmrs[i].order[j]].sum);
  else
   printf("%8d %8d#\n",hmrs[i].hinf[j].sum,hmrs[i].hinf[hmrs[i].order[j]].sum);
  }
 }
*/

//fprintf(hmr_out,",,");                                //$B=PNO%U%!%$%k0l9TL\$K%U%!%$%kL>$r%j%9%H$9$k(B
//for(i=0;i<n_files;i++)
// fprintf(hmr_out,"%s",files[i].word);
//fprintf(hmr_out,"\n");

int l1,l2,r1,r2;
while(1)                                                      // $B%U%!%$%k4VHf3S(B
 {
 min = MAX_INT;                                      
 l1 = MAX_INT; l2 = MAX_INT;
 r1 = MAX_INT; r2 = MAX_INT;

 for(i=0;i<n_files;i++)                                  // 1st $B%9%-%c%s(B $B:G>.CM$r8!=P(B
  {
  if(pointer[i] < hmrs[i].n_hmr)
   if(min > hmrs[i].hinf[pointer[i]].L1)
    {
    min = hmrs[i].hinf[pointer[i]].L1;
    r1= hmrs[i].hinf[pointer[i]].R1;
    l2= hmrs[i].hinf[pointer[i]].L2;
    r2= hmrs[i].hinf[pointer[i]].R2;
    strcpy(seq,hmrs[i].hinf[pointer[i]].seq);
    }
  }
 printf("MIN %d %d %d %d %s\n",min,r1,l2,r2,seq);
 fprintf(hmr_out,"%d,%d,%d,%d,%s,",min,r1,l2,r2,seq);
 fprintf(hmr_out2,"%d,%d,%d,%d,%s,",min,r1,l2,r2,seq);

 for(i=0;i<n_files;i++)                                 // 2nd $B%9%-%c%s(B $B:G>.$NCM$r=PNO(B
  {
  if(pointer[i] < hmrs[i].n_hmr)
   {
   if(min == hmrs[i].hinf[pointer[i]].L1)
    {
//    printf("%2d %8d %8d %8d %8d %8d %8d %s\n",i+1,
//                                hmrs[i].hinf[pointer[i]].L1,hmrs[i].hinf[pointer[i]].R1,
//                                hmrs[i].hinf[pointer[i]].L2,hmrs[i].hinf[pointer[i]].R2,
//                                hmrs[i].hinf[pointer[i]].n_member1,hmrs[i].hinf[pointer[i]].n_member2,
//                                hmrs[i].hinf[pointer[i]].seq);
    printf("%2d %8d %8d %8d %8d %8d %8d %10.2f %10.2f %s\n",i+1,
                                hmrs[i].hinf[pointer[i]].L1,hmrs[i].hinf[pointer[i]].R1,
                                hmrs[i].hinf[pointer[i]].L2,hmrs[i].hinf[pointer[i]].R2,
                                hmrs[i].hinf[pointer[i]].n_member1,
                                hmrs[i].hinf[pointer[i]].n_member2,
                                (double)hmrs[i].hinf[pointer[i]].n_member1/bias_ratio[i],
                                (double)hmrs[i].hinf[pointer[i]].n_member2/bias_ratio[i],
                                hmrs[i].hinf[pointer[i]].seq);
    fprintf(hmr_out,"%d,%d,", hmrs[i].hinf[pointer[i]].n_member1,hmrs[i].hinf[pointer[i]].n_member2);
    fprintf(hmr_out2,"%.2f,%.2f,", (double)hmrs[i].hinf[pointer[i]].n_member1/bias_ratio[i],
                                       (double)hmrs[i].hinf[pointer[i]].n_member2/bias_ratio[i]);
    pointer[i] ++;                                      // $B%]%$%s%?$r?J$a$k(B
    }
   else
    {
    fprintf(hmr_out,"0,0,");
    fprintf(hmr_out2,"0.0,0.0,");
    }
   }
  else
   {
   fprintf(hmr_out,"0,0,");
   fprintf(hmr_out2,"0.0,0.0,");
   }
  }
 fprintf(hmr_out,"\n");
 fprintf(hmr_out2,"\n");

 temp = 0;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] == hmrs[i].n_hmr)
   temp ++;                                             // $B:G8e$^$G%A%'%C%/$7$?(Bhmr$B%U%!%$%k$N?t$r%+%&%s%H(B
  }
 if(temp == n_files)
  break;
 }

/////////////////////////////////////////////////////////////////DONE READING FILES
}
/////////////////////////////////////////////////////////////////////////MAIN END

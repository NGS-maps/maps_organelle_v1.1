#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#define  MAX_LINE_LEN 5000

typedef struct hr_info
{
int  fr;
int  to;
int  read_count;
char *hseq;
int  hseq_len;
} hr_info;


char in_flnm[128];
FILE *infile;
char out1_flnm[128];
FILE *out1file;
char out2_flnm[128];
FILE *out2file;
char out3_flnm[128];
FILE *out3file;

int main(int argc, char **argv)
{
int i,j,k;
char buff[MAX_LINE_LEN];

char in_flnm[128];
FILE *infile;
char out1_flnm[128];
FILE *out1file;
char out2_flnm[128];
FILE *out2file;
char out3_flnm[128];
FILE *out3file;

if(argc != 2)
 {
 printf("Wrong Number of arguments\n");
 printf("Usage: hr_count foo.hr  \n");
 printf("       foo.hr is an output file from midhr\n");
 exit(1);
 }
strcpy(in_flnm,argv[1]);
sprintf(out1_flnm,"%s.3_5.pos",in_flnm);
sprintf(out2_flnm,"%s.6_10.pos",in_flnm);
sprintf(out3_flnm,"%s.10_100.pos",in_flnm);

infile = fopen(in_flnm,"r");
out1file = fopen(out1_flnm,"w");
out2file = fopen(out2_flnm,"w");
out3file = fopen(out3_flnm,"w");

if(infile == NULL)
 {
 printf("Failed to open input file %s\n",in_flnm);
 exit(1);
 }

int n_hr_line = 0;
hr_info *hrs;

while(fgets(buff,MAX_LINE_LEN,infile))
 {
 n_hr_line ++;
 }

printf("%d\n",n_hr_line);

hrs = (hr_info *)malloc(sizeof(hr_info) * (n_hr_line + 1));

rewind(infile);

i = 0;
char d1[8];
char d2[MAX_LINE_LEN];
while(fgets(buff,MAX_LINE_LEN,infile))
 {
 sscanf(buff,"%s %d %d %d %s",d1,&hrs[i].fr,&hrs[i].to,&hrs[i].read_count,d2);
 hrs[i].hseq_len = strlen(d2);
 i++;
 }

for(i=0;i<n_hr_line;i++)
 {
 printf("%10d %10d %10d %d\n",hrs[i].fr,hrs[i].to,hrs[i].read_count,hrs[i].hseq_len);

 int sl = hrs[i].hseq_len;
 if((sl >=3) && (sl <= 5))
  {
  fprintf(out1file,"%d\n",abs(hrs[i].fr));
  fprintf(out1file,"%d\n",abs(hrs[i].to));
  }
 if((sl >=6) && (sl <= 10))
  {
  fprintf(out2file,"%d\n",abs(hrs[i].fr));
  fprintf(out2file,"%d\n",abs(hrs[i].to));
  }
 if((sl >=11) && (sl <= 100))
  {
  fprintf(out3file,"%d\n",abs(hrs[i].fr));
  fprintf(out3file,"%d\n",abs(hrs[i].to));
  }
 }

/////////////////////////////////////////////////////// $B%/%m%b%=!<%`(Bfasta$B%U%!%$%kFI$_9~$_(B
}        // END MAIN


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "ispmap.h"


extern char genbank_flnm[];
extern int  n_gene;
extern int  n_CDS;
extern int  n_tRNA;
extern int  n_tmRNA;
extern int  n_rRNA;
extern int  n_miscRNA;
extern int  n_pseudo;
extern genbank_info *gbs;

int read_from(char *str)
{
int point;
int i;
int cc=0;
char tempchar[80];
point = 21;
if(strstr(str,"complement"))
 point = 32;
if((str[point] == '>') || (str[point] == '<'))
 point ++;
for(i=point;i<strlen(str);i++)
 {
 tempchar[cc] = str[i];
 cc++;
 if(str[i] == '.')
  break;
 }
tempchar[cc] = '\0';
return atoi(tempchar);
}

int read_to(char *str)
{
int i;
int cc;
int point=0;
char tempchar[80];
int flag=0;
for(i=0;i<strlen(str);i++)
 {
 if(str[i] == '.')
  flag ++;
 if(flag == 2)
  {
  point = i+1;
  break;
  }
 }

if((str[point] == '>') || (str[point] == '<'))
 point ++;
cc=0;
for(i=point;i<strlen(str);i++)
 {
 tempchar[cc] = str[i];
 cc++;
 if((str[i] == ')') || (str[i] == '\n'))
  break;
 }
tempchar[cc] = '\0';
return atoi(tempchar);
}

int read_complement(char *str)
{
if(strstr(str,"complement"))
 return 1;
else 
 return 0;
}

void read_genbank(void)
{
int i;
int cc;
char buff[1024];
FILE *genbank_file;

if(!(genbank_file = fopen(genbank_flnm,"r")))
 {
 printf("Failed to open input genbank file: %s\n",genbank_flnm);
 exit(1);
 }

while(fgets(buff,500,genbank_file))
 {
 if(strncmp(buff,"     gene",9) == 0)
  n_gene ++;
 if(strncmp(buff,"     CDS",8) == 0)
  n_CDS ++;
 if(strncmp(buff,"     tRNA",9) == 0)
  n_tRNA ++;
 if(strncmp(buff,"     tmRNA",10) == 0)
  n_tmRNA ++;
 if(strncmp(buff,"     rRNA",9) == 0)
  n_rRNA ++;
 if(strncmp(buff,"     misc_RNA",13) == 0)
  n_miscRNA ++;

// if((buff[5] != ' ') && ((strncmp(buff,"     gene",9)!=0) && (strncmp(buff,"     CDS",8) != 0) && (strncmp(buff,"     tRNA",9) != 0) && (strncmp(buff,"     rRNA",9) != 0) && (strncmp(buff,"     misc_RNA",13)!=0) && (strncmp(buff,"     tmRNA",10)!=0)))
//  printf("%s",buff);
 }

printf("n_gene = %5d n_CDS = %5d n_tRNA = %5d n_rRNA = %5d n_miscRNA = %5d n_pseudo = %5d\n",
        n_gene,n_CDS,n_tRNA,n_rRNA,n_miscRNA,n_pseudo);

gbs = (genbank_info *)malloc(sizeof(genbank_info)*(n_gene+10));
rewind(genbank_file);

cc = -1;
while(fgets(buff,500,genbank_file))
 {
 if(strncmp(buff,"     gene",9) == 0)
  {
  cc++;
  gbs[cc].from         = read_from(buff);
  gbs[cc].to           = read_to(buff);
  gbs[cc].complement   = read_complement(buff);
  }
 if(strncmp(buff,"     CDS",8) == 0)
  {
  gbs[cc].type = 1;
  strcpy(gbs[cc].type_char,"CDS");
  }
 if(strncmp(buff,"     tRNA",9) == 0)
  {
  gbs[cc].type = 2;
  strcpy(gbs[cc].type_char,"tRNA");
  }
 if(strncmp(buff,"     tmRNA",10) == 0)
  {
  gbs[cc].type = 5;
  strcpy(gbs[cc].type_char,"tmRNA");
  }
 if(strncmp(buff,"     rRNA",9) == 0)
  {
  gbs[cc].type = 3;
  strcpy(gbs[cc].type_char,"rRNA");
  }
 if(strncmp(buff,"     misc_RNA",13) == 0)
  {
  gbs[cc].type = 4;
  strcpy(gbs[cc].type_char,"misc_RNA");
  }
 if(strstr(buff,"/product=")) 
  {
  strcpy(gbs[cc].product_name,strstr(buff,"=")+2);
  gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
  if(gbs[cc].product_name[strlen(gbs[cc].product_name)-1] != '"')
   {
   fgets(buff,500,genbank_file);
   strcat(gbs[cc].product_name,buff+21);
   gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
   }
  gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
  }
 if(strncmp(buff,"                     /gene=",27) == 0) 
  {
  strcpy(gbs[cc].gene_name,strstr(buff,"=")+2);
  gbs[cc].gene_name[strlen(gbs[cc].gene_name)-2] = '\0';
  }
 if(strncmp(buff,"                     /locus_tag=",32) == 0) 
  {
  strcpy(gbs[cc].locus_tag,strstr(buff,"=")+2);
  gbs[cc].locus_tag[strlen(gbs[cc].locus_tag)-2] = '\0';
  }
 if(strncmp(buff,"                     /pseudo",28) == 0) 
  {
  strcpy(gbs[cc].type_char,"pseudo");
  strcpy(gbs[cc].product_name,"pseudo gene");
  gbs[cc].type = 6;
  }
 }

for(i=0;i<n_gene;i++)
 {
 gbs[i].tag_count = 0;
 gbs[i].intensity = 0;
 gbs[i].pre_tag_count = 0;
 gbs[i].pre_intensity = 0;
 }
for(i=0;i<n_gene;i++)
 {
 printf("FROM %12d TO %12d COMP %d GENE %12s TYPE %6s PRODUCT %s\n",gbs[i].from,gbs[i].to,gbs[i].complement,gbs[i].gene_name,gbs[i].type_char,gbs[i].product_name);
 }

fclose(genbank_file);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include "reptile.h"
#define MAX_ARG_LEN   256
#define MOD_SIZE    10000

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//    reptile = REPEAT detection from genome                                 //
//                                                                           //
//    usage: reptile [options] ref.fasta                                     //
//                                                                           //
//    options:                                                               //
//                                                                           //
//                                                                           //
//    Programed by Kensuke Nakamura, Since Jul. 2019, All right reserved.    //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#define MAX_INDEX_LEN      50            // $B:GBg%$%s%G%C%/%9D9(B      50  

////////////////////////////////STRUCTURE DEFINITION $B9=B$BNDj5A(B

typedef struct index_list                // $B9=B$BN(B index_list
 {
 char seq[MAX_INDEX_LEN+4];
 int n_pos;                              // $B%R%C%H0LCV$N?t(B
 int *pos;                               // $B%R%C%H0LCV$N%j%9%H(B
 } index_list;

////////////////////////////////STRUCTURE DEFINITION END 

////////////////////////////////GLOBAL VARIABLE $B%0%m!<%P%kJQ?t(B
char temp_buff[MAX_INDEX_LEN+2];         // $B%F%s%]%i%j!<%P%C%U%!%9%H%j%s%0(B $B!'(Bmk_quart$B$H$NJ8;zNs<uEO$7MQ(B
int index_length  = 3;                   // $B%$%s%G%C%/%9D9!!(B     $B%G%U%)%k%H!'#4(B
int index_size    = 0;                   // $B%$%s%G%C%/%9%5%$%:(B $B!!#4$N%$%s%G%C%/%9D9>h(B
int cyclic_flag   = 0;                   // $B%5%$%/%j%C%/%U%i%C%0(B 0:$B%j%K%"%2%N%`(B 1:$B%5%$%/%j%C%/%2%N%`(B
char arg1[MAX_ARG_LEN];
int  min_rep = 10;
int  max_rep = 500;
int min_len = 10;
int max_len = 500;
int print_hit = 0;
int print_seq = 0;
int print_pos_list = 1;
int print_dist = 1;
int print_heat_map = 1;
////////////////////////////////GLOBAL VARIABLE END 

////////////////////////////////FUNCTIONS    $B4X?tDj5A(B
int seq2index_num(char *seq)             // $B1v4pG[Ns$+$i%$%s%G%C%/%9HV9f$X$NJQ49(B A:0, C:1, G:2, T:3 $B$N#4?J?t(B
{                                        //                                      N$B$H(B.$B$O(BA(0)$B$H8+$J$9(B
int i;
int val;
int tempval;

val = 0;
for(i=0;i<index_length;i++)
 {
 tempval = 0;
 switch(seq[i])
  {
  case 'A':
   tempval = 0;
  break;
  case 'C':
   tempval = 1;
  break;
  case 'G':
   tempval = 2;
  break;
  case 'T':
   tempval = 3;
  break;
  case 'N':
   tempval = 0;
  break;
  case '.':
   tempval = 0;
  break;
  }
 val = val*4 + tempval;
 }
return val;
}
///////////////////////////////
char* mk_quart(int in)                   // $B%$%s%G%C%/%9HV9f$+$i1v4pG[Ns$X$NJQ49(B
 {
 int i,j,k,l;
 int mody;
 int rest;
 int c[MAX_INDEX_LEN+1];

 rest = in; 
 for(i=0;i<index_length;i++)
  {
  mody = rest % 4;
  rest = rest / 4;
  c[i] = mody;
  }
 for(i=0;i<index_length;i++)
  {
  if(c[i] == 0)
   temp_buff[index_length-1-i] = 'A';
  if(c[i] == 1)
   temp_buff[index_length-1-i] = 'C';
  if(c[i] == 2)
   temp_buff[index_length-1-i] = 'G';
  if(c[i] == 3)
   temp_buff[index_length-1-i] = 'T';
  }
 
 temp_buff[index_length] = '\0';
// strcpy(temp_buff,"AAAA");
 return temp_buff;
 };

char comp(char in)
 {
 switch(in)
  {
  case 'A':
   return 'T';
  break;
  case 'T':
   return 'A';
  break;
  case 'G':
   return 'C';
  break;
  case 'C':
   return 'G';
  break;
  default:
   return 'A';
  }
 }
////////////////////////////////FUNCTIONS END 


//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\FUNTION DEFINITIONS 


/////////////////////////////////////////////////////////////////////////////////////////////////////// MAIN$B4X?t(B
int main(int argc, char **argv)
{
int i,j,k,l,m;
char c;
int cc;
int pos;
FILE *infile;
char pos_list_flnm[256];
char dist_flnm[256];
char heat_map_flnm[256];
FILE *pos_list;
FILE *dist_file;
FILE *hm_file;
char *seq;
char *rev;
int  *fw;
int  *bw;
int seq_len=0;
char buff[512];
int index_size;
char temp_seq[256];
int temp_num;
int hm_mesh = 5000;
int **heat_map;
int hm_num;

int bin[1001];
for(i=0;i<1001;i++)
 bin[i] = 0;

char *quartet;                   // $BJ8;zNs(B
int  *hits;                      // $B%R%C%H%j%9%H(B        $BG[Ns%]%$%s%?(B
index_list *ils;                 // $B%$%s%G%C%/%9%j%9%H!!G[Ns%]%$%s%?(B

readargs(argc,argv);
printf("Input file is %s\n",arg1);

sprintf(pos_list_flnm,"%s.pos",arg1);
sprintf(dist_flnm,"%s.dst",arg1);
sprintf(heat_map_flnm,"%s.hmp",arg1);
pos_list = fopen(pos_list_flnm,"w");
dist_file = fopen(dist_flnm,"w");
hm_file = fopen(heat_map_flnm,"w");

infile = fopen(arg1,"r");
if(infile == NULL)
 {
 printf("Failed to open input file %s\n",arg1);
 exit(1);
 }
fgets(buff,512,infile);
while((c=fgetc(infile)) != EOF)
 {
 if(c != '\n')
  seq_len ++;
 }
printf("SEQUENCE LENGTH IS %d\n",seq_len);

seq = (char *)malloc(sizeof(char) * (seq_len + 10));
rev = (char *)malloc(sizeof(char) * (seq_len + 10));
if(print_heat_map == 1)
 {
 hm_num = (seq_len / 5000) + 1;
 heat_map = (int **)malloc(sizeof(int *)*(hm_num + 2));
 for(i=0;i<hm_num + 2;i++)
  {
  heat_map[i] = (int *)malloc(sizeof(int)*(hm_num+2));
  for(j=0;j<hm_num+2;j++)
   heat_map[i][j] = 0;
  }
 }

if(seq == NULL)
 {
 printf("Failed to allocate memory");
 exit(1);
 }
rewind(infile);

cc = 0;
fgets(buff,512,infile);

while((c=fgetc(infile)) != EOF)
 {
 if(c != '\n')
  seq[cc++] = c;
 }
seq[cc] = '\0';
//printf("%s",seq);
printf("\n");
for(i=0;i<seq_len;i++)
 {
 rev[i] = comp(seq[seq_len-i-1]);
 }
rev[i] = '\0';
//printf("%s",rev);

index_size = (int)pow(4,(double)index_length);  // $B%$%s%G%C%/%9%5%$%:(B 4 $B$N%$%s%G%C%/%9D9>h(B
quartet = (char *)malloc(sizeof(char)*(index_length+4));       // quartet = $BJ8;zNs$N$3$H(B
hits = (int *)malloc(sizeof(int)*(index_size+4));              // $B%R%C%H%j%9%H(B
ils = (index_list *)malloc(sizeof(index_list)*(index_size+4)); // $B%$%s%G%C%/%9%j%9%H(B

for(i=0;i<index_size;i++)                       // $B%R%C%H%j%9%H=i4|2=(B
 hits[i] = 0;

//////////////////////////////////////////////////////// Count number of hits
for(j=0;j<=seq_len;j++)
 {
 for(i=0;i<index_length;i++)
  temp_seq[i] = seq[j+i];
 temp_seq[index_length] = '\0';

 temp_num = seq2index_num(temp_seq);
 hits[temp_num] ++;
 }
//////////////////////////////////////////////////////// Count number of hits
//////////////////////////////////////////////////////// Allocate Memory
for(i=0;i<index_size;i++)
 {
 strcpy(quartet,mk_quart(i));
 ils[i].pos = (int*)malloc(sizeof(int)*(hits[i]+2));
 ils[i].n_pos = 0;
 strcpy(ils[i].seq,quartet);
 }
//////////////////////////////////////////////////////// Allocate Memory
//////////////////////////////////////////////////////// Fill the index list
for(j=0;j<=seq_len;j++)
 {
 for(i=0;i<index_length;i++)
  temp_seq[i] = seq[j+i];
 temp_seq[index_length] = '\0';

 temp_num = seq2index_num(temp_seq);
 ils[temp_num].pos[ils[temp_num].n_pos++] = j;
 }
//////////////////////////////////////////////////////// Fill the index list END


//////////////////////////////////////////////////////// Start searching
for(i=0;i<seq_len;i++)                 // $BHf3S3+;OE@(B
 {
 // $B=g:?%5!<%A(B
 for(j=0;j<index_length;j++)
  temp_seq[j] = seq[i+j];
 temp_seq[index_length] = '\0';
 temp_num=seq2index_num(temp_seq);
 for(j=0;j<ils[temp_num].n_pos;j++)    // $B%$%s%G%C%/%9%R%C%H?t%j%T!<%H(B
  {
  pos = ils[temp_num].pos[j];
  if(pos <= i)                         // $B%R%C%H0LCV$,:#$N0LCV$h$j<c$1$l$P!!GS=|!JBP>NJRJ}$N$_!K(B
   continue;
  cc = 0;
  if(((i-1) >= 0) && ((pos-1) >= 0))
   {
   if(seq[i-1] == seq[pos-1])          // $B%$%s%G%C%/%9$NA0$,0lCW$7$J$1$l$P!!GS=|!J%R%C%H$r%f%K!<%/$K!K(B
    continue;
   }
  cc = 0;
  for(k=0;k<=max_rep;k++)               // $BC`;z%A%'%C%/%k!<%W(B
   {
   if(pos+k > seq_len)
    {
    break;
    }
   else
    {
    if(seq[i+k] == seq[pos+k])
     {
     cc ++;
     }
    else
     {
     if((cc >= min_len) && (cc <= max_len))                  // $BD9$$(B(min_len$B0J>e!K%R%C%H$,8+$D$+$C$?;~(B
     //if(cc >= min_len) 
      {
      if(print_heat_map == 1)
       {
       if(((i+1) > 0) && ((i+1) < seq_len) && ((pos+1) > 0) && ((pos+1) < seq_len))
        heat_map[(i+1)/hm_mesh][(pos+1)/hm_mesh] ++;
       }
      if(print_pos_list == 1)
       fprintf(pos_list,"%10d\n%10d\n",i+1,pos+1);
      if(print_dist == 1)
       fprintf(dist_file,"%10d\n",abs(i-pos));

      if(print_hit == 1)
       printf("HIT from %10d to %10d length %10d\n",i+1,pos+1,cc);
      if(cc < 10000)
       bin[cc] ++;
      else
       bin[1000] ++;
      if(print_seq == 1)
       {
       for(l=0;l<cc;l++)
        printf("%c",seq[i+l]);
       printf("\n");
       for(l=0;l<cc;l++)
        printf("%c",seq[pos+l]);
       printf("\n");
       }
      cc = 0;
      }
     break;
     }
    }
   }
  }
 
 // $B5U:?%5!<%A(B
 for(j=0;j<index_length;j++)              // $B:8$+$i(B $BAjJd5U:9%$%s%G%C%/%9(B
  temp_seq[j] = comp(seq[i+index_length-j-1]);
 temp_seq[index_length] = '\0';
 temp_num=seq2index_num(temp_seq);
 for(j=0;j<ils[temp_num].n_pos;j++)    // $B%$%s%G%C%/%9%R%C%H?t%j%T!<%H(B
  {
  pos = ils[temp_num].pos[j];
//  if(pos <= i)                         // $B%R%C%H0LCV$,:#$N0LCV$h$j<c$1$l$P!!GS=|!JBP>NJRJ}$N$_!K(B
//   continue;
  cc = 0;
  if(((i-1) >= 0) && ((pos+index_length) < seq_len))
   {
   if(seq[i-1] == comp(seq[pos+index_length]))
    continue;
   }
  cc = 0;
  for(k=0;k<=max_rep;k++)               // $BC`;z%A%'%C%/%k!<%W(B
   {
   if(pos+index_length >= seq_len)     // $B1&$K$O$_=P$9(B
    {
    break;
    }
   else
    {
    if(seq[i+k] == comp(seq[pos+index_length-k-1]))
     {
     cc ++;
     }
    else
     {
     if((cc >= min_len)  && (cc <= max_len))                 // $BD9$$(B(min_len$B0J>e!K%R%C%H$,8+$D$+$C$?;~(B
//     if(cc >= min_len)
     if((pos - cc) <= i)
      {
      if(print_heat_map == 1)
       {
       if(((i+1) > 0) && ((i+1) < seq_len) && ((pos+index_length-cc) > 0) && ((pos+index_length-cc) < seq_len))
        heat_map[(i+1)/hm_mesh][(pos+index_length-cc)/hm_mesh] ++;
       }
      if(print_pos_list == 1)
       fprintf(pos_list,"%10d\n%10d\n",i+1,pos+index_length-cc);
      if(print_dist == 1)
       fprintf(dist_file,"%10d\n",abs(i-(pos+index_length)));

      if(print_hit == 1)
       printf("REV from %10d to %10d length %10d\n",i+1,pos+index_length-cc,cc);
      if(cc < 10000)
       bin[cc] ++;
      else
       bin[1000] ++;
      if(print_seq == 1)
       {
       for(l=0;l<cc;l++)
        printf("%c",seq[i+l]);
       printf("\n");
       for(l=0;l<cc;l++)
        printf("%c",seq[pos+index_length-cc+l]);   // $BAjJd5U:9$N%^%^(B
//        printf("%c",comp(seq[pos+index_length-l-1])); //$B8~$-B7$($k!J0lCW!K(B
       printf("\n");
       }
      cc = 0;
      }
     break;
     }
    }
   }
  }

 }

for(i=0;i<hm_num;i++)
 {
 for(j=0;j<hm_num;j++)
  {
  fprintf(hm_file,"%10d ",heat_map[i][j]);
  }
 fprintf(hm_file,"\n");
 }

for(i=0;i<1001;i++)
 printf("%10d %10d\n",i,bin[i]);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////// MAIN$B4X?t(B

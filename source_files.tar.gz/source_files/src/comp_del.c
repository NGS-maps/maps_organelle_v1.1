#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "comp_del.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
FILE        *del_list;
FILE        *del_file;
FILE        *del_out;
char        del_out_flnm[512];
FILE        *del_out2;                                                   ///
char        del_out2_flnm[512];                                          ///
char        buff[512];
int         n_files = 0;
int         n_lines = 0;
word_info   files[MAX_FILE];
dels_infos  dels[MAX_FILE];
int         read_count[MAX_FILE];                                        ///
double      bias_ratio[MAX_FILE];                                        ///
int         pointer[MAX_FILE];
int         min;
int         temp;
int         temp_min;
int         temp_order;
int         bias_flag = 1;                                               ///

readargs(argc,argv);

printf("INPUT PALINDROME LIST FILES NAME IS: %s\n",arg1);
del_list = fopen(arg1,"r");
if(del_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

sprintf(del_out_flnm,"%s.out",arg1);                           // $B=PNO%U%!%$%kL>(B
del_out = fopen(del_out_flnm,"w");
if(del_out == NULL)
 {
 printf("Failed to open the output file %s\n",del_out_flnm);
 exit(1);
 }

sprintf(del_out2_flnm,"%s.out2",arg1);                           /// $BJd@5=PNO%U%!%$%kL>(B
del_out2 = fopen(del_out2_flnm,"w");                             ///
if(del_out2 == NULL)                                             ///
 {                                                               ///
 printf("Failed to open the output file %s\n",del_out2_flnm);    ///
 exit(1);                                                        ///
 }                                                               ///

while(fgets(buff,512,del_list))                                // del$B%U%!%$%kL>%j%9%HFI$_9~$_(B
 {
 sscanf(buff,"%s %d",files[n_files].word,&read_count[n_files]);  ///
// buff[strlen(buff)-1] = '\0';                                  ///
// strcpy(files[n_files].word,buff);                             ///
 n_files ++;
 }

for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 if(read_count[i] == 0)                           // $BFI$_9~$s$@%j!<%I%+%&%s%H$K0l$D$G$b(B0$B$N$b$N$,$"$l$P(B              ///
  {                                                                                                                 ///
  bias_flag = 0;                                  // $B%j!<%I?t%P%$%"%9$O9MN8$7$J$$(B                                   ///
  }                                                                                                                 ///
 }                                                                                                                  ///

if(bias_flag == 1)                                                                                                  ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  {                                                                                                                 ///
  bias_ratio[i] = (double)read_count[i] / (double)read_count[0];                                                    ///
  }                                                                                                                 ///
 }                                                                                                                  ///
else                                                                                                                ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  bias_ratio[i] = 1.0;                                                                                              ///
 }                                                                                                                  ///

for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 printf("%-55s %10d %10.5f\n",files[i].word,read_count[i],bias_ratio[i]*100.0);                                     ///
 }                                                                                                                  ///

///////////////////////////////////////////////////// /////////////////////////////////////////////////////
for(i=0;i<n_files;i++)                                         // del$B%U%!%$%k$N?t$N%k!<%W(B
 {
 del_file = fopen(files[i].word,"r");                          // del$B%U%!%$%k3+$/(B
 if(del_file == NULL)
  {
  printf("Failed to open the input file %s\n",files[i].word);
  exit(1);
  }

 n_lines = 0;
 while(fgets(buff,512,del_file))
  {
  n_lines ++;
  }
 dels[i].n_del = n_lines;
 dels[i].dinf  = (del_info *)malloc(sizeof(del_info)*(n_lines + 2));
 
 rewind(del_file);

 n_lines = 0;
 while(fgets(buff,512,del_file))                              // del$B%U%!%$%k$NFI$_9~$_(B
  {
  dels[i].dinf[n_lines].n_del    = read_int(buff, 2, 6);      // del$B1v4p?t(B
  dels[i].dinf[n_lines].start    = read_int(buff, 9,10);      // del$B0LCV!J%2%N%`>e!K(B
  dels[i].dinf[n_lines].n_member = read_int(buff,20,10);      // $B%8%c%s%/%7%g%s%j!<%I?t(B
//  printf("%8d %8d %5d\n",dels[i].dinf[n_lines].start,dels[i].dinf[n_lines].n_del,dels[i].dinf[n_lines].n_member);
  n_lines ++;
  }
 printf("%5d %s\n",n_lines,files[i].word);
 fclose(del_file);
 pointer[i] = 0;
 }                                                            // del$B%U%!%$%k$N?t$N%k!<%W=*$o$j(B
///////////////////////////////////////////////////// /////////////////////////////////////////////////////

/*
for(i=0;i<n_files;i++)
 {
 for(j=0;j<dels[i].n_del;j++)
  {
  if(dels[i].dinf[j].sum == dels[i].dinf[dels[i].order[j]].sum)
   printf("%8d %8d\n",dels[i].dinf[j].sum,dels[i].dinf[dels[i].order[j]].sum);
  else
   printf("%8d %8d#\n",dels[i].dinf[j].sum,dels[i].dinf[dels[i].order[j]].sum);
  }
 }
*/

//fprintf(del_out,",,");                                //$B=PNO%U%!%$%k0l9TL\$K%U%!%$%kL>$r%j%9%H$9$k(B
//for(i=0;i<n_files;i++)
// fprintf(del_out,"%s",files[i].word);
//fprintf(del_out,"\n");
 
int ndel;
///////////////////////////////////////////////////// vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
while(1)                                                      // $B%U%!%$%k4VHf3S(B
 {
 min = MAX_INT;                                      
 ndel = MAX_INT;
 for(i=0;i<n_files;i++)                                  // 1st $B%9%-%c%s(B $B:G>.CM$r8!=P(B
  {
  if(pointer[i] < dels[i].n_del)
   if(min > dels[i].dinf[pointer[i]].start)
    {
    min = dels[i].dinf[pointer[i]].start;
    ndel= dels[i].dinf[pointer[i]].n_del;
    }
  }
 printf("MIN %d %d\n",min,ndel);
 fprintf(del_out,"%d,%d,",min,ndel);
 fprintf(del_out2,"%d,%d,",min,ndel);                                                                                              ///

 for(i=0;i<n_files;i++)                                 // 2nd $B%9%-%c%s(B $B:G>.$NCM$r=PNO(B
  {
  if(pointer[i] < dels[i].n_del)
   {
   if(min == dels[i].dinf[pointer[i]].start)
    {
    printf("%2d %8d %8d %8d %10.2f\n",i+1,dels[i].dinf[pointer[i]].start,dels[i].dinf[pointer[i]].n_del,                           ///
                                dels[i].dinf[pointer[i]].n_member, (double)dels[i].dinf[pointer[i]].n_member/bias_ratio[i]);       ///
    fprintf(del_out,"%d,",dels[i].dinf[pointer[i]].n_member);
    fprintf(del_out2,"%.2f,",(double)dels[i].dinf[pointer[i]].n_member/bias_ratio[i]);                                             ///
    pointer[i] ++;                                      // $B%]%$%s%?$r?J$a$k(B
    }
   else
    {
    fprintf(del_out,"0,");
    fprintf(del_out2,"0.0,");                                                                                                      ///
    }
   }
  else
   {
   fprintf(del_out,"0,");
   fprintf(del_out2,"0.0,");                                                                                                       ///
   }
  }
 fprintf(del_out,"\n");
 fprintf(del_out2,"\n");                                                                                                           ///

 temp = 0;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] == dels[i].n_del)
   temp ++;                                             // $B:G8e$^$G%A%'%C%/$7$?(Bdel$B%U%!%$%k$N?t$r%+%&%s%H(B
  }
 if(temp == n_files)
  break;
 }
///////////////////////////////////////////////////// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/////////////////////////////////////////////////////////////////DONE READING FILES
}
/////////////////////////////////////////////////////////////////////////MAIN END

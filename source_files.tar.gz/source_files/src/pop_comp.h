#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_READ_LEN           110
#define MAX_PAGE             10000

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct link_info     // $B%j%s%/>pJs(B
 {
 char  header;               // $B%X%C%@J8;z(B
 int   from;                 // $BHt$S85(B
 int   to;                   // $BHt$S@h(B
 int   n_read;               // $B%j!<%I?t(B  $B!J?.Mj@-!K(B
 char  *h_sequence;
 int   h_seq_len;
 } link_info;

void readargs(int argc, char **argv);

#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN       1024

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct pe_info
 {
 int  start;
 int  end;
 int  left;
 int  right;
 int  n_member;
 int  n_pe;
 } pe_info;

typedef struct pes_infos
 {
 int n_pe;
 pe_info *pinf;
 } pes_infos;

typedef struct share_info
 {
 int from;
 int to; 
 int *n_member;   // file$B?t@Z$C$F$=$l$>$l$N%j!<%I?t$rF~$l$k(B
 } share_info;

void readargs(int argc, char **argv);

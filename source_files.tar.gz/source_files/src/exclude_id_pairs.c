#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "exclude_id_pairs.h"
#define BUFLEN 512

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//    exclude_id_pairs = exclude artificial pairs using idss output          //
//                                                                           //
//    usage: exclude_id_pairs [options]  pdist_file ids_file                 //
//                                                                           //
//    options:      -m  ##:  minimum identical sequence length               //
//                  -i  ##:  index length                                    //
//                                                                           //
//    Programed by Kensuke Nakamura, Since Feb. 23 2018, All right reserved. //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

typedef struct pdist_info
{
int fr;
int to;
int id;
char line[256];
int flag;
} pdist_info;

typedef struct ids_info
{
int fr1,to1;
int fr2,to2;
int range;
int direction;
} ids_info;
////////////////////////////////////////GLOBAL VARIABLE     // グローバル変数宣言
char arg1[BUFLEN];
char arg2[BUFLEN];
//////////////////////////////////////// FUNCTION DEFINITIONS // 関数定義


int read_int (char *str,int start,int width)   // ## Function read_int 文字列から数値を取る
{
char buf[BUFLEN+1];

if (width > BUFLEN)
width = BUFLEN;
strncpy (buf, &str[start-1], width);
buf[width] = '\0';
return atoi (buf);
}

int within(int a, int c1, int c2)
 {
 int b1,b2;
 if(c1 < c2)  // 小さい方がb1 大きい方がb2
  {
  b1 = c1;
  b2 = c2;
  }
 else
  {
  b2 = c1;
  b1 = c2;
  }
 if((a > b1 - 1000) && (a < b2 + 1000))   // a1が区間内
  {
  return 1;
  }
//printf("%10d %10d %10d %10d %10d\n",a,b1,b2,c1,c2);
 return 0;
 }
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ FUNCTION DEFINITIONS    // 関数定義

////////////////////////////////////////// MAIN FUNCTION            // メイン関数
int main(int argc, char **argv)
{
int i,j,k,l,m;
int cc = 0;
int flag;
int a,b;
int c1,c2;
int d1,d2;

char ids_flnm[512];
char pdist_flnm[512];
FILE *ids_file;
FILE *pdist_file;
//FILE *out_file;
int n_pdist  = 0;
int n_ids = 0;
pdist_info  *pdists;
ids_info *idss;

char buff[512];

readargs(argc,argv);

pdist_file = fopen(arg1,"r");
if(pdist_file == NULL)
 {
 printf("Failed to open the paired_end file %s\n",pdist_flnm);
 exit(1);
 }

ids_file = fopen(arg2,"r");
if(ids_file == NULL)
 {
 printf("Failed to open the ids file %s\n",ids_flnm);
 exit(1);
 }

while(fgets(buff,132,pdist_file))
 {
 n_pdist ++;
 }
while(fgets(buff,132,ids_file))
 {
 n_ids ++;
 }
rewind(pdist_file);
rewind(ids_file);

pdists  = (pdist_info *)malloc(sizeof(pdist_info) * (n_pdist+5));
if(pdists == NULL)
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }
idss = (ids_info *)malloc(sizeof(ids_info) * (n_ids+5));
if(idss == NULL)
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }

for(i=0;i<n_pdist;i++)
 pdists[i].flag = 0;


cc = 0;
while(fgets(buff,132,pdist_file))
 {
 pdists[cc].id    = read_int(buff,1,10);
 pdists[cc].fr    = read_int(buff,12,10);
 pdists[cc].to    = read_int(buff,23,10);
 strcpy(pdists[cc].line,buff);
// printf("%10d %10d %10d\n",pdists[cc].id,pdists[cc].fr,pdists[cc].to);
 cc ++;
 }

cc = 0;
while(fgets(buff,132,ids_file))
 {
 idss[cc].fr1   = read_int(buff, 3,10);
 idss[cc].to1   = read_int(buff,14,10);
 idss[cc].fr2   = read_int(buff,25,10);
 idss[cc].to2   = read_int(buff,36,10);
 idss[cc].range = read_int(buff,46,10);

 cc++;
// printf("%10d %10d %10d %10d %10d\n",idss[cc].fr1,idss[cc].to1,idss[cc].fr2,idss[cc].to2,idss[cc].range);
 }


for(i=0;i<n_pdist;i++)      // 判定
 {
 if((abs(pdists[i].fr)) < (abs(pdists[i].to)))  // 絶対値の小さいほうがa 大きい方がb
  {
  a = abs(pdists[i].fr);
  b = abs(pdists[i].to);
  }
 else
  {
  a = abs(pdists[i].to);
  b = abs(pdists[i].fr);
  }
 for(j=0;j<n_ids;j++)
  {                                         // 絶対値の小さい区間がc 大きい区間がd
  if(idss[j].fr1 < idss[j].to1)
   {
   c1 = idss[j].fr1;
   c2 = idss[j].to1;
   }
  else
   {
   c1 = idss[j].to1;
   c2 = idss[j].fr1;
   }
   
  if(idss[j].fr2 < idss[j].to2)
   {
   d1 = idss[j].fr2;
   d2 = idss[j].to2;
   }
  else
   {
   d1 = idss[j].to2;
   d2 = idss[j].fr2;
   }

 if((a > (c1-3)) && ((a+50) < (c2+3)))
  {
  if( (b > (d1 - 600)) && (b < d1) )
   pdists[i].flag = 1;
  if( (b > (d2 - 50))  && (b < (d2+650)) )
   pdists[i].flag = 1;
  }

/*
 if((b > d1-3) && (b+50 < d2+3))
  {
  if((a > (c1 - 400)) && ((a+50) < c1+50))
   pdists[i].flag = 1;
  if((a > c2-50) && ((a+50) < (c2+400)))
   pdists[i].flag = 1;
  }
*/

/*********************************
 if((a > c1-3) && (a+50 < c2+3))
  {
  //if((b > (d1 - 600)) && ((b+50) < d1))
  if((b > (d1 - 400)) && ((b+50) < d1+50))
   pdists[i].flag = 1;
  //if((b > d2) && ((b+50) < (d2+400)))
  if((b > d2-50) && ((b+50) < (d2+400)))
   pdists[i].flag = 1;
  }

 if((b > d1-3) && (b+50 < d2+3))
  {
  if((a > (c1 - 400)) && ((a+50) < c1))
   pdists[i].flag = 1;
  if((a > c2) && ((a+50) < (c2+400)))
   pdists[i].flag = 1;
  }
*********************************/
 
 //if((c1 > c2) || (d1 > d2))
 // if(c1 > d1)
 // printf("wow %d %d %d %d\n",c1,c2,d1,d2);

/*
  if((within(a,c1,c2)==1) && (within(b,d1,d2)==1))
   {
   pes[i].flag = 1;
   }
  if((within(b,c1,c2)==1) && (within(a,d1,d2)==1))
   {
   pes[i].flag = 2;
   }
*/
  }
 }

for(i=0;i<n_pdist;i++)
 {
 if(pdists[i].flag == 0)
  {
//  printf("%2d %s",pdists[i].flag,pdists[i].line);
  printf("%s",pdists[i].line);
  }
 }
//printf("%d\n",n_pdist);
fclose (pdist_file);
fclose (ids_file);
return 0;
}

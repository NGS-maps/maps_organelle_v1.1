#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "chopfastq.h"

#define BUFLEN 512

////////////////////////////////////////////////////////////////////// GLOBAL VARIABLES

int  n_query        =  0;
int  query_len      =  0;
int  chop_length    = 30;
char  arg1[BUFLEN];
char  arg2[BUFLEN];
query_info *qs;

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int    i,j,k,l,m,n;
int    p_id;
char   buff[BUFLEN];
int    tempcount;
//***************************************
//* CHECK PROCESS ID                    *
//***************************************
p_id = getpid();
//***************************************
//* CHECK ARGUMENTS                     *
//***************************************
readargs(argc,argv);

char query_flnm[256];
char out_flnm[256];
FILE *query_file;
FILE *out_file;
sprintf(query_flnm,"%s",arg1);
sprintf(out_flnm,"chp%d_%s",chop_length,arg1);
if(!(query_file = fopen(query_flnm,"r")))
 {
 printf("Failed to open input query file: %s\n",query_flnm);
 exit(1);
 }
if(!(out_file = fopen(out_flnm,"w")))
 {
 printf("Failed to open output file: %s\n",out_flnm);
 exit(1);
 }
///////////////////////////////////////////////////////// COUNT QUERY READ SEQUENCES //Query 配列カウント
n_query = 0;
//while(fgets(buff,500,query_file))
// {
// if(buff[0] == '@')
//  {
//  n_query ++;
//  fgets(buff,500,query_file);
////  printf("%s",buff);
//  }
// }
while(fgets(buff,500,query_file))
 {
 fprintf(out_file,"%s",buff);
 n_query ++;
 fgets(buff,500,query_file);
 buff[chop_length]   = '\n';
 buff[chop_length+1] = '\0';
 fprintf(out_file,"%s",buff);
 fgets(buff,500,query_file);
 fprintf(out_file,"%s",buff);
 fgets(buff,500,query_file);
 buff[chop_length]   = '\n';
 buff[chop_length+1] = '\0';
 fprintf(out_file,"%s",buff);
 }
///////////////////////////////////////////////////////// END COUNT QUERY READ SEQUENCES // Query 配列カウント終
printf("NUMBER OF QUERY SEQUENCE IS:%10d\n",n_query);
printf("DONE READ QUERY \n");
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//printf("QUERY SEQUENCE IS: %s\n",queryseq);
//printf("QUERY SEQUENCE LENGTH IS: %d\n",(int)strlen(queryseq));
//for(k=0;k<n_query;k++)
// {
// printf("%s\n",qs[k].seq);
// }
}
//////////////////////////////////////////////////////////////////////////MAIN END

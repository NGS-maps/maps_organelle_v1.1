#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_MISS 75
#define MAX_QUERY_LEN      310
#define MAX_INDEX_LEN       14
#define MAX_INDEX_SIZE    5000
#define MAX_QUERY     55000000
#define MAX_INT     2147483647
#define MAX_BOX           1400
#define MAX_FOLD        100000
#define MAX_GENE         50000
#define MAX_PAGE         10000
#define MAX_THREAD_NUM      32
#define MAX_CHROMOSOME      80

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct query_info
 {
 char *seq;                 // リードの配列
 char *ceq;                 // complement sequence 相補鎖
 char *quality;
 char *cuality;
 char *quality_edge;
// int depth;
 } query_info;

typedef struct position_hit_info
 {
 int n_hit;
 int *hits;
 int *boxs;
 int n_f_hit;
 int n_r_hit;
 } position_hit_info;

typedef struct index_list
 {
 char seq[MAX_INDEX_LEN+1];
 int n_pos;
 int *pos;
 } index_list;

typedef struct splice_info
{
int n_segment;          // Number of segments // イントロンの数
int *froms;             // Start point of the i'th segment
int *tos;               // End point of the i'th segment
} splice_info;

typedef struct genbank_info
{
int from;
int to;
int chr_id;
int n_mrna;
splice_info *mrnas;
int n_cds;
splice_info *cdss;
int complement;
char gene_name[128];
char product_name[512];
char locus_tag[128];
char note[80];
int type;               //   1:CDS, 2:tRNA, 3:rRNA, 4:misc_RNA, 5:tmRNA, 6:misc_feature
char type_char[10];
int intensity;
int tag_count;
int pre_tag_count;
int pre_intensity;
} genbank_info;

typedef struct chromosome_info
 {
 char title[512];
 int  start_position;
 } chromosome_info;

typedef struct sam_line_info
 {
// char FNAME[MAX_FNAME_LEN];
 int FLAG;
// char RNAME[MAX_RNAME_LEN];
 int POS;
 int MAPQ;
 char *CIGAR;
// char RNEXT[MAX_RNAME_LEN];
 int PNEXT;
 int TLEN;
 char *SEQ;
 char *QUAL;
 char *ALIGN;
 } sam_line_info;


void readargs(int argc, char **argv);
void read_genbank(void);
void read_genbank_e(void);

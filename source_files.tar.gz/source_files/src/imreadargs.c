#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/////////////////////////////////$B30ItJQ?t(B
extern char arg1[];
extern char arg2[];
extern int n_thread;
extern int index_length;
extern int n_round;
extern int thresh_miss;
extern int jobname;
extern char job_name[];
extern int multi_hit;
extern int map_out;
extern int map_out_width;
//extern int cyclic;
/////////////////////////////////$B30ItJQ?t(B

void errorm(int en);                  // $B%(%i!<%a%C%;!<%84X?t!!%W%m%H%?%$%W(B

void readargs(int argc, char **argv)  // readargs: $B%"!<%.%e%a%s%H=hM}4X?t(B
{
int i;
int temp;
int arg;
int flag = 0;

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {
  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') && (argv[arg][3] == 'b'))   // -job jobname   reference.fasta.jobname.###
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    jobname = 1;
    arg ++;
    strcpy(job_name,argv[arg]);
    }
   continue;
   }
  if(argv[arg][1] == 'a')                                       // -a number (such as -a 4) as number of thread (multithread)
   {
   arg ++;
   n_thread = atoi(argv[arg]);
   printf("NTHREAD %d\n",n_thread);
   continue;
   }
  if(argv[arg][1] == 'r')                                       // -r number (such as -r 5) as round cycle
   {
   arg ++;
   n_round = atoi(argv[arg]);
   printf("NROUND %d\n",n_round);
   continue;
   }
  if(argv[arg][1] == 'h')                                       // -h number (such as -h 3) as threshold for hit (# mismatch)
   {
   arg ++;
   thresh_miss = atoi(argv[arg]);
   continue;
   }
  if(argv[arg][1] == 'i')                                       // -i number (such as -i 4) as index_length (# mismatch)
   {
   arg ++;
   index_length = atoi(argv[arg]);
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'h'))            // -mh consider multiple hit for a query
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    multi_hit = 1;
    }
   continue;
   }
  if((argv[arg][1] == 'm') && (argv[arg][2] == 'a') && (argv[arg][3] == 'p')) // -map output map file  reference.fasta.map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    map_out = 1;
    }
   continue;
   }

//  if((argv[arg][1] == 'c') && (argv[arg][2] == 'y') && (argv[arg][3] == 'c'))         // -cyc $B%5%$%/%j%C%/%2%N%`(B
//   {
//   if(argv[arg][4] != '\0')
//    errorm(1);
//   else
//    {
//    cyclic = 0;
//    }
//   continue;
//   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'w')) // -mw number (such as -a 200) as width of map (text) with -map option
   {
   arg ++;
   map_out_width = atoi(argv[arg]);
   printf("MAP_OUT_WIDTH %d\n",map_out_width);
   continue;
   }

  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference file name
   strcpy(arg1,argv[arg]);
   }
  else
   {                                             // read second argument without - as the read fastaq file name
   strcpy(arg2,argv[arg]);
   }
  flag ++;
  if(flag >= 3)
   errorm(2);
  }
 }

}

void errorm(int en)                              // $B%(%i!<%a%C%;!<%84X?t(B
 {
 printf("ERROR %d\n",en);
 printf("Usage:  ismap [-options] reference.fasta read_sequences.fastaq \n");
 printf("                                 .fasta(reference sequence) and .fastaq/.fq (sequencer reads) as input   \n");
 printf("                   -job jobname : specify smap run by jobname (suffix of query file)\n");
 printf("                   -cyc: input reference is a cyclic genome\n");
 printf("                   -map: create file of mapping results as reference.fasta.map \n");
 printf("                   -mw 100: define map width for text map when -map option is specified\n");
 printf("                   -a 4: set number of thread as 4 (default: 1)\n");
 printf("                   -i 4: set index length as 4 (default: 8)\n");
 printf("                   -r 5: set round cycle  as 5 (default: 2)\n");
 printf("                   -h 3: set treshold mismatch number for hit as 1 (default: 3)\n");
 printf("\n");
 printf("                   -mr : multi reference  input reference is a list of reference fasta files  NOT IN USE\n");
 exit(1);
 }


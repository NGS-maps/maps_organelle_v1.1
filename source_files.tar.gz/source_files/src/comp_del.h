#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN        256

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct del_info
 {
 int  start;
 int  n_member;
 int  n_del;
 } del_info;

typedef struct dels_infos
 {
 int n_del;
 del_info *dinf;
 } dels_infos;

void readargs(int argc, char **argv);

#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN        256

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct ins_info
 {
 int  start;
 int  n_member;
 int  n_ins;
 char seq[MAX_SEQ_LEN];
 } ins_info;

typedef struct ins_infos
 {
 int n_ins;
 ins_info *iinf;
 } ins_infos;

void readargs(int argc, char **argv);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <math.h>
#include "pop_comp.h"
#define MAX_ARG_LEN 132
#define BUFLEN      512
#define PI          3.1415926535897932
#define MAX_TRACK    20

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//    POP_COMP = COMPARE POPULATIONS OF READ MAPS                            //
//                                                                           //
//    usage: pop_comp [options] reference.peb sample.peb                     //
//                                                                           //
//    Programed by Kensuke Nakamura, Since Apr. 2018, All right reserved.    //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

typedef struct pop_info
{
int plus;
int minus;
} pop_info;

///////////////////GLOVAL VARIABLE

char arg1[MAX_ARG_LEN];
char arg2[MAX_ARG_LEN];

int genome_length;
int window_size        = 100;    // �P�E�B���h�E�̕`�敝�ɓ��鉖�
double left_margin     = 100;    // �P�E�B���h�E�̕`�敝�ɓ��鉖�
double bottom_margin   =  80;    // �P�E�B���h�E�̕`�敝�ɓ��鉖�
double pop_width       = 0.50;    // �P�E�B���h�E�̕`�敝�i�|�C���g�j
int num_iterations;            // ���ɕ��ԃE�B���h�E�̐�
double base_height     =  80.0;
double height_scale    =   1.0;
double pop_scale       =   1.0;
double thin_width      = 0.20;    // �P�E�B���h�E�̕`�敝�i�|�C���g�j

double step2_base     = 200.0;
double step3_base     = 320.0;

double step2_scale    = 0.005;
double step3_scale    = 0.005;

int ref_max = 0;
int sam_max = 0;

double tic_interval;
double ttic_interval;
double startx,starty;
double endx,endy;

pop_info   *ref_pops;
pop_info   *sam_pops;

FILE *psfile;                   // �o��ps�t�@�C��


//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\FUNTION DEFINITIONS END
int read_int (char *str,int start,int width)   // ## Function read_int �����񂩂琔�l����� 
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}

int count_comma(char *str)
 {
 int i,val=0;
 for(i=0;i<strlen(str);i++)
  {
  if(str[i] == ',')
   val ++;
  }
 return val+1;
 }

int ithnum(int a,int b,char *str)
 {
 int i,j;
 char ss[16];
 int begin,end;
 int flag = 0;
 int flag2= 0;
 int count= 0;
 int count2= 0;
 int thenum;
 thenum = b*2+a;
 for(i=0;i<strlen(str);i++)
  {
  if(flag == 0)  // �����łȂ�
   {
   if((str[i] >= '0') && (str[i] <= '9'))  // �����ɂȂ�
    {
    flag = 1;
    count ++;
    if(count == thenum)
     {
     flag2 = 1;
     ss[count2] = str[i];
     count2++;
     }
    }
   else                                    // �����łȂ��܂�
    {
    }
   }
  else           // �����̒�
   {
   if((str[i] >= '0') && (str[i] <= '9'))  // �����̑���
    {
    if(flag2 == 1)
     {
     ss[count2] = str[i];
     count2++;
     }
    }
   else                                    // �����łȂ��Ȃ�
    {
    if(flag2 == 1)
     {
     ss[count2] = '\0';
     return(atoi(ss));
     }
    flag = 0;
    }
   }
  }
 return (-1);
 }

///////////////////////////////////////////////////////////////////////////////////////////// MAIN
int main(int argc, char **argv)
{
int i,j,k,l,m;
char ps_buff[100000];
char psout_flnm[BUFLEN];
char buff[BUFLEN];
FILE *inref;                   // ���̓t�@�C��  hr, unk
FILE *insample;                   // ���̓t�@�C��  hr, unk
int n_pos;
int ref_plus_line=0;
int ref_minus_line=0;
int sam_plus_line=0;
int sam_minus_line=0;
int n_ref_line = 0;
int n_sam_line = 0;
int fr,to;
char sign;
int pop,max_pop,n_line;
int refpopsum;
int sampopsum;

double ps_font_size = 8.0;

readargs(argc,argv);

printf("input reference file    = %s\n",arg1);  // �W��peb WT
printf("input sample file       = %s\n",arg2);  // �ϑ�peb Mutant

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
inref = fopen(arg1,"r");
if(inref == NULL)
 {
 printf("Failed to open input reference file %s\n",arg1);
 exit(1);
 }

insample = fopen(arg2,"r");
if(insample == NULL)
 {
 printf("Failed to open input sample file %s\n",arg2);
 exit(1);
 }

while(fgets(buff,BUFLEN,inref))         // peb �t�@�C���X�L���� �i�J�E���g�j
 {
 sscanf(buff,"%d %d %c %d",&fr,&to,&sign,&pop);
//printf("%10d %10d %5c %10d\n",fr,to,sign,pop);
 if(fr != to)
  {
  printf("invalid format of peb %s file\n",arg1);
  exit(1);
  }
 if(sign == '+')
  ref_plus_line ++;
 if(sign == '-')
  ref_minus_line ++;
 n_ref_line ++;
 }                                      // peb�t�@�C���X�L�����I

while(fgets(buff,BUFLEN,insample))         // peb �t�@�C���X�L���� �i�J�E���g�j
 {
 sscanf(buff,"%d %d %c %d",&fr,&to,&sign,&pop);
//printf("%10d %10d %5c %10d\n",fr,to,sign,pop);
 if(fr != to)
  {
  printf("invalid format of peb %s file\n",arg2);
  exit(1);
  }
 if(sign == '+')
  sam_plus_line ++;
 if(sign == '-')
  sam_minus_line ++;
 n_sam_line ++;
 }                                      // peb�t�@�C���X�L�����I
printf("REF PEB + line is %10d\n",ref_plus_line);
printf("REF PEB - line is %10d\n",ref_minus_line);
printf("REF PEB   line is %10d\n",n_ref_line);
printf("SMP PEB + line is %10d\n",sam_plus_line);
printf("SMP PEB - line is %10d\n",sam_minus_line);
printf("SMP PEB   line is %10d\n",n_sam_line);

if((ref_plus_line == ref_minus_line) && (ref_plus_line == sam_plus_line) && (ref_plus_line == sam_minus_line))
 {
 genome_length = ref_plus_line;
 printf("genome_length = %d\n",genome_length);
 n_pos = genome_length;
 ref_pops = (pop_info *)malloc(sizeof(pop_info) * (genome_length + 10));
 sam_pops = (pop_info *)malloc(sizeof(pop_info) * (genome_length + 10));
 if((ref_pops == NULL) || (sam_pops == NULL))
  {
  printf("Failed to allocate memory\n");
  return(1);
  }
 }
else
 {
 printf("File size does not match\n");
 return(1);
 }

rewind(inref);
rewind(insample);

n_line = 0;
while(fgets(buff,BUFLEN,inref))         // ref.peb �t�@�C���ǂݍ���
 {
 sscanf(buff,"%d %d %c %d",&fr,&to,&sign,&pop);
 if(sign == '+')
  {
  ref_pops[fr].plus  = pop;
  }
 if(sign == '-')
  {
  ref_pops[fr].minus = pop;
  }
 n_line ++;
 if(pop > max_pop)
  max_pop = pop;
 }                                      // ref.peb�t�@�C���ǂݍ��ݏI

n_line = 0;
while(fgets(buff,BUFLEN,insample))      // sam.peb �t�@�C���ǂݍ���
 {
 sscanf(buff,"%d %d %c %d",&fr,&to,&sign,&pop);
 if(sign == '+')
  {
  sam_pops[fr].plus  = pop;
  }
 if(sign == '-')
  {
  sam_pops[fr].minus = pop;
  }
 n_line ++;
 if(pop > max_pop)
  max_pop = pop;
 }                                      // sam.peb�t�@�C���ǂݍ��ݏI

printf("MAX_POP = %10d\n",max_pop);


sprintf(psout_flnm,"%s.ps",arg2);
if(!(psfile = fopen(psout_flnm,"w")))
 {
 printf("Failed to open output ps file: %s\n",psout_flnm);
 exit(1);
 }
//////////////////////////////////////////////////////////////////////////////  PS OUT PREPARATION //�|�X�g�X�N���v�g�o�͏��� �w�b�_
time_t timeval;
char datestamp[80];
strcpy(datestamp,ctime(&timeval));
strcpy(buff,"%!PS-Adobe-"); fprintf(psfile,"%s\n",buff);                                                       // Global Header
strcpy(buff,"%%Creator: "); fprintf(psfile,"%s%s\n",buff,getenv("USER"));                                      // Global Header
strcpy(buff,"%%CreationDate: "); fprintf(psfile,"%s%s",buff,datestamp);                                        // Global Header
strcpy(buff,"%%DocumentFonts: (atend)"); fprintf(psfile,"%s\n",buff);                                          // Global Header
strcpy(buff,"%%Pages: (atend)"); fprintf(psfile,"%s\n",buff);                                                  // Global Header
strcpy(buff,"%%EndComments"); fprintf(psfile,"%s\n",buff);                                                     // Global Header
strcpy(buff,"/mv {moveto} def"); fprintf(psfile,"%s\n",buff);                                                  // Global Header
strcpy(buff,"%%EndProlog"); fprintf(psfile,"%s\n",buff);                                                       // Global Header
strcpy(buff,"<< /PageSize [842 595]"); fprintf(psfile,"%s\n",buff);                                           // A4
strcpy(buff,"   /Policies << /PageSize 6 >>"); fprintf(psfile,"%s\n",buff);                                    // A4
strcpy(buff,">> setpagedevice"); fprintf(psfile,"%s\n",buff);                                                  // A4
/////////////////////////////////////////////////////////////////////////////////////////  ^ HEADER
strcpy(buff,"%%Page: "); fprintf(psfile,"%s%d\n",buff,1);                                                     // Page Header 1
strcpy(buff,"<< /PageSize [842 595]"); fprintf(psfile,"%s\n",buff);                                           // A4
strcpy(buff,"   /Policies << /PageSize 6 >>"); fprintf(psfile,"%s\n",buff);                                   // A4
strcpy(buff,">> setpagedevice"); fprintf(psfile,"%s\n",buff);                                                 // A4
strcpy(buff,"/pg save def"); fprintf(psfile,"%s\n",buff);                                                     // Page Header 1
sprintf(buff,"/Courier-Bold findfont %5.2f scalefont setfont",ps_font_size); fprintf(psfile,"%s\n",buff);     // Page Header 1
/////////////////////////////////////////////////////////////////////////////////////////  ^ PAGE HEADER �w�b�_�I���

//startx    = 100.0;
//starty    = 100.0;
//endx      = 200.0;
//endy      = 300.0;
//pop_width = 0.5;
//fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
//fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
//fprintf(psfile,"  %f  setlinewidth\n",pop_width);
//fprintf(psfile,"stroke\n");

num_iterations = (genome_length/window_size)+1;

refpopsum = 0;
sampopsum = 0;
for(i=0;i<genome_length;i++)
 {
 if((i%window_size == 0) && (i != 0))
  {

///////////////////////////////////////////////////////////////////////////////////////////////  DRAW SAMPLE/REF RATE
  startx    = left_margin + i/window_size*pop_width;
  starty    = bottom_margin;
  endx      = startx;
  if(refpopsum != 0)
   {
   endy      = bottom_margin + (((double)sampopsum)/((double)refpopsum) * base_height * pop_scale);
   }
  else
   {
   endy      = bottom_margin;
   }
  fprintf(psfile,"  %f %f moveto\n",startx,starty);
  fprintf(psfile,"  %f %f lineto\n",endx,endy);
  fprintf(psfile,"  %f  setlinewidth\n",pop_width);
  fprintf(psfile," 0.5 0.5 0.5 setrgbcolor\n");
  fprintf(psfile,"stroke\n");
///////////////////////////////////////////////////////////////////////////////////////////////  DRAW SAMPLE pop
/*
  startx    = left_margin + i/window_size*pop_width;
  starty    = bottom_margin + step2_base;
  endx      = startx;
  endy      = bottom_margin + step2_base + ((double)sampopsum)*step2_scale;
  fprintf(psfile,"  %f %f moveto\n",startx,starty);
  fprintf(psfile,"  %f %f lineto\n",endx,endy);
  fprintf(psfile,"  %f  setlinewidth\n",pop_width);
  fprintf(psfile," 0.5 0.5 0.5 setrgbcolor\n");
  fprintf(psfile,"stroke\n");
///////////////////////////////////////////////////////////////////////////////////////////////  DRAW REFERENCE POP
  startx    = left_margin + i/window_size*pop_width;
  starty    = bottom_margin + step3_base;
  endx      = startx;
  endy      = bottom_margin + step3_base + ((double)refpopsum)*step3_scale;
  fprintf(psfile,"  %f %f moveto\n",startx,starty);
  fprintf(psfile,"  %f %f lineto\n",endx,endy);
  fprintf(psfile,"  %f  setlinewidth\n",pop_width);
  fprintf(psfile," 0.5 0.5 0.5 setrgbcolor\n");
  fprintf(psfile,"stroke\n");
*/
///////////////////////////////////////////////////////////////////////////////////////////////

  refpopsum = 0;
  sampopsum = 0;
  }
 else
  {
  refpopsum += ref_pops[i].plus;
  refpopsum += ref_pops[i].minus;
  sampopsum += sam_pops[i].plus;
  sampopsum += sam_pops[i].minus;
  }
 }

  startx    = left_margin;
  starty    = bottom_margin + base_height;
  endx      = left_margin + i/window_size * pop_width;
  endy      = starty;
  fprintf(psfile,"  %f %f moveto\n",startx,starty);
  fprintf(psfile,"  %f %f lineto\n",endx,endy);
  fprintf(psfile,"  %f  setlinewidth\n",thin_width);
  fprintf(psfile," 0.9 0.5 0.5 setrgbcolor\n");
  fprintf(psfile,"stroke\n");

/////////////////////////////////////////////////////////////////////////////////////////  v PAGE FOOTER �t�b�^
strcpy(buff,"showpage pg restore"); fprintf(psfile,"%s\n",buff);                                              // Page Footer 1
/////////////////////////////////////////////////////////////////////////////////////////  v FOOTER
strcpy(buff,"%%Trailer"); fprintf(psfile,"%s\n",buff);                                                         // Global Footer
strcpy(buff,"%%DocumentFonts: Courier Courier-Bold"); fprintf(psfile,"%s\n",buff);                             // Global Footer
strcpy(buff,"%%Pages: "); fprintf(psfile,"%s%d\n",buff,1);                                                // Global Footer
fclose(psfile);
/////////////////////////////////////////////////////////////////////////////////////////  FOOTER  �t�b�^�I���
}


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern char arg1[];
extern char arg2[];
//extern char arg3[];

extern int draw_method;
extern double max_radius;                // $BIA2h0h$N:GBgH>7B(B $B%]%$%s%HC10L(B
extern double circos_scale;               // CIRCOS$B2h$N%5%$%:(B $B:GBg(B1.0 
extern double radius_plus;               // CIRCOS$B2h$NCf$G$N%W%i%91_$NH>7B(B
extern double radius_minus;              // CIRCOS$B2h$NCf$G$N%^%$%J%91_$NH>7B(B
extern double radius_inside;             // CIRCOS$B2h$NCf$G$N%^%$%J%91_$NH>7B(B
extern double radius_zero;               // CIRCOS$B2h$NCf$G$N%W%i%91_$H%^%$%J%91_$NCf4V$NH>7B(B
extern double radius_anchor;             // CIRCOS$B2h$NCf$G$N%"%s%+!<1_$NH>7B(B   $B%j%s%/3Q$K0MB8(B
extern double width_circle;              // CIRCOS$B2h$G$N%W%i%9(B/$B%^%$%J%91_$NB@$5(B
extern double thresh_angle;              // $B$3$N3QEY0JFb$J$iD>@\%j%s%/!J30B&!K0J>e$J$i%"!<%/%j%s%/!JFbB&!K(B
extern double caption_scale;             // $BL\@9$j$N?tCM$r%9%1!<%k$N$I$NDxEY30B&$KCV$/$+(B
extern double min_radius_anchor;         // $B%"!<%/%j%s%/$N%"%s%+!<%]%$%s%H$NH>7B!!:G>.(B
extern double max_radius_anchor;         // $B%"!<%/%j%s%/$N%"%s%+!<%]%$%s%H$NH>7B!!:GBg(B
extern double link_width;                // $B%j%s%/$NB@$5(B         $BJQ?t$H$7$F$7$+;H$C$F$J$$(B
extern double base_link_width;           // $B%j%s%/$NB@$5$N4p=`(B   $B$3$l$K%j!<%I?t$N(Blog$B$r$+$1$k(B
extern double point_radius;              // $B@aE@$N1_$NH>7B(B
extern double point_width;               // $B@aE@$N1_$N@~I}(B
extern double tic_interval;              // $BL\@9$j$NI}!!!!>.9o$_(B
extern double tic_height;                // $BL\@9$j$N9b$5!!>.9o$_(B
extern double tic_width;                 // $BL\@9$j$NB@$5!!>.9o$_(B
extern double ttic_interval;              // $BL\@9$j$NI}!!!!Bg9o$_(B
extern double ttic_height;                // $BL\@9$j$N9b$5!!Bg9o$_(B
extern double ttic_width;                 // $BL\@9$j$NB@$5!!Bg9o$_(B
extern double balance_scale;                 // $BL\@9$j$NB@$5!!Bg9o$_(B
extern int  default_window_size;
extern int  paired_end;                 // $BL\@9$j$NB@$5!!Bg9o$_(B
extern double pop_scale;

extern int read_fasta_flag;
extern int read_gb_flag;
extern int read_peb_flag;
extern char fasta_flnm[];
extern char gb_flnm[];
extern char peb_flnm[];
//extern char blastrepeat_flnm[];
//extern char bo8_flnm[];
//extern int read_bo8;
//extern int read_br;
//extern int read_gb;
//extern int read_ge;
//extern int ps_out;

void errorm(int en);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;
int flag = 0;

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {
  if((argv[arg][1] == 't') && (argv[arg][2] == 'i'))                                 // -ti tic interval
   {
   arg ++;
   tic_interval = atoi(argv[arg]);
   printf("TIC INTERVAL %f\n",tic_interval);
   ttic_interval = tic_interval * 10.0;
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'e'))                                 // -pe pair_end mapping 
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {   
//    draw_method = 4;
    paired_end  = 1;
    draw_method = 5;
    }   
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'b'))    // -rgb genbank_flnm 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_gb_flag  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(gb_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'f') &&(argv[arg][3] == 'a'))    // -rfa fasta_flnm 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_fasta_flag  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(fasta_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'p') &&(argv[arg][3] == 'b'))    // -rpb peb_flnm 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_peb_flag  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(peb_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'b') && (argv[arg][2] == 'l') &&(argv[arg][3] == 's'))    // -bls balance_scale 
   {
   arg ++;
   balance_scale = atof(argv[arg]);
   continue;
   }

  if((argv[arg][1] == 'd') && (argv[arg][2] == 'r') &&(argv[arg][3] == 'm'))    // -drm draw_method 
   {
   arg ++;
   draw_method = atoi(argv[arg]);
   continue;
   }
  if((argv[arg][1] == 'w') && (argv[arg][2] == 's') &&(argv[arg][3] == 'z'))    // -wsz default_window_size 
   {
   arg ++;
   default_window_size = atoi(argv[arg]);
   continue;
   }
  if((argv[arg][1] == 'p') && (argv[arg][2] == 's') &&(argv[arg][3] == 'c'))    // -psc population scale 
   {
   arg ++;
   pop_scale = atof(argv[arg]);
   continue;
   }
/*
  if((argv[arg][1] == 's') && (argv[arg][2] == 'b') &&(argv[arg][3] == '8'))    // -bo8 blast format 8 output : read genom self blast format 8 output 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_bo8  = 1;
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
//printf("GENBANK_FILENAME %s\n",argv[arg]);
    strcpy(bo8_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'e'))    // -rge genbank_flnm : read eukariote genbank file and show gene info on the map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_ge  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(genbank_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 's'))    // -ps ps_out : output post script file
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    ps_out  = 1;
   }


  if(argv[arg][1] == 'i')                                        // -a number (such as -a 4) as number of thread (multithread)
   {
   arg ++;
   index_length = atoi(argv[arg]);
   printf("INDEX_LENGTH %d\n",index_length);
   continue;
   }
  if((argv[arg][1] == 'p') && (argv[arg][2] == 'i') && (argv[arg][3] == 'l'))        // -pil Print index_list
   {
   print_index_list = 1;
   continue;
   }
  if((argv[arg][1] == 'c') && (argv[arg][2] == 't'))                                 // -ct number Chop tail  Make index for the first part of reads
   {
   arg ++;
   chop_tail = atoi(argv[arg]);
   printf("CHOP TAIL %d\n",chop_tail);
   continue;
   }
  if((argv[arg][1] == 's') && (argv[arg][2] == 'p') && (argv[arg][3] == 's'))       // -sps spit seed
   {
   printf("SPIT SEED 1\n");
   spit_seed = 1;
   continue;
   }
  if(argv[arg][1] == 'a')                                        // -a number (such as -a 4) as number of thread (multithread)
   {
   arg ++;
   n_thread = atoi(argv[arg]);
   printf("NTHREAD %d\n",n_thread);
   continue;
   }
  /////////////////////////////////////////////////////////
  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') && (argv[arg][3] == 'b'))             // -job jobname          reference.fasta.jobname.###
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    jobname = 1;
    arg ++;
    strcpy(job_name,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'w'))              // -mw number (such as -a 200) as width of map (text) with -map option
   {
   arg ++;
   map_out_width = atoi(argv[arg]);
   printf("MAP_OUT_WIDTH %d\n",map_out_width);
   continue;
   }
  if(argv[arg][1] == 'r')                                        // -r number (such as -r 5) as round cycle
   {
   arg ++;
   n_round = atoi(argv[arg]);
   printf("NROUND %d\n",n_round);
   continue;
   }
  /////////////////////////////////////////////////////////
*/
  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference fasta file name
   strcpy(arg1,argv[arg]);
   }
//  if(flag == 1)
//   {                                             // read second argument without - as the contig fasta file name
//   strcpy(arg2,argv[arg]);
//   }
//  if(flag == 2)
//   {                                             // read third argument without - as the blast m8 out
//   strcpy(arg3,argv[arg]);
//   }
  flag ++;
  if(flag >= 2)
   errorm(2);
  }
 }
}

void errorm(int en)
 {
 printf("ERROR %d\n",en);
 printf("Usage: circmaps [-options] reference_length file.hr\n");
 printf("Options:                                           \n");
 exit(1);
 }

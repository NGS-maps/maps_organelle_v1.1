#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "comp_hmr.h"

extern char arg1[256];
extern char arg2[256];


void errorm(int en);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;
int flag = 0;
char tempchar[80];

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {
///////////////////////////  Options
/*
  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') &&(argv[arg][3] == 'b'))    // -job jobname : specify smap run by jobname
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    jobname  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
//    printf("%s",argv[arg]);
    strcpy(job_name,argv[arg]);
    }
   continue;
   }
*/
///////////////////////////
  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference fasta file name
   strcpy(arg1,argv[arg]);
   }
  else
   {                                             // read second argument without - as the read fastaq file name
   if(flag == 1)
    strcpy(arg2,argv[arg]);
   }
  flag ++;
  if(flag >= 3)
   errorm(2);
  }
 }
}

void errorm(int en)
 {
 printf("ERROR %d\n",en);
 printf("Usage:   comp_hmr [-options] hmr.list\n");
// printf("                        Provide a .fasta(reference sequence) and two .fastaq/.fq (sequence reads) as input fies.\n");
// printf("Options:      -job  : jobname : specify mpsmap run by jobname (suffix of query file)\n");
 exit(1);
 }

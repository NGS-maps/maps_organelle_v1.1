#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "comp_pe.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}
//////////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
FILE        *pe_list;
FILE        *pe_file;
FILE        *pe_out;
FILE        *pe_out2;
char        buff[512];
char        pe_out_flnm[512];
char        pe_out2_flnm[512];
int         n_files = 0;
int         n_lines = 0;
word_info   files[MAX_FILE];
pes_infos   pes[MAX_FILE];
int         pointer[MAX_FILE];
int         read_count[MAX_FILE];
double      bias_ratio[MAX_FILE];
int         min;
int         temp;
int         temp_min;
int         temp_order;
int         bias_flag = 1;
share_info  *scs;
int         n_scs   = 0;
int         max_scs = 0;
int         flag;
int         d1,d2,d3;
char        ds[BUFLEN];

FILE *out[20];
char outflnm[512];

readargs(argc,argv);

printf("INPUT UNKOWN JUNCTION LIST FILES NAME IS: %s\n",arg1);   // $BFI$_9~$`%j%9%H%U%!%$%k3+$/(B
pe_list = fopen(arg1,"r");
if(pe_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

sprintf(pe_out_flnm,"%s.out",arg1);                             // $B=PNO%U%!%$%k3+$/(B out1
pe_out = fopen(pe_out_flnm,"w");
if(pe_out == NULL)
 {
 printf("Failed to open the output file %s\n",pe_out_flnm);
 exit(1);
 }

sprintf(pe_out2_flnm,"%s.out2",arg1);                           // $B=PNO%U%!%$%k3+$/(B out2
pe_out2 = fopen(pe_out2_flnm,"w");
if(pe_out2 == NULL)
 {
 printf("Failed to open the output file %s\n",pe_out2_flnm);
 exit(1);
 }

while(fgets(buff,512,pe_list))                                  // $BF~NO%j%9%H%U%!%$%kFI$`(B
 {
 sscanf(buff,"%s %d",files[n_files].word,&read_count[n_files]);  // $B%U%!%$%kL>$H%j!<%I?t(B  files[].word, read_count[]
// buff[strlen(buff)-1] = '\0';
// printf("%s\n",buff);
// strcpy(files[n_files].word,buff);
 n_files ++;
 }

//////////////////////////////////////////////////////
for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 if(read_count[i] == 0)                           // $BFI$_9~$s$@%j!<%I%+%&%s%H$K0l$D$G$b(B0$B$N$b$N$,$"$l$P(B              ///
  {                                                                                                                 ///
  bias_flag = 0;                                  // $B%j!<%I?t%P%$%"%9$O9MN8$7$J$$(B                                   ///
  }                                                                                                                 ///
 }                                                                                                                  ///

///////////////////////////////////////////////////// $B%j!<%I?t%P%$%"%9$NHfN((B bias_ratio[] $B$r7W;;(B
if(bias_flag == 1)                                                                                                  ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  {                                                                                                                 ///
  bias_ratio[i] = (double)read_count[i] / (double)read_count[0];                                                    ///
  }                                                                                                                 ///
 }                                                                                                                  ///
else                                                                                                                ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  bias_ratio[i] = 1.0;                                                                                              ///
 }                                                                                                                  ///

/////////////////////////////////////////////////////   $BF~NO%U%!%$%kL>!&%j!<%I?t!&%P%$%"%9HfN($N3NG'=PNO(B
for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 printf("%-55s %10d %10.5f\n",files[i].word,read_count[i],bias_ratio[i]*100.0);                                     ///
 }                                                                                                                  ///

for(i=1;i<n_files;i++)
 {
 sprintf(outflnm,"%s_diff%d.pe",arg1,i);
 out[i] = fopen(outflnm,"w");
 }
//////////////////////////////////////////////////////

///////////////////////////////////////////////////// $B%j%9%H$KM-$kF~NO%U%!%$%k$r$9$Y$F3+$$$FFI$`(B
for(i=0;i<n_files;i++)
 {
 pe_file = fopen(files[i].word,"r");
 if(pe_file == NULL)
  {
  printf("Failed to open the input file %s\n",files[i].word);
  exit(1);
  }

 n_lines = 0;
 while(fgets(buff,512,pe_file))                    // $B9T?t!aF~NO%U%!%$%k$N?t!!%+%&%s%H(B
  {
  n_lines ++;
  }
 pes[i].n_pe = n_lines;
 pes[i].pinf  = (pe_info *)malloc(sizeof(pe_info)*(n_lines + 2));
 
 rewind(pe_file);                                  // $B4,$-La$7(B

 n_lines = 0;
 while(fgets(buff,512,pe_file))
  {
  pes[i].pinf[n_lines].start    = read_int(buff, 3,10);   // $B5/E@(B
  pes[i].pinf[n_lines].end      = read_int(buff,14,10);   // $B=*E@(B
  pes[i].pinf[n_lines].n_member = read_int(buff,25,10);   // $B%j!<%I?t(B

  if(abs(pes[i].pinf[n_lines].start) < abs(pes[i].pinf[n_lines].end))   // $B5/E@$H=*E@$rHf3S$7@dBPCM$N>/$J$$J}$r(Bleft
   {                                                                      // $B$b$&0lJ}$r(Bright $B$H$7$F$$$k!#(B
   pes[i].pinf[n_lines].left  = pes[i].pinf[n_lines].start;
   pes[i].pinf[n_lines].right = pes[i].pinf[n_lines].end;
   }
  else
   {
   pes[i].pinf[n_lines].right = pes[i].pinf[n_lines].start;
   pes[i].pinf[n_lines].left  = pes[i].pinf[n_lines].end;
   }
  n_lines ++;
  }
 max_scs += n_lines;
 fclose(pe_file);
 pointer[i] = 0;
 }
///////////////////////////////////////////////////// $B%j%9%H$KM-$kF~NO%U%!%$%k$r$9$Y$F3+$$$FFI$`(B
scs = (share_info *)malloc(sizeof(share_info) * (max_scs +1));
if (scs == NULL)
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }

for(i=0;i<max_scs;i++)        // $B$=$l$>$l$NF~NO%U%!%$%k!J<B83!K$K$D$$$F$N%a%s%P!<?t!J$J$1$l$P#0!K(B
 {
 scs[i].n_member = (int *)malloc(sizeof(int) * n_files);
 for(j=0;j<n_files;j++)
  scs[i].n_member[j] = 0;
 }

for(i=0;i<n_files;i++)        // $B%U%!%$%k!J<B83!K?t%k!<%W(B
 {
 for(j=0;j<pes[i].n_pe;j++)   // $B%U%!%$%kFb$N%Z%"?t%k!<%W(B
  {
  flag = 0;
  for(k=0;k<n_scs;k++)        // $B%7%'%"%j%9%H%(%s%H%j$H$NHf3S(B
   {
//   if((pes[i].pinf[j].left == scs[k].from) && (pes[i].pinf[j].right == scs[k].to))
   if((abs(pes[i].pinf[j].left - scs[k].from) + abs(pes[i].pinf[j].right - scs[k].to)) < 300)
    {
    scs[k].n_member[i] = pes[i].pinf[j].n_member;
    flag = 1;
    break;
    }
   }
  if(flag == 0)  // $B?75,%(%s%H%j(B
   {
   scs[n_scs].from          = pes[i].pinf[j].left;
   scs[n_scs].to            = pes[i].pinf[j].right;
   scs[n_scs].n_member[i]   = pes[i].pinf[j].n_member;
   n_scs ++;
   }
  }
 }

for(i=0;i<n_scs;i++)
 {
 fprintf(pe_out,"%8d %8d ",scs[i].from,scs[i].to);
 fprintf(pe_out2,"%8d %8d ",scs[i].from,scs[i].to);
 for(j=0;j<n_files;j++)
  {
  fprintf(pe_out,"%8d ",scs[i].n_member[j]);
  fprintf(pe_out2,"%8.2f ",(double)scs[i].n_member[j]*bias_ratio[j]);
  }
 fprintf(pe_out,"\n");
 fprintf(pe_out2,"\n");
 }
printf("N_SCS = %10d\n",n_scs);

for(i=0;i<n_scs;i++)      // $B$9$Y$F$N%7%'%"%j%9%H%(%s%H%j$K$D$$$F(B
 {
 for(j=1;j<n_files;j++)   // $B0lHVL\(B(WT)$B0J30$NF~NO%U%!%$%k$K$D$$$F(B
  {
  if((scs[i].n_member[0] == 0) &&   // $B0lHVL\(B(WT)$B$N%j!<%I?t$,#0$G(B
     (scs[i].n_member[j] != 0))     // $BEv3:%(%s%H%j$N%j!<%I?t$,#0$G$J$1$l$P(B
   {
   fprintf(out[j],"p%10d %10d %10d\n",scs[i].from,scs[i].to,scs[i].n_member[j]);
   }
  }
 }

/////////////////////////////////////////////////////////////////DONE READING FILES
}
/////////////////////////////////////////////////////////////////////////MAIN END

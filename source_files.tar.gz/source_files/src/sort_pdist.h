#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN        256

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct cluster_info
 {
 int  seed_a;
 int  seed_b;
 int  n_pair;
 int  *as;
 int  *bs;
 double  avea;
 double  aveb;
 double  dista;
 double  distb;
 } cluster_info;

//void readargs(int argc, char **argv);

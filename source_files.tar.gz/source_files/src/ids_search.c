#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ids_search.h"
#define BUFLEN 512

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//    idss       = plot gc contents                                          //
//                                                                           //
//    usage: idss [options] reads.fasta                                      //
//                                                                           //
//    options:      -m  ##:  minimum identical sequence length               //
//                  -i  ##:  index length                                    //
//                                                                           //
//    Programed by Kensuke Nakamura, Since Jan. 22 2017, All right reserved. //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////GLOBAL VARIABLE     // グローバル変数宣言
char arg1[BUFLEN];
char temp_buff[MAX_INDEX_LEN + 2];

int  index_len    = 10;
int  index_size;
int  min_ids_len  = 15;


//////////////////////////////////////// FUNCTION DEFINITIONS // 関数定義
int ha_comp(const hit_array_info *x,const hit_array_info *y)
 {
 if(x->fr < y->fr)
  return -1;
 else
  {
  if(x->fr > y->fr)
   return 1;
  else
   {
   if(x->to < y->to)
    return -1;
   else
    {
    if(x->to > y->to)
     return 1;
    else
     return 0;
    }
   }
  }
 return 0;
 }

int reverse_complement_seq(char* dest_seq,char* source_seq)
{
int i,j,k,l,m;
int seq_len;
seq_len = strlen(source_seq);
//printf("%d_%s\n",seq_len,source_seq);
for(i=0;i<seq_len;i++)
 {
 if(source_seq[i] == 'A') 
  dest_seq[seq_len-i-1] = 'T'; 
 if(source_seq[i] == 'T') 
  dest_seq[seq_len-i-1] = 'A'; 
 if(source_seq[i] == 'G') 
  dest_seq[seq_len-i-1] = 'C'; 
 if(source_seq[i] == 'C') 
  dest_seq[seq_len-i-1] = 'G'; 
 if(source_seq[i] == 'N') 
  dest_seq[seq_len-i-1] = 'N'; 
 if(source_seq[i] == '.') 
  dest_seq[seq_len-i-1] = 'N'; 
 }
dest_seq[seq_len] = '\0';
return 0;
}

char complement_char(char c)
{
if(c == 'A')
 return 'T';
if(c == 'T')
 return 'A';
if(c == 'G')
 return 'C';
if(c == 'C')
 return 'G';
if(c == 'N')
 return 'N';
if(c == '.')
 return 'N';
return 'N';
}


int seq2index_num(char *seq)
{
int i;
int val;
int tempval;

val = 0;
for(i=0;i<index_len;i++)
 {
 tempval = 0;
 switch(seq[i])
  {
  case 'A':
   tempval = 0;
  break;
  case 'C':
   tempval = 1;
  break;
  case 'G':
   tempval = 2;
  break;
  case 'T':
   tempval = 3;
  break;
  case 'N':
   tempval = 0;
  break;
  case '.':
   tempval = 0;
  break;
  }
 val = val*4 + tempval;
 }
return val;
}


char* mk_kmer(int in) 
 {
 int i,j,k,l;
 int mody;
 int rest;
 int c[index_len+4];

 rest = in; 
 for(i=0;i<index_len;i++)
  {
  mody = rest % 4;
  rest = rest / 4;
  c[i] = mody;
  }
 for(i=0;i<index_len;i++)
  {
  if(c[i] == 0)
   temp_buff[index_len-1-i] = 'A';
  if(c[i] == 1)
   temp_buff[index_len-1-i] = 'C';
  if(c[i] == 2)
   temp_buff[index_len-1-i] = 'G';
  if(c[i] == 3)
   temp_buff[index_len-1-i] = 'T';
  }

 temp_buff[index_len] = '\0';
// strcpy(temp_buff,"AAAA");
 return temp_buff;
 };

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ FUNCTION DEFINITIONS    // 関数定義


////////////////////////////////////////// MAIN FUNCTION            // メイン関数
int main(int argc, char **argv)
{
int i,j,k,l,m;
char c;
int cc = 0;
int flag;
int pl=0;

char seq_flnm[512];
char out_flnm[512];
FILE *seq_file;
//FILE *out_file;

char buff[512];
char title[512];
char temp_seq[512];
char temp_seq2[512];
int  temp_num;
int  inum;

int  seq_len = 0;
char *seq;
char *csq;
char *rcs;

char *kmer;
int  *hits;
index_list *ils;

int pos1,pos2;

int num_hit = 0;
hit_info first_hit;
hit_info *current_hit;
hit_info *ch2;
hit_array_info *hit_array;
current_hit = &first_hit;
ch2=&first_hit;

readargs(argc,argv);

//index_len = min_ids_len;
//if(index_len >= 12)
// index_len = 12;

printf("Index length               = %10d\n",index_len);
printf("Minimum identical sequence = %10d\n",min_ids_len);
/////////////////////////////////////////////////////////////////////////// FASTA ファイルの読み込み 
index_size = (int)pow(4,(double)index_len);
kmer = (char *)malloc(sizeof(char)*(index_len+4));
hits = (int *)malloc(sizeof(int)*(index_size+4));
ils = (index_list *)malloc(sizeof(index_list)*(index_size+4));
for(i=0;i<index_size;i++)
 hits[i] = 0;

strcpy(seq_flnm, arg1);
//sprintf(out_flnm,"%s.palout",arg1);
printf("Input  File Name is :%s\n",seq_flnm);
//printf("Output File Name is :%s\n",out_flnm);

seq_file = fopen(seq_flnm,"r");
if(seq_file == NULL)
 {
 printf("Failed to open the input file %s\n",seq_flnm);
 exit(1);
 }

//out_file = fopen(out_flnm,"w");
//if(out_file == NULL)
// {
// printf("Failed to open the output file %s\n",out_flnm);
// exit(1);
// }

fgets(title,512,seq_file);
printf("TITLE: %s",title);

while((c = fgetc(seq_file)))
 {
 if(c == EOF)
  break;
// printf("%c",c);
 if(c != '\n')
  seq_len ++;
 }
printf("The Length of Sequence is %d\n",seq_len);

seq = (char *)malloc(sizeof(char) * (seq_len + 10));
csq = (char *)malloc(sizeof(char) * (seq_len + 10));
rcs = (char *)malloc(sizeof(char) * (seq_len + 10));

rewind(seq_file);
fgets(title,512,seq_file);

while((c = fgetc(seq_file)))
 {
 if(c == EOF)
  break;
// printf("%c",c);
 if(c != '\n')
  {
  seq[cc] = c;
  cc ++;
  }
 }
seq[cc] = '\0';
//////////////////////////////読み込み終わり

for(i=0;i<seq_len;i++)
 {
 rcs[i] = complement_char(seq[seq_len-i-1]);
 csq[i] = complement_char(seq[i]);
 }
rcs[cc] = '\0';
csq[cc] = '\0';

///////////////////////////// 逆鎖と相補鎖

for(j=0;j<=seq_len-index_len;j++)
 {
 for(i=0;i<index_len;i++)
  temp_seq[i] = seq[j+i];
 temp_seq[index_len] = '\0';
 
 temp_num = seq2index_num(temp_seq);
 hits[temp_num] ++;
 }

//////////////////////////////////////////////////////// Allocate Memory For Index List
for(i=0;i<index_size;i++)
 {
 // printf("%s %10d\n",mk_kmer(i),hits[i]);
 strcpy(kmer,mk_kmer(i));
 ils[i].pos = (int*)malloc(sizeof(int)*(hits[i]+2));
 ils[i].n_pos = 0;
 strcpy(ils[i].seq,kmer);
 }
//////////////////////////////////////////////////////// Allocate Memory For Index List
//////////////////////////////////////////////////////// Fill the Index List
for(i=0;i<index_size;i++)
 {
 // printf("%s %10d\n",mk_kmer(i),hits[i]);
 strcpy(kmer,mk_kmer(i));
 ils[i].pos = (int*)malloc(sizeof(int)*(hits[i]+2));
 ils[i].n_pos = 0;
 strcpy(ils[i].seq,kmer);
 }
//////////////////////////////////////////////////////// End Fill the Index List
for(j=0;j<=seq_len-index_len;j++)
 {
 //strncpy(temp_seq,seq[j],index_len);
 for(i=0;i<index_len;i++)
  temp_seq[i] = seq[j+i];
 temp_seq[index_len] = '\0';

 temp_num = seq2index_num(temp_seq);
 ils[temp_num].pos[ils[temp_num].n_pos++] = j;
 }

//for(i=0;i<index_size;i++)
// {
// strcpy(kmer,mk_kmer(i));
// printf("%d\n",ils[i].n_pos);
// for(j=0;j<ils[i].n_pos;j++)
//  printf(" %d\n",ils[i].pos[j]+1);
// }

printf("Start searching\n");

for(i=0;i<index_size;i++)
 {
 ////////////////////////////// SAME DIRECTION
 strcpy(kmer,mk_kmer(i));
 for(j=0;j<ils[i].n_pos;j++)
  {
  for(k=j+1;k<ils[i].n_pos;k++)
//  for(k=0;k<ils[i].n_pos;k++)
   {
   pos1 = ils[i].pos[j];
   pos2 = ils[i].pos[k];

   if(seq[pos1-1] == seq[pos2-1])   // インデックスから始まる一致のみを見る
    continue;

//   printf("%10d %10d %s\n",pos1,pos2,kmer);
   cc=0;
   while(1)
    {
    if(seq[pos1+index_len+cc] != seq[pos2+index_len+cc])
     {
     break;
     }
    cc++;
    }
//   printf("%10d %10d %3d %s\n",pos1,pos2,cc,kmer);
   if(index_len + cc > min_ids_len)
    {
    current_hit->fr  = pos1;
    current_hit->to  = pos2;
    current_hit->len = index_len + cc;
    current_hit->next = (hit_info *)malloc(sizeof(hit_info));
    current_hit = current_hit->next;
    current_hit->next = NULL;
    num_hit ++;
    }
   }
  }
 ////////////////////////////// SAME DIRECTION
 
 ////////////////////////////// OPOSITE DIRECTION
 strcpy(kmer,mk_kmer(i));
 reverse_complement_seq(temp_seq,kmer);
 inum = seq2index_num(temp_seq);

//printf("## %s\n %s\n %10d %10d\n",kmer,temp_seq,i,inum);
 
 for(j=0;j<ils[i].n_pos;j++)
  {
  for(k=0;k<ils[inum].n_pos;k++)
   {
   pos1 = ils[i].pos[j];
   pos2 = ils[inum].pos[k];

   if(pos1 < pos2)
    {
//MARK
    if(seq[pos1-1] == complement_char(seq[pos2+index_len]))   // インデックスから始まる一致のみを見る
     continue;

//   printf("%10d %10d %s\n",pos1,pos2,kmer);
    cc=0;
    while(1)
     {
//    if(seq[pos1+index_len+cc-1] != complement_char(seq[pos2-cc]))
     if(seq[pos1+index_len+cc] != complement_char(seq[pos2-cc-1]))
      {
      break;
      }
     cc++;
     }
//   printf("%10d %10d %3d %s\n",pos1,pos2,cc,kmer);
    if(index_len + cc > min_ids_len)
     {
     current_hit->fr  = pos1;
     current_hit->to  = pos2+index_len-1;
     current_hit->len = (index_len + cc) * (-1);
     current_hit->next = (hit_info *)malloc(sizeof(hit_info));
     current_hit = current_hit->next;
     current_hit->next = NULL;
     num_hit ++;
     }
    }
   }
  }
 ////////////////////////////// OPOSITE DIRECTION
 }

hit_array = (hit_array_info *)malloc(sizeof(hit_array_info)*(num_hit+10));
if(hit_array == NULL)
 {
 printf("Failed to allocate memory for hit_array\n");
 exit(1);
 }
int n_hit = 0;
current_hit = &first_hit;
while(1)
 {
// printf("%10d %10d %3d\n",current_hit->fr+1,current_hit->to+1,current_hit->len);
 hit_array[n_hit].fr = current_hit->fr;
 hit_array[n_hit].to = current_hit->to;
 hit_array[n_hit].len = current_hit->len;
 if(current_hit->next == NULL)
  break;
 else
  {
  current_hit = current_hit->next;
  n_hit ++;
  }
 }

qsort(hit_array,n_hit,sizeof(hit_array_info),(int(*)(const void*,const void*))ha_comp);

for(i=0;i<n_hit;i++)
 {
// printf("%10d-%10d %10d-%10d %10d\n",hit_array[i].fr+1,hit_array[i].fr+abs(hit_array[i].len),
//                                     hit_array[i].to+1,hit_array[i].to+hit_array[i].len,hit_array[i].len);
 if(hit_array[i].len > 0)
  {
  printf(">%10d-%10d %10d-%10d %10d\n",hit_array[i].fr+1,hit_array[i].fr+abs(hit_array[i].len),
                                      hit_array[i].to+1,hit_array[i].to+hit_array[i].len,hit_array[i].len);
  }
 else
  {
  printf(">%10d-%10d %10d-%10d %10d\n",hit_array[i].fr+1,hit_array[i].fr+abs(hit_array[i].len),
                                      hit_array[i].to+1,hit_array[i].to+hit_array[i].len+2,hit_array[i].len);
  }
 for(j=0;j<abs(hit_array[i].len);j++)
  {
  printf("%c",seq[hit_array[i].fr+j]);
  if((j!=0) && ((j+1)%60 == 0))
   printf("\n");
  }
 printf("\n");
 }
 
//current_hit = &first_hit;
//while(1)
// {
// printf("%10d %10d %3d\n",current_hit->fr+1,current_hit->to+1,current_hit->len);
// if(current_hit->next == NULL)
//  break;
// else
//  current_hit = current_hit->next;
// }

/////////////////////////////////////////////////////////////////////////// 全体の塩基数カウントとGCコンテンツ計算

//printf("%s\n",seq);
//printf("%s\n",csq);
//printf("%s\n",rcs);

fclose(seq_file);
//fclose(out_file);
return 0;
}

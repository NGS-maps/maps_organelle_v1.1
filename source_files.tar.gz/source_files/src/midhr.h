#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INT     2147483647
#define HOMOSEQLEN         500          // 相同組み替えを判定するときの相同配列の長さの上限
#define MAX_J_HIT          200

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct read_info                // リード情報 構造体 reads
 {
 char *t1;                             // リードの配列
 char *seq;                             // リードの配列
 char *t2;                             // リードの配列
 char *quality;
 int n_mismatch;                        // number of mismatch to the sequence ミスマッチ数
 int junction_likelyhood;               // a factor to evaluate likelyhood to be a junction read ジャンクション性
 int mismatch_start_point;              // + to the right, - to the left リード上ミスマッチ開始点 負値は左へ
 int mismatch_start_point_on_genome;    // + to the right, - to the left ゲノム上ミスマッチ開始点 負値は左へ
 char *mismatch_seq;                    // mismatch sequence             ミスマッチ配列
 int pos;
 } read_info;

typedef struct distant_pair_info
 {
 int pos1,pos2;
 int rid;
 int posa,posb,posc;
 int n_cluster_member;
 int belongs_to;
 int *members;
 } distant_pair_info;

typedef struct junction_cluster_info    // ジャンクションクラスタ情報 構造体 jcs
 {
 int n_member;
 int n_exclude;
 int *hit_id;
 int mm_start;
 int total_mismatch;
 int shortest_mm_len;
 int longest_mm_len;
 int average_mm_len;
 int longest_id;
 int flag1;
 char *consensus_seq;                    // コンセンサス配列（全長）
 int  *consensus_depth;                  // コンセンサスと一致するリードの厚み（各位置）
 int  *consensus_depth_i2;                  // コンセンサスと一致するリードの厚み（各位置）
 char *consensus_seq_i1;                 // コンセンサス配列（閾値を下回ったところで切ったもの）
 char *consensus_seq_i2;                 // コンセンサス配列（閾値を下回ったところで切ったもの）
 char *homoseq;
 char *palseq;
 int num_hit;
 int *hit_pos;
 int *hit_flag;
 int indel;
 int idlen;
 int fflag;
 int flag;
 int hr_id;
 int n_true_member;                // ミスマッチコンセンサスに完全一致のリード数
 int *true_flag;                   // MAR04_2018 コンセンサスに完全一致するリードにマーク
 int new_flag;                     // MAR04_2018
 int base_count;                   // MAR04_2018
 int match_count;                   // MAR04_2018
 int num_ireg_pair;                // Aug 20 2020

int tmtlen;                        // Aug29 2020
int tstlen;                        // Aug29 2020
int tqtlen;                        // Aug29 2020
int tptlen;                        // Aug29 2020
int tmtcnt;                        // Aug29 2020
int tstcnt;                        // Aug29 2020
int tqtcnt;                        // Aug29 2020
int tptcnt;                        // Aug29 2020
 } junction_cluster_info;

typedef struct hr_info  // 相同組み替え情報
 {
 int  posa, posb;
 int  pos1L;            // 相同配列のゲノム上左端
 int  pos1R;            // 相同配列のゲノム上左端
 int  pos2L;            // 相同配列のゲノム上右端
 int  pos2R;            // 相同配列のゲノム上右端
 int  homolen;
 char *homoseq;         // 相同配列
 int  flag;             // pos1Rでの乗り換えがjcc1なら１反対なら２
 int  jcc1;             // ジャンクションクラスタ１
 int  jcc2;             // ジャンクションクラスタ２
 int  num_jcr1L;        // ジャンクションクラスタ１のリード数
 int  num_jcr1L_C;        // ジャンクションクラスタ１のリード数  配列チェック済
 int  *jcrs1L;          // ジャンクションクラスタ１のリード
 int  num_jcr2L;        // ジャンクションクラスタ２のリード数
 int  num_jcr2L_C;        // ジャンクションクラスタ２のリード数  配列チェック済
 int  *jcrs2L;          // ジャンクションクラスタ２のリード
 int  num_jcr1R;        // ジャンクションクラスタ１のリード数
 int  num_jcr1R_C;        // ジャンクションクラスタ１のリード数  配列チェック済
 int  *jcrs1R;          // ジャンクションクラスタ１のリード
 int  num_jcr2R;        // ジャンクションクラスタ２のリード数
 int  num_jcr2R_C;        // ジャンクションクラスタ２のリード数  配列チェック済
 int  *jcrs2R;          // ジャンクションクラスタ２のリード
 } hr_info;

typedef struct index_list
 {
 int n_pos;
 int *pos;
 } index_list;

typedef struct overlap_pair_info
 {
 int  overlap;
 char *overlapseq;
 } overlap_pair_info;

void readargs(int argc, char **argv);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

typedef struct hr_info
{
char type;
int  fr;
int  to;
int  readcount;
char sequence[512];
int  partner;
int  len;
} hr_info;

typedef struct pair_info
{
int pair1;
int pair2;
} pair_info;

typedef struct hmr_info
{
int h1_fr;
int h1_to;
int h2_fr;
int h2_to;
int dir;    // Same direction:0 or Oposite direction:1
int j1a;      // hr_id
int j1b;      // hr_id
int j2a;      // hr_id
int j2b;      // hr_id
int pop1;
int pop2;
int pop1a;
int pop2a;
int pop1b;
int pop2b;
char sequence[512];
} hmr_info;

int comp_dir(int fr, int to)   // $BId9fF1$8$J$i#1$rJV$90c$($P(B-1$B$rJV$9(B
 {
 if(((fr >= 0) && (to >= 0)) || ((fr < 0) && (to < 0)))
  {
  return 1;            // $BF1Id9f(B
  }
 else
  {
  return -1;           // $B5UId9f(B
  }
 }

int main(int argc,char **argv)
{
int i,j,k,l;
char buff[512];
FILE *infile;
int n_line = 0;
hr_info *hrs;
int n_pair = 0;
int n_pair2 = 0;
hmr_info *hmrs;
int n_hmr = 0;

infile = fopen(argv[1],"r");
while(fgets(buff,512,infile))
 {
 n_line ++;
 }

FILE *outfile;
char outflnm[512];
sprintf(outflnm,"%s.hmr",argv[1]);
outfile = fopen(outflnm,"w");

FILE *posdirfile;
char posdirflnm[512];
sprintf(posdirflnm,"%s.psd",argv[1]);
posdirfile = fopen(posdirflnm,"w");

FILE *posdirfile2;
char posdir2flnm[512];
sprintf(posdir2flnm,"%s.psd2",argv[1]);
posdirfile2 = fopen(posdir2flnm,"w");

rewind(infile);

hrs = (hr_info *)malloc(sizeof(hr_info) * n_line);
pair_info *pairs1 = (pair_info *)malloc(sizeof(pair_info) * n_line);
pair_info *pairs2 = (pair_info *)malloc(sizeof(pair_info) * n_line);

for(i=0;i<n_line;i++)
 hrs[i].partner = INT_MAX;

int cc = 0;
while(fgets(buff,512,infile))
 {
 sscanf(buff,"%c %d %d %d %s",&hrs[cc].type,&hrs[cc].fr,&hrs[cc].to,&hrs[cc].readcount,hrs[cc].sequence);
 hrs[cc].len = strlen(hrs[cc].sequence)+1;
 cc ++;
 }

hmrs = (hmr_info *)malloc(sizeof(hmr_info)*n_line);
for(i=0;i<n_line;i++)             // $B=i4|2=(B
 {
 hmrs[i].h1_fr = INT_MAX; hmrs[i].h1_to = INT_MAX; hmrs[i].h2_fr = INT_MAX; hmrs[i].h2_to = INT_MAX;
 hmrs[i].j1a   = INT_MAX; hmrs[i].j1b   = INT_MAX; hmrs[i].j2a   = INT_MAX; hmrs[i].j2b   = INT_MAX;
 hmrs[i].dir   = INT_MAX;
 hmrs[i].pop1  = 0; hmrs[i].pop1a = 0; hmrs[i].pop1b = 0;
 hmrs[i].pop2  = 0; hmrs[i].pop2a = 0; hmrs[i].pop2b = 0;
 }

for(i=0;i<n_line;i++)
 {
 int  dir;
 int  rtype;
 char stype;
 int h1_fr; int h1_to; int h2_fr; int h2_to;
 int len = hrs[i].len;
 int fr  = hrs[i].fr;
 int to  = hrs[i].to;
 int readcount = hrs[i].readcount;
 strcpy(buff,hrs[i].sequence);
 if(comp_dir(fr,to) == 1)  // $BF1J}8~(B S
  {
  dir = 1;
  if(abs(fr) < abs(to))    // fr$B$,:8(B  1a/2b
   {
   if(fr >= 0)             // 1a
    {
    rtype = 1; stype = 'a';
    h1_fr = fr - len;
    h1_to = fr;
    h2_fr = to - len;
    h2_to = to;
    printf("S 1a fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_fr,1,0);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_to,0,1);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_fr,readcount,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_to,0,readcount);
    }
   else                    // 2b
    {
    rtype = 2; stype = 'b';
    h1_fr = abs(fr);
    h1_to = abs(fr)+len;
    h2_fr = abs(to);
    h2_to = abs(to)+len;
    printf("S 2b fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_to,0,1);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_fr,1,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_to,0,readcount);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_fr,readcount,0);
    }
   }
  else                     // fr$B$,1&(B  1b/2a
   {
   if(fr >= 0)             // 2a
    {
    rtype = 2; stype = 'a';
    h1_fr = to - len;
    h1_to = to;
    h2_fr = fr - len;
    h2_to = fr;
    printf("S 2a fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_to,0,1);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_fr,1,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_to,0,readcount);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_fr,readcount,0);
    }
   else                    // 1b
    {
    rtype = 1; stype = 'b';
    h1_fr = abs(to);
    h1_to = abs(to) + len;
    h2_fr = abs(fr);
    h2_to = abs(fr) + len;
    printf("S 1b fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_fr,1,0);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_to,0,1);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_fr,readcount,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_to,0,readcount);
    }
   }
  }
 else                      // $B0[J}8~(B O
  {
  dir = -1;
  if(abs(fr) < abs(to))    // fr$B$,:8(B  1a/2b
   {
   if(fr >= 0)             // 1a
    {
    rtype = 1; stype = 'a';
    h1_fr = fr - len;
    h1_to = fr;
    h2_fr = abs(to);
    h2_to = abs(to) + len;
    printf("O 1a fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_fr,1,0);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_to,1,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_fr,readcount,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_to,readcount,0);
    }
   else                    // 2b
    {
    rtype = 2; stype = 'b';
    h1_fr = abs(fr);
    h1_to = abs(fr) + len;
    h2_fr = to - len;
    h2_to = to;
    printf("O 2b fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_fr,0,1);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_to,0,1);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_fr,0,readcount);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_to,0,readcount);
    }
   }
  else                     // fr$B$,1&(B  1b/2a
   {
   if(fr >= 0)             // 1b
    {
    rtype = 1; stype = 'b';
    h1_fr = abs(to);
    h1_to = abs(to) + len;
    h2_fr = fr - len;
    h2_to = fr;
    printf("O 1b fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_fr,1,0);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_to,1,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_fr,readcount,0);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_to,readcount,0);
    }
   else                    // 2a
    {
    rtype = 2; stype = 'a';
    h1_fr = to - len;
    h1_to = to;
    h2_fr = abs(fr);
    h2_to = abs(fr) + len;
    printf("O 2a fr:%10d to:%10d len:%10d h1 %10d-%10d h2 %10d-%10d seq:%s\n",fr,to,len,h1_fr,h1_to,h2_fr,h2_to,buff);
    fprintf(posdirfile,"%10d %10d %10d\n",h1_fr,0,1);
    fprintf(posdirfile,"%10d %10d %10d\n",h2_to,0,1);
    fprintf(posdirfile2,"%10d %10d %10d\n",h1_fr,0,readcount);
    fprintf(posdirfile2,"%10d %10d %10d\n",h2_to,0,readcount);
    }
   }
  }

 int hmr_flag = INT_MAX;
 for(j=0;j<n_hmr;j++)      // $B4{=P$N(Bhmr$B$+$I$&$+8!:w(B
  {
  if((hmrs[j].h1_fr == h1_fr) && (hmrs[j].h1_to == h1_to) && (hmrs[j].h2_fr == h2_fr) && (hmrs[j].h2_to == h2_to))  // $B0lCW$9$k4{=P$N$b$N$"$j(B
   {
   hmr_flag = j;
   break;
   }
  }
 if(hmr_flag == INT_MAX)         // $B=i=P(B
  {
  hmrs[n_hmr].h1_fr = h1_fr;
  hmrs[n_hmr].h1_to = h1_to;
  hmrs[n_hmr].h2_fr = h2_fr; 
  hmrs[n_hmr].h2_to = h2_to;
  hmrs[n_hmr].dir   = dir;
  strcpy(hmrs[n_hmr].sequence,buff);
  if(rtype == 1)
   {
   if(stype == 'a')   // 1a
    {
    hmrs[n_hmr].j1a = i;
    hmrs[n_hmr].pop1a += hrs[i].readcount;
    }
   else               // 1b
    {
    hmrs[n_hmr].j1b = i;
    hmrs[n_hmr].pop1b += hrs[i].readcount;
    }
   hmrs[n_hmr].pop1 += hrs[i].readcount;
   }
  else
   {
   if(stype == 'a')   // 2a
    {
    hmrs[n_hmr].j2a = i;
    hmrs[n_hmr].pop2a += hrs[i].readcount;
    }
   else               // 2b
    {
    hmrs[n_hmr].j2b = i;
    hmrs[n_hmr].pop2b += hrs[i].readcount;
    }
   hmrs[n_hmr].pop2 += hrs[i].readcount;

   }
  n_hmr ++;
  }
 else                          // $B4{=P(B
  {
  if(rtype == 1)
   {
   if(stype == 'a')   // 1a
    {
    hmrs[hmr_flag].j1a = i;
    hmrs[hmr_flag].pop1a += hrs[i].readcount;
    }
   else               // 1b
    {
    hmrs[hmr_flag].j1b = i;
    hmrs[hmr_flag].pop1b += hrs[i].readcount;
    }
   hmrs[hmr_flag].pop1 += hrs[i].readcount;
   }
  else
   {
   if(stype == 'a')   // 2a
    {
    hmrs[hmr_flag].j2a = i;
    hmrs[hmr_flag].pop2a += hrs[i].readcount;
    }
   else               // 2b
    {
    hmrs[hmr_flag].j2b = i;
    hmrs[hmr_flag].pop2b += hrs[i].readcount;
    }
   hmrs[hmr_flag].pop2 += hrs[i].readcount;
   }
  }
 }

printf("N_HR   %10d  N_HMR    %10d\n",n_line,n_hmr);
////////////////////////////////////////////////////// .hmr$B%U%!%$%k$r=PNO(B
for(i=0;i<n_hmr;i++)
 {
 if(hmrs[i].dir == 1)
  {
  printf("S H1:%10d %10d H2:%10d %10d POP:%10d %10d %10d %10d POP1:%10d POP2:%10d   %s\n",hmrs[i].h1_fr+1,hmrs[i].h1_to-1,hmrs[i].h2_fr+1,hmrs[i].h2_to-1,hmrs[i].pop1a,hmrs[i].pop1b,hmrs[i].pop2a,hmrs[i].pop2b,hmrs[i].pop1,hmrs[i].pop2,hmrs[i].sequence);
  fprintf(outfile,"S %10d %10d %10d %10d %10d %10d %s\n",hmrs[i].h1_fr+1,hmrs[i].h1_to-1,hmrs[i].h2_fr+1,hmrs[i].h2_to-1,hmrs[i].pop1,hmrs[i].pop2,hmrs[i].sequence);
  }
 else
  {
  printf("O H1:%10d %10d H2:%10d %10d POP:%10d %10d %10d %10d POP1:%10d POP2:%10d   %s\n",hmrs[i].h1_fr+1,hmrs[i].h1_to-1,hmrs[i].h2_fr+1,hmrs[i].h2_to-1,hmrs[i].pop1a,hmrs[i].pop1b,hmrs[i].pop2a,hmrs[i].pop2b,hmrs[i].pop1,hmrs[i].pop2,hmrs[i].sequence);
  fprintf(outfile,"O %10d %10d %10d %10d %10d %10d %s\n",hmrs[i].h1_fr+1,hmrs[i].h1_to-1,hmrs[i].h2_fr+1,hmrs[i].h2_to-1,hmrs[i].pop1,hmrs[i].pop2,hmrs[i].sequence);
  }
 }

}

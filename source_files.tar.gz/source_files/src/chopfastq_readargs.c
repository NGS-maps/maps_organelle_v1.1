#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "chopfastq.h"

extern int chop_length;
extern char arg1[];

void errorm(int en);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;
int flag = 0;
char tempchar[80];

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {

//  if((argv[arg][1] == 'n') && (argv[arg][2] == 'h') &&(argv[arg][3] == 'b'))    // -nhb: no histogram bar
//   {
//   if(argv[arg][4] != '\0')
//    errorm(1);
//   else
//    {
//    no_histo_bar  = 1;
//    }
//   continue;
//   }


  if(argv[arg][1] == 'l')     // -l  ##  : histogram type Population Display, ## = basepair per pixel
   {
   if(argv[arg][2] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    chop_length  = atoi(tempchar);
    }
   continue;
   }
  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference fasta file name
   strcpy(arg1,argv[arg]);
   }
  flag ++;
  if(flag >= 2)
   errorm(2);
  }
 }
}

void errorm(int en)
 {
 printf("ERROR %d\n",en);
 printf("Usage:   chopfastq [-options] readfile.fastq\n");
 printf("Options:               -l ##: shorten the fastq reads to ## bp, default is 30 bp\n");
 printf("Options:                    : replace ## with numbers\n");
 printf("                              output filename will be chp##_readfile.fastq\n");
 printf("                                                                                   \n");
 exit(1);
 }

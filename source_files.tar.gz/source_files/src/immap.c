#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <math.h>
#include "maps.h"
#define BUFLEN 512

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                         //
//  immap : $B8GDjD9%j!<%I(Bmaps$B$N%^%k%A%j%U%!%l%s%9HG(B                                                                         //
//                                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////GLOVAL VARIABLES  $B%0%m!<%P%kJQ?t(B
char arg1[256];
char arg2[256];

int  jobname      =  0;                   // jobname is asigned
char job_name[BUFLEN];                    // jobname to specify smap runs
int  index_length =  8;                   // INDEX LENGTH //$B%$%s%G%C%/%9$ND9$5(B
int  index_size;                          // TOTAL NUMBER OF INDEX 4^index_length//$B%$%s%G%C%/%9$N>l9g$N?t(B 4$B$N(Bindex_length$B>h(B 
int  n_round      =  2;                   // round cycle
int  thresh_miss  =  3;                   // NUMBER OF MISMATCH ALLOWED PER READ //$B%j!<%I$"$?$j%R%C%H$9$k:GBg$N%_%9%^%C%A?t(B
int  n_thread = 1;                        // number of threads                   // $B%9%l%C%I?t(B
int  map_out = 0;                         // $B%^%C%W=PNO(B $BM-(B:1 $BL5(B:0
int  map_out_width = 300;                 // $B%^%C%WI}(B
int  multi_hit = 0;                       // $B%^%k%A%R%C%H(B
int  skip_aaa = 0;                       // $B%^%k%A%R%C%H(B

char reference_title[512];                // $B%l%U%!%l%s%9%j%9%H%U%!%$%k$N%X%C%@(B 
int  n_chromosomes = 0;                   // $B%l%U%!%l%s%9$N%/%m%b%=!<%`?t(B
chromosome_info *chromosomes;             // $B%^%k%A%l%U%!%l%s%9BP1~(B $B%/%m%b%=!<%`>pJs(B

int  n_query;                             // NUMBER OF QUERY (READ)                //$B%/%'%j!<!J%j!<%I!K$N?t(B
query_info *qs;                           // QUERY INFORMATION                     //$B%/%'%j!<!J%j!<%I!K>pJs(B
int  query_len = 0;                       // LENGTH OF QUERY                       //$B%/%'%j!<!J%j!<%I!K$ND9$5(B
int  num_hit = 0;                         // NUMEBR OF HIT                         //$B%R%C%H?t(B
struct hit_position_info **hit_positions; // HIT POSITION FOR MULTIPLE HIT         //$B%R%C%H2U=j$,J#?t$"$k>l9g$N%j%9%H7A<0$G$NJ]B8(B
int  *hit_chromosome;                     // CHROMOSOME ID OF THE HIT
int  *hit_position;                       // HIT POSITION ON REFERENCE NEGATIVE IF COMPLEMENT
int  *num_hits;                           // NUMBER OF HIT POSITION                //$B%R%C%H0LCV$N8D?t(B
int  *hit_score;                          // HIT SCORE  suffix IS QUERY NUMBER     //$B%R%C%H$N%9%3%"!!E:;z$,%/%'%j!<$NHV9f(B
int  box[MAX_BOX+5];                      // $B%^%C%W$r?^<($9$k$H$-$N%j!<%I$N?<$5!J%l%$%d!<!K$rJ]B8(B
int  box_start[MAX_BOX+5];                // MODIFIED FOR CYCLIC GENOME 2015 May 3  $B$=$l$>$l$N%l%$%d!<$G$N:G=i$N%^%C%W3+;OE@$r5-O?(B
int  box_position[MAX_BOX+5];             // MODIFIED FOR CYCLIC GENOME 2015 May 3  $B$=$l$>$l$N%l%$%d!<$G$N:G8e$,$O$_=P$7$F@hF,$K7R$,$k%j!<%I$N%^%C%W3+;OE@$r5-O?(B
int  box_query[MAX_BOX+5];                // MODIFIED FOR CYCLIC GENOME 2015 May 3  $B$=$l$>$l$N%l%$%d!<$G$N:G8e$,$O$_=P$7$F@hF,$K7R$,$k%j!<%I$N(BID$B$r5-O?(B
int  box_hit[MAX_BOX+5];
int  box_cnt[MAX_BOX+5];
int  change_hit=0;
int  shift_val = 0;                       // $B%$%s%G%C%/%9$N%7%U%HCM(B
int  shift_vals[MAX_ROUND];
int  exclude_n    =  0;                   // exclude the read including N(Unidentified base) as bases
struct hit_position_info *p;
char tempseq[1024];                       // $B%F%s%]%i%j!<J8;zNs(B 
/////////////////////////////////////////////GLOVAL VARIABLES $B%0%m!<%P%kJQ?t(B END

/////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B
void complement_seq(char* source_seq,char* dest_seq)       // $B5UAjJdG[Ns!J%j%P!<%9%3%s%W%j%a%s%H!K$rJV$9(B
{
int i,j,k,l,m;
int seq_len;
seq_len = strlen(source_seq);
for(i=0;i<seq_len;i++)
 {
 switch(source_seq[i])
  {
  case 'A': dest_seq[seq_len-i-1] = 'T'; break;
  case 'T': dest_seq[seq_len-i-1] = 'A'; break;
  case 'G': dest_seq[seq_len-i-1] = 'C'; break;
  case 'C': dest_seq[seq_len-i-1] = 'G'; break;
  case 'N': dest_seq[seq_len-i-1] = 'N'; break;
  case '.': dest_seq[seq_len-i-1] = 'N'; break;
  default : dest_seq[seq_len-i-1] = 'N'; break;
  }
 }
dest_seq[seq_len] = '\0';
}
//////////////////////////////////////////////////
char complement_char(char chara)                            // $BAjJd1v4p(B(A$B$J$i(BT)$B$rJV$9(B
{
switch(chara)
 {
 case 'A': return 'T';
 case 'T': return 'A';
 case 'G': return 'C';
 case 'C': return 'G';
 case 'N': return 'N';
 case '.': return 'N';
 default : return 'N';
 }
}
///////////////////////////////////////////////////
int nth_word(char *dest,char *orig,int n,char deliminator)  // $BJ8;zNs$+$i%G%j%_%M!<%?!<$r;XDj$7$F2?@aL\$+$NJ8;zNs$rJV$9(B
{
int i;
int c=0;
int flag = 0;
if(n==1)
 {
 flag = 1;
 i=-1;
 }
else
 {
 for(i=0;i<strlen(orig);i++)
  {
  if(orig[i] == deliminator)
   c ++;
  if(c == n-1)
   {
   flag = 1;
   break;
   }
  }
 }
if(flag == 0)
 {
 dest[0] = '\n';
 return 1;
 }
else
 {
 strcpy(dest,&orig[i+1]);
 for(i=0;i<strlen(dest);i++)
  {
  if((dest[i] == '\n') || (dest[i] == '\t') || (dest[i] == ' '))
   dest[i] = '\0';
  }
 }
return 0;
}

struct hit_position_info *hpi_alloc(void)                   // $B?7$7$$%R%C%H0LCV$N%"%m%1!<%7%g%sMQ4X?t(B
{
return((struct hit_position_info *)malloc(sizeof(struct hit_position_info)));
}
/////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B END

/////////////////////////////////////////////THREAD FUNCTION  $B%9%l%C%I4X?t(B
void thread_func(void *arg)
{
int i,j,k,m,n;
thread_arg_t* targ = (thread_arg_t *)arg;
int tid;
int ni;
tid = targ->thread_no;
//printf("I %20d %20d %20d\n",tid,targ->tnum_hit[tid],targ->tchange_hit[tid]);
int  search_index;
struct hit_position_info *tempp;
struct hit_position_info *p;
int miss;
int  min_miss;
int  hit_pos;
int  start;
char queryseq[512];
char search_seq[MAX_INDEX_LEN+10];
int mat[16];
//printf("thresh miss = %10d\n",thresh_miss);
for(k=0;k<n_query;k++)                            // $B%/%'%j!<?t%k!<%W(B
 {
 if((k % n_thread) == tid)                        // $B%/%'%j!<(BID$B$r%9%l%C%I?t$G3d$C$?M>$j$,%9%l%C%I(BID$B$HF1$8$J$i<B9T(B
  {
//////////////////Apr11_2020  if((exclude_n == 0) || (qs[k].num_n == 0))      // EXCLUDE READS WITh N //N $B$NF~$C$F$k%j!<%I$r>o$K=|30(B
   {
   for(m=0;m<2;m++)                               // READ DIRECTIONS // complement $B=gFI$_(B m=0$B!"5UFI$_(B m=1
    {
    if(m==0)
     strcpy(queryseq,qs[k].seq);          // $B=g:?(B
    else
     complement_seq(qs[k].seq,queryseq);  // $B5U:?(B
    min_miss = query_len+1;
    for(i=0;i<index_length;i++)                   // $B%$%s%G%C%/%9%R%C%H$rC5$9G[Ns(B (search_seq) $B$rCj=P(B
     search_seq[i] = queryseq[i+shift_val];
    search_seq[index_length] = '\0';

    for(i=0;i<index_length;i++)                   // search_seq $B$r%$%s%G%C%/%9CM$KJQ49$9$k$?$a$N(Bmat$BG[Ns$rKd$a$k(B
     {
     switch(search_seq[i])
      {
      case 'N': mat[i] = 0; break;
      case '.': mat[i] = 0; break;
      case 'A': mat[i] = 0; break;
      case 'C': mat[i] = 1; break;
      case 'G': mat[i] = 2; break;
      case 'T': mat[i] = 3; break;
      default : mat[i] = 0; break;
      }
     }
    search_index = 0;
    for(i=0;i<index_length;i++)                   // search_seq$B$r%$%s%G%C%/%9CM(Bsearch_index$B$KJQ49(B
     search_index += mat[i] * (int)pow(4.0,(double)(index_length-i-1));

    if((skip_aaa == 0) || (search_index != 0))
    for(n=0;n<n_chromosomes;n++)          // chromosome loop  // $B@w?'BN%k!<%W(B
     {
     hit_pos = 0;
     ni = chromosomes[n].ils[search_index].n_pos;
     for(i=0;i<chromosomes[n].ils[search_index].n_pos;i++)        // LOOP FOR INDEX HIT NUMBER // $B%$%s%G%C%/%9%R%C%H?t(B $B%k!<%W(B
      {
      start = chromosomes[n].ils[search_index].pos[i]-shift_val;  //$B%^%C%A$K$D$$$F%/%'%j!<$N(Breference$B>e$N3+;O0LCV$r=P$9(B
      if(start < 0)
       {
       continue;
       }
      miss = 0;                                    // $B%_%9%^%C%A$N?t(B miss
//      for(j=0;j<query_len-1;j++)                        ////// LOOP FOR CHECKING MATCH //$BC`8l%A%'%C%/!!%k!<%W(B
      for(j=0;j<query_len;j++)                        ////// LOOP FOR CHECKING MATCH //$BC`8l%A%'%C%/!!%k!<%W(B
       {
       if(chromosomes[n].refseq[start+j] != queryseq[j])          // $BIT0lCW$J$i(B
        miss ++;                                   // miss$B$r%$%s%/%j%a%s%H(B
       }                                           ////// END LOOP FOR CHECKING MATCH //$BC`8l%A%'%C%/(B $B%k!<%W(BEND
      if(miss < min_miss)
       {
       min_miss = miss;
       hit_pos = chromosomes[n].ils[search_index].pos[i] - shift_val+1;
       if(m==1)                                    // $B5U:?$J$i(B
        hit_pos = hit_pos * (-1);                  // $B%R%C%H0LCV$NId9f$rH?E>(B
       }
 
      if(multi_hit == 1)                           // $B%^%k%A%R%C%H%*%W%7%g%s(B ON $B$N>l9g(B
       {
       if(miss <=thresh_miss)                      // look for ALL hits
        {
        tempp = hit_positions[k];
        hit_positions[k] = hpi_alloc();
        hit_positions[k]->hit_position = hit_pos;
        hit_positions[k]->hit_chromosome = n;
        hit_positions[k]->hit_score = min_miss;
        hit_positions[k]->pointer      = tempp;
        num_hits[k] ++;
        }                                          // look for ALL hits  END
       }
      }                                            // END LOOP FOR INDEX HIT NUMBER //$B%$%s%G%C%/%9%R%C%H?t%k!<%W!!(BEND
 
//printf("B:%3d %10d %3d %3d %3d %3d \n",k,hit_pos,min_miss,n,m,ni);

     if(min_miss <= thresh_miss)                   // small enough = HIT
      {
      if(hit_position[k] == MAX_INT)               // no_hit -> hit  
       {

//printf("P:%3d %10d %3d %3d %3d %3d \n",k,hit_pos,min_miss,n,m,ni);
//for(i=0;i<ni;i++)
// printf(" %3d,",chromosomes[n].ils[search_index].pos[i]-shift_val);
//printf("\n");

       hit_score[k] = min_miss;
       hit_position[k] = hit_pos;
       hit_chromosome[k] = n;
       targ->tnum_hit[tid] ++;
       }
      else
       {
       if(hit_score[k] > min_miss)                 // hit -> hit improving score
        {

//printf("S:%3d %10d %3d %3d %3d %3d \n",k,hit_pos,min_miss,n,m,ni);
//for(i=0;i<ni;i++)
// printf(" %3d,",chromosomes[n].ils[search_index].pos[i]-shift_val);
//printf("\n");

        hit_score[k] = min_miss;
        hit_position[k] = hit_pos;
        hit_chromosome[k] = n;
        targ->tchange_hit[tid] ++;
        }

//      if((m == 1) && (hit_score[k] >= min_miss))    // $B5U:?$GF1$8%9%3%"$N>l=j(B
//      if(m == 1)  // $B5U:?(B   $BL5$/$F$$$$(B
       if(hit_score[k] == min_miss)    // $BF1$8%9%3%"$N>l=j(B
        {

//printf("I:%3d %10d %3d %3d %3d %3d \n",k,hit_pos,min_miss,n,m,ni);
//for(i=0;i<ni;i++)
// printf(" %3d,",chromosomes[n].ils[search_index].pos[i]-shift_val);
//printf("\n");

        if(hit_chromosome[k] > n)               // $B$h$j<c$$@w?'BN$+(B
         {
         hit_score[k] = min_miss;
         hit_position[k] = hit_pos;
         hit_chromosome[k] = n;
         targ->tchange_hit[tid] ++;
         }
        if((hit_chromosome[k] == n) && (abs(hit_position[k]) > abs(hit_pos)))  //$BF1$8@w?'BN$N$h$j<c$$0LCV$K%R%C%H$9$k>l9g(B
         {
         hit_score[k] = min_miss;
         hit_position[k] = hit_pos;
         hit_chromosome[k] = n;
         targ->tchange_hit[tid] ++;
         }
        }
       }
      }
     }                               // chromosome loop  // $B@w?'BN%k!<%W(B $B=*(B
    }
   }
  }
 }
//printf("F %20d %20d %20d\n",tid,targ->tnum_hit[tid],targ->tchange_hit[tid]);
}
/////////////////////////////////////////////THREAD FUNCTION  $B%9%l%C%I4X?t(B END

///////////////////////////////////////////// MAIN FUNCTION $B%a%$%s4X?t(B
int main(int argc, char **argv)
{
////////////////////////////// VARIABLES $BJQ?t@k8@(B
int i,j,k,l,m;
int n_elem;
int n_count;
char queryseq[512];
char reference_flnm[256];
FILE *reference_file;
char refseq_flnm[256];
FILE *refseq_file;
char index_flnm[256];        // INDEX FILE NAME // $B%$%s%G%C%/%9%U%!%$%kL>(B
FILE *index_file;
char query_flnm[256];
FILE *query_file;
char hit_flnm[256];
FILE *hit_file;
char mhit_flnm[256];
FILE *mhit_file[100];
//char mzhit_flnm[256];
//FILE *mzhit_file[100];
char hits_flnm[256];
FILE *hits_file;
char mapout_flnm[256];
FILE *mapout_file;
char log_flnm[256];
FILE *log_file;
char buff[512];
char buff2[512];
char refseq_header[512];
char tempc;
int flag;
int apos;
pthread_t handle[MAX_THREAD_NUM];
thread_arg_t targ[MAX_THREAD_NUM];
int tnum_hit[MAX_THREAD_NUM];
int tchange_hit[MAX_THREAD_NUM];
int pre_hit=0;
////////////////////////////// VARIABLES $BJQ?t@k8@(B END

//***************************************
//* CHECK ARGUMENTS                     *
//***************************************

readargs(argc,argv);

printf("INDEX_LENGTH:%5d\n",index_length);
printf("ROUND_CYCLE :%5d\n",n_round);
printf("THRESH_MISS :%5d\n",thresh_miss);

//fprintf(log_file,"INDEX_LENGTH:%5d\n",index_length);
//fprintf(log_file,"ROUND_CYCLE :%5d\n",n_round);
//fprintf(log_file,"THRESH_MISS :%5d\n",thresh_miss);

index_size = (int)pow((double)4,index_length);
printf("INDEX SIZE %d\n",index_size);

///////////////////////////////////////////////////////// OPEN FILES $B%U%!%$%k%*!<%W%s(B
sprintf(reference_flnm,"%s",arg1);
//sprintf(index_flnm,"%s.index%d",arg1,index_length);
sprintf(query_flnm,"%s",arg2);
sprintf(log_flnm,"%s_%s.log",arg2,job_name);
sprintf(hit_flnm,"%s_%s.mht",arg2,job_name);
//sprintf(hits_flnm,"%s_%s.mhts",arg2,job_name);
sprintf(mapout_flnm,"%s_%s.map",arg2,job_name);

if(!(hit_file = fopen(hit_flnm,"w")))
 {
 printf("Failed to open output output file: %s\n",hit_flnm);
 exit(1);
 }

if(multi_hit == 1)
 {
 if(!(hits_file = fopen(hits_flnm,"w")))
  {
  printf("Failed to open output hits file: %s\n",hits_flnm);
  exit(1);
  }
 }

if(!(reference_file = fopen(reference_flnm,"r")))
 {
 printf("Failed to open input reference file: %s\n",reference_flnm);
 exit(1);
 }
if(!(query_file = fopen(query_flnm,"r")))
 {
 printf("Failed to open input query file: %s\n",query_flnm);
 exit(1);
 }
if(!(log_file = fopen(log_flnm,"w")))
 {
 printf("Failed to open output log file: %s\n",log_flnm);
 exit(1);
 }

printf("MAPOUT WIDTH %d\n",map_out_width);
fprintf(log_file,"MAPOUT WIDTH %d\n",map_out_width);

if(map_out == 1)
{
if(!(mapout_file = fopen(mapout_flnm,"w")))
 {
 printf("Failed to open mapout file: %s\n",mapout_flnm);
 exit(1);
 }
}
///////////////////////////////////////////////////////// OPEN FILES $B%U%!%$%k%*!<%W%s(B END

fgets(buff,512,reference_file);
strcpy(reference_title,buff);
while(fgets(buff,512,reference_file))
 {
 printf("%s",buff);
 n_chromosomes ++;
 }
printf("Number of Chromosome is %d\n",n_chromosomes);
rewind(reference_file);
chromosomes = (chromosome_info *)malloc(sizeof(chromosome_info)*(n_chromosomes+1));
printf("MALLOC CHROMOSOMES 426 %10lu Byte\n",sizeof(chromosome_info)*(n_chromosomes+1));
n_chromosomes = 0;
fgets(buff,512,reference_file);
while(fgets(buff,512,reference_file))
 {
 nth_word(buff2,buff,1,'\t');
 chromosomes[n_chromosomes].cyclic_flag = atoi(buff2);
 printf("%d\n",chromosomes[n_chromosomes].cyclic_flag);
 nth_word(chromosomes[n_chromosomes].fasta_flnm,buff,2,'\t');
 printf("%s\n",chromosomes[n_chromosomes].fasta_flnm);
 nth_word(chromosomes[n_chromosomes].gb_flnm,buff,3,'\t');
 printf("%s\n",chromosomes[n_chromosomes].gb_flnm);
 n_chromosomes ++;
 }

///////////////////////////////////////////////////////////////// Chromosome loop
for(i=0;i<n_chromosomes;i++)
 {
 /////////////////////////////////////////////////////////////////////////////////// READ FASTA   FILES
 if(!(refseq_file = fopen(chromosomes[i].fasta_flnm,"r")))
  {
  printf("Failed to open input fasta file of %dth chromosome: %s\n",i+1,chromosomes[i].fasta_flnm);
  exit(1);
  }
 //////////////////////////////// COUNT REFERENCE LENGTH $B%l%U%!%l%s%9G[Ns$NJ8;z?t%+%&%s%H(B
 chromosomes[i].length = 0;
 fgets(buff,500,refseq_file);                          // $B0l9TL\(B $B%?%$%H%k9T(B
 strcpy(chromosomes[i].title,buff);
 chromosomes[i].title[strlen(chromosomes[i].title)-1] = '\0';
 while((tempc=fgetc(refseq_file)))
  {
  if(tempc != '\n')
   {
   if(tempc == '>')
    {
    printf("ERROR: Multifasta reference is not supported\n");
    printf("       Prepare list of single fasta files.\n");
    exit(1);
    }
   chromosomes[i].length ++;
   }
  if(tempc == EOF)
   {
   break;
   }
  }
 //////////////////////////////// COUNT REFERENCE LENGTH    $B%l%U%!%l%s%9G[Ns$NJ8;z?t%+%&%s%H(B END
 //////////////////////////////// ALLOCATE REFERENCE MEMORY $B%l%U%!%l%s%9G[Ns$N%"%m%1!<%H(B
 chromosomes[i].refseq = (char *)malloc(sizeof(char)*(chromosomes[i].length + 500)); // $B%l%U%!%l%s%9%a%b%j3NJ](B
 printf("MALLOC CHROMOSOMES%3d:REFSEQ(474) %10lu Byte\n",i,sizeof(char)*(chromosomes[i].length + 500));
 for(j=0;j<chromosomes[i].length+500;j++)                               // $B%l%U%!%l%s%9=i4|2=(B A$B$r5M$a$k(B
  chromosomes[i].refseq[j] = 'A';
 rewind(refseq_file);
 //////////////////////////////// ALLOCATE REFERENCE MEMORY $B%l%U%!%l%s%9G[Ns$N%"%m%1!<%H(B END
 ///////////////////////////////////////////////////////// READ REFERENCE SEQUENCE $B%l%U%!%l%s%9G[NsFI$_9~$_(B
 chromosomes[i].length = 0;
 fgets(buff,500,refseq_file);
 while((tempc = fgetc(refseq_file)))
  {
  if(tempc != '\n')
   {
   if((tempc >= 97) && (tempc <= 122))
    chromosomes[i].refseq[chromosomes[i].length] = tempc - 32;
   else
    chromosomes[i].refseq[chromosomes[i].length] = tempc;
   chromosomes[i].length ++;
   }
  if((tempc == EOF) || (tempc =='\0'))
   {
   chromosomes[i].refseq[chromosomes[i].length-1] = '\0';
   break;
   }
  }
 if(chromosomes[i].cyclic_flag == 0)   // $B4D>u(BDNA$B$J$i%l%U%!%l%s%9$N:G8e$KF,(B400$B1v4p$[$I$r7R$2$F$*$/(B
  {
  for(j=0;j<400;j++)
   {
   chromosomes[i].refseq[chromosomes[i].length-1+j] = chromosomes[i].refseq[j];
   }
  chromosomes[i].refseq[chromosomes[i].length-1+400] = '\0';
  }
 
 printf("REFERENCE SEQUENCE LENGTH:  %10d\n",chromosomes[i].length);
 printf("INPUT REFSEQ FILE: %s\n",chromosomes[i].title);
 fprintf(log_file,"REFERENCE SEQUENCE LENGTH:  %10d\n",chromosomes[i].length);
 fprintf(log_file,"INPUT REFSEQ FILE: %s\n",chromosomes[i].title);
 ///////////////////////////////////////////////////////// READ REFERENCE SEQUENCE $B%l%U%!%l%s%9G[NsFI$_9~$_(B END
 
 fclose(refseq_file);
 /////////////////////////////////////////////////////////////////////////////////// READ FASTA FILES
 // READ INDEX FILES
 chromosomes[i].ils = (index_list *)malloc(sizeof(index_list)*(index_size+1));
 printf("MALLOC CHROMOSOMES ILS%3d(517) %10lu\n",i,sizeof(index_list)*(index_size+1));
 sprintf(index_flnm,"%s.index%d",chromosomes[i].fasta_flnm,index_length);
 printf("%s\n",index_flnm);
 if(!(index_file = fopen(index_flnm,"r")))
  {
  printf("Failed to open input index file: %s\n",index_flnm);
  exit(1);
  }

 for(j=0;j<index_size;j++)
  {
  fgets(buff,256,index_file);
  n_elem = atoi(buff);
  chromosomes[i].ils[j].n_pos = n_elem;
  chromosomes[i].ils[j].pos   = (int *)malloc(sizeof(int)*(n_elem+2));
  for(k=0;k<n_elem;k++)
   {
   fgets(buff,256,index_file);
   chromosomes[i].ils[j].pos[k] = atoi(buff);
   }
  }
 printf("DONE READING INDEX FILE\n");

 fclose(index_file);

 // READ GENBANK FILES
 // READ GENBANK FILES may not be necessary ... pending ...
 }
///////////////////////////////////////////////////////////////// END Chromosome loop

//////////////////////////////////////////////////////// COUNT READ DATA $B%j!<%I%G!<%?%+%&%s%H(B
printf("START READING READ FILE %s\n",query_flnm);
fgets(buff,500,query_file);                        // $B0l%(%s%H%j!<L\(B
fgets(buff,500,query_file);
query_len = strlen(buff)-1;                        // $B8GDjD9%/%'%j!<(B $B%/%'%j!<D9(B
fgets(buff,500,query_file);
fgets(buff,500,query_file);

n_query = 1;
while(fgets(buff,500,query_file))
 {
 fgets(buff,500,query_file);
 fgets(buff,500,query_file);
 fgets(buff,500,query_file);
 n_query ++;
 }
printf("NUMBER OF READ  SEQUENCE IS:%10d\n",n_query);
printf("READ_LENGTH              IS:%10d\n",query_len);
fprintf(log_file,"NUMBER OF READ  SEQUENCE IS:%10d\n",n_query);
fprintf(log_file,"READ_LENGTH              IS:%10d\n",query_len);
fflush(log_file);
//////////////////////////////////////////////////////// COUNT READ DATA $B%j!<%I%G!<%?%+%&%s%H(B END

///////////////////////////////////////////////////////// ALLOCATE MEMEORY FOR QUERY $B%j!<%IMQ%a%b%j3NJ](B
qs = (query_info *)malloc(sizeof(query_info)*(n_query + 100));
printf("MALLOC QS(572) %10lu\n",sizeof(query_info)*(n_query + 100));
if(!qs)
 {
 printf("Failed to allocate memory for qs");
 exit(1);
 }
rewind(query_file);
///////////////////////////////////////////////////////// ALLOCATE MEMEORY FOR QUERY $B%j!<%IMQ%a%b%j3NJ](B END

///////////////////////////////////////////////////////// READ QUERY SEQUENCES $B%j!<%IFI$_9~$_(B
n_query = 0;
while(fgets(buff,500,query_file))
 {
 fgets(buff,500,query_file);
 buff[query_len] = '\0';
 qs[n_query].seq = (char *)malloc(sizeof(char)*(query_len + 2));
 strcpy(qs[n_query].seq,buff);
 n_query ++;
 fgets(buff,500,query_file);
 fgets(buff,500,query_file);
 }
///////////////////////////////////////////////////////// READ QUERY SEQUENCES $B%j!<%IFI$_9~$_(B END

//////////////////////////////////////////////////////////////////////// $B%R%C%H0LCVEy$N%"%m%1!<%7%g%s(B
hit_position   = (int *)malloc(sizeof(int)*(n_query+2));           // HIT POSITION ON REFERENCE NEGATIVE IF COMPLEMENT
printf("MALLOC HIT_POSITION %10lu\n",sizeof(int)*(n_query+2));
hit_chromosome = (int *)malloc(sizeof(int)*(n_query+2));           // HIT POSITION ON REFERENCE NEGATIVE IF COMPLEMENT
printf("MALLOC HIT_CHROMOSO %10lu\n",sizeof(int)*(n_query+2));
hit_score = (int *)malloc(sizeof(int)*(n_query+2));                // HIT SCORE  suffix IS QUERY NUMBER //$B%R%C%H$N%9%3%"!!E:;z$,%/%'%j!<$NHV9f(B
if(multi_hit == 1)
 {
 hit_positions = (hit_position_info **)malloc(sizeof(hit_position_info **) * (n_query+2));
 num_hits = (int *)malloc(sizeof(int)*(n_query+10));                // NUMBER OF HIT POSITION //$B%R%C%H0LCV$N8D?t(B
 }
//////////////////////////////////////////////////////////////////////// $B%R%C%H0LCVEy$N%"%m%1!<%7%g%s(B END

/////////////////////////////////////////// N$B$r4^$`%/%'%j!<$r%+%&%s%H(B
int with_n = 0;
for(i=0;i<n_query;i++)
 {
 n_count = 0;
 for(j=0;j<query_len;j++)
  {
  if((qs[i].seq[j] == 'N') || (qs[i].seq[j] == '.'))
   n_count ++;
  }
 if(n_count != 0)
  with_n ++;
//// qs[i].num_n = n_count;
 }
printf("NUMBER OF QUERY WITH N IS  :%10d\n",with_n);
fprintf(log_file,"NUMBER OF QUERY WITH N IS  :%10d\n",with_n);
fflush(log_file);
/////////////////////////////////////////// N$B$r4^$`%/%'%j!<$r%+%&%s%H(B END


/////////////////////////////////////////// $BJQ?t=i4|2=(B
for(i=0;i<n_query;i++)
 {
 hit_position[i]   = MAX_INT;
 hit_chromosome[i] = MAX_INT;
 hit_score[i]      = MAX_INT;
 }
/////////////////////////////////////////// $BJQ?t=i4|2=(B END

/////////////////////////////////////////// $B%i%&%s%I$4$H$N%7%U%HNL$r7hDj(B
shift_vals[0] = 0;
int last_pos = query_len - index_length;
shift_vals[n_round -1] = last_pos;
for(i=1;i<n_round-1;i++)
 shift_vals[i] = last_pos / (n_round-1) * i;
printf("INDEX SHIFT_VALUES ARE\n");
fprintf(log_file,"INDEX SHIFT_VALUES ARE\n");
fflush(log_file);

for(i=0;i<n_round;i++)
 {
 printf("ROUND  %3d:%10d\n",i+1,shift_vals[i]);
 fflush(stdout);
 fprintf(log_file,"ROUND  %3d:%10d\n",i+1,shift_vals[i]);
 fflush(log_file);
 }
fprintf(log_file,"\n");
fflush(log_file);
/////////////////////////////////////////// $B%i%&%s%I$4$H$N%7%U%HNL$r7hDj(B END
//for(l=0;l<n_round;l++)
for(l=0;l<n_thread;l++)
 {
 tnum_hit[l] = 0;
 tchange_hit[l] = 0;
 }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
for(l=0;l<n_round;l++)         // ROUND LOOP  SHIFTING INDEX POSITION //$B%i%&%s%I%k!<%W!!!J%$%s%G%C%/%90LCV$r$:$i$9!K(B
 {
 shift_val = shift_vals[l];
 printf("ROUND %d\n",l+1);
 fprintf(log_file,"ROUND %d\n",l+1);
 fflush(log_file);

/////////////////////////// MULTI_THREAD MATCH CHECK //$B%^%k%A%9%l%C%I2=!!%^%C%A%+%&%s%H(B
 for(k=0;k<n_thread;k++)
  {
  targ[k].thread_no = k;
  targ[k].tnum_hit = tnum_hit;
  targ[k].tchange_hit = tchange_hit;
  pthread_create(&handle[k],NULL,(void *)thread_func,(void *)&targ[k]);      // $B%9%l%C%I%3!<%k(B
  }
 for(k=0;k<n_thread;k++)
  {
  pthread_join(handle[k],NULL);                                              // $B%9%l%C%I%8%g%$%s(B
  }
////////////////////////// MULTI_THREAD MATCH CHECK //$B%^%k%A%9%l%C%I2=!!%^%C%A%+%&%s%H(B END
 }                           // END ROUND LOOP //$B%i%&%s%I%k!<%W!!!J%$%s%G%C%/%90LCV$r$:$i$9!K(BEND
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////$B3F%9%l%C%I$N7k2L$r@Q;;(B
num_hit = 0;
change_hit = 0;
for(i=0;i<n_thread;i++)
 {
 num_hit += tnum_hit[i];           // $B%R%C%H?t(B
 change_hit += tchange_hit[i];     // $B%R%C%H$X$NJQ2=?t(B
// printf("%20d %20d %20d %20d\n",tnum_hit[i],tchange_hit[i],num_hit,change_hit);
 }
//////////////////////////////////////////////$B3F%9%l%C%I$N7k2L$r@Q;;(B
printf("Number of Hits    %10d\n",num_hit);
printf("Number of Upgrade %10d\n",change_hit);
printf("ROUNDS END\n");
printf("SAVING RESULTs\n");

int number_of_hit_read = 0;
int number_of_no_hit_read = 0;

for(i=0;i<n_query;i++)
 {
 if(hit_position[i] == MAX_INT)
  number_of_no_hit_read ++;
 else
  number_of_hit_read ++;
 }
printf("Number of Mapped Hit read is   %10d\n",number_of_hit_read);
printf("Mapped Ratio is                %10.2f\n",((float)number_of_hit_read)/((float)n_query)*100.0);
printf("Number of Unmapped Hit read is %10d\n",number_of_no_hit_read);

//////////////////////////////////////////////MAP ON REFERENCE
if(map_out == 1)
{
printf("Enter MAPPING\n");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////// FILL POSITION_HIT
////////////////////////////////////////// FILL position_hits list

for(j=0;j<n_chromosomes;j++)
 chromosomes[j].position_hits = (position_hit_info *)malloc(sizeof(position_hit_info) * chromosomes[j].length + 1);


for(j=0;j<n_chromosomes;j++)
 for(i=0;i<chromosomes[j].length;i++)            // $B%l%U%!%l%s%91v4p0LCV$K$D$$$F(B
  chromosomes[j].position_hits[i].n_hit = 0;         // n_hit $B=i4|2=(B

for(i=0;i<n_query;i++)               // n_hit $B%+%&%s%H(B
 {
 if(hit_position[i] != MAX_INT)
  chromosomes[hit_chromosome[i]].position_hits[abs(hit_position[i])-1].n_hit ++;  // MARK
 }

for(j=0;j<n_chromosomes;j++)
 for(i=0;i<chromosomes[j].length;i++)
  {
  if(chromosomes[j].position_hits[i].n_hit >= 1)     // $B%l%U%!%l%s%91v4p0LCV$G$N%R%C%H5-O?%a%b%j%"%m%1!<%H(B
   {
   chromosomes[j].position_hits[i].hits = (int *)malloc(sizeof(int) * (chromosomes[j].position_hits[i].n_hit + 1));
   chromosomes[j].position_hits[i].boxs = (int *)malloc(sizeof(int) * (chromosomes[j].position_hits[i].n_hit + 1));
   }
  }

for(j=0;j<n_chromosomes;j++)
 for(i=0;i<chromosomes[j].length;i++)            // $B$b$&0lEY(B n_hit $B=i4|2=(B
  {
  chromosomes[j].position_hits[i].n_hit = 0;
  }


for(i=0;i<n_query;i++)               // $B%R%C%H0LCV$N5-F~(B
 {
 if(hit_position[i] != MAX_INT)
  {
  apos=abs(hit_position[i])-1;
  chromosomes[hit_chromosome[i]].position_hits[apos].boxs[chromosomes[hit_chromosome[i]].position_hits[apos].n_hit] = 0;
  if(hit_position[i] > 0)
   chromosomes[hit_chromosome[i]].position_hits[apos].hits[chromosomes[hit_chromosome[i]].position_hits[apos].n_hit ++] =  (i+1); // MARK
  else
   chromosomes[hit_chromosome[i]].position_hits[apos].hits[chromosomes[hit_chromosome[i]].position_hits[apos].n_hit ++] = -(i+1); // MARK
  }
 }

printf("DONE FILLING POSITION_HIT LIST\n");
////////////////////////////////////////// FILL position_hits list END
////////////////////////////////////////////////////////////////////////////////////////////////////////////////// FILL POSITION_HIT


////////////////////////////////////////// FILL BOX, DECIDE WHICH ROW THE READ IS PRINTED ON MAP
////////////////////////////////////////// $B$=$l$>$l$N%j!<%I$r%^%C%W$N2?9TL\$K=q$/$+$r7h$a$F$f$/(B
////////////////////////////////////////// $B:8$+$i=g$K>e$+$i%j!<%I$r5M$a$F$f$/!"=q$1$J$$0LCV$O(Bbox$BJQ?t$r(B0$B0J30$K$9$k(B

int min_hit;
int max_box_num = 0;

for(m=0;m<n_chromosomes;m++)
 {

 for(i=0;i<MAX_BOX+5;i++)                  // $BJQ?t=i4|2=(B
  {
  box[i] = 0;
  box_start[i] = MAX_INT;
  box_hit[i] = MAX_INT;
  box_cnt[i] = 0;
  box_position[i] = MAX_INT;
  box_query[i] = MAX_INT;
  }

 for(i=0;i<chromosomes[m].length;i++)                   // $B;2>HG[Ns$N3F0LCV$K$D$$$F(B
  {
  if(chromosomes[m].position_hits[i].n_hit >= 0)            // $B3F0LCV$G$N%R%C%H?t$N%k!<%W(B
   {
   for(j=0;j<chromosomes[m].position_hits[i].n_hit;j++)
    {
    min_hit = 0;
    flag = 0;
    for(k=0;k<MAX_BOX;k++)                   // 0 $B$+$i:GBg9T?t$^$G(B
     {
     if(chromosomes[m].cyclic_flag == 0)
      {
      if(box[k] == 0)                         // $B$=$N9T$,6u$J$i(B
       {
       if((box_start[k] == MAX_INT) || ((chromosomes[m].length + box_start[k]) > (i + query_len + 2)))                             // CMARK
        {
        if(i + query_len >= chromosomes[m].length)
         {
         box_position[k] = (i+query_len)-chromosomes[m].length+1;
         box_query[k]    = chromosomes[m].position_hits[i].hits[j];
         }
        chromosomes[m].position_hits[i].boxs[j] = k;          // $B$=$N0LCV$N%R%C%H?tHVL\$N%R%C%H$O(Bk$B9TL\$KF~$k(B
        box[k] = query_len+2;                  // k $B9TL\$N;D$j1v4p?tCM$r%j!<%ID9(B+2$B$H$9$k(B
        if(box_start[k] == MAX_INT)            // $B%5%$%/%j%C%/%2%N%`IA2h$N$?$a$K$=$l$>$l$N(Bbox$B0LCV$G$N:G=i$N%R%C%H$N>l=j$r5-21$9$k(B  // CMARK
         box_start[k] = i;
        qs[abs(chromosomes[m].position_hits[i].hits[j])-1].depth = k;  // $B$=$N%/%'%j!<$,2?9TL\$K=q$+$l$k$N$+$r21$($k(B
//        qs[abs(chromosomes[m].position_hits[i].hits[j])].depth = k;  // $B$=$N%/%'%j!<$,2?9TL\$K=q$+$l$k$N$+$r21$($k(B
        if(k > max_box_num)
         max_box_num = k;                      // k $B$N:GBgCM$r(Bmax_box_num$B$H$9$k(B
        flag = 1;                              // $B%U%i%0$rN)$F$k(B
        break;
        }
       }
      }
     else
      {
      if(box[k] == 0)                         // $B$=$N9T$,6u$J$i(B
       {
       chromosomes[m].position_hits[i].boxs[j] = k;          // $B$=$N0LCV$N%R%C%H?tHVL\$N%R%C%H$O(Bk$B9TL\$KF~$k(B
       box[k] = query_len+2;                  // k $B9TL\$N;D$j1v4p?tCM$r%j!<%ID9(B+2$B$H$9$k(B
//       qs[abs(chromosomes[m].position_hits[i].hits[j])].depth = k;  // $B$=$N%/%'%j!<$,2?9TL\$K=q$+$l$k$N$+$r21$($k(B
       qs[abs(chromosomes[m].position_hits[i].hits[j])-1].depth = k;  // $B$=$N%/%'%j!<$,2?9TL\$K=q$+$l$k$N$+$r21$($k(B
       if(k > max_box_num)
        max_box_num = k;                      // k $B$N:GBgCM$r(Bmax_box_num$B$H$9$k(B
       flag = 1;                              // $B%U%i%0$rN)$F$k(B
       break;
       }
      }
     }                       // k BOX loop
    if(flag == 0)                        // $B%U%i%0$,#0$J$i(B
     {
     chromosomes[m].position_hits[i].boxs[j] = -1;      // OMIT DRAWING IF BOX IS FULL // BOX$B$,0n$l$?$i(BMAX_BOX$B0J>e$OIA$+$J$$!#(B
     }
    }                        // j HIT loop
   }                         // i GENOME POSITION loop
  for(j=0;j<MAX_BOX;j++)
   {
   if(box[j] >= 1)
    box[j] --;                           //$B3F9T$N;D$j1v4p?tCM$,@5$J$i#1$r$R$/(B
   }
  }

//for(i=0;i<MAX_BOX+5;i++)
// printf("%10d %10d %10d %10d\n",i,box_start[i],box_position[i],box_query[i]);

printf("DONE FILLING BOX LIST FOR MAPPING POSITIONS\n");
////////////////////////////////////////// FILL BOX, DECIDE WHICH ROW THE READ IS PRINTED ON MAP :END

 int map_fold = (chromosomes[m].length / map_out_width) + 1;
 int map_depth = max_box_num;
 
 //printf("MAX_DEPTH       %10d\n",max_box_num);
 //printf("MAP_OUT_WIDTH   %10d\n",map_out_width);
 //printf("MAP_FOLD        %10d\n",map_fold);
 //fprintf(log_file,"MAX_DEPTH       %10d\n",max_box_num);
 //fprintf(log_file,"MAP_OUT_WIDTH   %10d\n",map_out_width);
 //fprintf(log_file,"MAP_FOLD        %10d\n",map_fold);
 //fflush(log_file);
 fprintf(mapout_file,"\nCHROMOSOME %3d %s\n\n",m+1,chromosomes[m].title);
 
 ////////////////////////////////////////////////////////// OUTPUT MAP //MAP$B!!=PNO(B
 int from;
 int to;
 int max_depth_of_the_fold=0;
 
 for(i=0;i<map_fold;i++)                        // FOLD LOOP  // $B3F%U%)!<%k%I$N%k!<%W(B
  {
  from = i * map_out_width;
  to   = (i+1) * map_out_width - 1;
  max_depth_of_the_fold = 0;
  fprintf(mapout_file,"CHR:%6d: %s\n",m+1,chromosomes[m].title);           // PRINT REFERENCE POSITION  //$B%l%U%!%l%s%90LCVI=<(!J:8!K(B
  fprintf(mapout_file,"%10d: ",from);           // PRINT REFERENCE POSITION  //$B%l%U%!%l%s%90LCVI=<(!J:8!K(B
 
  if(to > chromosomes[m].length)
   to = chromosomes[m].length-2;
  for(j=from;j<=to;j++)                         // PRINT REFERENCE SEQUENCE    // $B%l%U%!%l%s%9G[NsI=<((B
   {
   fprintf(mapout_file,"%c",chromosomes[m].refseq[j]);
   }
 
  for(j=from-query_len-1;j<=to;j++)
   {
   if(j<0)
    j= 0;
   for(l=0;l<chromosomes[m].position_hits[j].n_hit;l++)        // CALCULATE MAX DEPTH OF THE FOLD //$B%U%)!<%k%IFb$N:GBg?<$5$r7W;;(B
    {
    if(chromosomes[m].position_hits[j].boxs[l]+1 > max_depth_of_the_fold)
     {
     max_depth_of_the_fold = chromosomes[m].position_hits[j].boxs[l]+1;
     }
    }
   }
  if(chromosomes[m].cyclic_flag == 0)
   if(i==0)
    for(j=0;j<MAX_BOX+5;j++)
     if(box_position[j] != MAX_INT)
      if(j>max_depth_of_the_fold)
       max_depth_of_the_fold = j;
  
  fprintf(mapout_file,"\n");
//  fprintf(mapout_file,"            ");
  fprintf(mapout_file,"           ");          // $BL\@9$j0LCV=$@5(B
 
  for(j=from;j<=to;j++)                         // PRINT TICS  //$BL\@9$j?tCMI=<((B
   {
   if(j%10 == 0)
    fprintf(mapout_file,"%d",(j/10)%10);
   else
    fprintf(mapout_file," ");
   }
  fprintf(mapout_file,"\n");
 
  for(k=0;k<max_depth_of_the_fold + 2;k++)      // LOOP FOR EACH DEPTH
   {
   fprintf(mapout_file,"          : ");
   for(j=from;j<=to;j++)
    {
    for(l=0;l<chromosomes[m].position_hits[j].n_hit;l++)
     {
     if(chromosomes[m].position_hits[j].boxs[l] == k)
      {
      box_hit[k] = chromosomes[m].position_hits[j].hits[l];  // MARK
      box_cnt[k] = query_len+1;
      }
     }                     // l POSITION HIT LOOP

    pre_hit = 0;
    if(j>=1)               // TO SHOW DIRECTION OF READ 2015/5/13
     {
     for(l=0;l<chromosomes[m].position_hits[j+1].n_hit;l++)
      {
      if(chromosomes[m].position_hits[j+1].boxs[l] == k)
       {
       pre_hit = chromosomes[m].position_hits[j+1].hits[l];  // MARK
       }
      }                     // l POSITION HIT LOOP
     }

    if(box_cnt[k] == 1)    // box$B$N;D$j?t$,#1$K$J$C$?$i(BMAX_INT$B$K%j%;%C%H(B
     {
     box_hit[k] = MAX_INT;
     }
    if(box_cnt[k] >= 1)    // box$B$N;D$j?t$,#10J>e$J$i%G%/%j%a%s%H(B
     {
     box_cnt[k] --;
     }
 
    if(box_hit[k] != MAX_INT)
     {
     if(box_hit[k] > 0)
      {
      tempc = qs[abs(box_hit[k])-1].seq[query_len-box_cnt[k]];
      if(tempc == chromosomes[m].refseq[j])
       fprintf(mapout_file,"%c",tempc);
      else
       fprintf(mapout_file,"%c",tempc+32);
      }
     else
      {
      tempc = complement_char(qs[abs(box_hit[k])-1].seq[box_cnt[k]-1]);
      if(tempc == chromosomes[m].refseq[j])
       fprintf(mapout_file,"%c",tempc);
      else
       fprintf(mapout_file,"%c",tempc+32);
      }
     }
    else
     {

     if(chromosomes[m].cyclic_flag == 0)
      {
      if(box_position[k] != MAX_INT)
       {
       if(box_query[k] > 0)
        {
        tempc = qs[abs(box_query[k])-1].seq[query_len-box_position[k]];
        if(tempc == chromosomes[m].refseq[j])
         fprintf(mapout_file,"%c",tempc);
        else
         fprintf(mapout_file,"%c",tempc+32);
//        fprintf(mapout_file,"#");
        }
       else
        {
        tempc = complement_char(qs[abs(box_query[k])-1].seq[box_position[k]-1]);
        if(tempc == chromosomes[m].refseq[j])
         fprintf(mapout_file,"%c",tempc);
        else
         fprintf(mapout_file,"%c",tempc+32);
//        fprintf(mapout_file,"$");
        }
       box_position[k] --;
       if(box_position[k] == 0)
        box_position[k] = MAX_INT;
       }
      else
       {
       fprintf(mapout_file," ");
       }
      }
     else
      {
      if(pre_hit >= 1)
       fprintf(mapout_file,">");
      else
       if(pre_hit <= -1)
        fprintf(mapout_file,"<");
       else
        fprintf(mapout_file," ");
      pre_hit = 0;
      }

     }
    }
   fprintf(mapout_file,"\n");
   }                             // k BOX DEPTH  LOOP
  }                              // i FOLD       LOOP
 }                               // m CHROMOSOME LOOP
}                                //   map_out is TRUE
////////////////////////////////////////////////////////// END MAP OUTPUT //MAP$B!!=PNO(B END

//////////////////////////////////////////// PRINT HIT_LIST
if(map_out == 1)
 {
 for(i=0;i<n_query;i++)
  {
  if(hit_position[i] != MAX_INT)
   {
   fprintf(hit_file,"%10d %10d %10d %10d \n",i,hit_chromosome[i],hit_position[i],qs[i].depth);  //map$B7W;;$7$F$?$i$=$N%j!<%I$N?<$50LCV$b=P$9(B
   }
  }
 for(i=0;i<n_chromosomes;i++)
  {
  sprintf(mhit_flnm,"%s_%s_%d.hit",arg2,job_name,i);
  if(!(mhit_file[i] = fopen(mhit_flnm,"w")))
   {
   printf("Failed to open output output file: %s\n",mhit_flnm);
   exit(1);
   }
//  sprintf(mzhit_flnm,"%s_%s_%dz.hit",arg2,job_name,i);
//  if(!(mzhit_file[i] = fopen(mzhit_flnm,"w")))
//   {
//   printf("Failed to open output output file: %s\n",mzhit_flnm);
//   exit(1);
//   }
  }
 for(i=0;i<n_query;i++)
  {
  if(hit_position[i] != MAX_INT)
   {
   fprintf(mhit_file[hit_chromosome[i]],"%10d %10d %10d\n",i,hit_position[i],qs[i].depth);  //map$B7W;;$7$F$?$i$=$N%j!<%I$N?<$50LCV$b=P$9(B
//   fprintf(mzhit_file[hit_chromosome[i]],"%10d %10d %10d\n",i,hit_position[i]-1,qs[i].depth);  //map$B7W;;$7$F$?$i$=$N%j!<%I$N?<$50LCV$b=P$9(B
   }
  }
 for(i=0;i<n_chromosomes;i++)
  fclose(mhit_file[i]);
 }
else
 {
 for(i=0;i<n_query;i++)
  {
  if(hit_position[i] != MAX_INT)
   {
   fprintf(hit_file,"%10d %10d %10d \n",i,hit_chromosome[i],hit_position[i]);
   }
  }
 for(i=0;i<n_chromosomes;i++)
  {
  sprintf(mhit_flnm,"%s_%s_%d.hit",arg2,job_name,i);
  if(!(mhit_file[i] = fopen(mhit_flnm,"w")))
   {
   printf("Failed to open output output file: %s\n",mhit_flnm);
   exit(1);
   }
//  sprintf(mzhit_flnm,"%s_%s_%dz.hit",arg2,job_name,i);
//  if(!(mzhit_file[i] = fopen(mzhit_flnm,"w")))
//   {
//   printf("Failed to open output output file: %s\n",mzhit_flnm);
//   exit(1);
//   }
  }
 for(i=0;i<n_query;i++)
  {
  if(hit_position[i] != MAX_INT)
   {
   fprintf(mhit_file[hit_chromosome[i]],"%10d %10d\n",i,hit_position[i]);  //map$B7W;;$7$F$?$i$=$N%j!<%I$N?<$50LCV$b=P$9(B
//   fprintf(mzhit_file[hit_chromosome[i]],"%10d %10d\n",i,hit_position[i]-1);  //map$B7W;;$7$F$?$i$=$N%j!<%I$N?<$50LCV$b=P$9(B
   }
  }
 for(i=0;i<n_chromosomes;i++)
  fclose(mhit_file[i]);
 }
//////////////////////////////////////////////
}
///////////////////////////////////////////// MAIN FUNCTION $B%a%$%s4X?t(B END

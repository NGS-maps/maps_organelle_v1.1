#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_READ_LEN           110
#define MAX_CHROMOSOME         100
#define MAX_ID_LEN              64
#define MAX_CHR_ID_LEN          64
#define BUFLEN                2014
#define MAX_GENE             50000
#define MAX_FOLD            100000
#define MAX_PAGE             10000
#define MAX_CONTIG_LEN    10000000
#define MAX_GENOME_LEN    30000000

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct seq_info
 {
 char *seq;
 int  seq_len;
 int  cov_area;
 char id[MAX_ID_LEN];
 char chr_id[MAX_CHR_ID_LEN];
 char *title;
 int  title_len;
 } seq_info;

typedef struct member_list
 {
 int match_id;
 struct member_list *next;
 } member_list;

typedef struct consecutive_hit_list
 {
 int nqueid;
 int nrefid;
 int match_id;
 int n_member;
 int *members;
 member_list *mlist;
 struct consecutive_hit_list *next;
 }consecutive_hit_list;

typedef struct consecutive_hit_info
 {
 int  nrefid;
 int  nqueid;
 int  n_member;
 int  *members;
 int  *mm_id;
 
 int   total_match;
 int   q_ini_pos;
 int   q_fin_pos;
 int   q_stretch;
 float q_match_ratio;
 int   r_ini_pos;
 int   r_fin_pos;
 int   r_stretch;
 float r_match_ratio;
 } consecutive_hit_info;

typedef struct match_info
 {
 char refid[MAX_ID_LEN];
 int  nrefid;
 int  rpos;
 int  qpos;
 int  len;
 } match_info;

typedef struct id_record
{
char id[MAX_ID_LEN];
int  pos;
struct id_record *next;
struct id_record *last;
} id_record;

typedef struct r_hit_info
{
char refid[MAX_ID_LEN];
int  nrefid;
int n_member;
int total_len;
int *members;
float cov_per_reflen;
float cov_per_quelen;
int  l_longmatch;
} r_hit_info;

typedef struct mum_info
 {
 char queid[MAX_ID_LEN];
 int  nqueid;
 int  n_match;
 match_info *match;
 int  n_r_hit;
 r_hit_info *rhits;
 int  n_consecutive_hits;
 consecutive_hit_info *chi;
 int  max_r_hit;
 int  match_total;
 int  direction;
 } mum_info;

typedef struct delta_align_info
 {
 int  qini,qfin;
 int  rini,rfin;
 int  nerr,serr,scdn;
 int  gaplist_length;
 int  *gaplist;
 } delta_align_info;

typedef struct delta_info
 {
 char queid[MAX_ID_LEN];
 char refid[MAX_ID_LEN];
 int  nqueid;
 int  nrefid;
 int  quelen,reflen;
 int n_align;
 delta_align_info *das;
 } delta_info;

void readargs(int argc, char **argv);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <math.h>
#include "circmaps.h"
#define MAX_ARG_LEN 132
#define BUFLEN      512
#define PI          3.1415926535897932
#define MAX_TRACK    20

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//    CIRCMAPS = DRAW CIRCOS LIKE LINK MAP FOR MAPS RESULTS                  //
//                                                                           //
//    usage: circmap [options] result.hr                                     //
//                                                                           //
//    Programed by Kensuke Nakamura, Since Nov. 2017, All right reserved.    //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

typedef struct track_info
{
int    plot_type;
double in_radius;
double out_radius;
char   data_flnm[BUFLEN];
int   window_size;
double track_width;
double track_true_width;
double bg_color_r;
double bg_color_g;
double bg_color_b;
} track_info;

typedef struct gene_segment_info
{
int from;
int to;
int direction;
} gene_segment_info;

typedef struct gene_info
{
int n_segments;
gene_segment_info *gene_segments;
int direction;
char gene_name[64];
} gene_info;

typedef struct pop_info
{
int plus;
int minus;
} pop_info;

void read_fasta(void);
void read_genbank(void);
void plot_gc_contents(int track_id);
void plot_gc_skew(int track_id);
void plot_genes(int track_id);
void plot_population(int track_id);
void plot_rearrange_direction(int track_id);
///////////////////GLOVAL VARIABLE

char arg1[MAX_ARG_LEN];
//char arg2[MAX_ARG_LEN];
//char arg3[MAX_ARG_LEN];

int genome_length;

int draw_method      = 3;
int paired_end       = 0;
//int draw_method    = 4;
double font_size     = 8.0;
double max_radius    = 275.0;                // �`���̍ő唼�a �|�C���g�P��
double scale_radius  =   1.02;               // �ڐ���̔��a
double circos_scale  =   0.7;                // CIRCOS��̃T�C�Y �ő�1.0
double radius_plus   =   0.95;               // CIRCOS��̒��ł̃v���X�~�̔��a
double radius_plus2  =   0.92;               // CIRCOS��̒��ł̃v���X�~�̔��a
double radius_d5out  =   0.95;               // CIRCOS��̒��ł̃v���X�~�̔��a
double radius_d5in   =   0.85;               // CIRCOS��̒��ł̃v���X�~�̔��a
double radius_minus  =   0.80;               // CIRCOS��̒��ł̃}�C�i�X�~�̔��a
double radius_minus2 =   0.77;               // CIRCOS��̒��ł̃}�C�i�X�~�̔��a
double radius_inside =   0.65;               // CIRCOS��̒��ł̃}�C�i�X�~�̔��a
double radius_inside2=   0.62;               // CIRCOS��̒��ł̃}�C�i�X�~�̔��a
double radius_zero ;                        // CIRCOS��̒��ł̃v���X�~�ƃ}�C�i�X�~�̒��Ԃ̔��a
double radius_anchor =   0.00;               // CIRCOS��̒��ł̃A���J�[�~�̔��a   �����N�p�Ɉˑ�
double width_circle  =   0.30;               // CIRCOS��ł̃v���X/�}�C�i�X�~�̑���
double width_gene    =   1.60;               // CIRCOS��ł̃v���X/�}�C�i�X�~�̑���
double thresh_angle  =   45.00;              // ���̊p�x�ȓ��Ȃ璼�ڃ����N�i�O���j�ȏ�Ȃ�A�[�N�����N�i�����j
double caption_scale =   1.01;              // �ڐ���̐��l���X�P�[���̂ǂ̒��x�O���ɒu����
double min_radius_anchor = 0.00;            // �A�[�N�����N�̃A���J�[�|�C���g�̔��a�@�ŏ�
double max_radius_anchor = 0.60;            // �A�[�N�����N�̃A���J�[�|�C���g�̔��a�@�ő�
double link_width    = 0.2;                  // �����N�̑���         �ϐ��Ƃ��Ă����g���ĂȂ�
double base_link_width   = 0.3;             // �����N�̑����̊   ����Ƀ��[�h����log��������
double point_radius  = 2.0;                  // �ߓ_�̉~�̔��a
double point_width   = 0.1;                  // �ߓ_�̉~�̐���
double tic_interval  = 1000.0;               // �ڐ���̕��@�@������
double tic_height    = 2.0;                  // �ڐ���̍����@������
double tic_width     = 0.2;                  // �ڐ���̑����@������
double ttic_interval = 10000.0;              // �ڐ���̕��@�@�协��
double ttic_height   = 5.0;                  // �ڐ���̍����@�协��
double ttic_width    = 0.5;                  // �ڐ���̑����@�协��
double gc_width      = 1.0;
double pop_width     = 1.0;
double pop_scale     = 1.0;
double balance_scale = 1.0;
double minimum_link_width = 0.01;
int    default_window_size = 100;

int    n_track       = 4;
track_info tracks[MAX_TRACK];
double track_margin  = 0.03;
double track_boundary_width = 0.05;

double angle;
double startx,starty;                       // �n�_���W
double anchorx,anchory;                     // �A���J�[�|�C���g���W
double a1x,a1y;                             // �A���J�[�|�C���g���W
double a2x,a2y;                             // �A���J�[�|�C���g���W
double endx,endy;                           // �I�_���W
double startangle;                          // �n�_�p
double endangle;                            // �I�_�p
double midangle;                            // ���_�p
double formangle;                           // �n�_�ƏI�_�̂Ȃ��p

double shift_len;
double shiftx,shifty;
double shift_angle;

int read_fasta_flag = -1;
char fasta_flnm[256];
//int  seq_len = -1;
char *seq;

int read_gb_flag = -1;
char gb_flnm[256];
int   n_gene =  0;
gene_info  *genes;

int read_peb_flag = -1;
char peb_flnm[256];
int   n_pos =  0;
pop_info   *pops;

int  n_links = 0;               // �����N���@���̓t�@�C���̍s��
link_info *links;               // �����N���

FILE *psfile;                   // �o��ps�t�@�C��

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\FUNTION DEFINITIONS END
int read_int (char *str,int start,int width)   // ## Function read_int �����񂩂琔�l����� 
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}

int count_comma(char *str)
 {
 int i,val=0;
 for(i=0;i<strlen(str);i++)
  {
  if(str[i] == ',')
   val ++;
  }
 return val+1;
 }

int ithnum(int a,int b,char *str)
 {
 int i,j;
 char ss[16];
 int begin,end;
 int flag = 0;
 int flag2= 0;
 int count= 0;
 int count2= 0;
 int thenum;
 thenum = b*2+a;
 for(i=0;i<strlen(str);i++)
  {
  if(flag == 0)  // �����łȂ�
   {
   if((str[i] >= '0') && (str[i] <= '9'))  // �����ɂȂ�
    {
    flag = 1;
    count ++;
    if(count == thenum)
     {
     flag2 = 1;
     ss[count2] = str[i];
     count2++;
     }
    }
   else                                    // �����łȂ��܂�
    {
    }
   }
  else           // �����̒�
   {
   if((str[i] >= '0') && (str[i] <= '9'))  // �����̑���
    {
    if(flag2 == 1)
     {
     ss[count2] = str[i];
     count2++;
     }
    }
   else                                    // �����łȂ��Ȃ�
    {
    if(flag2 == 1)
     {
     ss[count2] = '\0';
     return(atoi(ss));
     }
    flag = 0;
    }
   }
  }
 return (-1);
 }

///////////////////////////////////////////////////////////////////////////////////////////// MAIN
int main(int argc, char **argv)
{
int i,j,k,l,m;
char ps_buff[100000];
char psout_flnm[BUFLEN];
char buff[BUFLEN];
FILE *infile;                   // ���̓t�@�C��  hr, unk

double ps_font_size = 8.0;

readargs(argc,argv);

//genome_length = atoi(arg1);

if((draw_method == 5) || (draw_method == 6))
 {
 max_radius_anchor = 0.9;
 }

if(read_fasta_flag == 1)
 {
 read_fasta();
 }
if(read_gb_flag == 1)
 {
 read_genbank();
 }

printf("input file    = %s\n",arg1);
printf("genome_length = %d\n",genome_length);
n_pos = genome_length;
pops = (pop_info *)malloc(sizeof(pop_info) * (genome_length + 10));
////////////////////////////////////////////
tracks[0].in_radius  = 0.0;
tracks[0].out_radius = 0.7;

tracks[1].in_radius  = 0.7;
tracks[1].out_radius = 0.75;
tracks[2].in_radius  = 0.75;
tracks[2].out_radius = 0.9;
tracks[3].in_radius  = 0.9;
tracks[3].out_radius = 0.95;
tracks[4].in_radius  = 0.95;
tracks[4].out_radius = 1.00;

tracks[0].bg_color_r  = 1.0; tracks[0].bg_color_g  = 1.0; tracks[0].bg_color_b  = 1.0;
tracks[1].bg_color_r  = 1.0; tracks[1].bg_color_g  = 1.0; tracks[1].bg_color_b  = 1.0;
tracks[2].bg_color_r  = 1.0; tracks[2].bg_color_g  = 1.0; tracks[2].bg_color_b  = 1.0;
tracks[3].bg_color_r  = 1.0; tracks[3].bg_color_g  = 1.0; tracks[3].bg_color_b  = 1.0;
tracks[4].bg_color_r  = 1.0; tracks[4].bg_color_g  = 1.0; tracks[4].bg_color_b  = 1.0;
//tracks[5].in_radius  = 0.95;
//tracks[5].out_radius = 1.00;

tracks[1].plot_type   = 31;    //
tracks[1].window_size = default_window_size;

tracks[2].plot_type   = 21;    //
tracks[2].window_size = default_window_size;

tracks[3].plot_type   = 11;    //
tracks[3].window_size = default_window_size;

tracks[4].plot_type   = 15;    //
tracks[4].window_size = default_window_size;
/*************************
//tracks[0].in_radius  = 0.0;
//tracks[0].out_radius = 0.7;
//tracks[1].in_radius  = 0.7;
//tracks[1].out_radius = 0.75;
//tracks[2].in_radius  = 0.75;
//tracks[2].out_radius = 0.8;
//tracks[3].in_radius  = 0.8;
//tracks[3].out_radius = 0.95;
//tracks[4].in_radius  = 0.95;
//tracks[4].out_radius = 1.00;

////tracks[5].in_radius  = 0.95;
////tracks[5].out_radius = 1.00;

//tracks[1].plot_type   = 11;    //
//tracks[1].window_size = default_window_size;
//
//tracks[2].plot_type   = 15;    //
//tracks[2].window_size = default_window_size;
//
//tracks[3].plot_type   = 21;    //
//tracks[3].window_size = default_window_size;
//
//tracks[4].plot_type   = 31;    //
//tracks[4].window_size = default_window_size;
*************************/
//tracks[5].plot_type   = 31;    //  �W�����N�V���������̕��z
//tracks[5].window_size = default_window_size;
////////////////////////////////////////////////////////////////////////////// ���̓t�@�C���ǂݍ���
if(!(infile = fopen(arg1,"r")))
 {
 printf("Failed to open input file %s\n",arg1);
 exit(1);
 }
while(fgets(buff,512,infile))
 {
 n_links ++;
 }
printf("Number of Data is %d\n",n_links);

links = (link_info *)malloc(sizeof(link_info)*(n_links + 10));
if(links == NULL)
 {
 printf("Failed to allocate memory for links data\n");
 exit(1);
 }
 
rewind(infile);
for(i=0;i<n_links;i++)
 {
 fgets(buff,512,infile);
 links[i].header = buff[0];                                                                        // �e�s�P������
 links[i].from   = read_int(buff,2,11);                                                            // �����N��
 links[i].to     = read_int(buff,13,11);                                                           // �����N��
 links[i].n_read = read_int(buff,24,11);                                                           // ���[�h��
// printf("%c %10d %10d %10d\n",links[i].header,links[i].from,links[i].to,links[i].n_read);
 }
////////////////////////////////////////////////////////////////////////////// ���̓t�@�C���ǂݍ���

//sprintf(psout_flnm,"%s_%d.ps",arg1,draw_method);  // include draw_method in output ps filename
sprintf(psout_flnm,"%s.ps",arg1);
if(!(psfile = fopen(psout_flnm,"w")))
 {
 printf("Failed to open output ps file: %s\n",psout_flnm);
 exit(1);
 }
//////////////////////////////////////////////////////////////////////////////  PS OUT PREPARATION //�|�X�g�X�N���v�g�o�͏��� MARKP
time_t timeval;
char datestamp[80];
strcpy(datestamp,ctime(&timeval));
strcpy(buff,"%!PS-Adobe-"); fprintf(psfile,"%s\n",buff);                                                       // Global Header
strcpy(buff,"%%Creator: "); fprintf(psfile,"%s%s\n",buff,getenv("USER"));                                      // Global Header
strcpy(buff,"%%CreationDate: "); fprintf(psfile,"%s%s",buff,datestamp);                                        // Global Header
strcpy(buff,"%%DocumentFonts: (atend)"); fprintf(psfile,"%s\n",buff);                                          // Global Header
strcpy(buff,"%%Pages: (atend)"); fprintf(psfile,"%s\n",buff);                                                  // Global Header
strcpy(buff,"%%EndComments"); fprintf(psfile,"%s\n",buff);                                                     // Global Header
strcpy(buff,"/mv {moveto} def"); fprintf(psfile,"%s\n",buff);                                                  // Global Header
strcpy(buff,"%%EndProlog"); fprintf(psfile,"%s\n",buff);                                                       // Global Header
strcpy(buff,"<< /PageSize [595 842]"); fprintf(psfile,"%s\n",buff);                                           // A4
strcpy(buff,"   /Policies << /PageSize 6 >>"); fprintf(psfile,"%s\n",buff);                                    // A4
strcpy(buff,">> setpagedevice"); fprintf(psfile,"%s\n",buff);                                                  // A4
/////////////////////////////////////////////////////////////////////////////////////////  ^ HEADER
strcpy(buff,"%%Page: "); fprintf(psfile,"%s%d\n",buff,1);                                                     // Page Header 1
strcpy(buff,"<< /PageSize [595 842]"); fprintf(psfile,"%s\n",buff);                                           // A4
strcpy(buff,"   /Policies << /PageSize 6 >>"); fprintf(psfile,"%s\n",buff);                                   // A4
strcpy(buff,">> setpagedevice"); fprintf(psfile,"%s\n",buff);                                                 // A4
strcpy(buff,"/pg save def"); fprintf(psfile,"%s\n",buff);                                                     // Page Header 1
sprintf(buff,"/Courier-Bold findfont %5.2f scalefont setfont",ps_font_size); fprintf(psfile,"%s\n",buff);     // Page Header 1
/////////////////////////////////////////////////////////////////////////////////////////  ^ PAGE HEADER


fprintf(psfile,"newpath\n");
fprintf(psfile,"297 421 translate\n");                           // Center of Circle  ���S�_�Ɉړ�


if((draw_method == 5) || (draw_method == 6))     // �w�i�F  bg_color  mark
 {
 for(i=4;i>0;i--)
  {
  tracks[i].track_width      = tracks[i].out_radius - tracks[i].in_radius;
  tracks[i].track_true_width = tracks[i].track_width  * (1.0-(2.0*track_margin));
  fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*(tracks[i].out_radius-(track_margin * tracks[i].track_width))); // �g���b�N�O��
  fprintf(psfile,"%f %f %f setrgbcolor\n",tracks[i].bg_color_r,tracks[i].bg_color_g,tracks[i].bg_color_b);
  fprintf(psfile,"fill\n");

  fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*(tracks[i].in_radius+(track_margin * tracks[i].track_width)));  // �g���b�N����
  fprintf(psfile,"0 0 0 setrgbcolor\n");
  fprintf(psfile,"stroke\n");
  }
 }
fprintf(psfile,"0 0 0 setrgbcolor\n");
///////////////////////////////////////////////// �g���b�N�w�i�F

//////////////////////////////////////////////////////////////// Draw circle for plus direction  �v���X�����~�`��
if((draw_method == 5) || (draw_method == 6))     // method5�ł͊O���̂Q�̂�
 {
 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_d5out);
 fprintf(psfile,"  %f  setlinewidth\n",width_circle);
 fprintf(psfile,"stroke\n");
 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_d5in);
 fprintf(psfile,"  %f  setlinewidth\n",width_circle);
 fprintf(psfile,"stroke\n");
 }
else
 {
 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_plus);
 fprintf(psfile,"  %f  setlinewidth\n",width_circle);
 fprintf(psfile,"stroke\n");
 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_plus2);
 fprintf(psfile,"  %f  setlinewidth\n",width_circle);
 fprintf(psfile,"stroke\n");

 //////////////////////////////////////////////////////////////// Draw circle for minus direction �}�C�i�X�����~�`��
 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_minus);
 fprintf(psfile,"  %f  setlinewidth\n",width_circle*2);
 fprintf(psfile,"stroke\n");
 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_minus2);
 fprintf(psfile,"  %f  setlinewidth\n",width_circle*2);
 fprintf(psfile,"stroke\n");
 
 if((draw_method == 3) || (draw_method == 4))
  {
  //////////////////////////////////////////////////////////////// Draw inside circle  �����~�`��
  fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_inside);
  fprintf(psfile,"  %f  setlinewidth\n",width_circle);
  fprintf(psfile,"stroke\n");
  fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*circos_scale*radius_inside2);
  fprintf(psfile,"  %f  setlinewidth\n",width_circle);
  fprintf(psfile,"stroke\n");
  }
 }

//////////////////////////////////////////////////////////////// v Draw Tics �ڐ���`��
fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*scale_radius);
fprintf(psfile,"  %f  setlinewidth\n",width_circle);
fprintf(psfile,"stroke\n");

for(i=0;i<genome_length/tic_interval;i++)                     // ������
 {
 angle = 2.0 * PI * (double)(tic_interval * i) / (double)genome_length;
 startx = sin(angle) * max_radius * scale_radius;
 starty = cos(angle) * max_radius * scale_radius;
 endx   = sin(angle) * (max_radius - tic_height) * scale_radius;
 endy   = cos(angle) * (max_radius - tic_height) * scale_radius;
 fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
 fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
 fprintf(psfile,"  %f  setlinewidth\n",tic_width);
 fprintf(psfile,"stroke\n");
 }

for(i=0;i<genome_length/ttic_interval;i++)                    // �协��
 {
 angle = 2.0 * PI * (double)(ttic_interval * i) / (double)genome_length;
 startx = sin(angle) * max_radius * scale_radius;
 starty = cos(angle) * max_radius * scale_radius;
 endx   = sin(angle) * (max_radius - ttic_height) * scale_radius;
 endy   = cos(angle) * (max_radius - ttic_height) * scale_radius;
 fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
 fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
 fprintf(psfile,"  %f  setlinewidth\n",ttic_width);
 fprintf(psfile,"stroke\n");

 if(i*(int)ttic_interval == 0)
  {shift_len = font_size * 0.7 * scale_radius;}
 else
  {shift_len = ((double)((int)log10(i*(int)ttic_interval)) * font_size * 0.7 * scale_radius);}
 shift_angle = angle - (PI/2.0);
 shiftx = sin(shift_angle) * shift_len;
 shifty = cos(shift_angle) * shift_len;

 startx = sin(angle) * max_radius * scale_radius * caption_scale;
 starty = cos(angle) * max_radius * scale_radius * caption_scale;
 fprintf(psfile,"gsave\n");
// fprintf(psfile," %f %f translate\n",startx*shiftx,starty*shifty);                               // �ڐ���̐��l
 fprintf(psfile," %f %f translate\n",startx,starty);                               // �ڐ���̐��l
 fprintf(psfile," %f rotate\n",(angle * ((-180.0)/PI)));
 fprintf(psfile," 0 0  moveto\n");
// fprintf(psfile," %f %f  moveto\n",shiftx,shifty);
 fprintf(psfile,"(%d) show\n",i*(int)ttic_interval);
 fprintf(psfile,"stroke\n");
 fprintf(psfile,"grestore\n");
 }
//////////////////////////////////////////////////////////////// ^ Draw Tics �ڐ���`��

//////////////////////////////////////////////////////////////// v Draw links �����N�`��
for(i=0;i<n_links;i++)
 {
 startangle = 2.0 * PI * ((double)abs(links[i].from) / (double)genome_length);
 endangle   = 2.0 * PI * ((double)abs(links[i].to)   / (double)genome_length);
 if(startangle > 2.0*PI) startangle = startangle - 2.0*PI;
 if(endangle   > 2.0*PI) endangle   = endangle   - 2.0*PI;

 if(links[i].n_read != 0)
  {
  link_width = base_link_width * log10((double)links[i].n_read);
  }
 else
  {
  continue;            // ���[�h���O�̃����N�͕`���Ȃ�
  }
 /////////////////////////////////////////////////////////////////////// v ���_�p�ƂȂ��p�̌v�Z
 if(endangle > startangle)            // �I�[�p���n�_�p���傫�����
  {
  if((endangle - startangle) < PI)    // �I�[�p-�n�_�p��180�x��菬�������
   {
   midangle    = (startangle + endangle)/2.0;
   formangle   =  endangle - startangle;
   }
  else                                // �I�[�p-�n�_�p��180�x���傫�����
   {
   midangle    = ((2.0*PI) + startangle + endangle)/2.0;
   formangle   = (2.0*PI) + startangle - endangle;
   }
  }
 else
  {
  if((startangle - endangle) < PI)
   {
   midangle    = (endangle + startangle)/2.0;
   formangle   =  startangle - endangle;
   }
  else
   {
   midangle    = ((2.0*PI) + endangle + startangle)/2.0;
   formangle   =  (2.0*PI) + endangle - startangle;
   }
  }
 if(midangle > 2.0*PI)    midangle = midangle - 2.0*PI;
 if(formangle   > 2.0*PI) formangle   = formangle   - 2.0*PI;
 /////////////////////////////////////////////////////////////////////// ^ ���_�p�ƂȂ��p�̌v�Z
 radius_anchor = (1.0 -(formangle/PI)) * max_radius_anchor;

 if((draw_method == 3) || (draw_method == 4))
  {
  if(formangle < ((PI / 180.0) * thresh_angle))            // Thresh_angle�x�ȓ��Ȃ璆����O
   {
   /////////////////////////////////////////////////////////////////////// v �n�_�̌v�Z
   if(links[i].from > 0)
    {
    startx = sin(startangle) * radius_minus * circos_scale * max_radius;
    starty = cos(startangle) * radius_minus * circos_scale * max_radius;
    radius_zero = (radius_plus + radius_minus) / 2.0;
  
    a1x = sin(startangle) * radius_zero * circos_scale * max_radius;
    a1y = cos(startangle) * radius_zero * circos_scale * max_radius;
    }
   else
    {
    startx = sin(startangle) * radius_minus2 * circos_scale * max_radius;
    starty = cos(startangle) * radius_minus2 * circos_scale * max_radius;
    radius_zero = (radius_plus + radius_minus) / 2.0;
  
    a1x = sin(startangle) * radius_zero * circos_scale * max_radius;
    a1y = cos(startangle) * radius_zero * circos_scale * max_radius;
    }
   /////////////////////////////////////////////////////////////////////// ^ �n�_�̌v�Z
  
   /////////////////////////////////////////////////////////////////////// v �I�_�̌v�Z
   if(draw_method == 3)
    {
    if(links[i].to > 0)
     {
     endx = sin(endangle) * radius_plus2 * circos_scale * max_radius;
     endy = cos(endangle) * radius_plus2 * circos_scale * max_radius;
  
     a2x = sin(endangle) * radius_zero * circos_scale * max_radius;
     a2y = cos(endangle) * radius_zero * circos_scale * max_radius;
     }
    else
     {
     endx = sin(endangle) * radius_plus * circos_scale * max_radius;
     endy = cos(endangle) * radius_plus * circos_scale * max_radius;
  
     a2x = sin(endangle) * radius_zero * circos_scale * max_radius;
     a2y = cos(endangle) * radius_zero * circos_scale * max_radius;
     }
    }
   else
   if(draw_method == 4)
    {
    if(links[i].to > 0)
     {
     endx = sin(endangle) * radius_plus * circos_scale * max_radius;
     endy = cos(endangle) * radius_plus * circos_scale * max_radius;
  
     a2x = sin(endangle) * radius_zero * circos_scale * max_radius;
     a2y = cos(endangle) * radius_zero * circos_scale * max_radius;
     }
    else
     {
     endx = sin(endangle) * radius_plus2 * circos_scale * max_radius;
     endy = cos(endangle) * radius_plus2 * circos_scale * max_radius;
  
     a2x = sin(endangle) * radius_zero * circos_scale * max_radius;
     a2y = cos(endangle) * radius_zero * circos_scale * max_radius;
     }
    }
   /////////////////////////////////////////////////////////////////////// ^ �I�_�̌v�Z
  
   //////////////////////////////////////////////////////// v �����N�����o��   �����^
    fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �n�_  x,y
    fprintf(psfile,"  %f %f %f %f %f %f curveto\n",a1x,a1y,a2x,a2y,endx,endy);        // �I�_  x,y
    fprintf(psfile,"  %f  setlinewidth\n",link_width);
    fprintf(psfile,"stroke\n");
   //////////////////////////////////////////////////////// ^ �����N�����o��   �����^
   }
  else
   {
   /////////////////////////////////////////////////////////////////////// v �n�_�̌v�Z
   if(links[i].from > 0)
    {
    startx = sin(startangle) * radius_minus * circos_scale * max_radius;
    starty = cos(startangle) * radius_minus * circos_scale * max_radius;
    radius_zero = (radius_inside + radius_minus) / 2.0;
    }
   else
    {
    startx = sin(startangle) * radius_minus2 * circos_scale * max_radius;
    starty = cos(startangle) * radius_minus2 * circos_scale * max_radius;
    radius_zero = (radius_inside + radius_minus) / 2.0;
    }
   /////////////////////////////////////////////////////////////////////// ^ �n�_�̌v�Z
  
   /////////////////////////////////////////////////////////////////////// v �A���J�[�_�̌v�Z
    anchorx = sin(midangle) * radius_anchor * circos_scale * max_radius;
    anchory = cos(midangle) * radius_anchor * circos_scale * max_radius;
   /////////////////////////////////////////////////////////////////////// ^ �A���J�[�_�̌v�Z
  
   /////////////////////////////////////////////////////////////////////// v �I�_�̌v�Z
   if(draw_method == 3)
    {
    if(links[i].to > 0)
     {
     endx = sin(endangle) * radius_inside2 * circos_scale * max_radius;
     endy = cos(endangle) * radius_inside2 * circos_scale * max_radius;
     }
    else
     {
     endx = sin(endangle) * radius_inside * circos_scale * max_radius;
     endy = cos(endangle) * radius_inside * circos_scale * max_radius;
     }
    }
   else
   if(draw_method == 4)
    {
    if(links[i].to > 0)
     {
     endx = sin(endangle) * radius_inside * circos_scale * max_radius;
     endy = cos(endangle) * radius_inside * circos_scale * max_radius;
     }
    else
     {
     endx = sin(endangle) * radius_inside2 * circos_scale * max_radius;
     endy = cos(endangle) * radius_inside2 * circos_scale * max_radius;
     }
    }
    
   /////////////////////////////////////////////////////////////////////// ^ �I�_�̌v�Z
  
   //////////////////////////////////////////////////////// v �����N�����o��   ���[�v�����N�^
   fprintf(psfile,"  %f %f moveto\n",startx,starty);                                            // �n�_  x,y
   fprintf(psfile,"  %f %f %f %f %f %f curveto\n",anchorx,anchory,anchorx,anchory,endx,endy);   // �A���J�[�|�C���gx,y ��ӏ��@�Ɓ@�I�_ x,y
   fprintf(psfile,"  %f  setlinewidth\n",link_width);
   fprintf(psfile,"stroke\n");
   //////////////////////////////////////////////////////// ^ �����N�����o��   ���[�v�����N�^
   }
  
  //////////////////////////////////////////////////////// v �|�C���g�����o��
  if(links[i].from > 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                              // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else 
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                              // �n�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
 
  if(draw_method == 3)
   {
   if(links[i].to > 0)
    {
    fprintf(psfile,"gsave\n");
    fprintf(psfile,"  %f %f translate\n",endx,endy);                                  // �I�_  x,y  ���� 
    fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
    fprintf(psfile,"1.0 setgray\n");
    fprintf(psfile,"fill\n");
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
    fprintf(psfile,"0.0 setgray\n");
    fprintf(psfile,"  %f  setlinewidth\n",point_width);
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"grestore\n");
    }
   else
    {
    fprintf(psfile,"gsave\n");
    fprintf(psfile,"  %f %f translate\n",endx,endy);                                 // �I�_  x,y  ����
    fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
    fprintf(psfile,"fill\n");
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"grestore\n");
    }
   }
  else
  if(draw_method == 4)
   {
   if(links[i].to < 0)
    {
    fprintf(psfile,"gsave\n");
    fprintf(psfile,"  %f %f translate\n",endx,endy);                                  // �I�_  x,y  ���� 
    fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
    fprintf(psfile,"1.0 setgray\n");
    fprintf(psfile,"fill\n");
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
    fprintf(psfile,"0.0 setgray\n");
    fprintf(psfile,"  %f  setlinewidth\n",point_width);
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"grestore\n");
    }
   else
    {
    fprintf(psfile,"gsave\n");
    fprintf(psfile,"  %f %f translate\n",endx,endy);                                 // �I�_  x,y  ����
    fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
    fprintf(psfile,"fill\n");
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"grestore\n");
    }
   }
   
  //////////////////////////////////////////////////////// ^ �|�C���g�����o��
  }

 if(draw_method == 2)
  {
  /////////////////////////////////////////////////////////////////////// v �n�_�̌v�Z
//  startx = cos(startangle) * radius_plus * circos_scale * max_radius;
//  starty = sin(startangle) * radius_plus * circos_scale * max_radius;
  startx = sin(startangle) * radius_plus * circos_scale * max_radius;
  starty = cos(startangle) * radius_plus * circos_scale * max_radius;
  radius_zero = (radius_plus + radius_minus) / 2.0;

  a1x = sin(startangle) * radius_zero * circos_scale * max_radius;
  a1y = cos(startangle) * radius_zero * circos_scale * max_radius;
  /////////////////////////////////////////////////////////////////////// ^ �n�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �A���J�[�_�̌v�Z
//  anchorx = cos(midangle) * radius_anchor * circos_scale * max_radius;
//  anchory = sin(midangle) * radius_anchor * circos_scale * max_radius;
  anchorx = sin(midangle) * radius_anchor * circos_scale * max_radius;
  anchory = cos(midangle) * radius_anchor * circos_scale * max_radius;
  /////////////////////////////////////////////////////////////////////// ^ �A���J�[�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �I�_�̌v�Z
//  endx = cos(endangle) * radius_minus * circos_scale * max_radius;
//  endy = sin(endangle) * radius_minus * circos_scale * max_radius;
  endx = sin(endangle) * radius_minus * circos_scale * max_radius;
  endy = cos(endangle) * radius_minus * circos_scale * max_radius;

  a2x = sin(endangle) * radius_zero * circos_scale * max_radius;
  a2y = cos(endangle) * radius_zero * circos_scale * max_radius;
  /////////////////////////////////////////////////////////////////////// ^ �I�_�̌v�Z
 
  //////////////////////////////////////////////////////// v �����N�����o��
  if(formangle < ((PI / 180.0) * thresh_angle))            // Thresh_angle�x�ȓ��Ȃ璼��
   {
   fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �n�_  x,y
//   fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �I�_  x,y
   fprintf(psfile,"  %f %f %f %f %f %f curveto\n",a1x,a1y,a2x,a2y,endx,endy);                                     // �I�_  x,y
   fprintf(psfile,"  %f  setlinewidth\n",link_width);
   fprintf(psfile,"stroke\n");
   }
  else                                            // Thresh_angle�x�ȏ�Ȃ烋�[�v�����N
   {
   fprintf(psfile,"  %f %f moveto\n",startx,starty);                                     // �n�_  x,y
   fprintf(psfile,"  %f %f %f %f %f %f curveto\n",anchorx,anchory,anchorx,anchory,endx,endy);   // �A���J�[�|�C���gx,y ��ӏ��@�Ɓ@�I�_ x,y
   fprintf(psfile,"  %f  setlinewidth\n",link_width);
   fprintf(psfile,"stroke\n");
   }
  //////////////////////////////////////////////////////// ^ �����N�����o��
 
  //////////////////////////////////////////////////////// v �|�C���g�����o��
  if(links[i].from > 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                                 // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else 
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                                     // �I�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
 
  if(links[i].to > 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",endx,endy);                                     // �I�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",endx,endy);                                 // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  //////////////////////////////////////////////////////// ^ �|�C���g�����o��
  }
 if(draw_method == 1)
  {
  /////////////////////////////////////////////////////////////////////// v �n�_�̌v�Z
  if(links[i].from > 0)
   {
//   startx = cos(startangle) * radius_plus * circos_scale * max_radius;
//   starty = sin(startangle) * radius_plus * circos_scale * max_radius;
   startx = sin(startangle) * radius_plus * circos_scale * max_radius;
   starty = cos(startangle) * radius_plus * circos_scale * max_radius;
   }
  else
   {
//   startx = cos(startangle) * radius_minus * circos_scale * max_radius;
//   starty = sin(startangle) * radius_minus * circos_scale * max_radius;
   startx = sin(startangle) * radius_minus * circos_scale * max_radius;
   starty = cos(startangle) * radius_minus * circos_scale * max_radius;
   }
  /////////////////////////////////////////////////////////////////////// ^ �n�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �A���J�[�_�̌v�Z
//  anchorx = cos(midangle) * radius_anchor * circos_scale * max_radius;
//  anchory = sin(midangle) * radius_anchor * circos_scale * max_radius;
  anchorx = sin(midangle) * radius_anchor * circos_scale * max_radius;
  anchory = cos(midangle) * radius_anchor * circos_scale * max_radius;
  /////////////////////////////////////////////////////////////////////// ^ �A���J�[�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �I�_�̌v�Z
  if(links[i].to > 0)
   {
//   endx = cos(endangle) * radius_minus * circos_scale * max_radius;
//   endy = sin(endangle) * radius_minus * circos_scale * max_radius;
   endx = sin(endangle) * radius_minus * circos_scale * max_radius;
   endy = cos(endangle) * radius_minus * circos_scale * max_radius;
   }
  else
   {
//   endx = cos(endangle) * radius_plus * circos_scale * max_radius;
//   endy = sin(endangle) * radius_plus * circos_scale * max_radius;
   endx = sin(endangle) * radius_plus * circos_scale * max_radius;
   endy = cos(endangle) * radius_plus * circos_scale * max_radius;
   }
  /////////////////////////////////////////////////////////////////////// ^ �I�_�̌v�Z
 
  //////////////////////////////////////////////////////// v �����N�����o��
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                     // �n�_  x,y
  fprintf(psfile,"  %f %f %f %f %f %f curveto\n",anchorx,anchory,anchorx,anchory,endx,endy);   // �A���J�[�|�C���gx,y ��ӏ��@�Ɓ@�I�_ x,y
  fprintf(psfile,"  %f  setlinewidth\n",link_width);
  fprintf(psfile,"stroke\n");
  //////////////////////////////////////////////////////// ^ �����N�����o��
 
  //////////////////////////////////////////////////////// v �|�C���g�����o��
  fprintf(psfile,"gsave\n");
  fprintf(psfile,"  %f %f translate\n",startx,starty);                                 // �n�_  x,y  ����
  fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
  fprintf(psfile,"fill\n");
  fprintf(psfile,"stroke\n");
  fprintf(psfile,"grestore\n");
 
  fprintf(psfile,"gsave\n");
  fprintf(psfile,"  %f %f translate\n",endx,endy);                                     // �I�_  x,y  ���� 
  fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
  fprintf(psfile,"1.0 setgray\n");
  fprintf(psfile,"fill\n");
  fprintf(psfile,"stroke\n");
  fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
  fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
  fprintf(psfile,"stroke\n");
  fprintf(psfile,"grestore\n");
  //////////////////////////////////////////////////////// ^ �|�C���g�����o��
  }

 if(draw_method == 5)     // �y�A�G���h   MARK
  {
//printf("HERE\n");
  /////////////////////////////////////////////////////////////////////// v �n�_�̌v�Z
  if(links[i].from > 0)
   {
   startx = sin(startangle) * radius_d5out * circos_scale * max_radius;
   starty = cos(startangle) * radius_d5out * circos_scale * max_radius;
   }
  else
   {
   startx = sin(startangle) * radius_d5in * circos_scale * max_radius;
   starty = cos(startangle) * radius_d5in * circos_scale * max_radius;
   }
  /////////////////////////////////////////////////////////////////////// ^ �n�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �A���J�[�_�̌v�Z
  anchorx = sin(midangle) * radius_anchor * circos_scale * max_radius;
  anchory = cos(midangle) * radius_anchor * circos_scale * max_radius;
  /////////////////////////////////////////////////////////////////////// ^ �A���J�[�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �I�_�̌v�Z
  if(links[i].to > 0)
   {
   endx = sin(endangle) * radius_d5out * circos_scale * max_radius;
   endy = cos(endangle) * radius_d5out * circos_scale * max_radius;
   }
  else
   {
   endx = sin(endangle) * radius_d5in * circos_scale * max_radius;
   endy = cos(endangle) * radius_d5in * circos_scale * max_radius;
   }
  /////////////////////////////////////////////////////////////////////// ^ �I�_�̌v�Z
 
  //////////////////////////////////////////////////////// v �����N�����o��
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                     // �n�_  x,y
  fprintf(psfile,"  %f %f %f %f %f %f curveto\n",anchorx,anchory,anchorx,anchory,endx,endy);   // �A���J�[�|�C���gx,y ��ӏ��@�Ɓ@�I�_ x,y
  fprintf(psfile,"  %f  setlinewidth\n",link_width);
  fprintf(psfile,"stroke\n");
  //////////////////////////////////////////////////////// ^ �����N�����o��
 
  //////////////////////////////////////////////////////// v �|�C���g�����o��
  if(links[i].from > 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                                 // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                                     // �I�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  if(links[i].to > 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",endx,endy);                                 // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",endx,endy);                                     // �I�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }   // MARK
  //////////////////////////////////////////////////////// ^ �|�C���g�����o��
  }

 if(draw_method == 6)     // �W�����N�V���������N
  if((links[i].header != 'D') && (links[i].header != 'I'))             // INDEL �ȊO  HR,PAL,UNK
  {
  /////////////////////////////////////////////////////////////////////// v �n�_�̌v�Z
  if(links[i].from > 0)
   {
   startx = sin(startangle) * radius_d5out * circos_scale * max_radius;
   starty = cos(startangle) * radius_d5out * circos_scale * max_radius;
   }
  else
   {
   startx = sin(startangle) * radius_d5in * circos_scale * max_radius;
   starty = cos(startangle) * radius_d5in * circos_scale * max_radius;
   }
  /////////////////////////////////////////////////////////////////////// ^ �n�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �A���J�[�_�̌v�Z
  anchorx = sin(midangle) * radius_anchor * circos_scale * max_radius;
  anchory = cos(midangle) * radius_anchor * circos_scale * max_radius;
  /////////////////////////////////////////////////////////////////////// ^ �A���J�[�_�̌v�Z
 
  /////////////////////////////////////////////////////////////////////// v �I�_�̌v�Z
  if(links[i].to > 0)
   {
   endx = sin(endangle) * radius_d5in * circos_scale * max_radius;
   endy = cos(endangle) * radius_d5in * circos_scale * max_radius;
   }
  else
   {
   endx = sin(endangle) * radius_d5out * circos_scale * max_radius;
   endy = cos(endangle) * radius_d5out * circos_scale * max_radius;
   }
  /////////////////////////////////////////////////////////////////////// ^ �I�_�̌v�Z
 
  //////////////////////////////////////////////////////// v �����N�����o��
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                     // �n�_  x,y
  fprintf(psfile,"  %f %f %f %f %f %f curveto\n",anchorx,anchory,anchorx,anchory,endx,endy);   // �A���J�[�|�C���gx,y ��ӏ��@�Ɓ@�I�_ x,y
  fprintf(psfile,"  %f  setlinewidth\n",link_width);
  fprintf(psfile,"stroke\n");
  //////////////////////////////////////////////////////// ^ �����N�����o��
 
  //////////////////////////////////////////////////////// v �|�C���g�����o��
  if(links[i].from > 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                                 // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",startx,starty);                                     // �I�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  if(links[i].to < 0)
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",endx,endy);                                 // �n�_  x,y  ����
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }
  else
   {
   fprintf(psfile,"gsave\n");
   fprintf(psfile,"  %f %f translate\n",endx,endy);                                     // �I�_  x,y  ���� 
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"1.0 setgray\n");
   fprintf(psfile,"fill\n");
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"0 0 %f 0 360 arc\n",point_radius*circos_scale);
   fprintf(psfile,"0.0 setgray\n");
   fprintf(psfile,"  %f  setlinewidth\n",point_width);
   fprintf(psfile,"stroke\n");
   fprintf(psfile,"grestore\n");
   }   // MARK
  //////////////////////////////////////////////////////// ^ �|�C���g�����o��
  }

 }
//////////////////////////////////////////////////////////////// ^ Draw links �����N�`��

for(i=1;i<=n_track;i++)
 {
 tracks[i].track_width      = tracks[i].out_radius - tracks[i].in_radius;
 tracks[i].track_true_width = tracks[i].track_width  * (1.0-(2.0*track_margin));

 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*(tracks[i].in_radius+(track_margin * tracks[i].track_width)));  // �g���b�N����
 fprintf(psfile,"  %f  setlinewidth\n",track_boundary_width);
 fprintf(psfile,"stroke\n");

 if(tracks[i].plot_type == 11)
  {
  plot_gc_contents(i);
  }
 if(tracks[i].plot_type == 12)
  {
  plot_gc_skew(i);
  }
 if(tracks[i].plot_type == 15)
  {
  plot_genes(i);
  }
 if(tracks[i].plot_type == 21)
  {
  if(read_peb_flag == 1)
   {
   plot_population(i);
   }
  }
 if(tracks[i].plot_type == 31)
  {
  plot_rearrange_direction(i);
  }

 fprintf(psfile,"  0   0  %f    0 360 arc\n",max_radius*(tracks[i].out_radius-(track_margin * tracks[i].track_width))); // �g���b�N�O��
 fprintf(psfile,"  %f  setlinewidth\n",track_boundary_width);
 fprintf(psfile,"stroke\n");
 }

////////////////////////////////////////////////////////�`��e�X�g�p�~�ƌ�
//fprintf(psfile,"  0   0  250    0 360 arc\n");         // �傫�ȉ~�@���a250 0~360�x
//fprintf(psfile,"  0   250 moveto\n");                  // �n�_  x,y
//fprintf(psfile,"  0   0    0    0 250 0 curveto\n");   // �A���J�[�|�C���gx,y ��ӏ��@�Ɓ@�I�_ x,y
////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////  v PAGE FOOTER
strcpy(buff,"showpage pg restore"); fprintf(psfile,"%s\n",buff);                                              // Page Footer 1
/////////////////////////////////////////////////////////////////////////////////////////  v FOOTER
strcpy(buff,"%%Trailer"); fprintf(psfile,"%s\n",buff);                                                         // Global Footer
strcpy(buff,"%%DocumentFonts: Courier Courier-Bold"); fprintf(psfile,"%s\n",buff);                             // Global Footer
strcpy(buff,"%%Pages: "); fprintf(psfile,"%s%d\n",buff,1);                                                // Global Footer
fclose(psfile);
/////////////////////////////////////////////////////////////////////////////////////////  FOOTER 
////////////////////////////////////////////////////// c_ps_outfile  Cyclic postscript output in One page END
}

void plot_rearrange_direction(int track_id)   // �y�A�G���h�̌����̒~��
 {
 int i,j,k;
 int num_iterations;
 int range_from;
 int range_to;
 int balance;
 int max_balance = 0;
 double balance_ratio;

 num_iterations = genome_length/tracks[track_id].window_size;

 for(i=0;i<num_iterations;i++)
  {
  range_from =     i*tracks[track_id].window_size;
  range_to   = (i+1)*tracks[track_id].window_size;
  balance = 0;
  for(j=0;j<n_links;j++)
   {
   if((abs(links[j].from) > range_from) && (abs(links[j].from) < range_to))
    {
    if(links[j].from > 0)
     {
     if(paired_end == 1)
      balance = balance + links[j].n_read;
     else
      balance = balance + links[j].n_read;
     }
    else
     {
     if(paired_end == 1)
      balance = balance - links[j].n_read;
     else
      balance = balance - links[j].n_read;
     }
    }

   if((abs(links[j].to) > range_from) && (abs(links[j].to) < range_to))
    {
    if(links[j].to > 0)
     {
     if(paired_end == 1)
      balance = balance + links[j].n_read;
     else
      balance = balance - links[j].n_read;
     }
    else
     {
     if(paired_end == 1)
      balance = balance - links[j].n_read;
     else
      balance = balance + links[j].n_read;
     }
    }
   }
  if(abs(balance) > max_balance)
   max_balance = abs(balance);
  }
 if(max_balance == 0)
  max_balance = 1;

 for(i=0;i<num_iterations;i++)
  {
  range_from =     i*tracks[track_id].window_size;
  range_to   = (i+1)*tracks[track_id].window_size;
  balance = 0;
  for(j=0;j<n_links;j++)
   {
   if((abs(links[j].from) > range_from) && (abs(links[j].from) < range_to))
    {
    if(links[j].from > 0)
     {
     if(paired_end == 1)
      balance = balance + links[j].n_read;
     else
      balance = balance + links[j].n_read;
     }
    else
     {
     if(paired_end == 1)
      balance = balance - links[j].n_read;
     else
      balance = balance - links[j].n_read;
     }
    }

   if((abs(links[j].to) > range_from) && (abs(links[j].to) < range_to))
    {
    if(links[j].to > 0)
     {
     if(paired_end == 1)
      balance = balance + links[j].n_read;
     else
      balance = balance - links[j].n_read;
     }
    else
     {
     if(paired_end == 1)
      balance = balance - links[j].n_read;
     else
      balance = balance + links[j].n_read;
     }
    }
   }

//  balance_ratio = (double)balance / ((double)max_balance * 2.0);

  if(balance == 0)
   continue;
  else
   {
   if(balance > 0)
    balance_ratio = (log10((double)balance)) / (log10((double)max_balance)*2.0);
   else
    balance_ratio = -(log10((double)abs(balance))) / (log10((double)max_balance)*2.0);
   }

//  printf("balance_ratio %10.3f balance %d max_balance %d balance_scale %10.3f\n",balance_ratio,balance,max_balance,balance_scale);
  //if(paired_end == 1)
  balance_ratio = balance_ratio * balance_scale;

  if(balance_ratio > 0.5)   // 0.5���傫���Ȃ�Ȃ��悤��
   balance_ratio = 0.5;
  if(balance_ratio < -0.5)  //-0.5��菬�����Ȃ�Ȃ��悤��
   balance_ratio = -0.5;

  angle = 2.0 * PI * (double)(tracks[track_id].window_size * i) / (double)genome_length;
 //printf("%10d %10d %10d %10d %10d %5d %8.2f\n",n_links,max_balance,range_from,range_to,i*tracks[track_id].window_size,balance,balance_ratio);
  startx = sin(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width));
  starty = cos(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width));
  endx   = sin(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width) 
                                                                 - (tracks[track_id].track_true_width * balance_ratio));
  endy   = cos(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width)
                                                                 - (tracks[track_id].track_true_width * balance_ratio));
//  endx   = sin(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width) 
//                                                                 + (tracks[track_id].track_true_width * balance_ratio));
//  endy   = cos(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width)
//                                                                 + (tracks[track_id].track_true_width * balance_ratio));
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
  fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
  fprintf(psfile,"  %f  setlinewidth\n",gc_width);
  if(balance_ratio > 0.0)
   fprintf(psfile,"1.0 0.4 0.4 setrgbcolor\n");      // ��
  else
   fprintf(psfile,"0.4 0.4 1.0 setrgbcolor\n");      // ��
  fprintf(psfile,"stroke\n");
  fprintf(psfile,"0 0 0 setrgbcolor\n");       // ��
  }

 }

void plot_gc_contents(int track_id)  // GC�R���e���c�̃v���b�g
 {
 int i,j,k;
 FILE *infile;
 char buff[BUFLEN];
 char c;
 int num_iterations = 0;
 int na,nt,ng,nc;
 int nbase;
 double gc_ratio;
 double mid_radius;

 mid_radius = (tracks[track_id].in_radius + tracks[track_id].out_radius)/2.0;

 num_iterations = genome_length/tracks[track_id].window_size;
 printf("NUM_ITERATIONS %d\n",num_iterations);

 for(i=0;i<num_iterations;i++)
  {
  nbase = 0;
  na = 0; nt = 0; ng = 0; nc = 0;
  for(j=0;j<tracks[track_id].window_size;j++)
   {
   c = seq[i*tracks[track_id].window_size+j];
   if(c == 'A') {na ++; nbase ++;}
   if(c == 'T') {nt ++; nbase ++;}
   if(c == 'G') {ng ++; nbase ++;}
   if(c == 'C') {nc ++; nbase ++;}
   }
  gc_ratio = (double)(ng+nc)/(double)nbase;
 
  angle = 2.0 * PI * (double)(tracks[track_id].window_size * i) / (double)genome_length;

  //printf("%6d %3d %3d %3d %3d %3d %8.4f %8.2f\n",i*tracks[track_id].window_size,na,nt,ng,nc,nbase,angle,gc_ratio);

//  startx = sin(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width));   //MARK
//  starty = cos(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width));   //MARK

  startx = sin(angle) * max_radius * (mid_radius + (track_margin * tracks[track_id].track_width));   // modified Feb14 2018
  starty = cos(angle) * max_radius * (mid_radius + (track_margin * tracks[track_id].track_width));   //

  endx   = sin(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width) 
                                                                 + (tracks[track_id].track_true_width * gc_ratio));
  endy   = cos(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width)
                                                                 + (tracks[track_id].track_true_width * gc_ratio));
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
  fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
  fprintf(psfile,"  %f  setlinewidth\n",gc_width);

  if(gc_ratio > 0.5)
   fprintf(psfile,"0.2 0.8 1.0 setrgbcolor\n");      // GC rich ��
  else
   fprintf(psfile,"1.0 0.7 1.0 setrgbcolor\n");      // AT rich �}�[���^

  fprintf(psfile,"stroke\n");
 
  fprintf(psfile,"0 0 0 setrgbcolor\n");       // ���ɖ߂�
  }
 //printf("%s\n",seq);
 }                                // GC�R���e���c�̃v���b�g

/***************************
void plot_gc_contents(int track_id)  // GC�R���e���c�̃v���b�g
 {
 int i,j,k;
 FILE *infile;
 char buff[BUFLEN];
 char c;
 int num_iterations = 0;
 int na,nt,ng,nc;
 int nbase;
 double gc_ratio;
 double mid_radius;

 mid_radius = (tracks[track_id].in_radius + tracks[track_id].out_radius)/2.0;

 num_iterations = genome_length/tracks[track_id].window_size;
 printf("NUM_ITERATIONS %d\n",num_iterations);

 for(i=0;i<num_iterations;i++)
  {
  nbase = 0;
  na = 0; nt = 0; ng = 0; nc = 0;
  for(j=0;j<tracks[track_id].window_size;j++)
   {
   c = seq[i*tracks[track_id].window_size+j];
   if(c == 'A') {na ++; nbase ++;}
   if(c == 'T') {nt ++; nbase ++;}
   if(c == 'G') {ng ++; nbase ++;}
   if(c == 'C') {nc ++; nbase ++;}
   }
  gc_ratio = (double)(ng+nc)/(double)nbase;
 
  angle = 2.0 * PI * (double)(tracks[track_id].window_size * i) / (double)genome_length;

  //printf("%6d %3d %3d %3d %3d %3d %8.4f %8.2f\n",i*tracks[track_id].window_size,na,nt,ng,nc,nbase,angle,gc_ratio);

  startx = sin(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width));   //MARK
  starty = cos(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width));   //MARK

//  startx = sin(angle) * max_radius * (mid_radius + (track_margin * tracks[track_id].track_width));   // modified Feb14 2018
//  starty = cos(angle) * max_radius * (mid_radius + (track_margin * tracks[track_id].track_width));   //

  endx   = sin(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width) 
                                                                 + (tracks[track_id].track_true_width * gc_ratio));
  endy   = cos(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width)
                                                                 + (tracks[track_id].track_true_width * gc_ratio));
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
  fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
  fprintf(psfile,"  %f  setlinewidth\n",gc_width);
  fprintf(psfile,"stroke\n");
  }
 //printf("%s\n",seq);
 }                                // GC�R���e���c�̃v���b�g
***************************/

void plot_gc_skew(int track_id)   // GC �X�L���[�̃v���b�g
 {
 int i,j,k;
 FILE *infile;
 char buff[BUFLEN];
 char c;
 int num_iterations = 0;
 int na,nt,ng,nc;
 int nbase;
 double gc_skew;

 num_iterations = genome_length/tracks[track_id].window_size;
 printf("NUM_ITERATIONS %d\n",num_iterations);

 for(i=0;i<num_iterations;i++)
  {

  nbase = 0;
  na = 0; nt = 0; ng = 0; nc = 0;
  for(j=0;j<tracks[track_id].window_size;j++)
   {
   c = seq[i*tracks[track_id].window_size+j];
   if(c == 'A') {na ++; nbase ++;}
   if(c == 'T') {nt ++; nbase ++;}
   if(c == 'G') {ng ++; nbase ++;}
   if(c == 'C') {nc ++; nbase ++;}
   }
  gc_skew = (double)(nc-ng)/(double)(nc+ng);
  gc_skew = gc_skew * 0.5;                      // �X�L���[�@������

  angle = 2.0 * PI * (double)(tracks[track_id].window_size * i) / (double)genome_length;
 // printf("%6d %3d %3d %3d %3d %3d %8.4f %8.2f\n",i*tracks[track_id].window_size,na,nt,ng,nc,nbase,angle,gc_ratio);
  startx = sin(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width));
  starty = cos(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width));
  endx   = sin(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width) 
                                                                 + (tracks[track_id].track_true_width * gc_skew));
  endy   = cos(angle) * max_radius * (tracks[track_id].in_radius + (0.5 * tracks[track_id].track_width)
                                                                 + (tracks[track_id].track_true_width * gc_skew));
  fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
  fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
  fprintf(psfile,"  %f  setlinewidth\n",gc_width);
  fprintf(psfile,"stroke\n");
  }
 }                                 // GC �X�L���[�̃v���b�g

void plot_genes(int track_id)      // ��`�q�ʒu�i�����j�̃v���b�g
 {
 int i,j;
 double angle_from;
 double angle_to;
 double radius;

 for(i=0;i<n_gene;i++)
  {
  for(j=0;j<genes[i].n_segments;j++)
   {
   if((genes[i].gene_segments[j].from <= genome_length) && (genes[i].gene_segments[j].to <= genome_length))
    {
    //printf("%2d %6d %6d\n",genes[i].gene_segments[j].direction,genes[i].gene_segments[j].from,genes[i].gene_segments[j].to);

    angle_to = 90.0 - (360.0 * (double)genes[i].gene_segments[j].from / (double)genome_length); 
    angle_from   = 90.0 - (360.0 * (double)genes[i].gene_segments[j].to   / (double)genome_length); 
    radius     = max_radius * (tracks[track_id].in_radius + (tracks[track_id].track_width/2.0) + (genes[i].gene_segments[j].direction * 0.007));

    fprintf(psfile,"  0   0  %f %f %f arc\n",radius,angle_from,angle_to);
    fprintf(psfile,"  %f  setlinewidth\n",width_gene);
    if(genes[i].gene_segments[j].direction == -1)
     fprintf(psfile,"0.96 0.675 0.234 setrgbcolor\n");      // �I�����W R246 F6 AD 3C  246 173 60
     //fprintf(psfile,"1.0 0.4 0.4 setrgbcolor\n");      // ��
    else
     fprintf(psfile,"0.523 0.719 0.105 setrgbcolor\n");      // �O���[�� R134 86 B8 1B  134 184 27
     //fprintf(psfile,"0.4 0.4 1.0 setrgbcolor\n");      // ��
    fprintf(psfile,"stroke\n");
    fprintf(psfile,"0 0 0 setrgbcolor\n");
    }
   }
  }
 }

void plot_population(int track_id)
{
int i,j;
int fr,to,pop;
char sign;
int max_pop = 0;
int sum_pop = 0;
int count;
double ave_pop = 0.0;
int plus_line = 0;
int minus_line = 0;
int num_iterations = 0;
int n_line = 0;
double pop_ratio;
char buff[BUFLEN];
FILE *infile;
double angle,startx,starty,endx,endy;
infile = fopen(peb_flnm,"r");
if(infile == NULL)
 {
 printf("Failed to open input file %s\n",peb_flnm);
 exit(1);
 }
while(fgets(buff,BUFLEN,infile))         // peb �t�@�C���X�L���� �i�`�F�b�N�j
 {
 sscanf(buff,"%d %d %c %d",&fr,&to,&sign,&pop);
//printf("%10d %10d %5c %10d\n",fr,to,sign,pop);
 if(fr != to)
  {
  printf("invalid format of peb %s file\n",peb_flnm);
  exit(1);
  }
 if(sign == '+')
  plus_line ++;
 if(sign == '-')
  minus_line ++;
 n_line ++;
 }                                      // peb�t�@�C���X�L�����I
//printf("PEB + line is %10d\n",plus_line);
//printf("PEB - line is %10d\n",minus_line);
//printf("PEB   line is %10d\n",n_line);
if((plus_line >  n_pos+1) || (minus_line >  n_pos+1))
 {
 printf("Too many info in %s file %d %d %d\n",peb_flnm,plus_line,minus_line,n_pos);
 exit(1);
 }
rewind(infile);
n_line = 0;
while(fgets(buff,BUFLEN,infile))         // peb �t�@�C���ǂݍ���
 {
 sscanf(buff,"%d %d %c %d",&fr,&to,&sign,&pop);
 if(sign == '+')
  {
  pops[fr].plus  = pop;
  }
 if(sign == '-')
  {
  pops[fr].minus = pop;
  }
 n_line ++;
 if(pop > max_pop)
  max_pop = pop;
 }                                      // peb�t�@�C���ǂݍ��ݏI

printf("MAX_POP = %10d\n",max_pop);

num_iterations = genome_length/tracks[track_id].window_size+1;

for(i=0;i<num_iterations;i++)
 {
 count = 0;
 sum_pop = 0;
 for(j=0;j<tracks[track_id].window_size;j++)
  {
  sum_pop += pops[i*tracks[track_id].window_size+j].plus;
  sum_pop += pops[i*tracks[track_id].window_size+j].minus;
  count ++;
  }
// ave_pop = (double)sum_pop / (double)tracks[track_id].window_size / 2.0;
 ave_pop = (double)sum_pop / (double)count / 2.0;
 pop_ratio = ave_pop / (double)max_pop;
 pop_ratio = pop_ratio * pop_scale;
 if(pop_ratio > 1.0)
  pop_ratio = 1.0;
 if(pop_ratio < 0.0)
  pop_ratio = 0.0;

 angle = 2.0 * PI * (double)(tracks[track_id].window_size * i) / (double)genome_length;
 //printf("%6d %8.4f %8d %8.2f\n",i*tracks[track_id].window_size,angle,sum_pop,pop_ratio);
 startx = sin(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width));
 starty = cos(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width));
 endx   = sin(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width) 
                                                                + (tracks[track_id].track_true_width * pop_ratio));
 endy   = cos(angle) * max_radius * (tracks[track_id].in_radius + (track_margin * tracks[track_id].track_width)
                                                                + (tracks[track_id].track_true_width * pop_ratio));
 fprintf(psfile,"  %f %f moveto\n",startx,starty);                                 // �ڐ���̎n�_  x,y
 fprintf(psfile,"  %f %f lineto\n",endx,endy);                                     // �ڐ���̏I�_  x,y
 fprintf(psfile,"  %f  setlinewidth\n",pop_width);
 fprintf(psfile,"stroke\n");
 }

}

void read_genbank(void)
{
int i;
int n1,n2;
char buff[BUFLEN];
FILE *infile;
n_gene = 0;
infile = fopen(gb_flnm,"r");
if(infile == NULL)
 {
 printf("Failed to open input file %s\n",gb_flnm);
 exit(1);
 }
while(fgets(buff,BUFLEN,infile))    // genbank �t�@�C���ǂݍ���
 {
 if(strncmp(buff,"     gene  ",10) == 0) // gene �s����
  {
  n_gene ++;
  }
 }
printf("Number of genes is %10d\n",n_gene);
genes = (gene_info *)malloc(sizeof(gene_info) * (n_gene + 5));
if(genes == NULL)
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }
rewind(infile);
n_gene = 0;
while(fgets(buff,BUFLEN,infile))    // genbank �t�@�C���ǂݍ���
 {
 if(strncmp(buff,"     gene  ",10) == 0) // gene �s����
  {
  if(strstr(buff,"join") == NULL)   // join ���Ȃ�
   {
   genes[n_gene].n_segments = 1;
   }
  else                              // join ������
   {
   genes[n_gene].n_segments = count_comma(buff);
   }
  genes[n_gene].gene_segments = (gene_segment_info *)malloc(sizeof(gene_segment_info)*genes[n_gene].n_segments);
// printf("N_gene %10d\n",genes[n_gene].n_segments);
  n_gene ++;
  }
 }

rewind(infile);
n_gene = 0;
while(fgets(buff,BUFLEN,infile))    // genbank �t�@�C���ǂݍ���
 {
 if(strncmp(buff,"     gene  ",10) == 0) // gene �s����
  {
  if(strstr(buff,"complement") == NULL)   // complement �łȂ�
    {
    for(i=0;i<genes[n_gene].n_segments;i++)
     {
     genes[n_gene].gene_segments[i].direction   = 1;
     }
    }
   else                                    // complement �ł���
    {
    for(i=0;i<genes[n_gene].n_segments;i++)
     {
     genes[n_gene].gene_segments[i].direction   =-1;
     }
    }
   for(i=0;i<genes[n_gene].n_segments;i++)
    {
    n1 = ithnum(1,i,buff);
    n2 = ithnum(2,i,buff);
    genes[n_gene].gene_segments[i].from = n1;
    genes[n_gene].gene_segments[i].to   = n2;
//printf("%6d %6d\n",n1,n2);
    }
   n_gene ++;
   }
  }
}

void read_fasta(void)
{
char buff[BUFLEN];
char c;
FILE *infile;                   // ���̓t�@�C�� fasta_file

  genome_length = 0;
  infile = fopen(fasta_flnm,"r");
  if(infile == NULL)
   {
   printf("Failed to open input file %s\n",fasta_flnm);
   exit(1);
   }
  fgets(buff,BUFLEN,infile);    // fasta �^�C�g���s
  while(1)
   {
   c = fgetc(infile);
   if(c==EOF)
    {
    break;
    }
   if((c != '\n') && (c != ' '))
    {
    genome_length ++;
    }
   }
//  printf("Sequence length of fasta file %s is %d\n",tracks[track_id].data_flnm,genome_length);
  printf("Sequence length is %d\n",genome_length);
  rewind(infile);
  seq = (char *)malloc(sizeof(char) * (genome_length + 10));
  genome_length = 0;
  fgets(buff,BUFLEN,infile);    // fasta �^�C�g���s
  while(1)
   {
   c = fgetc(infile);
   if(c==EOF)
    {
    break;
    }
   if((c != '\n') && (c != ' '))
    {
    seq[genome_length] = c;
    genome_length ++;
    }
   }
  seq[genome_length] = '\0';
  fclose(infile);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//////////////////////////////// h2h(hr2hmr)のpsd（組み換えの位置と向き）出力を
//////////////////////////////// ヒストグラム的なものに変換
//////////////////////////////// h2h_histo  #Windowsize #Genomelength infile.psd

int main(int argc,char **argv)
 {
 char buff[512];
 FILE *infile;
 infile = fopen(argv[3],"r");
 
 int windowsize = atoi(argv[1]);
 int genomelen  = atoi(argv[2]);
 int n_windows  = (genomelen+windowsize-1)/windowsize;

 int *bin1;
 int *bin2;

 bin1 = (int *)malloc(sizeof(int) * (n_windows + 2));
 bin2 = (int *)malloc(sizeof(int) * (n_windows + 2));
 for(int i=0;i<n_windows+2;i++)                         // binの初期化
  {
  bin1[i] = 0;
  bin2[i] = 0;
  }

 while(fgets(buff,512,infile))
  {
  int pos,v1,v2;
  sscanf(buff,"%d %d %d",&pos,&v1,&v2);
  bin1[pos/windowsize] += v1;
  bin2[pos/windowsize] += v2;
  }
 
 int b1t1 = 0;
 int b1b1 = 0;
 int b1b2 = 0;
 int b2t1 = 0;
 int b2b1 = 0;
 int b2b2 = 0;
 for(int i=0;i<n_windows;i++)
  {
  printf("%10d %10d\n",bin1[i],bin2[i]);
  b1t1 += bin1[i] * (bin1[i]-1);
  b1b1 += bin1[i];
  if(bin1[i] != 0)
   b1b2 += bin1[i]-1;
  b2t1 += bin2[i] * (bin2[i]-1);
  b2b1 += bin2[i];
  if(bin2[i] != 0)
   b2b2 += bin2[i]-1;
  }

// printf("%10d %10d %10d\n",b1t1,b1b1,b1b2);
// printf("%10d %10d %10d\n",b2t1,b2b1,b2b2);
 float id1 = (float)(n_windows * b1t1) / (float)(b1b1 * b1b2);
 float id2 = (float)(n_windows * b2t1) / (float)(b2b1 * b2b2);
// printf("id1 = %10.3f\n",id1);
// printf("id2 = %10.3f\n",id2);
 }

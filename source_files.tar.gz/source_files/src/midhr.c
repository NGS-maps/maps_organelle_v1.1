#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "midhr.h"
#define BUFLEN   512

/////////////////////////////
char arg1[256];                       // $BBh0l0z?t(B   ref.fasta
char arg2[256];                       // $BBhFs0z?t(B   reads.fastq
/////////////////////////////            Usage: midhr ref.fasta reads.fastq

////////////////////////////////////////////////////////////////////////////////////
// $B30ItJQ?t@k8@(B      GROBAL VARIABLES                                             //
////////////////////////////////////////////////////////////////////////////////////

long int refseq_len = 0;              // $B;2>HG[NsD9(B
int  jobname = 0;                     // $B%8%g%VL>$NM-L5(B
char job_name[512];                   // $B%8%g%VL>(B
int mm_thresh =  3;                   // Threshold as Minimum Number of Mismatch
char homoseq[512];                    // $B%_%9%^%C%A%3%s%;%s%5%9G[Ns$N%W%j%s%HMQ(B

char junction_cluster_flnm[256];      // $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%kL>(B
FILE *junction_cluster;               // $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k(B   .jcc

char junction_cluster_pair_flnm[256];      // $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%kL>(B
FILE *junction_cluster_pair;               // $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k(B   .jcc

int *hit_pos1;                        // R1$B$N%R%C%H0LCV(B    $B%Z%"%(%s%I%j!<%I?t(B(n_pair)$B$NG[Ns(B
int *hit_pos2;                        // R2$B$N%R%C%H0LCV(B    $B%j!<%I?t(B n_read $B$NH>J,(B

int index_length = 6;                 // $B%_%9%^%C%AG[NsC5:w$N;~$N%$%s%G%C%/%9D9(B
int index_size;                       // $B#4$N%$%s%G%C%/%9D9>h(B
index_list *ils;                      // $B%$%s%G%C%/%9%j%9%H(B  $B%l%U%!%l%s%9>e$K%3%s%;%s%5%9$N0lCW$rC5:w$9$k$?$a(B
int pairmap = 0;                      // $B%Z%"%(%s%I%^%C%W$+$I$&$+$N%U%i%0(B

int consensus_depth  =  2;            // $B%8%c%s%/%7%g%s$N%3%s%;%s%5%9$r<h$k8|$_$NogCM(B
int consensus_depth2 =  2;            // $B%8%c%s%/%7%g%s$N%3%s%;%s%5%9$r<h$k8|$_$NogCM(B
int consensus_length = 15;            // $B%8%c%s%/%7%g%s$N%3%s%;%s%5%9D9$NogCM(B
int pair_thresh_distance = 600;       // $B%Z%"%(%s%I$G$3$l0J>eN%$l$F$$$k$H1s$$$HH=CG$9$kogCM(B

int jcf_out = 0;
int jco_out = 0;
int snp_only = 0;

int       n_read = 0;
int       n_pair;

int num_hrp = 0;
hr_info *hrp;
////////////////////////////////////////////////////////////////////////////////////
// $B4X?tDj5A(B  FUNCTION DEFINITIONS                                                 //
////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////// ##FUNCTION $B1v4pG[NsCf$K(BN$B$,4^$^$l$F$$$l$P$=$N8D?t$rJV$94X?t(B

////////////////////////////////////////////////////////////////////
float second_ratio(int a, int t, int g, int c, int b)
 {
 int maxm = 0;
 int next = 0;
 int n[5];
 n[1] = a;
 n[2] = t;
 n[3] = g;
 n[4] = c;
 if((a >= t) && (a >= g) && (a >= c))
  {
  maxm = 1;
  if((t >= g) && (t >= c))
   next = 2;
  if((g >= t) && (g >= c))
   next = 3;
  if((c >= t) && (c >= g))
   next = 4;
  }
 if((t >= a) && (t >= g) && (t >= c))
  {
  maxm = 2;
  if((a >= g) && (a >= c))
   next = 1;
  if((g >= a) && (g >= c))
   next = 3;
  if((c >= a) && (c >= g))
   next = 4;
  }
 if((g >= a) && (g >= t) && (g >= c))
  {
  maxm = 3;
  if((a >= t) && (a >= c))
   next = 1;
  if((t >= a) && (t >= c))
   next = 2;
  if((c >= a) && (c >= t))
   next = 4;
  }
 if((c >= a) && (c >= t) && (c >= g))
  {
  maxm = 4;
  if((a >= t) && (a >= g))
   next = 1;
  if((t >= a) && (t >= g))
   next = 2;
  if((g >= a) && (g >= t))
   next = 3;
  }
  
 float val = (float)n[next] / (float)b * 100.0;
 return val;
 }
//////////////////////////////////////////////////////////////////

int pid(int id)
 {
 int val;
 if(id >= n_pair)
  {
  val  = id - n_pair;
  }
 else
  {
  val  = id + n_pair;
  }
 if((val > n_read) || (val < 0))
  {
  printf("Invalid read id in pid\n");
  exit(1);
  }
 else
  return val;
 }
//////////////////////////////////////////////////
int include_n(char *seq)
{
int i;
int len = strlen(seq);
int val = 0;
for(i=0;i<len;i++)
 {
 if(seq[i] == 'N')
  {
  val ++;
  }
 }
return val;
}
///////////////////////////////////////////////////////////////////////////////////// ##FUNCTION $B%*!<%P!<%i%C%W(B $B%Z%"$N%=!<%H(B(qsort)$BMQHf3S4X?t(B
int op_sort(const void *a, const void *b)
 {
 int val1a,val1b;
 int val2a,val2b;
 int mina,minb;
 int maxa,maxb;
 val1a = hit_pos1[*(int *)a];
 val1b = hit_pos1[*(int *)b];
 val2a = hit_pos2[*(int *)a];
 val2b = hit_pos2[*(int *)b];
 if(val1a < val2a)
  {
  mina = abs(val1a); 
  maxa = abs(val2a);
  }
 else
  {
  mina = abs(val2a); 
  maxa = abs(val1a);
  }
 if(val1b < val2b)
  {
  minb = abs(val1b); 
  maxb = abs(val2b);
  }
 else
  {
  minb = abs(val2b); 
  maxb = abs(val1b);
  }
 if((abs(val1a) + abs(val2a)) < (abs(val1b) + abs(val2b)))
  return -1;
 return 1;
 }
///////////////////////////////////////////////// ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
int read_int (char *str,int start,int width)   
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}
///////////////////////////////////////////////// ## Function complement_char $BJ8;z7?JQ?t$N1v4p(BATGC$B$r<h$C$F$=$N%3%s%W%j%a%s%H$rJV$9(B
char complement_char(char c)                   
{
switch(c)
 {
 case 'A':
  return 'T';
 case 'T':
  return 'A';
 case 'G':
  return 'C';
 case 'C':
  return 'G';
 }
return 'N';
}

int rev_comp(char *dest,char *orig)
 {
 int i;
 int len = strlen(orig);
 for(i=0;i<len;i++)
  {
  dest[i] = complement_char(orig[len-i-2]);
  }
 dest[len] = '\0';
 return 0;
 }
//////////////////////////////////////////////// ## Function compare_mm_seq $B%_%9%^%C%AJ8;zNs$NHf3S(B $BC;$$J}$NG[Ns$KBP$7$FIT0lCW?t$r%+%&%s%H(B 
int compare_mm_seq(char *seq1,char *seq2)       
 {
 int i,j,k;
 int len;
 int mm = 0;
 if(strlen(seq1) > strlen(seq2))
  len = strlen(seq2);
 else
  len = strlen(seq1);

 for(i=0;i<len;i++)
  {
  if(seq1[i] != seq2[i])
   mm ++;
  }
 return mm;
 }
////////////////////////////////////////////////// ## Function check_homology $BFs$D$N%_%9%^%C%AG[Ns$rHf3S$7$FF1$81v4p$,2?1v4pL\$^$GB7$C$F$$$k$+$r%+%&%s%H(B 
//////////////////////////////////////////////////    $BAjF1AH$_BX$($NAjF1G[Ns$N%A%'%C%/$KMxMQ(B
int check_homology2(char *seq1,char *seq2)       
 {                                               
 int i;
 int flag = 0;
 char prev;
 for(i=0;i<HOMOSEQLEN;i++)
  {
  if(seq1[i] != seq2[i])
   {
   return i;
   }
  }
 return HOMOSEQLEN;
 }
//////////////////////////////////////////////////// ## Function check_homology $BFs$D$N%_%9%^%C%AG[Ns$rHf3S$7$FF1$81v4p$,2?1v4pL\$^$GB7$C$F$$$k$+$r%+%&%s%H(B
int check_homology(char *seq1,char *seq2)       
 {
 int i;
 int flag = 0;
 char prev;
 for(i=0;i<HOMOSEQLEN;i++)
  {
  if(seq1[i] == prev)
   {
   flag ++;
   }
  if(seq1[i] != seq2[i])
   {
   if(flag >= i)  // $BA4ItF1$8(B
    {
    return MAX_INT;
    }
   else
    {
    return i;
    }
   }
  prev = seq1[i];
  }
 return MAX_INT;
 }
//////////////////////////////////////////////////// ## Function complement_seq  $BJ8;zNs!J1v4pG[Ns!K$r<h$C$F%j%P!<%9%3%s%W%j%a%s%H$rJV$9(B
void complement_seq(char* dest_seq,char* source_seq)  
 {
 int i,j,k,l,m;
 int seq_len;
 seq_len = strlen(source_seq);
 for(i=0;i<seq_len;i++)
  {
  switch(source_seq[i])
   {
   case 'A': dest_seq[seq_len-i-1] = 'T'; break;
   case 'T': dest_seq[seq_len-i-1] = 'A'; break;
   case 'G': dest_seq[seq_len-i-1] = 'C'; break;
   case 'C': dest_seq[seq_len-i-1] = 'G'; break;
   case 'N': dest_seq[seq_len-i-1] = 'N'; break;
   case '.': dest_seq[seq_len-i-1] = 'N'; break;
   default: dest_seq[seq_len-i-1]  = 'N'; break;
   }
  }
 dest_seq[seq_len] = '\0';
 }
////////////////////////////////////////////////////////////////////////////////////
// $B%a%$%s4X?t(B      MAIN FUNCTION                                                  //
////////////////////////////////////////////////////////////////////////////////////
int main(int argc, char **argv)
{
int    i,j,k,l,m,n;
int    cc;
int    mm;
int    n_elem;
int    mat[32];
int    search_index;
int    start,n_hit,hit_pos,miss;
int    pos_diff, pos_dir, pos_indl;
int    rev_match;
int    num_hr   = 0;
int    num_pal  = 0;
int    num_ins  = 0;
int    num_del  = 0;
int    num_unk  = 0;
int    consensus_len;
int    hitid;
int    mindiff = 0;
int    nop=0;
overlap_pair_info *ops;
int    *op;
int    distance;
char   mark_direction;    // $B8~$-$N%^!<%/(B S:$BF1J}8~!!(BO:$B5UJ}8~(B
char   mark_distance;     // $B5wN%$N%^!<%/(B J:10$B0JFb(B  F:50$B0JFb(B H:100$B0JFb(B V:500$B0JFb(B K:1000$B0JFb(B
char   mark_homology;     // $BAjF1G[NsD9$N%^!<%/(B X:6$B0J>e(B Y:3$B0J>e(B W:2$B0J2<(B Z:0
int    seqlen;
int    overlap;
int    plus,minus;
int    *hmr_sort;
int    *hmr_flag;
char   *refseq;
char   refseq_header[512];
char   fasta_header[512];
char   refseq_flnm[256];
char   buff[512];
FILE   *refseq_file;
int    read_len=0;
int    flag;
char   tempc;
char   qseq[512];
int    rearrangement_candidate = 0;
char   junctionseq1[512];
word_info junctionseq2[MAX_J_HIT];
char   junctionseq3[512];
char   tempseq1[512];
char   tempseq2[512];
char   temprev2[512];
read_info *read;
int   num_hit  = 0;
int   tempcount;
int   val1,val2;
int   *hit_position;
int   *rid_hid;
int   *hit_id;
int   *hit_flag;
int   *pos_A;
int   *pos_T;
int   *pos_G;
int   *pos_C;
int   *pos_Base;
int   n_match;
int   n_mismatch;
int   nmm_left;
int   nmm_right;
int   fflag;
int   n_cluster = 0;
int   temp;
int   *position_count_plus;
int   *position_count_minus;
int   *position_address;
int   *position_address_plus;
int   *position_address_minus;
int   junction_count=0;
int   num_jcs = 0;
junction_cluster_info *jcs;

 long int atmtlen = 0;
 long int atstlen = 0;
 long int atqtlen = 0;
 long int atptlen = 0;
 long int atmtcnt = 0;
 long int atstcnt = 0;
 long int atqtcnt = 0;
 long int atptcnt = 0;

int cl_count;

char read_flnm[256]; FILE *read_file;
char hit_flnm[256]; FILE *hit_file;
char  junction_out_flnm[256]; FILE  *junction_out;
char  pair_distance_flnm[256]; FILE  *pair_distance;
char  pair_distance2_flnm[256]; FILE  *pair_distance2;
char  pair_distance3_flnm[256]; FILE  *pair_distance3;
char  pair_distance4_flnm[256]; FILE  *pair_distance4;
char  jcs_flnm[256]; FILE  *jcs_file;
char  jrr_flnm[256]; FILE  *jrr_file;
char  pair_histo_flnm[256]; FILE  *pair_histo_file;
char  jcsfl_flnm[256]; FILE  *jcsfl_file;
char  jco_flnm[256]; FILE  *jco_file;
char  index_flnm[256]; FILE  *index_file;
char  pair_overlap_flnm[256]; FILE  *pair_overlap_file;
char  pair_overlap2_flnm[256]; FILE  *pair_overlap2_file;
char  ins_flnm[256]; FILE  *ins_file;
char  del_flnm[256]; FILE  *del_file;
char  hr_flnm[256]; FILE  *hr_file;
char  hmr_flnm[256]; FILE  *hmr_file;
char  pal_flnm[256]; FILE  *pal_file;
char  unk_flnm[256]; FILE  *unk_file;
char  arr_flnm[256];   FILE  *arr_file;       // 2017/11/26 // unk,hr, pal $B$rE;$a$k(B
char  pairmap_flnm[256]; FILE  *pairmap_file;

char mmp_read_flnm[256]; FILE *mmp_read_file;
char reg_read_flnm[256]; FILE *reg_read_file;
char mm2_read_flnm[256]; FILE *mm2_read_file;
char rg2_read_flnm[256]; FILE *rg2_read_file;

char snp_flnm[256]; FILE *snp_file;

////////////////////////////////////////////////////////////////////////////////////////////////////////
/////                                                 $B%"!<%.%e%a%s%HFI$_9~$_(B  READ ARGUMENTS          //
////////////////////////////////////////////////////////////////////////////////////////////////////////
readargs(argc,argv); 
printf("PAIRMAP OPTION IS %d\n",pairmap);
printf("SNPONLY OPTION IS %d\n",snp_only);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////// $B;2>HG[NsFI$_9~$_(B                 READ REFERENCE   STEP0.1    ///
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////              OPEN REFERENCE FILE   //  $B%l%U%!%l%s%9%U%!%$%k3+$/(B
sprintf(refseq_flnm,"%s",arg1);
if(!(refseq_file = fopen(refseq_flnm,"r")))
 {
 printf("Failed to open input refseq file: %s\n",refseq_flnm);
 exit(1);
 }
printf("OPENING REFSEQ FILE %s\n",refseq_flnm);
printf("READ FILE NAME IS %s\n",arg2);
///////////////////////////////////////              READ FASTA TITLE LINE // $B%l%U%!%l%s%9$N%?%$%H%k9TFI$_9~$_(B
fgets(buff,500,refseq_file);
strcpy(refseq_header,buff);
refseq_header[strlen(refseq_header)-1] = '\0';
for(i=1;i<strlen(refseq_header)-1;i++)
 {
 fasta_header[i-1] = refseq_header[i];
 if((refseq_header[i] == ' ') || (refseq_header[i] == '\0') || (refseq_header[i] == '\t') || (refseq_header[i] == '\n'))
  {
  fasta_header[i-1] = '\0';
  break;
  }
 }
///////////////////////////////////////              COUNT REFERENCE LENGTH //$B%l%U%'%l%s%9G[Ns$NJ8;z?t%+%&%s%H(B
refseq_len = 0;
while((tempc=fgetc(refseq_file)))
 {
 if(tempc != '\n')
  {
  refseq_len ++;
  }
 if(tempc == EOF)
  {
  break;
  }
 }
printf("LENGTH OF REFERENCE SEQUENCE IS %10ld\n",refseq_len);
///////////////////////////////////////              ALLOCATE REFSEQ MEMORY  //$B%l%U%!%l%s%9G[Ns$N5-21NN0h3NJ](B
refseq           = (char *)malloc(sizeof(char)*(refseq_len + 100));
position_count_plus   = (int  *)malloc(sizeof(int) *(refseq_len + 100));
position_count_minus   = (int  *)malloc(sizeof(int) *(refseq_len + 100));
position_address = (int  *)malloc(sizeof(int) *(refseq_len + 100));
position_address_plus = (int  *)malloc(sizeof(int) *(refseq_len + 100));
position_address_minus = (int  *)malloc(sizeof(int) *(refseq_len + 100));

if((refseq == NULL) || (position_address == NULL) ||
   (position_count_plus == NULL) || (position_count_minus == NULL) ||
   (position_address_plus == NULL) || (position_address_minus == NULL))
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }

for(i=0;i<refseq_len + 100;i++)
 {
 position_count_plus[i] = 0;
 position_count_minus[i] = 0;
 position_address[i] = 0;
 position_address_plus[i] = 0;
 position_address_minus[i] = 0;
 }
///////////////////////////////////////
rewind(refseq_file);        // $B4,La$7(B
///////////////////////////////////////              READ REFSEQ  $B%l%U%!%l%s%9G[NsFI$_9~$_(B
fgets(buff,500,refseq_file);
refseq_len = 0;
while((tempc=fgetc(refseq_file)))
 {
 if(tempc != '\n')
  refseq[refseq_len++] = tempc;
 if(tempc == EOF)
  {
  break;
  }
 }
refseq[refseq_len-1] = '\0';
fclose(refseq_file);
/////////////////////////////////////////////////// $B%l%U%!%l%s%9FI$_9~$_=*$o$j(B

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////// $B%l%U%!%l%s%9$N%$%s%G%C%/%9$rFI$_9~$_(B  STEP0.2            ///
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
index_size = (int)pow((double)4,index_length);
ils=(index_list *)malloc(sizeof(index_list)*(index_size+10));
sprintf(index_flnm,"%s.indx%d",arg1,index_length);
if(!(index_file = fopen(index_flnm,"r")))
 {
 printf("Failed to open input index file: %s\n",index_flnm);
 exit(1);
 }

for(i=0;i<index_size;i++)
 {
 fgets(buff,256,index_file);
 n_elem = atoi(buff);
 ils[i].n_pos = n_elem;
 ils[i].pos = (int *)malloc(sizeof(int)*(n_elem+2));
 for(j=0;j<n_elem;j++)
  {
  fgets(buff,256,index_file);
  ils[i].pos[j] = atoi(buff);
  }
 }
printf("DONE READING INDEX FILE\n");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////// $B%j!<%I%G!<%?$NFI$_9~$_(B       STEP0.3                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////              OPEN READ FILE        // $B%j!<%I%U%!%$%k3+$/(B
strcpy(read_flnm,arg2);
if(!(read_file = fopen(read_flnm,"r")))
 {
 printf("Failed to open input read file: %s\n",read_flnm);
 exit(1);
 }

sprintf(mmp_read_flnm,"%s.mmp.fastq",arg2);
if(!(mmp_read_file = fopen(mmp_read_flnm,"w")))
 {
 printf("Failed to open input read file: %s\n",mmp_read_flnm);
 exit(1);
 }
sprintf(reg_read_flnm,"%s.reg.fastq",arg2);
if(!(reg_read_file = fopen(reg_read_flnm,"w")))
 {
 printf("Failed to open input read file: %s\n",reg_read_flnm);
 exit(1);
 }
sprintf(mm2_read_flnm,"%s.mm2.fastq",arg2);
if(!(mm2_read_file = fopen(mm2_read_flnm,"w")))
 {
 printf("Failed to open input read file: %s\n",mm2_read_flnm);
 exit(1);
 }
sprintf(rg2_read_flnm,"%s.rg2.fastq",arg2);
if(!(rg2_read_file = fopen(rg2_read_flnm,"w")))
 {
 printf("Failed to open input read file: %s\n",rg2_read_flnm);
 exit(1);
 }

sprintf(snp_flnm,"%s.snp",arg2);
if(!(snp_file = fopen(snp_flnm,"w")))
 {
 printf("Failed to open input read file: %s\n",snp_flnm);
 exit(1);
 }

///////////////////////////////////////              COUNT READ FILE       // $B%j!<%I%U%!%$%k%+%&%s%H(B
while(fgets(buff,500,read_file))
 {
 fgets(buff,500,read_file);
 fgets(buff,500,read_file);
 fgets(buff,500,read_file);
 n_read++;
 }

n_pair = n_read / 2;                                 // n_pair = $B%Z%"%(%s%I$N%Z%"$N?t!!(BR1$B$^$?$O(BR2$BJRJ}$N%j!<%I?t(B
int partner_id;                                      // $B%Z%"%(%s%I$NAj<j(B

printf("N_READ = %10d\n",n_read);
printf("N_PAIR = %10d\n",n_pair);

///////////////////////////////////////
rewind(read_file);  // $B4,La$7(B
///////////////////////////////////////              ALLOCATE MEMORY FOR READS // $B%j!<%IMQ%a%b%j%"%m%1!<%H(B
read = (read_info *)malloc(sizeof(read_info)*(n_read + 1000));

hit_pos1 = (int *)malloc(sizeof(int)*(n_read + 10));
hit_pos2 = (int *)malloc(sizeof(int)*(n_read + 10));

if(read == NULL)
 {
 printf("MALLOC FAIL FOR read\n");
 exit(1);
 }
if((hit_pos1 == NULL) || (hit_pos2 == NULL))
 {
 printf("MALLOC FAIL FOR hit_pos\n");
 exit(1);
 }

for(i=0;i< n_read + 100;i++)
 {
 read[i].junction_likelyhood  = 0;
 read[i].mismatch_start_point = MAX_INT;
 read[i].mismatch_start_point_on_genome = MAX_INT;
 read[i].pos = MAX_INT;
 }

for(i=0;i< n_read + 10;i++)
 {
 hit_pos1[i] =  MAX_INT;
 hit_pos2[i] =  MAX_INT;
 }

hit_position = (int *)malloc(sizeof(int)*(n_read + 1000));
rid_hid      = (int *)malloc(sizeof(int)*(n_read + 1000));
hit_id       = (int *)malloc(sizeof(int)*(n_read + 1000));
hit_flag     = (int *)malloc(sizeof(int)*(n_read + 1000));

pos_A     = (int *)malloc(sizeof(int)*(n_read + 1000));
pos_T     = (int *)malloc(sizeof(int)*(n_read + 1000));
pos_G     = (int *)malloc(sizeof(int)*(n_read + 1000));
pos_C     = (int *)malloc(sizeof(int)*(n_read + 1000));
pos_Base  = (int *)malloc(sizeof(int)*(n_read + 1000));

if(hit_position == NULL)
 {
 printf("MALLOC FAIL hit_position\n");
 exit(1);
 }
if(rid_hid == NULL)
 {
 printf("MALLOC FAIL rid_hid\n");
 exit(1);
 }
if(hit_id       == NULL)
 {
 printf("MALLOC FAIL hit_id\n");
 exit(1);
 }
if(hit_flag     == NULL)
 {
 printf("MALLOC FAIL hit_flag\n");
 exit(1);
 }
if(pos_A     == NULL)
 {
 printf("MALLOC FAIL pos_A\n");
 exit(1);
 }
if(pos_T     == NULL)
 {
 printf("MALLOC FAIL pos_A\n");
 exit(1);
 }
if(pos_G     == NULL)
 {
 printf("MALLOC FAIL pos_A\n");
 exit(1);
 }
if(pos_C     == NULL)
 {
 printf("MALLOC FAIL pos_A\n");
 exit(1);
 }
if(pos_Base  == NULL)
 {
 printf("MALLOC FAIL pos_A\n");
 exit(1);
 }
for(i=0;i< n_read + 1000;i++)     // $B=i4|2=(B
 {
 hit_position[i] = MAX_INT;
 rid_hid[i]      = MAX_INT;
 hit_id[i]       = MAX_INT;
 hit_flag[i]     = MAX_INT;
 pos_A[i]        = 0;
 pos_T[i]        = 0;
 pos_G[i]        = 0;
 pos_C[i]        = 0;
 pos_Base[i]     = 0;
 }
///////////////////////////////////////              READ READ FILE        $B%j!<%I%U%!%$%kFI$_9~$_(B
for(i=0;i<n_read;i++)
 {
 fgets(buff,500,read_file);
 read[i].t1 = (char *)malloc(sizeof(char)*(strlen(buff)+2));
 if(read[i].t1 == NULL)
  {
  printf("Failed to allocate memory\n");
  exit(1);
  }
 strcpy(read[i].t1,buff);
 fgets(buff,500,read_file);
 read[i].seq = (char *)malloc(sizeof(char)*(strlen(buff)+2));
 if(read[i].seq == NULL)
  {
  printf("Failed to allocate memory\n");
  exit(1);
  }
 strcpy(read[i].seq,buff);
 fgets(buff,500,read_file);
 read[i].t2 = (char *)malloc(sizeof(char)*(strlen(buff)+2));
 if(read[i].t2 == NULL)
  {
  printf("Failed to allocate memory\n");
  exit(1);
  }
 strcpy(read[i].t2,buff);
 fgets(buff,500,read_file);
 read[i].quality = (char *)malloc(sizeof(char)*(strlen(buff)+2));
 if(read[i].quality == NULL)
  {
  printf("Failed to allocate memory\n");
  exit(1);
  }
 strcpy(read[i].quality,buff);
 }
read_len = strlen(read[1].seq)-1;
printf("READ LENGTH = %10d\n",read_len);
fclose(read_file);
//////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////// $B%R%C%H%U%!%$%k$NFI$_9~$_(B STEP0.4              ///
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////              OPEN HIT FILE          $B%R%C%H%U%!%$%k3+$/(B
sprintf(hit_flnm,"%s_%s.hit",arg2,job_name);
printf("HIT FILE NAME IS %s\n",hit_flnm);
if(!(hit_file = fopen(hit_flnm,"r")))
 {
 printf("Failed to open hit file: %s\n",hit_flnm);
 exit(1);
 }
///////////////////////////////////////              COUNT HIT FILE         $B%R%C%H%U%!%$%k%+%&%s%H(B
num_hit = 0;
while(fgets(buff,500,hit_file))
 {
 num_hit ++;
 }
printf("N_HIT  = %10d\n",num_hit);

rewind(hit_file);
///////////////////////////////////////              READ HIT FILE          $B%R%C%H%U%!%$%kFI$_9~$_(B

tempcount = 0;
while(fgets(buff,500,hit_file))
 {
 val1 = read_int(buff,1,10);
 val2 = read_int(buff,12,10);
// printf("#%10d %10d %10d \n",tempcount,val1,val2);
 if((val1 >= 0) && (val1 < n_read))
  {
  hit_id[tempcount]       = val1;                  // tempcount $BL\$N%R%C%H$N%j!<%I(BID$B$,(Bhit_id[tempcount]
  if(val2 > 0)
   {
   hit_position[tempcount] = val2-1;               // tempcount $BL\$N%R%C%H0LCV$,(Bhit_position[tempcount]
   read[val1].pos = val2-1;
   }
  else
   {
   hit_position[tempcount] = -(abs(val2)-1);
   read[val1].pos = -(abs(val2)-1);
   }

  rid_hid[val1] = tempcount;                       // $B%j!<%I(BID$B$r%R%C%H(BID$B$KJQ49(B
  }
 else
  printf("Wrong data %10d %10d\n",val1,val2);
 tempcount ++;
 }
fclose(hit_file);
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////// $B=PNO%U%!%$%k3+$/(B              STEP0.5                            ///
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////              OPEN JUNCTION FILE    $B%8%c%s%/%7%g%s%U%!%$%k!J=PNO!K3+$/(B            .jcr
sprintf(junction_out_flnm,"%s_%s.jcr",arg2,job_name);
printf("JUNCTION LIST OUTPUT FILE NAME IS %s\n",junction_out_flnm);
if(!(junction_out = fopen(junction_out_flnm,"w")))
 {
 printf("Failed to open junction output file: %s\n",junction_out_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN JUNCTION FILE    $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k!J=PNO!K3+$/(B   .jcc
sprintf(junction_cluster_flnm,"%s_%s.jcc",arg2,job_name);
printf("JUNCTION CLUSTER OUTPUT FILE NAME IS %s\n",junction_cluster_flnm);
if(!(junction_cluster = fopen(junction_cluster_flnm,"w")))
 {
 printf("Failed to open junction output file: %s\n",junction_cluster_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN JUNCTION FILE    $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k!J=PNO!K3+$/(B   .jcp
sprintf(junction_cluster_pair_flnm,"%s_%s.jcp",arg2,job_name);
printf("JUNCTION CLUSTER OUTPUT FILE NAME IS %s\n",junction_cluster_pair_flnm);
if(!(junction_cluster_pair = fopen(junction_cluster_pair_flnm,"w")))
 {
 printf("Failed to open junction output file: %s\n",junction_cluster_pair_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN JUNCTION CLUSTER READ $B%8%c%s%/%7%g%s%/%i%9%?$KF~$k%j!<%I%U%!%$%k!J=PNO!K3+$/(B   .jrr
sprintf(jrr_flnm,"%s_%s.jrr",arg2,job_name);
printf("JUNCTION CLUSTER READ OUTPUT FILE NAME IS %s\n",jrr_flnm);
if(!(jrr_file = fopen(jrr_flnm,"w")))
 {
 printf("Failed to open junction output file: %s\n",jrr_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN JUNCTION FILE    $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k(B2$B!J=PNO!K3+$/(B  .jco
if(jco_out == 1)
 {
 sprintf(jco_flnm,"%s_%s.jco",arg2,job_name);
 printf("JUNCTION CLUSTER (NEW) OUTPUT FILE NAME IS %s\n",jco_flnm);
 if(!(jco_file = fopen(jco_flnm,"w")))
  {
  printf("Failed to open junction output file: %s\n",jco_flnm);
  exit(1);
  }
 }
///////////////////////////////////////              OPEN JUNCTION FILE    $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k(B3$B!J=PNO!K3+$/(B  .jcs
sprintf(jcs_flnm,"%s_%s.jcs",arg2,job_name);
printf("JUNCTION CLUSTER SUMMARY FILE NAME IS %s\n",jcs_flnm);
if(!(jcs_file = fopen(jcs_flnm,"w")))
 {
 printf("Failed to open junction summary file: %s\n",jcs_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIRED END FILE  $B%Z%"%(%s%I5wN%J,I[%U%!%$%k!J=PNO!K3+$/(B      .phs
sprintf(pair_histo_flnm,"%s_%s.phs",arg2,job_name);
printf("PAIRED END HISTOGRAM FILE NAME IS %s\n",pair_histo_flnm);
if(!(pair_histo_file = fopen(pair_histo_flnm,"w")))
 {
 printf("Failed to open pair_histo summary file: %s\n",pair_histo_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN JUNCTION FILE  $B%8%c%s%/%7%g%s%/%i%9%?%5%^%j!<%U%!%$%k!J=PNO!K3+$/(B   .jcf
if(jcf_out == 1)
 {
 sprintf(jcsfl_flnm,"%s_%s.jcf",arg2,job_name);
 printf("JUNCTION CLUSTER SUMMARY FILE NAME IS %s\n",jcsfl_flnm);
 if(!(jcsfl_file = fopen(jcsfl_flnm,"w")))
  {
  printf("Failed to open junction summary file: %s\n",jcsfl_flnm);
  exit(1);
  }
 }
///////////////////////////////////////              OPEN INSERT FILE  $B%$%s%5!<%H!J=PNO!K3+$/(B   .ins
sprintf(ins_flnm,"%s_%s.ins",arg2,job_name);
printf("INSERTION LIST FILE NAME IS %s\n",ins_flnm);
if(!(ins_file = fopen(ins_flnm,"w")))
 {
 printf("Failed to open insertion summary file: %s\n",ins_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN DELETION FILE  $B%G%j!<%7%g%s!J=PNO!K3+$/(B   .del
sprintf(del_flnm,"%s_%s.del",arg2,job_name);
printf("DELETION LIST FILE NAME IS %s\n",del_flnm);
if(!(del_file = fopen(del_flnm,"w")))
 {
 printf("Failed to open deletion summary file: %s\n",del_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN HOMOROGOUS REARRANGE FILE  $BAjF1AH$_49$(!J=PNO!K3+$/(B   .hr
sprintf(hr_flnm,"%s_%s.hr",arg2,job_name);
printf("HOMOLOGOUS REARRANGEMENT SUMMARY FILE NAME IS %s\n",hr_flnm);
if(!(hr_file = fopen(hr_flnm,"w")))
 {
 printf("Failed to open homologous rearrangement summary file: %s\n",hr_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN HOMOROGOUS REARRANGE FILE  $BAjF1AH$_49$(!J=PNO!K3+$/(B   .hmr
sprintf(hmr_flnm,"%s_%s.hmr",arg2,job_name);
printf("HOMOLOGOUR REARRANGEMENT SUMMARY FILE NAME IS %s\n",hmr_flnm);
if(!(hmr_file = fopen(hmr_flnm,"w")))
 {
 printf("Failed to open homologous rearrangement summary file: %s\n",hmr_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PALINDROME REARRANGE FILE  $B%Q%j%s%I%m!<%`7?AH$_49$(!J=PNO!K3+$/(B   .pal
sprintf(pal_flnm,"%s_%s.pal",arg2,job_name);
printf("PALINDROME SUMMARY FILE NAME IS %s\n",pal_flnm);
if(!(pal_file = fopen(pal_flnm,"w")))
 {
 printf("Failed to open palindrome summary file: %s\n",pal_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN REARRANGE FILE  $BA4$F$NAH$_49$(!J=PNO!K3+$/(B   .arr
sprintf(arr_flnm,"%s_%s.arr",arg2,job_name);                          // all rearrangement file
printf("ALL REARRANGEMENT SUMMARY FILE NAME IS %s\n",arr_flnm);
if(!(arr_file = fopen(arr_flnm,"w")))
 {
 printf("Failed to open All rearrangement file: %s\n",arr_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN UNKNOWN REARRANGE FILE  $BAjF1G[Ns$N$J$$AH$_49$(!J=PNO!K3+$/(B   .unk
sprintf(unk_flnm,"%s_%s.unk",arg2,job_name);
printf("UNKNOWN CLUSTER SUMMARY FILE NAME IS %s\n",unk_flnm);
if(!(unk_file = fopen(unk_flnm,"w")))
 {
 printf("Failed to open unknown summary file: %s\n",unk_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR DISTANCE FILE  $B%Z%"%(%s%I$N5wN%J,I[%U%!%$%k3+$/(B   .pdist
sprintf(pair_distance_flnm,"%s_%s.pdist",arg2,job_name);
printf("PAIR DISTANCE OUTPUT FILE NAME IS %s\n",pair_distance_flnm);
if(!(pair_distance = fopen(pair_distance_flnm,"w")))
 {
 printf("Failed to open pair distance output file: %s\n",pair_distance_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR DISTANCE FILE  $B%Z%"%(%s%I$N5wN%J,I[%U%!%$%k3+$/(B   .pdist2
sprintf(pair_distance2_flnm,"%s_%s.pdist2",arg2,job_name);
printf("PAIR DISTANCE OUTPUT FILE NAME 2 IS %s\n",pair_distance2_flnm);
if(!(pair_distance2 = fopen(pair_distance2_flnm,"w")))
 {
 printf("Failed to open pair distance output file: %s\n",pair_distance2_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR DISTANCE FILE  $B%Z%"%(%s%I$N5wN%J,I[%U%!%$%k3+$/(B   .pdist3
sprintf(pair_distance3_flnm,"%s_%s.pdist3",arg2,job_name);
printf("PAIR DISTANCE OUTPUT FILE NAME 3 IS %s\n",pair_distance3_flnm);
if(!(pair_distance3 = fopen(pair_distance3_flnm,"w")))
 {
 printf("Failed to open pair distance output file: %s\n",pair_distance3_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR DISTANCE FILE  $B%Z%"%(%s%I$N5wN%J,I[%U%!%$%k3+$/(B   .pdist4
sprintf(pair_distance4_flnm,"%s_%s.pdist4",arg2,job_name);
printf("PAIR DISTANCE OUTPUT FILE NAME 4 IS %s\n",pair_distance4_flnm);
if(!(pair_distance4 = fopen(pair_distance4_flnm,"w")))
 {
 printf("Failed to open pair distance output file: %s\n",pair_distance4_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR OVERLAP FILE  $B%Z%"%(%s%I$N%*!<%P!<%i%C%W%U%!%$%k3+$/(B   .pol
sprintf(pair_overlap_flnm,"%s_%s.pol",arg2,job_name);
printf("PAIR OVERLAP FILE NAME IS %s\n",pair_overlap_flnm);
if(!(pair_overlap_file = fopen(pair_overlap_flnm,"w")))
 {
 printf("Failed to open pair overlap file: %s\n",pair_overlap_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR OVERLAP FILE  $B%Z%"%(%s%I$N%*!<%P!<%i%C%W%U%!%$%k(B2$B3+$/(B   .pol2
sprintf(pair_overlap2_flnm,"%s_%s.pol2",arg2,job_name);
printf("PAIR OVERLAP FILE NAME IS %s\n",pair_overlap2_flnm);
if(!(pair_overlap2_file = fopen(pair_overlap2_flnm,"w")))
 {
 printf("Failed to open pair overlap file: %s\n",pair_overlap2_flnm);
 exit(1);
 }
///////////////////////////////////////              OPEN PAIR OVERLAP FILE  $B%Z%"%(%s%I3+$/(B   .pairmap   -pm $B%*%W%7%g%s(B
if(pairmap == 1)                                                                                       // $BL$;HMQ(B
{
sprintf(pairmap_flnm,"%s_%s.pairmap",arg2,job_name);
printf("PAIR MAP OUTPUT FILE NAME 2 IS %s\n",pairmap_flnm);
if(!(pairmap_file = fopen(pairmap_flnm,"w")))
 {
 printf("Failed to open pair map output file: %s\n",pairmap_flnm);
 exit(1);
 }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s@ZJR%j!<%I$N8!=P(B  STEP1.1 //////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// $B%l%U%!%l%s%9$KBP$7$F#38D0J>e$N%_%9%^%C%A$,$"$j!"%j!<%I$N1&H>J,$+:8H>J,$K=8Cf$7$F$$$k%j!<%I(B
printf("DETECTING JUNCTIONS READ\n");

for(i=0;i<num_hit;i++)
 {
 fflag = 0;
 n_match = 0;
 n_mismatch = 0;
 nmm_left = 0;
 nmm_right = 0;
 if(hit_position[i] >= 0)                                         // $B=gJ}8~%R%C%H(B
  {
  if((hit_position[i] + read_len) > refseq_len)                   // $B$O$_=P$9%j!<%I$O=|30(B  ## $B%5%$%/%j%C%/BP1~$G$OCm0U(B
   {
   fflag = 1;
   }
  else
   {
   for(j=0;j<read_len;j++)                                        // $B%j!<%I$H%l%U%!%l%s%9Hf3S(B
    {
    if(read[hit_id[i]].seq[j] == 'N')                             // N $B$N$"$k%j!<%I$O=|30(B
     fflag = 1;
    if(read[hit_id[i]].seq[j] == refseq[hit_position[i]+j])       // $B%^%C%A$7$?(B
     n_match ++;
    else                                                          // $B%^%C%A$7$J$+$C$?(B
     {
     n_mismatch ++;
     if(j < read_len/2)
      nmm_left ++;                                                // $B%j!<%I:8H>J,$N%_%9%^%C%A%+%&%s%H(B
     else
      nmm_right ++;                                               // $B%j!<%I1&H>J,$N%_%9%^%C%A%+%&%s%H(B
     }
    }
   }
  read[hit_id[i]].n_mismatch = n_mismatch;                        // $B%j!<%I$N%_%9%^%C%A?t$r5-O?(B $B%^%C%W0LCV(B 2020 July22
/////////////////////////////////////////////////////
//  if(n_mismatch <= 3)
   {
   for(j=0;j<read_len;j++)
    {
    pos_Base[hit_position[i]+j] ++;
    switch(read[hit_id[i]].seq[j])
     {
     case 'A':
       pos_A[hit_position[i]+j] ++;
       break;
     case 'T':
       pos_T[hit_position[i]+j] ++;
       break;
     case 'G':
       pos_G[hit_position[i]+j] ++;
       break;
     case 'C':
       pos_C[hit_position[i]+j] ++;
       break;
     case 'a':
       pos_A[hit_position[i]+j] ++;
       break;
     case 't':
       pos_T[hit_position[i]+j] ++;
       break;
     case 'g':
       pos_G[hit_position[i]+j] ++;
       break;
     case 'c':
       pos_C[hit_position[i]+j] ++;
       break;
     }
    }
   }

  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if((fflag == 0) && ((nmm_left >= 5) && (nmm_right >= 5))) // $B%_%9%^%C%A$,:81&H>J,$$$:$l$K$b#58D0J>e(B   June 16 2020
   {
   fprintf(mmp_read_file,"%s",read[hit_id[i]].t1);
   fprintf(mmp_read_file,"%s",read[hit_id[i]].seq);
   fprintf(mmp_read_file,"%s",read[hit_id[i]].t2);
   fprintf(mmp_read_file,"%s",read[hit_id[i]].quality);
   }
  else
   {
   fprintf(reg_read_file,"%s",read[hit_id[i]].t1);
   fprintf(reg_read_file,"%s",read[hit_id[i]].seq);
   fprintf(reg_read_file,"%s",read[hit_id[i]].t2);
   fprintf(reg_read_file,"%s",read[hit_id[i]].quality);
   }
  if((fflag == 0) && ((nmm_left >= 5) || (nmm_right >= 5))) // $B%_%9%^%C%A$,:81&H>J,$$$:$l$K$b#58D0J>e(B   June 16 2020
   {
   fprintf(mm2_read_file,"%s",read[hit_id[i]].t1);
   fprintf(mm2_read_file,"%s",read[hit_id[i]].seq);
   fprintf(mm2_read_file,"%s",read[hit_id[i]].t2);
   fprintf(mm2_read_file,"%s",read[hit_id[i]].quality);
   }
  else
   {
   fprintf(rg2_read_file,"%s",read[hit_id[i]].t1);
   fprintf(rg2_read_file,"%s",read[hit_id[i]].seq);
   fprintf(rg2_read_file,"%s",read[hit_id[i]].t2);
   fprintf(rg2_read_file,"%s",read[hit_id[i]].quality);
   }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  if((fflag == 0) && (n_mismatch > mm_thresh) && ((nmm_left == 0) || (nmm_right == 0))) // $B%_%9%^%C%A$,(Bthresholod$B0J>e$G!":81&H>J,$$$:$l$+$K0l8D$b$J$$(B
   {
   read[hit_id[i]].junction_likelyhood = 1;                                             // $B%8%c%s%/%7%g%sE*$G$"$k$HH=Dj(B
   junction_count ++;
   fprintf(junction_out,"%10d %10d %10d\n",i,hit_position[i],hit_id[i]);
   fprintf(junction_out,"MATCH %3d MISMATCH %3d MM_LEFT %3d MM_RIGHT %3d\n",
             n_match,n_mismatch,nmm_left,nmm_right);
   if(nmm_left == 0)                   // mismatch $B3+;OE@$rC5$9(B $B:8$+$i(B
    {
    for(j=read_len/2;j<read_len;j++)   // $B$^$sCf$+$i%A%'%C%/(B 
     {
     if(read[hit_id[i]].seq[j] != refseq[hit_position[i]+j])
      {
      read[hit_id[i]].mismatch_start_point = j;                                       // $B%j!<%I>e$N%_%9%^%C%A3+;OE@(B
      read[hit_id[i]].mismatch_start_point_on_genome = (hit_position[i]+1) + j;       // $B%2%N%`>e$N%_%9%^%C%A3+;OE@(B
      break;
      }
     }
    read[hit_id[i]].mismatch_seq = (char *)malloc(sizeof(char)*(read_len));           // $B%_%9%^%C%AG[Ns$N5-O?(B
    if(read[hit_id[i]].mismatch_seq == NULL)
     {
     printf("Failed to allocate memory for mismatch sequence\n");
     exit(1);
     }
    for(j=0;j<read_len;j++)                                                           // Initialize mismatch sequence
     read[hit_id[i]].mismatch_seq[j] = '\0';                                          // Feb.7 2017
    strcpy(read[hit_id[i]].mismatch_seq,&read[hit_id[i]].seq[read[hit_id[i]].mismatch_start_point]);
    read[hit_id[i]].mismatch_seq[strlen(read[hit_id[i]].mismatch_seq)-1] = '\0';
    }
   else
    {
    if(nmm_right == 0)                 // mismatch $B3+;OE@$rC5$9(B $B1&$+$i(B
     {
     for(j=read_len-1;j>=0;j--)
      {
      if(read[hit_id[i]].seq[j] != refseq[hit_position[i]+j])
       {
       read[hit_id[i]].mismatch_start_point = -j;
       read[hit_id[i]].mismatch_start_point_on_genome = -((hit_position[i]+1) + j);
       break;
       }
      }
      read[hit_id[i]].mismatch_seq = (char *)malloc(sizeof(char)*(read_len));         // $B%_%9%^%C%AG[Ns$N5-O?(B
      if(read[hit_id[i]].mismatch_seq == NULL)
       {
       printf("Failed to allocate memory for mismatch sequence\n");
       exit(1);
       }
      for(k=0;k<=abs(read[hit_id[i]].mismatch_start_point);k++)
       {
       read[hit_id[i]].mismatch_seq[k] = complement_char(read[hit_id[i]].seq[abs(read[hit_id[i]].mismatch_start_point) - k]);
       }
      read[hit_id[i]].mismatch_seq[abs(read[hit_id[i]].mismatch_start_point)+1] = '\0';
     }
    }
   fprintf(junction_out,"MISMATCH START AT %5d ON READ AND %10d ON GENOME# %s\n",read[hit_id[i]].mismatch_start_point,
                                                               read[hit_id[i]].mismatch_start_point_on_genome,
                                                               read[hit_id[i]].mismatch_seq);
   for(j=0;j<read_len;j++)                                                           // $B%R%C%H0LCV$N%l%U%!%l%s%9$=$N$^$^(B $B%W%j%s%H(B
    {
    fprintf(junction_out,"%c",refseq[hit_position[i]+j]);
    }
   fprintf(junction_out,"\n");
   for(j=0;j<read_len;j++)                                                           // $B%j!<%I$=$N$^$^(B $B%W%j%s%H(B
    {
    fprintf(junction_out,"%c",read[hit_id[i]].seq[j]);
    }
   fprintf(junction_out,"\n");
   for(j=0;j<read_len;j++)                                                           // $B%j!<%I$H%l%U%!%l%s%9Hf3S$r%W%j%s%H(B
    {
    if(read[hit_id[i]].seq[j] == refseq[hit_position[i]+j])
     fprintf(junction_out," ");
    else
     fprintf(junction_out,"*");
    }
   fprintf(junction_out,"\n");
   }
  }
 else                                                                                // $B5UJ}8~%R%C%H(B
  {
   {
   if((abs(hit_position[i]) + read_len) > refseq_len)
    fflag = 1;
   else
    {
    for(j=0;j<read_len;j++)                                                          // $B%j!<%I$H%l%U%!%l%s%9Hf3S(B
     {
     if(read[hit_id[i]].seq[j] == 'N')
      fflag = 1;
     if(complement_char(read[hit_id[i]].seq[read_len-j-1]) == (refseq[abs(hit_position[i])+j]))
      n_match ++;
     else
      {
      n_mismatch ++;
      if(j < read_len/2)
       nmm_left ++;
      else
       nmm_right ++;
      }
     }
    }
  read[hit_id[i]].n_mismatch = n_mismatch;   // $B%j!<%I$N%_%9%^%C%A?t$r5-O?!!(B020 July22

  if(n_mismatch <= 3)
   {
////////////////////////////////////////////////////////////2020 July      -so $B%*%W%7%g%s(B SNP$B$N8!=P$N$?$a$K(B $B%l%U%!%l%s%93F0LCV$N%j!<%I$N(BATGC$B?t$r5-O?(B
//   for(j=0;j<read_len;j++)
   for(j=3;j<read_len-3;j++)
    {    
    pos_Base[abs(hit_position[i])+j] ++;
    switch(complement_char(read[hit_id[i]].seq[read_len-j-1]))
     {    
     case 'A': 
       pos_A[abs(hit_position[i])+j] ++;
       break;
     case 'T': 
       pos_T[abs(hit_position[i])+j] ++;
       break;
     case 'G': 
       pos_G[abs(hit_position[i])+j] ++;
       break;
     case 'C': 
       pos_C[abs(hit_position[i])+j] ++;
       break;
     case 'a': 
       pos_A[abs(hit_position[i])+j] ++;
       break;
     case 't': 
       pos_T[abs(hit_position[i])+j] ++;
       break;
     case 'g': 
       pos_G[abs(hit_position[i])+j] ++;
       break;
     case 'c': 
       pos_C[abs(hit_position[i])+j] ++;
       break;
     }    
    }    
   }
////////////////////////////////////////////////////////////2020 July      -so $B%*%W%7%g%s(B SNP$B$N8!=P$N$?$a$K(B $B%l%U%!%l%s%93F0LCV$N%j!<%I$N(BATGC$B?t$r5-O?(B

  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  if((fflag == 0) && ((nmm_left >= 5) && (nmm_right >= 5))) // $B%_%9%^%C%A$,:81&H>J,$$$:$l$K$b#58D0J>e(B   June 16 2020
   {
   fprintf(mmp_read_file,"%s",read[hit_id[i]].t1);
   fprintf(mmp_read_file,"%s",read[hit_id[i]].seq);
   fprintf(mmp_read_file,"%s",read[hit_id[i]].t2);
   fprintf(mmp_read_file,"%s",read[hit_id[i]].quality);
   }
  else
   {
   fprintf(reg_read_file,"%s",read[hit_id[i]].t1);
   fprintf(reg_read_file,"%s",read[hit_id[i]].seq);
   fprintf(reg_read_file,"%s",read[hit_id[i]].t2);
   fprintf(reg_read_file,"%s",read[hit_id[i]].quality);
   }
  if((fflag == 0) && ((nmm_left >= 5) || (nmm_right >= 5))) // $B%_%9%^%C%A$,:81&H>J,$$$:$l$K$b#58D0J>e(B   June 16 2020
   {
   fprintf(mm2_read_file,"%s",read[hit_id[i]].t1);
   fprintf(mm2_read_file,"%s",read[hit_id[i]].seq);
   fprintf(mm2_read_file,"%s",read[hit_id[i]].t2);
   fprintf(mm2_read_file,"%s",read[hit_id[i]].quality);
   }
  else
   {
   fprintf(rg2_read_file,"%s",read[hit_id[i]].t1);
   fprintf(rg2_read_file,"%s",read[hit_id[i]].seq);
   fprintf(rg2_read_file,"%s",read[hit_id[i]].t2);
   fprintf(rg2_read_file,"%s",read[hit_id[i]].quality);
   }
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   if((fflag == 0) && (n_mismatch > mm_thresh) && ((nmm_left == 0) || (nmm_right == 0))) // $B%_%9%^%C%A$,(Bthresholod$B0J>e$G!":81&H>J,$$$:$l$+$K0l8D$b$J$$(B
    {
    read[hit_id[i]].junction_likelyhood = 1;
    junction_count ++;

    fprintf(junction_out,"%10d %10d %10d\n",i,hit_position[i],hit_id[i]);
    fprintf(junction_out,"MATCH %3d MISMATCH %3d MM_LEFT %3d MM_RIGHT %3d\n",
            n_match,n_mismatch,nmm_left,nmm_right);

    if(nmm_left == 0)                                                             // mismatch $B3+;OE@$rC5$9(B $B:8$+$i(B
     {
     for(j=0;j<read_len;j++)
      {
      if(complement_char(read[hit_id[i]].seq[read_len-j-1]) != (refseq[abs(hit_position[i])+j]))
       {
       read[hit_id[i]].mismatch_start_point = j;
       read[hit_id[i]].mismatch_start_point_on_genome = abs(hit_position[i]) + j + 1;
       break;
       }
      }
      read[hit_id[i]].mismatch_seq = (char *)malloc(sizeof(char)*(read_len));     // mismatch$BG[Ns$N5-O?(B
       if(read[hit_id[i]].mismatch_seq == NULL)
       {
       printf("Failed to allocate memory for mismatch sequence\n");
       exit(1);
       }
     for(k=0;k<read_len-read[hit_id[i]].mismatch_start_point;k++)
      {
       read[hit_id[i]].mismatch_seq[k] = 
              complement_char(read[hit_id[i]].seq[read_len-abs(read[hit_id[i]].mismatch_start_point)-k-1]); 
      }
     read[hit_id[i]].mismatch_seq[read_len-abs(read[hit_id[i]].mismatch_start_point)] = '\0';
     }
    else
     {
     if(nmm_right == 0)                                                          // mismatch $B3+;OE@$rC5$9(B $B1&$+$i(B
      {
      for(j=read_len/2;j>=0;j--)
       {
       if(complement_char(read[hit_id[i]].seq[read_len-j-1]) != (refseq[abs(hit_position[i])+j]))
        {
        read[hit_id[i]].mismatch_start_point = -j;
        read[hit_id[i]].mismatch_start_point_on_genome = -(abs(hit_position[i]) + j+1);
        break;
        }
       }
      read[hit_id[i]].mismatch_seq = (char *)malloc(sizeof(char)*(read_len));    // mismatch$BG[Ns$N5-O?(B
      if(read[hit_id[i]].mismatch_seq == NULL)
       {
       printf("Failed to allocate memory for mismatch sequence\n");
       exit(1);
       }
      for(k=0;k<read_len-abs(read[hit_id[i]].mismatch_start_point);k++)
       {
       read[hit_id[i]].mismatch_seq[k] = 
                read[hit_id[i]].seq[(read_len-abs(read[hit_id[i]].mismatch_start_point))+k-1];
       }
      read[hit_id[i]].mismatch_seq[abs(read[hit_id[i]].mismatch_start_point)+1] = '\0';
      }
     }
   
    fprintf(junction_out,"MISMATCH START AT %5d ON READ AND %10d ON GENOME# %s\n",read[hit_id[i]].mismatch_start_point,
                                                              read[hit_id[i]].mismatch_start_point_on_genome,
                                                              read[hit_id[i]].mismatch_seq);

    for(j=0;j<read_len;j++)                                                    // $B%R%C%H0LCV$N%l%U%!%l%s%9$=$N$^$^(B
     {
     fprintf(junction_out,"%c",refseq[abs(hit_position[i])+j]);
     }
    fprintf(junction_out,"\n");
    for(j=0;j<read_len;j++)                                                    // $B%j!<%I$=$N$^$^(B
     {
     fprintf(junction_out,"%c",read[hit_id[i]].seq[j]);
     }
    fprintf(junction_out,"\n");
    for(j=0;j<read_len;j++)                                                    // $B%j!<%I$N%j%P!<%9%3%s%W%j(B
     {
     fprintf(junction_out,"%c",complement_char(read[hit_id[i]].seq[read_len-j-1]));
     }
    fprintf(junction_out,"\n");
    for(j=0;j<read_len;j++)                                                    // $B%j!<%I$H%l%U%!%l%s%9Hf3S(B
     {
     if(complement_char(read[hit_id[i]].seq[read_len-j-1]) == (refseq[abs(hit_position[i])+j]))
      fprintf(junction_out," ");
     else
      fprintf(junction_out,"*");
     }
    fprintf(junction_out,"\n");
    }
   }
  }
 }

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////// $B%_%9%^%C%A3+;OE@$N%2%N%`$X$N%^%C%W(B STEP1.2    //////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////// $B;2>H%2%N%`>e3F0LCV$G$N@ZJR$N%+%&%s%H(B  position_count_plus[], position_count_minus[]
int temp_position;

for(i=0;i<num_hit;i++)              // $B%2%N%`>e$N3F0LCV$G%_%9%^%C%A3+;OE@$H$J$C$F$$$k%j!<%I$r%+%&%s%H(B
 {
 temp_position = read[hit_id[i]].mismatch_start_point_on_genome;
 if((abs(temp_position) <= refseq_len))
  {
  if(temp_position < 0)                        // $BIiCM(B  position_count_minus[]
   position_count_minus[abs(temp_position)] ++;
  else                                         // $B@5CM(B  position_count_plus[]
   position_count_plus[temp_position] ++;
  }
 }
///////////////////////////////////////////////////// $B3F%2%N%`0LCV$G%_%9%^%C%A3+;OE@$H$J$C$F$$$k%j!<%I?t(B
int more_than2  = 0;
int more_than5  = 0;
int more_than10 = 0;
for(i=0;i<refseq_len;i++)
 {
 if(position_count_plus[i] + position_count_minus[i] >= 1)
  {
  num_jcs ++;
  if(position_count_plus[i] + position_count_minus[i] >= 2)
   {
   more_than2 ++;
   if(position_count_plus[i] + position_count_minus[i] >= 5)
    {
    more_than5 ++;
    if(position_count_plus[i] + position_count_minus[i] >= 8)
     more_than10 ++;
    }
   }
  }
 }

printf("NUMBER OF JUNCTIONS ARE                          %10d\n",junction_count);
printf("NUMBER OF JUNCTION POSITIONS ARE                 %10d\n",num_jcs);
printf("NUMBER OF POSITION WITH MORE THAN 2 JUNCTION ARE %10d\n",more_than2);
printf("NUMBER OF POSITION WITH MORE THAN 5 JUNCTION ARE %10d\n",more_than5);
printf("NUMBER OF POSITION WITH MORE THAN 10JUNCTION ARE %10d\n",more_than10);

num_jcs = 0;
for(i=0;i<refseq_len;i++) // $B%_%9%^%C%A3+;OE@$N$"$k%2%N%`%]%8%7%g%s$N?t$@$1%8%c%s%/%7%g%s%/%i%9%?$,$"$k$H$9$k(B
 {
 if(position_count_plus[i] >= 1)
  num_jcs ++;
 if(position_count_minus[i] >= 1)
  num_jcs ++;
 }                                                                  // +/-
printf("NUMBER OF JUNCTION POSITIONS +/- ARE             %10d\n",num_jcs);
                                // $B%8%c%s%/%7%g%s%j!<%I$N?t(B
                                // $B%2%N%`>e$G%_%9%^%C%A3+;OE@$,(B2,5,10$B8D0J>e%@%V$C$F$$$k=j$N%+%&%s%H!"?t(B
///////////////////////////////////////////////////// 

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////  $B%8%c%s%/%7%g%s%/%i%9%?MQ%G!<%?9=B$BN(Bjcs$B$N=`Hw(B STEP1.3   /////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////  $B%8%c%s%/%7%g%s%/%i%9%?=i4|2=(B   MARK_JCS
jcs = (junction_cluster_info *)malloc(sizeof(junction_cluster_info)*(num_jcs+10)); // $B%8%c%s%/%7%g%s%/%i%9%?%a%b%j3NJ](B
                                // $BF1$8%_%9%^%C%A3+;OE@$r6&M-$9$k%8%c%s%/%7%g%s$N=8$^$j(B
                                // $B$N>pJs$r0];}$9$k$?$a$N9=B$BN(B
if(jcs == NULL)
 {
 printf("Failed to allocate memory for junction cluster\n");
 exit(1);
 }

for(i=0;i<num_jcs+10;i++)
 {
 jcs[i].total_mismatch = 0;
 jcs[i].shortest_mm_len = 0;
 jcs[i].longest_mm_len = 0;
 jcs[i].average_mm_len = 0;
 jcs[i].flag1          = 0;
 jcs[i].num_ireg_pair  = 0;
 jcs[i].longest_id     = MAX_INT;
 }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////  $B%8%c%s%/%7%g%s%/%i%9%?$N@8@.(B STEP1.4         /////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

cc = 0;                         // $B%8%c%s%/%7%g%s%/%i%9%?$N%+%&%s%?(B       $B%W%i%9(B $B%^%$%J%9J}8~$NJ,N%(B
for(i=0;i<refseq_len;i++)       // $B%l%U%!%l%s%9G[NsD9>e$rAv$k%k!<%W(B
 { 
 if(position_count_plus[i] >= 1)     // $B%W%i%9J}8~$N%_%9%^%C%A3+;OE@$,0l$D$G$b$"$l$P(Bjcc$B%/%i%9%?$r:n$k(B
  {
  jcs[cc].n_member    = 0;           // $B%8%c%s%/%7%g%s%/%i%9%?$N%j!<%I%a%s%P!<?t(B
  jcs[cc].n_exclude   = 0;           // $B%8%c%s%/%7%g%s%/%i%9%?$N%j!<%I%a%s%P!<$+$i:G8e$K=|30$9$k%a%s%P!<$N?t(B
  jcs[cc].hit_id      = (int *)malloc(sizeof(int)*(position_count_plus[i]+1));
                                     // $B%8%c%s%/%7%g%s%/%i%9%?$N%j!<%I%a%s%P!<%j%9%H$N5-21NN0h$r3NJ](B
  if(jcs[cc].hit_id == NULL)
   {
   printf("Failed to allocate memory for junction cluster hit id list\n");
   exit(1);
   }
  position_address_plus[i] = cc;     // $B%2%N%`G[Ns>e$N0LCV$K(Bjcc$B$N(Bid$B$r3d$j?6$k(B 
                                     // $B$3$NCM$r;2>H$9$l$P$=$3$K$"$k%8%c%s%/%7%g%s%/%i%9%?$N(Bid$B$,$o$+$k(B
  cc++;
  }
 if(position_count_minus[i] >= 1)     // $B%^%$%J%9J}8~$N%_%9%^%C%A3+;OE@$,0l$D$G$b$"$l$P(Bjcc$B%/%i%9%?$r:n$k(B
  {
  jcs[cc].n_member    = 0;           // $B%8%c%s%/%7%g%s%/%i%9%?$N%j!<%I%a%s%P!<?t(B
  jcs[cc].hit_id      = (int *)malloc(sizeof(int)*(position_count_minus[i]+1));
                                     // $B%8%c%s%/%7%g%s%/%i%9%?$N%j!<%I%a%s%P!<%j%9%H$N5-21NN0h$r3NJ](B
  if(jcs[cc].hit_id == NULL)
   {
   printf("Failed to allocate memory for junction cluster hit id list\n");
   exit(1);
   }
  position_address_minus[i] = cc;     // $B%2%N%`G[Ns>e$N0LCV$K(Bjcc$B$N(Bid$B$r3d$j?6$k(B 
                                     // $B$3$NCM$r;2>H$9$l$P$=$3$K$"$k%8%c%s%/%7%g%s%/%i%9%?$N(Bid$B$,$o$+$k(B
  cc++;
  }
 }
/////////////////////////////////////////////////////  +/-

///////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?$N%j!<%I%a%s%P?t$N%+%&%s%H$H%j!<%I%a%s%PEPO?(B
int pat;
for(i=0;i<num_hit;i++)          // $B%j!<%I$N%R%C%H?t$@$1Av$k%k!<%W(B
 {
 if(read[hit_id[i]].junction_likelyhood == 1)      // $B$=$N%j!<%I$,%8%c%s%/%7%g%s%j!<%I$J$i(B
  {
  temp_position = read[hit_id[i]].mismatch_start_point_on_genome; // $B$=$N%j!<%I$N%_%9%^%C%A%9%?!<%H%]%$%s%H(B
  if(temp_position >= 0)                                          // $B%_%9%^%C%A3+;OE@$NJ}8~$,@5(B
   {
   pat = position_address_plus[abs(temp_position)];               // $B$=$N0LCV$K3d$jEv$F$i$l$?%8%c%s%/%7%g%s%/%i%9%?(BID : pat
   if((abs(temp_position) <= refseq_len))
    {
    jcs[pat].hit_id[jcs[pat].n_member] = i;             // $B%8%c%s%/%7%g%s%/%i%9%?$K%j!<%I$rEPO?(B
    jcs[pat].n_member ++;                               // $B%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P?t$r%$%s%/%j%a%s%H(B
    }
   }
  else                                                            // $B%_%9%^%C%A3+;OE@$NJ}8~$,Ii(B
   {
   temp_position = read[hit_id[i]].mismatch_start_point_on_genome;
   pat = position_address_minus[abs(temp_position)];               // $B$=$N0LCV$K3d$jEv$F$i$l$?%8%c%s%/%7%g%s%/%i%9%?(BID : pat
   if((abs(temp_position) <= refseq_len))
    {
    jcs[pat].hit_id[jcs[pat].n_member] = i;             // $B%8%c%s%/%7%g%s%/%i%9%?$K%j!<%I$rEPO?(B
    jcs[pat].n_member ++;                               // $B%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P?t$r%$%s%/%j%a%s%H(B
    }
   }
  }
 }
///////////////////////////////////////////////////// +/-
///////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?Fb$N%_%9%^%C%AG[Ns$N:G$bC;$$$b$N$dD9$$$b$N$rC5$9(B
///////////////////////////////////////////////////// $B$3$N;~E@$G%8%c%s%/%7%g%s%/%i%9%?$O%2%N%`>e%_%9%^%C%A3+;OE@$r6&M-$9$k%8%c%s%/%7%g%s%j!<%I$N=8$^$j(B
int shortest_len;
int longest_len;
int longest_id;
int total_len;
int temp_len;
int max_cluster_size = 0; // $B0lHV%a%s%P?t$NB?$$%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P!<?t(B
for(i=0;i<num_jcs;i++)    // $BA4%8%c%s%/%7%g%s%/%i%9%?$N?t$N%k!<%W(B
 {
 if(jcs[i].n_member > max_cluster_size)
  max_cluster_size = jcs[i].n_member;
 shortest_len = MAX_INT;
 longest_len  = 0;
 total_len    = 0;
 flag = 0;
 for(j=0;j<jcs[i].n_member;j++)   // $B%8%c%s%/%7%g%s%/%i%9%?$N3F%a%s%P!<$N%k!<%W(B  $B%a%s%P!<Fb$G$N:GBg:G>.(B
  {
  temp_len = strlen(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
  if(temp_len < shortest_len)  // $B3F%j!<%I$N%_%9%^%C%AG[NsD9(B
   shortest_len = temp_len;    // $B$N:GC;$H(B
  if(temp_len > longest_len)
   {
   longest_len = temp_len;     // $B:GD9$ND9$5$H(B
   longest_id  = hit_id[jcs[i].hit_id[j]];                                // $B:GD9$N(BID$B$r(B $B5-O?(B
   }
  total_len += temp_len;       // $B%_%9%^%C%AG[NsD9$NAmOB(B
  for(k=j;k<jcs[i].n_member;k++)           // $B%8%c%s%/%7%g%s%/%i%9%?%a%s%P!<$NAmEv$?$j(B
   {
   mm = compare_mm_seq(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq,read[hit_id[jcs[i].hit_id[k]]].mismatch_seq);
    flag += mm;                                           // jcs$B%a%s%P!<4V$N%_%9%^%C%AG[Ns$NAj0c0LCV$N@Q;;(B
   }
  }
                                                          // $B%8%c%s%/%7%g%s%/%i%9%?$N?.Mj@-$rI>2A$9$k$?$a$K(B
                                                          // $BD9$5!"%_%9%^%C%A?tEy$N%/%i%$%F%j%"$r@_Dj$9$k(B
 jcs[i].total_mismatch  = flag;                           // $B%_%9%^%C%AG[Ns4V$NAmEv$?$j$N%_%9%^%C%A?t$N7W$r%/%i%$%F%j%"#1$H$9$k(B
 jcs[i].shortest_mm_len  = shortest_len;                   // $B0lHVC;$$%_%9%^%C%AG[NsD9(B
 jcs[i].longest_mm_len  = longest_len;                    // $B0lHVD9$$%_%9%^%C%AG[NsD9(B
 jcs[i].average_mm_len  = total_len/jcs[i].n_member;      // $BJ?6Q%_%9%^%C%AG[NsD9(B
 jcs[i].consensus_seq   = (char *)malloc(sizeof(char) * (longest_len + 5));  // jcs$B$N%_%9%^%C%A%3%s%;%s%5%9G[Ns$N5-21NN0h$r3NJ](B
 jcs[i].consensus_seq_i1= (char *)malloc(sizeof(char) * (longest_len + 5));  // jcs$B$N%_%9%^%C%A%3%s%;%s%5%9G[Ns$N5-21NN0h$r3NJ](B
 jcs[i].consensus_seq_i2= (char *)malloc(sizeof(char) * (longest_len + 5));  // jcs$B$N%_%9%^%C%A%3%s%;%s%5%9G[Ns$N5-21NN0h$r3NJ](B
 jcs[i].consensus_depth = (int *)malloc(sizeof(int) * (longest_len + 5));    // jcs$B$N%_%9%^%C%A%3%s%;%s%5%9G[Ns$N0lCW?t$N5-21NN0h$r3NJ](B
 jcs[i].consensus_depth_i2 = (int *)malloc(sizeof(int) * (longest_len + 5));    // jcs$B$N%_%9%^%C%A%3%s%;%s%5%9G[Ns$N0lCW?t$N5-21NN0h$r3NJ](B
 jcs[i].mm_start        = MAX_INT;
 for(j=0;j<longest_len+5;j++)      // $B%3%s%;%s%5%9G[Ns=i4|2=(B
  {
  jcs[i].consensus_seq[j]    = '\0';
  jcs[i].consensus_seq_i1[j] = '\0';
  jcs[i].consensus_seq_i2[j] = '\0';
  jcs[i].consensus_depth[j]  = 0;
  jcs[i].consensus_depth_i2[j]  = 0;
  }
 jcs[i].true_flag = (int *)malloc(sizeof(int) * (jcs[i].n_member+2));  // Mar04_2018
 }
printf("THE LARGEST JUNCTION CLUSTER HAS %4d members\n",max_cluster_size);
/////////////////////////////////////////////////////
for(i=0;i<num_jcs;i++)    // $B%8%c%s%/%7%g%s%/%i%9%?$N?t$N%k!<%W(B        // MAR04_2018   // $B%3%s%;%s%5%9$K40A40lCW$9$k%j!<%I$K(Btrue_flag $B$3$3$O=i4|2=(B 
 {
 for(j=0;j<jcs[i].n_member;j++)
  {
  jcs[i].true_flag[j] = 0;
  }
 }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////// STEP2 $B%_%9%^%C%AG[Ns$+$i%3%s%;%s%5%9$rCj=P$7%2%N%`>e$KC5:w(B  ////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////  $B0l<!%3%s%;%s%5%9G[Ns$NCj=P(B  STEP2.1             //////
/////////////////////////////////////////////////////  consensus_seq_i1                                //////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
int count_A,count_T,count_G,count_C;
for(i=0;i<num_jcs;i++)                // $B%8%c%s%/%7%g%s%/%i%9%??t%k!<%W(B   // $B%_%9%^%C%AG[Ns$NCf$N%3%s%;%s%5%9G[Ns$NCj=P(B 
 {                                    // $BLs(B200$B9T$ND9$$%k!<%W(B
 for(j=0;j<jcs[i].longest_mm_len;j++)      //$B%/%i%9%?Fb$G0lHVD9$$G[NsD9(B      // $B%3%s%;%s%5%9G[Ns:GBgD9$^$G$N%k!<%W(B // $B1v4p0LCV$K$D$$$F$N%k!<%W(B
  {
  count_A = 0; count_T = 0; count_G = 0; count_C = 0;           // A,T,G,C $B$N%+%&%s%?$r=i4|2=(B
  for(k=0;k<jcs[i].n_member;k++)        //$B%/%i%9%?$N%a%s%P?t(B    // $B%8%c%s%/%7%g%s%/%i%9%?%a%s%P?t$N%k!<%W(B
   {                                                            // $B3F%+%i%`$G$N3F1v4p?t$r%+%&%s%H(B   
   if(j < strlen(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq))
    {

    if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'A')
     {
     count_A ++;
     continue;
     }
    if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'T')
     {
     count_T ++;
     continue;
     }
    if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'G')
     {
     count_G ++;
     continue;
     }
    if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'C')
     {
     count_C ++;
     continue;
     }
    }
   }

  if((count_A >= count_T) && (count_A >= count_G) && (count_A >= count_C))  // A $B$,0lHVB?$1$l$P(B
   {
   jcs[i].consensus_seq[j]   = 'A';                           // $B%3%s%;%s%5%9$r(BA$B$H$7(B
   jcs[i].consensus_depth[j] = count_A;                       // A$B$N?t$r?<$5$H$7$F5-O?(B
   continue;
   }
  if((count_T >= count_A) && (count_T >= count_G) && (count_T >= count_C))  // T $B$,0lHVB?$1$l$P(B
   {
   jcs[i].consensus_seq[j] = 'T';                             // $B%3%s%;%s%5%9$r(BT$B$H$7(B
   jcs[i].consensus_depth[j] = count_T;                       // T$B$N?t$r?<$5$H$7$F5-O?(B
   continue;
   }
  if((count_G >= count_T) && (count_G >= count_A) && (count_G >= count_C))  // G $B$,0lHVB?$1$l$P(B
   {
   jcs[i].consensus_seq[j] = 'G';                             // $B%3%s%;%s%5%9$r(BG$B$H$7(B
   jcs[i].consensus_depth[j] = count_G;                       // G$B$N?t$r?<$5$H$7$F5-O?(B
   continue;
   }
  if((count_C >= count_T) && (count_C >= count_A) && (count_C >= count_G))  // C $B$,0lHVB?$1$l$P(B
   {
   jcs[i].consensus_seq[j] = 'C';                             // $B%3%s%;%s%5%9$r(BC$B$H$7(B
   jcs[i].consensus_depth[j] = count_C;                       // C$B$N?t$r?<$5$H$7$F5-O?(B
   continue;
   }
  }

 jcs[i].consensus_seq[jcs[i].longest_mm_len] = '\0';          // $B%3%s%;%s%5%9G[Ns$N:G8e$K%L%kJ8;z$r5M$a$k(B
 strcpy(jcs[i].consensus_seq_i1,jcs[i].consensus_seq);        // consensus_seq_i1$B$rJL$KDj5A$7$FogCM(B(consensus_depth)$B$r2<2s$C$?$H$3$m$G@Z$k(B
 for(j=0;j<strlen(jcs[i].consensus_seq);j++)
  {
  if(jcs[i].consensus_depth[j] <= consensus_depth)            // $B%3%s%;%s%5%9$GogCM!J%G%U%)%k%H#2!K0J>e$N8|$_$,$J$$$H$3$m$+$i@h$O@Z$k(B
   {
   jcs[i].consensus_seq_i1[j] = '\0';           // $B%L%kJ8;zF~$l$k(B
   break;
   }
  }
///////////////////////////////////////////////////// $B%_%9%^%C%A(B $B%3%s%;%s%5%9G[Ns(B consensus_seq_i1 $B$G$-$?(B

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////  $B0l<!%3%s%;%s%5%9$K40A40lCW$9$kG[Ns$r%+%&%s%H$7%U%i%0$r?6$k(B STEP2.2 /////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////// vvvv    2017/11/27 jcs[].n_true_member = $B%3%s%;%s%5%9G[Ns$K0lCW$9$k%j!<%I$N$_$N?t$r%+%&%s%H(B
 char consensus_seq_here[512];   // $B$3$3$G$N%3%s%;%s%5%9G[Ns(B
 char read_seq_here[512];        // $B$3$3$G$N%j!<%IG[Ns(B
 int compare_length;             // $BHf$Y$kD9$5(B
 int compare_flag;               // $BHf3SMQ%U%i%0(B

 jcs[i].n_true_member = 0;
 strcpy(consensus_seq_here,jcs[i].consensus_seq_i1);   // $B$3$3$G$N%3%s%;%s%5%9G[Ns(B  $B8|$_$N%/%i%$%F%j%"$G@Z$C$?$b$N(B
 for(j=0;j<jcs[i].n_member;j++)
  {
  strcpy(read_seq_here,read[hit_id[jcs[i].hit_id[j]]].mismatch_seq); 
  
  if(strlen(consensus_seq_here) < strlen(read_seq_here))
   compare_length= strlen(consensus_seq_here);            // $B%3%s%;%s%5%9D9$N$[$&$,C;$$(B
  else
   compare_length= strlen(read_seq_here);                 // $B%j!<%ID9$NJ}$,C;$$(B

  compare_flag = 0;
  for(k=0;k<compare_length;k++)
   {
   if(consensus_seq_here[k] != read_seq_here[k])          // $B0l<!%3%s%;%s%5%9$H%j!<%IG[Ns$,=E$J$kItJ,$G#1J8;z$G$b0c$($P(B
    {
    compare_flag = 1;
    break;
    }
   }
  if(compare_flag == 0)
   {
   jcs[i].n_true_member ++;                               // $B0l<!%3%s%;%s%5%9%j!<%I$H40A40lCW$9$kG[Ns$NK\?t%+%&%s%H(B
   jcs[i].true_flag[j] = 1;                               // MAR04_2018 $B%3%s%;%s%5%9$K40A40lCW$9$k%j!<%I$K%^!<%/(B
   }
  }
//////////////////////////////////////////////////// ^^^^    2017/11/27 jcs[].n_true_member = $B%3%s%;%s%5%9G[Ns$K0lCW$9$k%j!<%I$N$_$N?t$r%+%&%s%H(B    MARK_A

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////  $BFs<!%3%s%;%s%5%9$N:n@.(B STEP2.3        H30.Apr.8                /////
/////////////////////////////////////////////////////  consensus_seq_i2                                               /////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

 if(strlen(jcs[i].consensus_seq_i1) >= consensus_length)   // $B%3%s%;%s%5%9$ND9$5$r(B -cl ## $B1v4p0J>e$H$9$k(B $B8|$_(B(-cd)$B$O%3%s%;%s%5%9$r@Z$k$H$-$K;H$C$F$$$k(B 
  {                                                        // $B40A40lCW$N%8%c%s%/%7%g%s%j!<%I$,#3K\0J>e$G%a%s%P!<$NH>J,0J>e(B 
  if((jcs[i].n_true_member > 3) && ((((float)jcs[i].n_true_member)/((float)jcs[i].n_member)) > 0.5))
   {
   int longest_len = 0; 
   for(j=0;j<jcs[i].n_member;j++)  // $B%8%c%s%/%7%g%s%/%i%9%?$N:G$bD9$$%a%s%P!<$ND9$5(B $B$r<h$j=P$9(B
    {
    if(jcs[i].true_flag[j] == 1)   // $B0l<!%3%s%;%s%5%9$K40A40lCW$9$k%j!<%I$J$i(B
     {
     if(strlen(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq) > longest_len)
      {
      longest_len = strlen(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
      }
     }
    }
   for(j=0;j<longest_len;j++)      //$B%/%i%9%?Fb$G0lHVD9$$G[NsD9(B      // $B%3%s%;%s%5%9G[Ns:GBgD9$^$G$N%k!<%W(B 
    {    
    count_A = 0; count_T = 0; count_G = 0; count_C = 0;           // A,T,G,C $B$N%+%&%s%?$r=i4|2=(B 
    for(k=0;k<jcs[i].n_member;k++)        //$B%/%i%9%?$N%a%s%P?t(B    // $B%8%c%s%/%7%g%s%/%i%9%?%a%s%P?t$N%k!<%W(B 
     {                                                            // $B3F%+%i%`$G$N3F1v4p?t$r%+%&%s%H(B   
     if(jcs[i].true_flag[k] == 1)   // $B0l<!%3%s%;%s%5%9$K40A40lCW$9$k%j!<%I$J$i(B
      {    
      if(j < strlen(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq))
       {    

       if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'A') 
        {    
        count_A ++;
        continue;
        }    
       if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'T') 
        {    
        count_T ++;
        continue;
        }    
       if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'G') 
        {    
        count_G ++;
        continue;
        }    
       if(read[hit_id[jcs[i].hit_id[k]]].mismatch_seq[j] == 'C') 
        {    
        count_C ++;
        continue;
        }    
       }    
      }    
     }    
    if((count_A >= count_T) && (count_A >= count_G) && (count_A >= count_C))  // A $B$,0lHVB?$1$l$P(B   // $B3F0LCV%3%s%;%s%5%9$N7hDj(B
     {    
     jcs[i].consensus_seq_i2[j]   = 'A';                           // $B%3%s%;%s%5%9$r(BA$B$H$7(B
     jcs[i].consensus_depth_i2[j] = count_A;                       // A$B$N?t$r?<$5$H$7$F5-O?(B 
     continue;
     }    
    if((count_T >= count_A) && (count_T >= count_G) && (count_T >= count_C))  // T $B$,0lHVB?$1$l$P(B 
     {    
     jcs[i].consensus_seq_i2[j] = 'T';                             // $B%3%s%;%s%5%9$r(BT$B$H$7(B
     jcs[i].consensus_depth_i2[j] = count_T;                       // T$B$N?t$r?<$5$H$7$F5-O?(B 
     continue;
     }    
    if((count_G >= count_T) && (count_G >= count_A) && (count_G >= count_C))  // G $B$,0lHVB?$1$l$P(B 
     {    
     jcs[i].consensus_seq_i2[j] = 'G';                             // $B%3%s%;%s%5%9$r(BG$B$H$7(B
     jcs[i].consensus_depth_i2[j] = count_G;                       // G$B$N?t$r?<$5$H$7$F5-O?(B 
     continue;
     }    
    if((count_C >= count_T) && (count_C >= count_A) && (count_C >= count_G))  // C $B$,0lHVB?$1$l$P(B 
      {    
     jcs[i].consensus_seq_i2[j] = 'C';                             // $B%3%s%;%s%5%9$r(BC$B$H$7(B
     jcs[i].consensus_depth_i2[j] = count_C;                       // C$B$N?t$r?<$5$H$7$F5-O?(B 
     continue;
     }    
    }
    jcs[i].consensus_seq_i2[longest_len] = '\0';          // $B%3%s%;%s%5%9G[Ns$N:G8e$K%L%kJ8;z$r5M$a$k(B 

   for(j=0;j<longest_len;j++)
    {
    if(jcs[i].consensus_depth_i2[j] <= consensus_depth2)            // $B%3%s%;%s%5%9$GogCM!J%G%U%)%k%H(B2$B!K0J>e$N8|$_$,$J$$$H$3$m$+$i@h$O@Z$k(B
     {
     jcs[i].consensus_seq_i2[j] = '\0';           // $B%L%kJ8;zF~$l$k(B
     break;
     }
    }
                                    ////////////////////////////////////////////////////////////
                                    // $BFs<!%3%s%;%s%5%9(B consensus_seq_i2 $B$G$-$?(B 
                                    ////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////// MAR04_2018  $B%8%c%s%/%7%g%s%/%i%9%?A*JL$N%/%i%$%F%j%"#2(B 
    char consensus_seq_here[512];   // $B$3$3$G$N%3%s%;%s%5%9G[Ns(B 
    char read_seq_here[512];        // $B$3$3$G$N%j!<%IG[Ns(B 
    int compare_length;             // $BHf$Y$kD9$5(B 
    int compare_flag;               // $BHf3SMQ%U%i%0(B 
    int base_count = 0;             // $BHf3SJ8;zNs$NBP$N?t(B
    int match_count = 0;            // $B%^%C%A$9$k1v4pBP$N?t(B
    strcpy(consensus_seq_here,jcs[i].consensus_seq_i2);   // $B$3$3$G$N%3%s%;%s%5%9G[Ns(B = $BFs<!%3%s%;%s%5%9(B
    for(j=0;j<jcs[i].n_member;j++)
     {    
     strcpy(read_seq_here,read[hit_id[jcs[i].hit_id[j]]].mismatch_seq); 
     if(jcs[i].true_flag[j] == 1)                             // $B@Z$C$?%_%9%^%C%AG[Ns$,A4D9%R%C%H$9$k>l9g$N$_(B 
      {
      if(strlen(consensus_seq_here) < strlen(read_seq_here))
       compare_length= strlen(consensus_seq_here);            // $B%3%s%;%s%5%9D9$N$[$&$,C;$$(B
      else
       compare_length= strlen(read_seq_here);                 // $B%j!<%ID9$NJ}$,C;$$(B

      for(k=0;k<compare_length;k++)
       {
       if(consensus_seq_here[k] == read_seq_here[k])          // $B%3%s%;%s%5%9$H%j!<%I$,%^%C%A$7$?(B
        {
        match_count ++;
        }
       base_count ++;
       }
      }
     }
    jcs[i].match_count = match_count;
    jcs[i].base_count  = base_count;
////////////////////////////////////////////////////////////// MAR04_2018  $B%8%c%s%/%7%g%s%/%i%9%?A*JL$N%/%i%$%F%j%"#2(B
   }
  }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////// STEP2.4 $BFs<!%3%s%;%s%5%9G[Ns$r%l%U%!%l%s%9>e$KC5:w(B       /////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 if(strlen(jcs[i].consensus_seq_i2) > index_length)  // $B%3%s%;%s%5%9G[NsD9$,%$%s%G%/%9D9(B(6)$B$h$jD9$1$l$P(B
  {
  n_hit = 0;
  for(m=0;m<2;m++)                                   // $B=g:?$H5U:?(B $B$^$:%R%C%H$9$k0LCV$N?t$r%+%&%s%H(B  ROUND 1
   {
   if(m==0)
    strcpy(qseq, jcs[i].consensus_seq_i2);           // $B%3%s%;%s%5%9$r=g:?$H$7$F%l%U%!%l%s%9>e$KC5:w(B
   else
    complement_seq(qseq, jcs[i].consensus_seq_i2);    // $B%3%s%;%s%5%9$r5U:?$H$7$F%l%U%!%l%s%9>e$KC5:w(B
   for(j=0;j<index_length;j++)                       // $B%$%s%G%/%9%5!<%AMQ$N%^%H%j%/%9$r:n$k(B $BJ8;zNs"*?tNs(B
    {
    switch(qseq[j])
     {
     case 'A': mat[j] = 0; break;
     case 'C': mat[j] = 1; break;
     case 'G': mat[j] = 2; break;
     case 'T': mat[j] = 3; break;
     default : mat[j] = 0; break;
     }
    }
   search_index = 0;
   for(j=0;j<index_length;j++)
    search_index += mat[j] * (int)pow(4.0,(double)(index_length-j-1));       // $B%$%s%G%C%/%9CM!!;;=P(B

   hit_pos = MAX_INT;
   for(j=0;j<ils[search_index].n_pos;j++)                                    // $B3:Ev%$%s%G%C%/%9$N0LCV$N?t(B
    {
    start = ils[search_index].pos[j];                                        // $B%$%s%G%C%/%90LCV(B
    if(start < 0)
     continue;
    miss = 0;
    for(k=0;k<strlen(qseq);k++)                     // $B%3%s%;%s%5%9G[Ns$NA4D9$K$D$$$FAv$k%k!<%W(B
     {
     if(refseq[start+k] != qseq[k])
      miss ++;
     }
    if(miss == 0)             // $B40A40lCW(B
     {
     n_hit ++;                // $B$"$k%3%s%;%s%5%9G[Ns$,%2%N%`>e$K%R%C%H$9$k0LCV$N?t%+%&%s%?!<$r%$%s%/%j%a%s%H(B
     }
    }
   }

  jcs[i].hit_pos  = (int *)malloc(sizeof(int) * (n_hit+1));        // $B%2%N%`>e%_%9%^%C%AG[Ns$N%R%C%H0LCV$r5-O?$9$kNN0h3NJ](B
  jcs[i].hit_flag = (int *)malloc(sizeof(int) * (n_hit+1));        // $BAHBX$($N%?%$%W$r5-O?$9$kNN0h3NJ](B  1:pal, 2:del, 3:hmr, 4:ins
  for(m=0;m<n_hit+1;m++)
   jcs[i].hit_flag[m] = 0;

  for(m=0;m<2;m++)            // $B=g:?$H5U:?!!%3%s%;%s%5%9G[Ns$N%2%N%`>e(B $B%R%C%H0LCV$N5-O?(B  ROUND 2
   {
   if(m==0)
    strcpy(qseq, jcs[i].consensus_seq_i2);           // $B%3%s%;%s%5%9$r=g:?$H$7$F%l%U%!%l%s%9>e$KC5:w(B
   else
    complement_seq(qseq, jcs[i].consensus_seq_i2);    // $B%3%s%;%s%5%9$r5U:?$H$7$F%l%U%!%l%s%9>e$KC5:w(B

   for(j=0;j<index_length;j++)
    {
    switch(qseq[j])
     {
     case 'A': mat[j] = 0; break;
     case 'C': mat[j] = 1; break;
     case 'G': mat[j] = 2; break;
     case 'T': mat[j] = 3; break;
     default : mat[j] = 0; break;
     }
    }
   search_index = 0;
   for(j=0;j<index_length;j++)
    search_index += mat[j] * (int)pow(4.0,(double)(index_length-j-1));    // $B%$%s%G%C%/%9CM;;=P(B

   hit_pos = MAX_INT;
   for(j=0;j<ils[search_index].n_pos;j++)                                 // $B3:Ev%$%s%G%C%/%90LCV$N?t(B
    {
    start = ils[search_index].pos[j];                                     // $B%$%s%G%C%/%90LCV(B
    if(start < 0)
     continue;
    miss = 0;
    for(k=0;k<strlen(qseq);k++)                                           // $B%/%'%j!<$NA4D9$K$o$?$C$FAv$k%k!<%W(B
     {
     if(refseq[start+k] != qseq[k])
      miss ++;
     }
    if(miss == 0)             // $B40A40lCW(B
     {
     jcs[i].hit_pos[jcs[i].num_hit] = ils[search_index].pos[j]+1;   // $B%3%s%;%s%5%9G[Ns$N%2%N%`>e%R%C%H0LCV(B
     if(m==1)
      jcs[i].hit_pos[jcs[i].num_hit] = (ils[search_index].pos[j] + strlen(qseq)) * (-1);
     jcs[i].num_hit ++;       // $B%_%9%^%C%A%3%s%;%s%5%9G[Ns$,%2%N%`G[Ns>e$K%R%C%H$7$?>l=j$N?t(B
     }
    }
   }
  }
 }     // $B%8%c%s%/%7%g%s%/%i%9%??t$N%k!<%W(B
///////////////////////////////////////////////////////////////////       $B%8%c%s%/%7%g%s%/%i%9%?$N%_%9%^%C%A3+;OE@$N@_Dj(B $B0lHVL\$N%j!<%I$K$D$$$F(B
for(i=0;i<num_jcs;i++)                                   // $B=q$-D>$7(B2018/4/2
 {
 jcs[i].mm_start = read[hit_id[jcs[i].hit_id[0]]].mismatch_start_point_on_genome;
 }
///////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////// STEP2.5 .jcf$B%U%!%$%k=PNO(B                            //////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?>pJs$N=PNO(B .jcf$B%U%!%$%k(B  $B%G%P%C%0MQ(B
                                                              /// $B%a%s%P?t$N>/$J$$$b$N$b4^$a$?$9$Y$F$N%8%c%s%/%7%g%s%/%i%9%?!!(Bjcc$B$G$OH=Dj:Q$_$N$b$N$@$1$,=P$k(B
if(jcf_out == 1)
 {
 for(i=0;i<num_jcs;i++)
  {
  fprintf(jcsfl_file,"# %5d %6d-%3d C1:%2d C2:%2d C3:%2d C4:%3d: NUM_HIT %5d NUM_MEMBER %5d %10.5f ",cl_count,i,
                            jcs[i].n_member,jcs[i].total_mismatch,jcs[i].shortest_mm_len,jcs[i].longest_mm_len,jcs[i].average_mm_len,jcs[i].num_hit,jcs[i].n_member,
                            (((float)jcs[i].total_mismatch)/((float)jcs[i].n_member)-1));
  fprintf(jcsfl_file,"N_HITS:%5d HITS: ",jcs[i].num_hit);
 
  for(j=0;j<jcs[i].num_hit;j++)
   fprintf(jcsfl_file,"%5d ",jcs[i].hit_pos[j]);
  fprintf(jcsfl_file,"\n");
  for(j=0;j<jcs[i].n_member;j++)
   fprintf(jcsfl_file," - %8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                         read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
  fprintf(jcsfl_file,"                     %s\n",jcs[i].consensus_seq);
  fprintf(jcsfl_file,"                     %s\n",jcs[i].consensus_seq_i1);
  }
 }
///////////////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?%U%!%$%k(B .jcf $B$X$N=PNO(B

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////// STEP2.6 .jco$B%U%!%$%k=PNO(B $BITMW!)(B           /////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////// 2016 Sep. 16 //////////////////
/////////////////    $B$3$3$G$N%3%s%;%s%5%9$r(Bi1$B$+$i(Bi2$B$KJQ99(B        Apr.10 2018
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(jco_out == 1)
 {
int c_length = 0;
int n_identical_seq;
int n_different_seq;
int mflag;
float consensus_ratio;

cl_count = 0;
for(i=0;i<num_jcs;i++)                      ///  $B%8%c%s%/%7%g%s%/%i%9%?!<$K$D$$$F$N%k!<%W(B
 { //////////////////////////////////////////////////////////// $B$^$:%3%s%;%s%5%9$H40A40lCW$9$k%8%c%s%/%7%g%s%/%i%9%?%a%s%P$r%+%&%s%H(B
 c_length = strlen(jcs[i].consensus_seq_i2);                 // $B%3%s%;%s%5%9G[NsD9(B
 n_identical_seq  = 0;                                       // $B40A40lCW$9$k%j!<%I?t(B
 n_different_seq  = 0;                                       // $B40A40lCW$7$J$$%j!<%I?t(B
 for(j=0;j<jcs[i].n_member;j++)                              // $B%8%c%s%/%7%g%s%/%i%9%?%a%s%P!<$K$D$$$F(B
  {
  mflag = 0;                                                 // $B%U%i%0$r=i4|2=(B
  for(k=0;k<c_length;k++)
   {
   if(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq[k] == '\0')  // $B%_%9%^%C%AG[NsKvHx$^$G$-$?$i(B
    break;                                                     // $B%k!<%W=*N;(B
   if(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq[k] != jcs[i].consensus_seq_i2[k])  // $B%3%s%;%s%5%9$H%_%9%^%C%AG[Ns$,0lJ8;z$G$b0c$($P(B
    {
    mflag = 1;                                                 // $B%U%i%0$rN)$F(B
    break;                                                     // $B%k!<%W=*N;(B
    }
   }
  if(mflag == 0)
   n_identical_seq ++;
  else
   n_different_seq ++;
  }
 consensus_ratio = (float)n_identical_seq / (float)jcs[i].n_member;     // $B40A40lCW$N%j!<%I?t$rAm%a%s%P!<?t$G$o$k(B
 if(consensus_ratio < 0.5)                                    // $B%3%s%;%s%5%9G[Ns$H%^%C%A$9$k%_%9%^%C%AG[Ns$,H>J,0J2<$J$i9MN8$7$J$$(B
  {
  continue;                                                   // $B<!$N%8%c%s%/%7%g%s%/%i%9%?$X(B
  }
/////////////////////////////////////////////////////////////////////////MARK_CONSENSUS
 if(jcs[i].num_hit == 1)                                 // $B%8%c%s%/%7%g%s%/%i%9%?$N%3%s%;%s%5%9$,%2%N%`>e$I$3$+$K0l2U=j$@$1%R%C%H$7$F$$$l$P(B
  {
  if(jcs[i].n_member >= 3)                               // $B%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P!<%8%c%s%/%7%g%s?t$,#30J>e$J$i(B MARK
   {
   if(strlen(jcs[i].consensus_seq_i2) >= consensus_length)   // $B%3%s%;%s%5%9$ND9$5$r(B -cl ## $B1v4p0J>e$H$9$k(B $B8|$_$O%3%s%;%s%5%9$r<h$k$H$-$K7h$a$F$"$k(B
    {                            // $BAjF1AHBX$($G$"$k$+$NH=Dj$N$?$a$KAHBX$(E@$NA0$NAjF1G[Ns$r3NG'(B
    ///////////////////////////////$B%8%c%s%/%7%g%sG[Ns#1!'%_%9%^%C%A3+;OE@$ND>A0G[Ns!!AjF1AH$_BX$($N>l9g$N%j!<%IB&$NAjF1G[Ns(B junctionseq1
    if(jcs[i].mm_start > 0)                   // $B%_%9%^%C%AG[Ns=gJ}8~(B
     {
     for(j=0;j<HOMOSEQLEN;j++)
      {
      if(jcs[i].mm_start-j-2 <= 0)            // $B%2%N%`5/E@$h$jA0(B
       {
       junctionseq1[j] = '\0';
       break;
       }
      junctionseq1[j] = complement_char(refseq[jcs[i].mm_start-j-2]);    // $B%_%9%^%C%A3+;OE@D>A0$NG[Ns(B
      }
     }
    else                                     // $B%_%9%^%C%AG[Ns5UJ}8~(B
     {
     for(j=0;j<HOMOSEQLEN;j++)
      {
      if(abs(jcs[i].mm_start)+j >= refseq_len)
       {
       junctionseq1[j] = '\0';
       break;
       }
      junctionseq1[j] = refseq[abs(jcs[i].mm_start)+j];
      }
     }
    ///////////////////////////////$B%8%c%s%/%7%g%sG[Ns#2!'%_%9%^%C%A3+;OE@$ND>A0G[Ns!!AjF1AH$_BX$($N>l9g$N;2>HG[NsB&$NAjF1G[Ns(B junctionseq2
    if(jcs[i].hit_pos[0] > 0)
     {
     for(j=0;j<HOMOSEQLEN;j++)
      {
      if(jcs[i].hit_pos[0]-j-2 <= 0)
       {
       junctionseq2[0].word[j] = '\0';
       break;
       }
      junctionseq2[0].word[j] = complement_char(refseq[jcs[i].hit_pos[0]-j-2]);
      }
     }
    else
     {
     for(j=0;j<HOMOSEQLEN;j++)
      {
      if(abs(jcs[i].hit_pos[0])+j >= refseq_len)
       {
       junctionseq2[0].word[j] = '\0';
       break;
       }
       junctionseq2[0].word[j] = refseq[abs(jcs[i].hit_pos[0])+j];
      }
     }
    fflag = check_homology2(junctionseq1,junctionseq2[0].word);       // check_homology $BLa$jCM(B(fflag)$B$O%8%c%s%/%7%g%sG[Ns$NAjF1It0L$ND9$5(B
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s$N%_%9%^%C%AG[NsA0$NG[Ns$rHf3S$7$F(B
    //////////////////////////////////////////////////////////////////// $BAjF1G[Ns$NEY9g$$$rI>2A(B
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    cl_count ++;       // $B%/%i%9%??t%$%s%/%j%a%s%H(B
    if(((jcs[i].mm_start>0) && (jcs[i].hit_pos[0] > 0)) ||
       ((jcs[i].mm_start<0) && (jcs[i].hit_pos[0] < 0)))            // $B8~$-$,F1$8(B
     mark_direction = 'S';
    else
     mark_direction = 'O';

    if(fflag >= 6)
     mark_homology = 'X';
    else
     if(fflag >= 3)
      mark_homology = 'Y';
     else
      if(fflag >= 1)
       mark_homology = 'W';
      else
       mark_homology = 'Z';
    distance = abs(abs(jcs[i].mm_start)-abs(jcs[i].hit_pos[0]));
    if(distance <= 10)
     mark_distance = 'J';
    else
     if(distance <= 50)
      mark_distance = 'F';
     else
      if(distance <= 100)
       mark_distance = 'H';
      else
       if(distance <= 500)
        mark_distance = 'V';
       else
        if(distance <= 1000)
         mark_distance = 'K';
        else
         mark_distance = 'L';
    if(!((mark_direction == 'S') && (mark_distance == 'J')))
     {
     strcpy(homoseq,junctionseq1);
     homoseq[fflag] = '\0';
     fprintf(jco_file,"%8d %c%c %c %6d %10d %10d %10d %3ld %3d %s\n",
                          i,mark_direction,mark_distance,mark_homology,
                          jcs[i].n_member,jcs[i].mm_start,jcs[i].hit_pos[0],distance,
                          strlen(jcs[i].consensus_seq_i2),fflag,homoseq);
     }
    }
   }
  }
 }
 }
///////////////////////////////////// mark_homology   $BAjF1G[Ns$ND9$5(B
///////////////////////////////////// mark_distance   $BAHBX$(E@4V$N5wN%(B
///////////////////////////////////// $B$3$l$i$rJ]B8$7$F$J$$$N$G%8%c%s%/%7%g%s%/%i%9%?$NI>2A$K$O;H$C$F$J$$!)(B
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////// 2016 Sep. 16 //////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////  $BAH$_49$(%?%$%WH=Dj(B                          STEP3.1      //////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////  ~500$B9T$ND9$$%k!<%W(B
/////////////////////////////////////////////////////  $B%$%s%G%k(BINDEL,$B%Q%j%s%I%m!<%`5U:?(BPAL,$BAjF1AH49(BHR$B$J$I$NH=Dj(B
cl_count = 0;
for(i=0;i<num_jcs;i++)              // $B%8%c%s%/%7%g%s%/%i%9%?$N%k!<%W(B    // ~500$B9T$ND9$$%k!<%W(B
 {
 if(jcs[i].num_hit == 1)                                 // $B%8%c%s%/%7%g%s%/%i%9%?$N%3%s%;%s%5%9$,%2%N%`>e$I$3$+$K0l2U=j$@$1%R%C%H$7$F$$$l$P(B
  {
//  if(jcs[i].n_member > 3)                               // $B%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P!<%8%c%s%/%7%g%s?t$,#30J>e$J$i(B
   {
   if(strlen(jcs[i].consensus_seq_i2) >= consensus_length)   // $B%3%s%;%s%5%9$ND9$5$r(B -cl ## $B1v4p0J>e$H$9$k(B $B8|$_(B(-cd)$B$O%3%s%;%s%5%9$r@Z$k$H$-$K;H$C$F$$$k(B
    {                                                        // $B40A40lCW$N%8%c%s%/%7%g%s%j!<%I$,#3K\0J>e$G%a%s%P!<$NH>J,0J>e(B   // $B$3$N%V%m%C%/$N3g$j(B ~590$B9T(B
    if((jcs[i].n_true_member > 3) && ((((float)jcs[i].n_true_member)/((float)jcs[i].n_member)) > 0.5))
     {                                                                                                 ///////////////////vvvvvvvvvvvvvvvvvvvvvvv $B30B&$NBg$-$J%k!<%W(B
     int longest_len = 0;
     for(j=0;j<jcs[i].n_member;j++)  // $B%8%c%s%/%7%g%s%/%i%9%?$N:G$bD9$$%a%s%P!<$ND9$5(B
      {
      if(jcs[i].true_flag[j] == 1)
       {
       if(strlen(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq) > longest_len)
        {
        longest_len = strlen(read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
        }
       }
      }                              //
     //////////////////////// MARKP                         /////////////// vvvvvvvvvvvvvvvvvvvv  $BFbB&$NBg$-$J%k!<%W(B
     if(jcs[i].base_count != 0)                                           // $BJ,Jl%A%'%C%/(B 0 $B$G$J$$(B
      {
      if(((float)jcs[i].match_count)/((float)jcs[i].base_count) > 0.95)   // $B%3%s%;%s%5%9$H$N0lCW$,(B95%$B0J>e$N%j!<%I$N$_(B
       {
       ///////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?$H$7$F(B jcc$B%U%!%$%k(B $B$K=PNO(B
       cl_count ++;       // $B>r7o$K%^%C%A$7$?%/%i%9%??t%$%s%/%j%a%s%H(B

       if(jcs[i].base_count == 0)    // .jcc $B#19TL\=PNO(B
        {
        fprintf(junction_cluster,"# %5d %6d-%3d C1:%2d C2:%2d C3:%2d C4:%3d:  %8d %5d %5d %5d %5d %8.2f\n",cl_count,i,           
                jcs[i].n_member,jcs[i].total_mismatch,jcs[i].shortest_mm_len,jcs[i].longest_mm_len,jcs[i].average_mm_len,jcs[i].mm_start,
                jcs[i].n_member,jcs[i].n_true_member,
                jcs[i].match_count,jcs[i].base_count,0.01);
        }
       else
        {
        fprintf(junction_cluster,"# %5d %6d-%3d C1:%2d C2:%2d C3:%2d C4:%3d:  %8d %5d %5d %5d %5d %8.2f\n",cl_count,i,           
                jcs[i].n_member,jcs[i].total_mismatch,jcs[i].shortest_mm_len,jcs[i].longest_mm_len,jcs[i].average_mm_len,
                jcs[i].mm_start,jcs[i].n_member,jcs[i].n_true_member,
                jcs[i].match_count,jcs[i].base_count,(((float)jcs[i].match_count)/((float)jcs[i].base_count))*100.0);
        }

       for(j=0;j<jcs[i].n_member;j++)
        {
        if(jcs[i].true_flag[j] == 1)
         fprintf(junction_cluster," + %8d-%11d-%8d %s\n",jcs[i].hit_id[j],hit_id[jcs[i].hit_id[j]],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                 read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
        else
         fprintf(junction_cluster," - %8d-%11d-%8d %s\n",jcs[i].hit_id[j],hit_id[jcs[i].hit_id[j]],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                 read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
        fprintf(jrr_file,"%10d %10d\n",jcs[i].hit_id[j],hit_id[jcs[i].hit_id[j]]);
        }
       fprintf(junction_cluster,"                                 %s\n",jcs[i].consensus_seq); // $B%3%s%;%s%5%9G[Ns!J@Z$kA0!KI=<((B
       fprintf(junction_cluster,"                                 ");
       for(j=0;j<strlen(jcs[i].consensus_seq);j++)
        {
        if(jcs[i].consensus_depth[j] >= 10)                                                    // $B%3%s%;%s%5%98|$_!J0l<!!KI=<((B
         fprintf(junction_cluster,"*");
        else
         fprintf(junction_cluster,"%d",jcs[i].consensus_depth[j]);
        }
       fprintf(junction_cluster,"\n");
       fprintf(junction_cluster,"                                 %s\n",jcs[i].consensus_seq_i1);
       fprintf(junction_cluster,"                                 %s\n",jcs[i].consensus_seq_i2);
       fprintf(junction_cluster,"  MM_START %10d NUM_HIT %10d HIT_POS ",jcs[i].mm_start,jcs[i].num_hit);
       for(j=0;j<jcs[i].num_hit;j++)
        fprintf(junction_cluster," %10d ",jcs[i].hit_pos[j]);
       fprintf(junction_cluster,"\n");
    ///////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?$H$7$F(Bjcc$B%U%!%$%k$K=PNO(B END
 
    ////////////////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?$H$7$F(Bjcs$B%U%!%$%k$K=PNO(B
       fprintf(jcs_file,"%5d %10d ",cl_count,read[hit_id[jcs[i].hit_id[0]]].mismatch_start_point_on_genome);
       for(j=0;j<jcs[i].num_hit;j++)
        {
        if(abs(abs(read[hit_id[jcs[i].hit_id[0]]].mismatch_start_point_on_genome) - abs(jcs[i].hit_pos[j])) < 100)
         {
         fprintf(jcs_file," %10d ",jcs[i].hit_pos[j]);
         }
        else
         {
         fprintf(jcs_file," %10d* ",jcs[i].hit_pos[j]);
         rearrangement_candidate ++;
         }
        }
       fprintf(jcs_file,"\n");
    ////////////////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%s%/%i%9%?$H$7$F(Bjcs$B%U%!%$%k$K=PNO(B
 
       jcs[i].flag1 = 1;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%sG[Ns(B1$B$H(B2$B$N%;%C%H(B
    //                                                                    $BAH$_BX$(E@$NAjF1@-$NI>2A(B
    // $B%_%9%^%C%A3+;OE@$N>eN.$K$"$kG[Ns$,(B         $B%8%c%s%/%7%g%sG[Ns#1!!(B
    // $B%_%9%^%C%AG[Ns%R%C%H0LCV$N>eN.$K$"$kG[Ns$,(B $B%8%c%s%/%7%g%sG[Ns#2(B
    // $BAjF1AH49$G$O#1$H#2$,F1$8$K$J$k(B
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////$B%8%c%s%/%7%g%sG[Ns#1!'%_%9%^%C%A3+;OE@$NG[Ns(B
       if(jcs[i].mm_start > 0)
        {
        for(j=0;j<HOMOSEQLEN;j++)
         {
         if(jcs[i].mm_start-j-2 <= 0)
          {
          junctionseq1[j] = '\0';
          break;
          }
         junctionseq1[j] = complement_char(refseq[jcs[i].mm_start-j-2]); 
         }
        }
       else
        {
        for(j=0;j<HOMOSEQLEN;j++)
         {
         if(abs(jcs[i].mm_start)+j >= refseq_len)
          {
          junctionseq1[j] = '\0';
          break;
          }
         junctionseq1[j] = refseq[abs(jcs[i].mm_start)+j]; 
         }
        }
    ///////////////////////////////$B%8%c%s%/%7%g%sG[Ns#2!'%R%C%H0LCV$NG[Ns(B
       if(jcs[i].num_hit != 0)
        {
        for(k=0;k<jcs[i].num_hit;k++)
         {
         if(jcs[i].hit_pos[k] > 0) 
          {
          for(j=0;j<HOMOSEQLEN;j++)
           {
           if(jcs[i].hit_pos[k]-j-2 <= 0)
            {
            junctionseq2[k].word[j] = '\0';
            break;
            }
           junctionseq2[k].word[j] = complement_char(refseq[jcs[i].hit_pos[0]-j-2]); 
           }
          }
         else
          {
          for(j=0;j<HOMOSEQLEN;j++)
           {
           if(abs(jcs[i].hit_pos[k])+j >= refseq_len)
            {
            junctionseq2[k].word[j] = '\0';
            break;
            }
           junctionseq2[k].word[j] = refseq[abs(jcs[i].hit_pos[k])+j]; 
           }
          }
         }
        }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%sG[Ns(B1$B$H(B2$B$N%;%C%H(B
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////// JUDGEMENT
///////////////////  $B$=$l$>$l$N%8%c%s%/%7%g%s%/%i%9%?$N%2%N%`>e$N%2%N%`>e$N3F%R%C%H0LCV$K$D$$$F!"$I$&$$$&%?%$%W$NE>0\$+$rH=Dj(B
///////////////////  HR:$BAjF1AH$_BX$(!"(BINS:$B%$%s%5!<%7%g%s!"(BDEL:$B%G%j!<%7%g%s!"(BPAL:$B5U0L(B
////////////////////////////////////////////////////////////////////////////////////////////////////////// $B%R%C%H?t%k!<%W(B
       for(j=0;j<jcs[i].num_hit;j++) // $B%_%9%^%C%AG[Ns$N%R%C%H0LCV$=$l$>$l$K$D$$$F(B
        {
        homoseq[0] = '\0';
        pos_diff = abs(abs(jcs[i].hit_pos[j]) - abs(jcs[i].mm_start));                    // $B%_%9%^%C%AG[Ns0LCV$H%R%C%H0LCV$N5wN%(B
        pos_indl = jcs[i].mm_start - jcs[i].hit_pos[j];                                   // $B@dBPCM$r<h$i$J$$:9(B = $B%$%s%G%k$N5wN%(B
        if(((jcs[i].hit_pos[j]>0)&&(jcs[i].mm_start>0)) || ((jcs[i].hit_pos[j]<0)&&(jcs[i].mm_start<0)))
         {
         pos_dir = 1;                                                                     // $B%_%9%^%C%AG[Ns$H%R%C%HG[Ns$N8~$-$,F1$8(B
         }
        else
         {
         pos_dir = -1;                                                                    // $B%_%9%^%C%AG[Ns$H%R%C%HG[Ns$N8~$-$,H?BP(B
         }
//printf("POSPOS %10d %10d %10d\n",jcs[i].hit_pos[j],jcs[i].mm_start,pos_dir);
        flag = 0;
                                                                                       // ### HR CHECK $BAjF1AH49(B
        fflag = check_homology(junctionseq1,junctionseq2[j].word);       // check_homology $BLa$jCM(B(fflag)$B$O%8%c%s%/%7%g%sG[Ns$NAjF1It0L$ND9$5(B
        jcs[i].fflag = fflag;
        if((fflag >= 2) && (fflag != MAX_INT))                                            // HR $B%[%b%m%,%9%j%"%l%s%8%a%s%H$N2DG=@-$r%A%'%C%/(B
         {                                                                                // $BAjF1G[Ns$ND9$5$,#20J>e$J$i(B
         jcs[i].homoseq = (char *)malloc(sizeof(char)*(fflag+5));                         // $B5-21NN0h$r3NJ]$7$F(B
         strncpy(jcs[i].homoseq,junctionseq1,fflag);                                      // $BAH49$N5/$-$F$$$kAjF1G[Ns$rJ]B8(B
         jcs[i].homoseq[fflag] = '\0';                                                    // $BJ8;zNs$N=*$o$j(B
         flag = 3;                                                                        // $BE>0\$N%?%$%W$r#3!JAjF1AH49!K$K@_Dj(B
         num_hr ++;                                                                       // $BAjF1AH49$N?t!J(Bnum_hr$B!K$r%$%s%/%j%a%s%H(B
         }

////////////////////////////////////////////////////////////////////////////////////////

///        if((flag == 0)||(fflag < 8)) // HR$B$G$J$$$+!"(BHR$B$,C;$1$l$PB>$N2DG=@-$b%A%'%C%/(B  // $B>o$K%A%'%C%/$KJQ99(B 2015/12/3
         {
                                                                                          // ### PAL CHECK  $B%Q%j%s%I%m!<%`(B
         if((pos_dir == -1) && (pos_diff < 70))          // $B8~$-$,5U$G(B70$B1v4p0JFb(B $B5U0L8uJd(B
          {
          rev_match = 0;
          fflag = 0;

          for(k=0;k<(pos_diff - 1);k++)           // mm$B3+;OE@$H(Bhit$B0LCV$N4V$NNN0h$G%Q%j%s%I%m!<%`EY$r%A%'%C%/(B
           {
//          fprintf(junction_cluster,"%c %c\n",junctionseq1[k],complement_char(junctionseq1[pos_diff-2-k]));
           if(junctionseq1[k] == complement_char(junctionseq1[pos_diff-2-k]))
            {
            rev_match ++;                         // $BBP1~$9$k0LCV$N?t(B
            if(k<3)
             fflag ++;                            // $BC<$+$i#31v4p0JFb$GBP1~$9$k0LCV$N?t(B
            }
           }

          if((fflag >= 1) && ((float)rev_match/(float)(pos_diff-1)) > 0.25 )   // $BC<$,B7$C$F$F<+J,<+?H$N%j%P!<%9%3%s%W%j%a%s$H$H$J$C$F$$$k1v4p$,(B25%$B0J>e$J$i(B
           {                                                                   // PAL
           flag = 1;
           num_pal ++;
           jcs[i].homoseq = (char *)malloc(sizeof(char)*(pos_diff+10));
           jcs[i].palseq  = (char *)malloc(sizeof(char)*(pos_diff+5));
           strncpy(jcs[i].homoseq,junctionseq1,pos_diff);                      // $BAH49$N5/$-$F$$$k5<;w%Q%j%s%I%m!<%`G[Ns(B
           for(k=0;k<pos_diff;k++)
            {
            if(jcs[i].homoseq[k] == complement_char(jcs[i].homoseq[pos_diff-k-2]))
             jcs[i].palseq[k] = '*';                                           // $B5<;w%Q%j%s%I%m!<%`$NBP1~4X78(B $B!v$,BP1~2U=j(B
            else
             jcs[i].palseq[k] = ' ';
            }
           jcs[i].homoseq[pos_diff-1] = '\0';
           jcs[i].palseq[pos_diff-1] = '\0';
           }
          }
                                                                                       // ### INDEL CHECK  $BA^F~7g<:(B
         if((pos_dir == 1) && (pos_diff < 50))           // $B8~$-(B(pos_dir)$B$,F1$8(B(1) $B$G(B $B0LCV$N:9(B(pos_diff)$B$,(B50$B1v4p0JFb(B   INDEL$B8uJd(B
          {
          if(pos_indl >= 1)                                              // pos_indl$B!J(BMM$B3+;OE@$H(Bhit$B0LCV$N:9!K(B $B$,@5(B          ## INS $B%$%s%5!<%7%g%s(B
           {
           jcs[i].indel = pos_indl;                                      // jcs[].indel$B$KA^F~G[Ns$ND9$5$,F~$k(B
           jcs[i].idlen = pos_diff;                                      // $B7g<:G[Ns$N1v4pD9!!!J@5CM!K(B
           num_ins ++;                                                   // $BA^F~(B(num_ins)$B$N?t$r%$%s%/%j%a%s%H(B
           flag = 4;                                                     // $BAH49$N%?%$%W(B $B#4!!!JA^F~!K(B
           jcs[i].homoseq = (char *)malloc(sizeof(char)*(pos_indl+2));   // $BA^F~G[Ns$N5-21NN0h$r3NJ](B  $B!JJ8;zNs(Bhomoseq$B$rN.MQ(B)
           for(k=0;k<pos_indl;k++)                                       // $B$^$:(B
            {
            jcs[i].homoseq[k] = 'N';                                     // N $B$r5M$a$k(B
            }
           if(jcs[i].mm_start > 0)                                       // $B%_%9%^%C%A3+;OE@$N8~$-$,1&8~$-$J$i(B
            {
            for(k=0;k<pos_indl;k++)
             {
             if(pos_indl-k-1 < consensus_len)                            // $B%_%9%^%C%A%3%s%;%s%5%9G[NsD9$h$jC;$$4V$O(B
              jcs[i].homoseq[k] = jcs[i].consensus_seq[k]; // $B%_%9%^%C%A%3%s%;%s%5%9G[Ns$NBP1~0LCV$NAjJd1v4p$r5M$a$F9T$/(B
             else
              jcs[i].homoseq[k] = 'N';
             }
            jcs[i].homoseq[pos_indl] = '\0';
            }
           else                                                          // $B%_%9%^%C%A3+;OE@$N8~$-$,:88~$-$J$i(B
            {
            consensus_len = strlen(jcs[i].consensus_seq);                // $B%_%9%^%C%A%3%s%;%s%5%9G[Ns$ND9$5$r=P$7$F(B
            for(k=0;k<pos_indl;k++)                                      // 1$BJ8;z$E$D(B
             {
             if(pos_indl-k-1 < consensus_len)                            // $B%_%9%^%C%A%3%s%;%s%5%9G[NsD9$h$jC;$$4V$O(B
              jcs[i].homoseq[k] = complement_char(jcs[i].consensus_seq[pos_indl-k-1]); // $B%_%9%^%C%A%3%s%;%s%5%9G[Ns$NBP1~0LCV$NAjJd1v4p$r5M$a$F9T$/(B
             else                                                        // $B%_%9%^%C%A%3%s%;%s%5%9$h$jD9$$0LCV$G$OA^F~G[Ns$OITL@$J$N$G(B
              jcs[i].homoseq[k] = 'N';                                   // N$B$rCV$/(B
             }
            jcs[i].homoseq[pos_indl] = '\0';
            }
           }
          else                                                           // pos_indlMM$B3+;OE@$H(Bhit$B0LCV$N:9(B $B$,Ii(B (pos_indl < 0) ## DEL$B%G%j!<%7%g%s(B
           {
//        fprintf(del_file,"%d\n",(jcs[i].hit_pos[j] * jcs[i].mm_start));
           jcs[i].indel = pos_indl;                                      // $B7g<:G[Ns$N1v4pD9!!!JIiCM!K(B
           jcs[i].idlen = pos_diff;                                      // $B7g<:G[Ns$N1v4pD9!!!J@5CM!K(B
           num_del ++;                                                   // $B7g<:$N?t(B(num_del)$B$r%$%s%/%j%a%s%H(B
           flag = 2;                                                     // $BAH49$N%?%$%W(B 2 $B!J7g<:!K(B
           }
          }
         }
        jcs[i].hit_flag[j] = flag;                                       // $BAH49$N%?%$%W$r3NDj(B
        }
////////////////////////////////////////////////////////////////////////////////////////////////////////// $B%R%C%H?t%k!<%W!!=*(B

       mindiff = MAX_INT;                     // $BAH$_BX$(E@$,:G$b6a$$$b$N$rA*Br(B
       hitid = -1;
       flag  = 0;
       for(j=0;j<jcs[i].num_hit;j++)          // $B%R%C%H?t$N%k!<%W(B
        {
        pos_diff = abs(abs(jcs[i].hit_pos[j]) - abs(jcs[i].mm_start));
        if((jcs[i].hit_flag[j] != 0) && (pos_diff < mindiff))
         {
         mindiff = pos_diff;
         flag = jcs[i].hit_flag[j];           // $B$=$N%R%C%H$NAH49$N%?%$%W$r!"$3$N%8%c%s%/%7%g%s%/%i%9%?$NAH49%?%$%W$H7h$a$k(B
         hitid = j;                           // hitid $B$K$=$N%R%C%H$N(BID$B$r5-O?(B
         }
        }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////$B%8%c%s%/%7%g%s%/%i%9%?!<(B(.jcc)$B%U%!%$%k$X$N=PNO(B
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//       if(hitid != -1)
//        {
//        if(flag == 1)
//         fprintf(arr_file,"P %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
//        if(flag == 2)
//         fprintf(arr_file,"D %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
//        if(flag == 3)
//         fprintf(arr_file,"H %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
//        if(flag == 4)
//         fprintf(arr_file,"I %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
//        }
//       else
//        {
//        fprintf(arr_file,"U %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
//        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////   2017/11/26  -> 2020 Aug 22 arr$B=PNO$O%8%c%s%/%7%g%s%/%i%9%?H=Dj8e$K0\F0(B

       if(hitid != -1)
        {
        if(flag == 1)               // .pal $B5U0L(B
         {
//         fprintf(junction_cluster," PAIR%d: POS_DIFF = %6d POS_DIR = %2d  PALINDROME  %s\n",j+1,pos_diff,pos_dir,jcs[i].homoseq);
         fprintf(junction_cluster," PAIR%d: POS_DIFF = %6d POS_DIR = %2d  PALINDROME  %s\n",hitid+1,jcs[i].idlen,pos_dir,jcs[i].homoseq);
         fprintf(junction_cluster,"                                                    %s\n",jcs[i].palseq);

/////////////////////////////////////////// Jul 28. 2016 MARKPAL
         for(j=0;j<jcs[i].n_member;j++)
          {
          if(jcs[i].hit_id[j] != MAX_INT)
           {
           if(hit_id[jcs[i].hit_id[j]] > n_pair)
            {
            partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] - n_pair];
            if(partner_id != MAX_INT)
             fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                              partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                              read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
            }
           else
            {
            partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] + n_pair];
            if(partner_id != MAX_INT)
             fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                              partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                              read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
            }
           }
          }
         fprintf(junction_cluster,"                     %s\n\n",jcs[i].consensus_seq);

         //fprintf(pal_file,"P %10d %10d %10d %s\n",abs(jcs[i].mm_start),abs(jcs[i].hit_pos[hitid]),jcs[i].n_true_member,jcs[i].homoseq);
         }
        else
         {
         if(flag == 2)              // .del $B%G%j!<%7%g%s(B
          {
          fprintf(junction_cluster," PAIR%d: POS_DIFF = %6d POS_DIR = %2d %d BASE DELETION  ===",hitid+1,jcs[i].idlen,pos_dir,jcs[i].indel);
          for(k=0;k<abs(pos_diff);k++)
           fprintf(junction_cluster,"#");
          fprintf(junction_cluster,"===\n");
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
         for(j=0;j<jcs[i].n_member;j++)
           {
           if(jcs[i].hit_id[j] != MAX_INT)
            {
            if(hit_id[jcs[i].hit_id[j]] > n_pair)
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] - n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
             else
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] + n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
            }
           }
         fprintf(junction_cluster,"                     %s\n\n",jcs[i].consensus_seq);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
          //fprintf(del_file,"D %5d %10d %10d\n",abs(jcs[i].idlen),abs(jcs[i].mm_start),jcs[i].n_true_member);
          }
         else
          {
          if(flag == 3)             // .hr  $B%[%b%m%,%9%j%"%l%s%8%a%s%H(B
           {
           fprintf(junction_cluster," PAIR%d: POS_DIFF = %6d POS_DIR = %2d  FF = %10d H-REARRANGE >>>%s<<<\n",hitid+1,jcs[i].idlen,pos_dir,jcs[i].fflag,jcs[i].homoseq);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
         for(j=0;j<jcs[i].n_member;j++)
           {
           if(jcs[i].hit_id[j] != MAX_INT)
            {
            if(hit_id[jcs[i].hit_id[j]] > n_pair)
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] - n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
             else
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] + n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
            }
           }
         fprintf(junction_cluster,"                     %s\n\n",jcs[i].consensus_seq);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
           //fprintf(hr_file,"H %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);
           }
          else
           {
           if(flag == 4)            // .ins $B%$%s%5!<%7%g%s(B
            {
            fprintf(junction_cluster," PAIR%d: POS_DIFF = %6d POS_DIR = %2d  %d BASE INSERTION +++%s+++\n",hitid+1,jcs[i].idlen,pos_dir,jcs[i].indel,jcs[i].homoseq);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
         for(j=0;j<jcs[i].n_member;j++)
           {
           if(jcs[i].hit_id[j] != MAX_INT)
            {
            if(hit_id[jcs[i].hit_id[j]] > n_pair)
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] - n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
             else
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] + n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                             partner_id,hit_id[partner_id],hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                             read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
            }
           }
         fprintf(junction_cluster,"                     %s\n\n",jcs[i].consensus_seq);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
            //if(jcs[i].mm_start > 0)
            // fprintf(ins_file,"I %5d %10d %10d %s\n",abs(jcs[i].idlen),jcs[i].mm_start-1,jcs[i].n_true_member,jcs[i].homoseq);
            //else
            // fprintf(ins_file,"I %5d %10d %10d %s\n",abs(jcs[i].idlen),abs(jcs[i].mm_start),jcs[i].n_true_member,jcs[i].homoseq);
            }
           }
          }
         }
        }
       else                         // .unk
        {
        fprintf(junction_cluster," PAIR%d: POS_DIFF = %6d POS_DIR = %2d  FF = %10d UNKNOWN JUNCTION   UUUUUUUUUUU\n",hitid+1,jcs[i].idlen,pos_dir,jcs[i].fflag);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
         for(j=0;j<jcs[i].n_member;j++)
           {
           if(jcs[i].hit_id[j] != MAX_INT)
            {
            if(hit_id[jcs[i].hit_id[j]] > n_pair)
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] - n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
             else
              {
              partner_id = rid_hid[hit_id[jcs[i].hit_id[j]] + n_pair];
              if(partner_id != MAX_INT)
               fprintf(junction_cluster," - %8d-%8d-%8d-%8d-%8d %s\n",jcs[i].hit_id[j],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point_on_genome,
                                                                partner_id,hit_position[jcs[i].hit_id[j]],hit_position[partner_id],
                                                                read[hit_id[jcs[i].hit_id[j]]].mismatch_seq);
              }
            }
           }
         fprintf(junction_cluster,"                     %s\n\n",jcs[i].consensus_seq);
/////////////////////////////////////////// Jul 28. 2016 MARKPAL
        //fprintf(unk_file,"U %10d %10d %10d\n",jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].n_true_member);            // $B$H$j$"$($:#18DL\$N%R%C%H$rI=<((B
        num_unk ++;
        }
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////$B%8%c%s%/%7%g%s%/%i%9%?!<(B(.jcc)$B%U%!%$%k$X$N=PNO(B $B=*(B
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
/////////////////////////////////////////////////////////////////////////////////////////MARK3

///////////////////////////////////////////////////////////////////// $B%8%c%s%/%7%g%sG[NsF1;N$NHf3S!!AjF1G[Ns!&%Q%j%s%I%m!<%`$N8!=P(B $B=*(B
       junctionseq1[HOMOSEQLEN] = '\0';
       fprintf(junction_cluster,"%s\n",junctionseq1);
       for(k=0;k<jcs[i].num_hit;k++)
        {
        junctionseq2[k].word[HOMOSEQLEN] = '\0';
        fprintf(junction_cluster,"%s\n",junctionseq2[k].word);
        }
       fprintf(junction_cluster,"\n");
/////////////////////////////////////////////////////////////////////
//  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
       }
      }
     //////////////////////// MARKP                         /////////////// ^^^^^^^^^^^^^^^^^^^^^
     }                                                                                                   ///////////////////^^^^^^^^^^^^^^^^^^^^^^^
    }                                             // MARKP
   }
  }
 }
printf("Number of cluster with more than 2 members is %6d\n",cl_count);
printf("Number of rearrangement candidate          is %6d\n",rearrangement_candidate);

printf("Number of palindrome    candidate            is %6d\n",num_pal);
printf("Number of homorogous rearrangement candidate is %6d\n",num_hr);
printf("Number of insertion     candidate            is %6d\n",num_ins);
printf("Number of deletion      candidate            is %6d\n",num_del);
printf("Number of unknown junction                   is %6d\n",num_unk);

///MARKMARK  2020 Aug 20 num_jcs $B$OB?$/$N>.$5$J%/%i%9%?$r4^$`$3$H$r3NG'(B
// for(i=0;i<num_jcs;i++)                                                   // $B%8%c%s%/%7%g%s%/%i%9%?$N?t%k!<%W(B
//  printf("ID:%5d NUM_HIT:%5d CONSENSUSi2_LEN:%5lu N_TRUE_MEMBE:%5d N_MEMBER:%5d\n",i,jcs[i].num_hit,strlen(jcs[i].consensus_seq_i2),jcs[i].n_true_member,jcs[i].n_member);

if(snp_only == 0)       // excluded when so= SNP only option is set
 {
 //////////////////////////////////////////////////////////////////////////////////////////////////////////
 /////////////////////////////////////////////////////////  $BAjF1AH$_BX$(>pJs$N@0M}(B  STEP4.1    ////////////
 //////////////////////////////////////////////////////////////////////////////////////////////////////////
 int match_flag = 0;
 int posa,posb;
 int pos1L,pos1R,pos2L,pos2R;
 hrp = (hr_info *)malloc(sizeof(hr_info)*num_hr);    // $BB?$a$K!J(Bhr$B$N?t$@$1!K3NJ](B
 for(i=0;i<num_jcs;i++)
  {
  jcs[i].hr_id = MAX_INT;
  }
 for(i=0;i<num_hr;i++)
  {
  hrp[i].jcc1 = -1;
  hrp[i].jcc2 = -1;
  }
 ////////////////////////////
 for(i=0;i<num_jcs;i++)
  {
  mindiff = MAX_INT;                      // $BAH$_BX$(E@$,:G$b6a$$$b$N$rA*Br(B
  hitid = -1;
  flag  = 0;
  for(j=0;j<jcs[i].num_hit;j++)           // $BAH$_49$(@h$N%R%C%H0LCV(B
   {
   pos_diff = abs(abs(jcs[i].hit_pos[j]) - abs(jcs[i].mm_start));
   if((jcs[i].hit_flag[j] != 0) && (pos_diff < mindiff))
    {
    mindiff = pos_diff;                
    flag = jcs[i].hit_flag[j];           // $B$=$N%R%C%H$NAH49$N%?%$%W$r!"$3$N%8%c%s%/%7%g%s%/%i%9%?$NAH49%?%$%W$H7h$a$k(B
    hitid = j;                           // hitid $B$K$=$N%R%C%H$N(BID$B$r5-O?(B
    }
   }
  if((flag == 3) && (jcs[i].hr_id == MAX_INT))   // hr($BAjF1AH$_49$(7?(B)
   {
   hrp[num_hrp].homolen = strlen(jcs[i].homoseq);            // $BAjF1G[Ns$ND9$5(B homolen
   if(abs(jcs[i].mm_start) < abs(jcs[i].hit_pos[hitid]))     // $BAjF1G[Ns$N>l=j(B posa$B$H(Bposb
    {
    hrp[num_hrp].posa = jcs[i].mm_start;
    hrp[num_hrp].posb = jcs[i].hit_pos[hitid];
    }
   else
    {
    hrp[num_hrp].posb = jcs[i].mm_start;
    hrp[num_hrp].posa = jcs[i].hit_pos[hitid];
    }
 
   if(((hrp[num_hrp].posa > 0) && (hrp[num_hrp].posb > 0)) || 
      ((hrp[num_hrp].posa < 0) && (hrp[num_hrp].posb < 0)))  // $B%_%9%^%C%A3+;OE@$H(Bhit$B0LCV$,F1$88~$-$N>l9g$N$_=hM}(B //$B$3$l$G$$$$!)(B
    {
    if(hrp[num_hrp].posa > 0) // posa $B$,@5!!1&8~(B
     {
     hrp[num_hrp].pos1R = hrp[num_hrp].posa-1;                                             // $B>eN.$NAjF1NN0h(B pos1 $B$N1&B&!J2<N.!K(B pos1R
     hrp[num_hrp].pos1L = hrp[num_hrp].posa-hrp[num_hrp].homolen;                          // $B>eN.$NAjF1NN0h(B pos1 $B$N:8B&!J>eN.!K(B pos1L
     hrp[num_hrp].pos2R = hrp[num_hrp].posb-1;                                             // $B2<N.$NAjF1NN0h(B pos2 $B$N1&B&!J2<N.!K(B pos2R
     hrp[num_hrp].pos2L = hrp[num_hrp].posb-hrp[num_hrp].homolen;                          // $B2<N.$NAjF1NN0h(B pos2 $B$N:8B&!J>eN.!K(B pos2L
     hrp[num_hrp].homoseq = (char *)malloc(sizeof(char)*(strlen(jcs[i].homoseq)+5));       // $BAjF1G[Ns$N5-21NN0h3NJ](B
     complement_seq(hrp[num_hrp].homoseq, jcs[i].homoseq);                                  // $BAjF1G[Ns$N5-O?(B
     } 
    else                       // posa$B$,Ii!!:88~(B
     {
     hrp[num_hrp].pos1L = abs(hrp[num_hrp].posa)+1;
     hrp[num_hrp].pos1R = abs(hrp[num_hrp].posa)+hrp[num_hrp].homolen;
     hrp[num_hrp].pos2L = abs(hrp[num_hrp].posb)+1;
     hrp[num_hrp].pos2R = abs(hrp[num_hrp].posb)+hrp[num_hrp].homolen;
     hrp[num_hrp].homoseq = (char *)malloc(sizeof(char)*(strlen(jcs[i].homoseq)+5));
     strcpy(hrp[num_hrp].homoseq,jcs[i].homoseq);
     }
 
    match_flag = 0;
    for(j=0;j<num_hrp;j++)                                                                         // $B$3$l$^$G$N(Bhrp$B$NCf$K(B
     {
     if((hrp[num_hrp].pos1L == hrp[j].pos1L) && (hrp[num_hrp].pos1R == hrp[j].pos1R) &&            // $BAjF1NN0h$NN>C<$,A4$/F1$8(Bhrp$B$,$"$l$P(B
        (hrp[num_hrp].pos2L == hrp[j].pos2L) && (hrp[num_hrp].pos2R == hrp[j].pos2R))
      {
 
 //     printf("MATCH WITH %d\n",j+1);
      match_flag = 1;                                                                              // $B%^%C%A%U%i%C%0$rN)$F$F(B
      if(hrp[j].jcc1 == -1)                                                                        // jcc1 $B$,$^$@Kd$^$C$F$J$1$l$P(B
       hrp[j].jcc1 = i;                                                                            // jcc1 $B$r:#$N%8%c%s%/%7%g%s%/%i%9%?(B(i)$B$H$7(B
      else                                                                                         // jcc1 $B$,Kd$^$C$F$$$l$P(B
       hrp[j].jcc2 = i;                                                                            // jcc2 $B$r:#$N%8%c%s%/%7%g%s%/%i%9%?$H$9$k(B
      break;
      }    
     }
 ///
 //   printf("H %10d %10d %10d %10d %10d %10d %10d %10d %10d %10d %10d %s\n",num_hrp+1,i+1,jcs[i].mm_start,jcs[i].hit_pos[hitid],
 //                  jcs[i].n_member,hrp[num_hrp].posa,hrp[num_hrp].posb,
 //                  hrp[num_hrp].pos1L,hrp[num_hrp].pos1R,
 //                  hrp[num_hrp].pos2L,hrp[num_hrp].pos2R,
 //                  jcs[i].homoseq);
 //   printf(" %s\n",hrp[num_hrp].homoseq);
 ///
    if(match_flag == 0)                                               // $B%^%C%A%U%i%C%0$,%<%m!!$D$^$j$3$l$^$G$N(Bhrp$B$KN>C<$NB7$C$?$b$N$,$J$$>l9g(B
     {
     if(abs(jcs[i].mm_start) < abs(jcs[i].hit_pos[hitid]))            // $B%_%9%^%C%A3+;OE@$,%R%C%H0LCV$h$j>eN.$J$i(B
      hrp[num_hrp].jcc1 = i;                                          // jcc1 $B$KEPO?(B
     else                                                             // $B2<N.$J$i(B
      hrp[num_hrp].jcc2 = i;                                          // jcc2 $B$KEPO?(B
     num_hrp ++;                                                      // hrp $B$N?t$r%$%s%/%j%a%s%H(B  $BAjF1AH$_49$($N%Z%"$N?t(B
     }
    }                                                                                                             //
   }
  }
 ////////////////////////
 
 for(i=0;i<num_hrp;i++)
  {
  hrp[i].num_jcr1L = 0;
  hrp[i].num_jcr1R = 0;
  hrp[i].num_jcr2L = 0;
  hrp[i].num_jcr2R = 0;
  }
 
                                                                 // $BAjF1E>0\$NG[Ns$NN>C<$K%_%9%^%C%A3+;OE@$,0lCW$9$k%j!<%I$r$9$Y$F%+%&%s%H$7$F$$$k(B //$B$=$l$G$$$$!)(B
 
 for(i=0;i<num_hrp;i++)      // $BAjF1E>0\$N?t$N%k!<%W(B
  {
  for(j=0;j<num_hit;j++)     // $B%j!<%I$N$&$A%2%N%`>e$K%R%C%H$7$?$b$N$N?t$N%k!<%W(B
   {
   temp = read[hit_id[j]].mismatch_start_point_on_genome;  // $B3F%j!<%I$N%2%N%`>e$N%_%9%^%C%A3+;OE@$r(Btemp$B$H$7(B
   if(-(hrp[i].pos1L - 1) == temp)                         // pos1L $B$H0lCW$9$l$P(B
    hrp[i].num_jcr1L ++;                                    // num_jcr1L $B$r%$%s%/%j%a%s%H(B
   if(hrp[i].pos1R + 1 == temp)                            // pos1R $B$H0lCW$9$l$P(B
    hrp[i].num_jcr1R ++;                                    // num_jcr1R $B$r%$%s%/%j%a%s%H(B
   if(-(hrp[i].pos2L - 1) == temp)                         // pos2L $B$H0lCW$9$l$P(B
    hrp[i].num_jcr2L ++;                                    // num_jcr2L $B$r%$%s%/%j%a%s%H(B
   if(hrp[i].pos2R + 1 == temp)                            // pos2R $B$H0lCW$9$l$P(B
    hrp[i].num_jcr2R ++;                                    // num_jcr2R $B$r%$%s%/%j%a%s%H(B
   }
  }
 
 for(i=0;i<num_hrp;i++)                                                 // $BAjF1E>0\G[Ns$NN>C<$K%_%9%^%C%A3+;OE@$,%^%C%A$9$k%j!<%I$r5-O?$9$kNN0h$r3NJ](B
  {
  hrp[i].jcrs1L = (int *)malloc(sizeof(int)*(hrp[i].num_jcr1L));
  hrp[i].jcrs1R = (int *)malloc(sizeof(int)*(hrp[i].num_jcr1R));
  hrp[i].jcrs2L = (int *)malloc(sizeof(int)*(hrp[i].num_jcr2L));
  hrp[i].jcrs2R = (int *)malloc(sizeof(int)*(hrp[i].num_jcr2R));
  hrp[i].num_jcr1L = 0;
  hrp[i].num_jcr1R = 0;
  hrp[i].num_jcr2L = 0;
  hrp[i].num_jcr2R = 0;
  }
 
 for(i=0;i<num_hrp;i++)
  {
  for(j=0;j<num_hit;j++)
   {
   temp = read[hit_id[j]].mismatch_start_point_on_genome;
   if(-(hrp[i].pos1L - 1) == temp)
    {
    hrp[i].jcrs1L[hrp[i].num_jcr1L] = j;
    hrp[i].num_jcr1L ++;
    }
   if(hrp[i].pos1R + 1 == temp)
    {
   hrp[i].jcrs1R[hrp[i].num_jcr1R] = j;
    hrp[i].num_jcr1R ++;
    }
   if(-(hrp[i].pos2L - 1) == temp)
    {
    hrp[i].jcrs2L[hrp[i].num_jcr2L] = j;
    hrp[i].num_jcr2L ++;
    }
   if(hrp[i].pos2R + 1 == temp)
    {
    hrp[i].jcrs2R[hrp[i].num_jcr2R] = j;
    hrp[i].num_jcr2R ++;
    }
   }
  }
 
 
 ////////////////////////////////////////////////////////////// hrp$B%G!<%?$r(Bpos1L$B$N=g=x$G%=!<%H(B
 int min;
 int min_id;
 hmr_sort = (int *)malloc(sizeof(int)*(num_hrp+5));
 hmr_flag = (int *)malloc(sizeof(int)*(num_hrp+5));
 
 for(i=0;i<num_hrp+5;i++)
  {
  hmr_sort[i] = -1;
  hmr_flag[i] = -1;
  }
 
 for(i=0;i<num_hrp;i++)
  {
  min = MAX_INT;
  min_id = -1;
  for(j=0;j<num_hrp;j++)
   {
   if(hmr_flag[j] == -1)
    {
    if(min > hrp[j].pos1L)
     {
     min = hrp[j].pos1L;
     min_id = j;
     }
    }
   }
  hmr_sort[i] = min_id;
  hmr_flag[min_id] = 1;
  }
 
 
 for(i=0;i<num_hrp;i++)                                      // .hmr $B%U%!%$%k=PNO(B
  {
  fprintf(hmr_file,"H %10d %10d %10d %10d %10d %10d %s\n",hrp[hmr_sort[i]].pos1L,hrp[hmr_sort[i]].pos1R,hrp[hmr_sort[i]].pos2L,hrp[hmr_sort[i]].pos2R,
                                                          hrp[hmr_sort[i]].num_jcr1L+hrp[hmr_sort[i]].num_jcr1R,
                                                          hrp[hmr_sort[i]].num_jcr2L+hrp[hmr_sort[i]].num_jcr2R,
                                                          hrp[hmr_sort[i]].homoseq);
  }
 ////////////////////////////////////////////////////////////////// $BAjF1AH$_BX$(>pJs$N@0M}(B
 
 //////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////////////////////////////  $B%Z%"%(%s%I>pJs$N2r@O(B STEP5.1    ////////////
 //////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 printf("Entering paired end analysis\n");
 
 /////////////////////////////////////////////////////////////////////////////////////////////////////////
 ////////////////////////////////////CHECK PAIRD END DATA MARK    $B%Z%"%(%s%I>pJs$N2r@O(B ///////////////////
 /////////////////////////////////////////////////////////////////////////////////////////////////////////
 
 ///////////////////////// hit_position[i] $B$,%R%C%H?t$@$1$N%^%H%j%/%9$K$J$C$F$$$?$N$KBP$7(B
 ///////////////////////// $B%j!<%I!J%Z%"!K?t$KBP1~$5$;$?%j%9%H(Bhit_pos1$B$H(Bhit_pos2$B$r:n$k!"(B
 ///////////////////////// $B%R%C%H$7$F$$$J$$%j!<%I$O(BMAX_INT$B!"%R%C%H$7$F$$$k%j!<%I$O%R%C%H0LCV$,F~$k(B
 for(i=0;i<num_hit;i++)                               // $B%R%C%H?t%k!<%W(B
  {
  if(hit_id[i] < n_pair)                              // R1$B%R%C%H$J$i(B
   {
   hit_pos1[hit_id[i]] = hit_position[i];             // hit_pos1[$B%j!<%I(BID] = R1 $B$N%R%C%H0LCV(B
   }
  else                                                // R2$B%R%C%H$J$i(B
   {
   hit_pos2[hit_id[i]-n_pair] = hit_position[i];      // hit_pos2[$B%j!<%I(BID] = R2 $B$N%R%C%H0LCV(B
   }
  }
  
 printf("P1\n");
 
 int n_pair_map = 0;                    // $B%Z%"N>J}$,%^%C%W$5$l$F$$$k?t(B
 int n_one_map = 0;                     // $B%Z%"JRJ}$,%^%C%W$5$l$F$$$k?t(B
 int n_none_map = 0;                    // $B%Z%"N>J}$,%^%C%W$5$l$F$$$J$$?t(B
 int n_pair_within = 0;                 // $B%Z%"$,(B500$B1v4p0JFb$K%^%C%W$5$l$F$$$k?t(B
 int n_same_direction_within = 0;       // $B%Z%"$N%^%C%W0LCV$,6a$/$F8~$-$,F1$8?t(B
 int n_oposite_direction_distant = 0;   // $B%Z%"$N%^%C%W0LCV$,1s$/$F8~$-$,5U$N?t(B
 int n_pair_distant = 0;                // $B%Z%"$N%^%C%W0LCV$,1s$$$b$N$N?t(B
 int n_pair_close   = 0;                // $B%Z%"$N%^%C%W0LCV$,6a$/$FF1$88~$-$N?t(B
 distant_pair_info *distant_pairs;
 distant_pair_info *close_pairs;
 int n_same_direction_distant = 0;      // $B%Z%"$N%^%C%W0LCV$,1s$/$F8~$-$,F1$8?t(B
 int n_regitimate = 0;                  // $B%Z%"$N%^%C%W0LCV$,6a$/$F8~$-9g$C$F$$$k?t(B
 int bin[1000];
 for(i=0;i<1000;i++)
  bin[i] = 0;
 
 int n_less_than_1k_opositedir_pair  = 0;
 int n_between_1k_5k_opositedir_pair = 0;
 int n_over_5k_opositedir_pair       = 0;
 int n_less_than_1k_samedir_pair     = 0;
 int n_over_1k_samedir_pair          = 0;
 
 /////////////////////////////////////////////////////////////////// MARKPO1
 ops          = (overlap_pair_info *)malloc(sizeof(overlap_pair_info)*(n_read/2 + 1000));
 op           = (int *)malloc(sizeof(int)*(n_read/2 + 1000));
 for(i=0;i<n_pair;i++)   
  {
  ops[i].overlap = MAX_INT;
  ops[i].overlapseq = (char *)malloc(sizeof(char)*(read_len*2+2));
  ops[i].overlapseq[0] = '\0';
  op[i] = MAX_INT;
  }
 ///////////////////////////////////////////////////////////////////

 ///////////////////////////////////////////////////////////////////////////////////////////// $B%Z%"%*!<%P!<%i%C%W(B .pol
 for(i=0;i<n_pair;i++)                  // $B%Z%"%(%s%I$N>uBV$r6hJL$9$k%k!<%W(B
  {
  if((hit_pos1[i] != MAX_INT) && (hit_pos2[i] != MAX_INT))    // $B%Z%"$,N>J}$H$b%^%C%W$5$l$F$$$l$P(B
   {
   if(((hit_pos1[i] > 0) && (hit_pos2[i] < 0)) ||            // $B8~$-$,5U(B
      ((hit_pos1[i] < 0) && (hit_pos2[i] > 0)))
    {
    if(abs(abs(hit_pos2[i])-abs(hit_pos1[i])) < 1000)        // $B%Z%"$N%^%C%W0LCV$,(B1000bp $B0JFb$J$i(B
     {
     n_less_than_1k_opositedir_pair++;
     }
    else
     {
     if(abs(abs(hit_pos2[i])-abs(hit_pos1[i])) < 5000)        // $B%Z%"$N%^%C%W0LCV$,(B5000bp $B0JFb$J$i(B
      {
      n_between_1k_5k_opositedir_pair++;
      }
     else
      {
      n_over_5k_opositedir_pair ++;
      }
     }
    }
   else                                                      // $B8~$-$,F1$8(B
    {
    if(abs(abs(hit_pos2[i])-abs(hit_pos1[i])) < 1000)        // $B%Z%"$N%^%C%W0LCV$,(B1000bp $B0JFb$J$i(B
     {
     n_less_than_1k_samedir_pair++;
     }
    else
     {
     n_over_1k_samedir_pair ++;
     }
    }
 
   n_pair_map ++;                                           
   if(abs(abs(hit_pos2[i])-abs(hit_pos1[i])) < pair_thresh_distance)           // $B%Z%"$N%^%C%W0LCV$,(B600bp(pair_thresh_distance) $B0JFb$J$i(B
    {
    if(((hit_pos1[i] > 0) && (hit_pos2[i] < 0)) ||            // $B8~$-$,5U(B
       ((hit_pos1[i] < 0) && (hit_pos2[i] > 0)))
     {
     n_regitimate ++;                                         // 600$B1v4p(B pair_thresh_distance $B0JFb$G8~$-9g$C$F$$$k?t(B
     bin[abs(abs(hit_pos2[i])-abs(hit_pos1[i]))] ++;          // $B5wN%$N%R%9%H%0%i%`(B
     fprintf(pair_distance2,"%10d %10d %10d\n",i,hit_pos1[i],hit_pos2[i]); // $BE,EY$J5wN%$N%Z%"$N%j%9%H(B
     }
    else
     {
     n_pair_close ++;
     n_same_direction_within ++;                 // 600$B1v4p(B pair_thresh_distance $B0JFb$G8~$-$,F1$8(B
     fprintf(pair_distance3,"%10d %10d %10d\n",i,hit_pos1[i],hit_pos2[i]); // $BE,EY$J5wN%$N%Z%"$N%j%9%H(B
     fprintf(pair_distance4,"%10d %10d %10d\n",i,hit_pos1[i],hit_pos2[i]); // $BE,EY$J5wN%$N%Z%"$N%j%9%H(B
     }
    n_pair_within ++;                            // 600$B1v4p(B pair_thresh_distance $B0JFb$N%Z%"!J8~$-$K$h$i$:!K$N?t(B
    }
   else                                                      // $B%Z%"$N%^%C%W0LCV$N5wN%$,(B600bp pair_thresh_distance $B0J>eN%$l$F$$$l$P(B
    {
    n_pair_distant ++;                                       // 600$B1v4p(B pair_thresh_distance $B0J>eN%$l$?%Z%"!J8~$-$K$h$i$:!K$N?t(B
    fprintf(pair_distance,"%10d %10d %10d\n",i,hit_pos1[i],hit_pos2[i]);  // $BAjF1AH498uJd(B
    fprintf(pair_distance4,"%10d %10d %10d\n",i,hit_pos1[i],hit_pos2[i]);  // $BAjF1AH498uJd(B
    if(((hit_pos1[i] > 0) && (hit_pos2[i] > 0)) || ((hit_pos1[i] < 0) && (hit_pos2[i] < 0)))  // $B8~$-$,F1$8(B
     {
     n_same_direction_distant ++;
     }
    else
     {
     n_oposite_direction_distant ++;
     }
    }

 ////////////////////////////////////// CHECK OVERLAP OF PAIRERED READS MARKPO2   MARCH 20 2017
 
   strcpy(tempseq1,read[i].seq);
   strcpy(tempseq2,read[i+n_pair].seq);
   seqlen = strlen(tempseq1);
   if((include_n(tempseq1) == 0) && (include_n(tempseq2) == 0))  // $B%Z%"$N$=$l$>$l$,(BN$B$r4^$`%j!<%I$G$J$1$l$P(B
    {
    tempseq1[strlen(tempseq1)-1] = '\0';
    tempseq2[strlen(tempseq2)-1] = '\0';
    complement_seq(temprev2, tempseq2);
    overlap = 0;
    for(j=0;j<seqlen;j++)
     {
     flag = 0;
     for(k=0;k<seqlen-j-1;k++)
      {
      if(tempseq1[k+j] != temprev2[k])
       {
       flag = 1;
       break;
       }
      }
     if(flag == 0)
      {
      overlap = seqlen-j-1;
      break;
      }
     }
 
    fprintf(pair_overlap_file,"%10d %10d %s\n%10d %10d %s\n",i,hit_pos1[i],tempseq1,i+n_pair,hit_pos2[i],tempseq2);
    fprintf(pair_overlap_file,"%10d            ",overlap);
    if(overlap > 5)
     {
     for(j=0;j<seqlen-overlap-1;j++)
      fprintf(pair_overlap_file," ");
     }
    fprintf(pair_overlap_file,"%s\n\n",temprev2);
 
    if((overlap > 5) && (abs(abs(hit_pos1[i])-abs(hit_pos2[i])) > 1000))
     {
     ops[i].overlap  = overlap;
     op[nop++] = i;
     }
    }
 //////////////////////////////////////   MARCH 20 2017
 
   }
  else                                                     // $B%Z%"$,N>J}$O%^%C%W$5$l$F$$$J$1$l$P(B
   {
   if((hit_pos1[i] == MAX_INT) && (hit_pos2[i] == MAX_INT))   
    {
    n_none_map ++;                        // $B$I$A$i$b%^%C%W$5$l$F$J$$(B
    }
   else
    {
    n_one_map ++;                         // $BJRB&$@$1%^%C%W(B
    }
   }
  }
 ///////////////////////////////////////////////////////////////////////////////////////////// $B%Z%"%*!<%P!<%i%C%W#2(B .pol2

 qsort(op,nop,sizeof(int),op_sort);

  ///////////////////////////////////////////////////////////////////////////////////////////// $B%Z%"%*!<%P!<%i%C%W#2(B .pol2
 /////////////////////////////////////  MARKPO3  $B%Z%"%*!<%P!<%i%C%W(B 
 int pospos;
 for(i=0;i<nop;i++)                  
  {
   {
   strcpy(tempseq1,read[op[i]].seq);
  strcpy(tempseq2,read[op[i]+n_pair].seq);
   seqlen = strlen(tempseq1);
   tempseq1[strlen(tempseq1)-1] = '\0';
   tempseq2[strlen(tempseq2)-1] = '\0';
   complement_seq(temprev2,tempseq2);
   overlap = ops[op[i]].overlap;
 
   //////////////////
   if(hit_pos1[op[i]] > 0)                                     //$B!!%j!<%I$N;2>HG[Ns$rI=<(!!0lK\L\!!=gJ}8~(B
    {
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len*2-overlap;j++)
     {
     if((j+hit_pos1[op[i]]>0) && (j+hit_pos1[op[i]]<=refseq_len))
      {
      fprintf(pair_overlap2_file,"%c",refseq[hit_pos1[op[i]]+j]);
      }
     }
    fprintf(pair_overlap2_file,"\n");
 
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len;j++)
     {
     if((j+hit_pos1[op[i]]>0) && (j+hit_pos1[op[i]]<=refseq_len))
      {
      if(refseq[hit_pos1[op[i]]+j] == tempseq1[j])
       fprintf(pair_overlap2_file," ");
      else
       fprintf(pair_overlap2_file,"*");
      }
     }
    fprintf(pair_overlap2_file,"\n");
    }
   else                                                       // $B%j!<%I$N;2>HG[Ns$rI=<(!!(B1$BK\L\!!5UJ}8~(B
    {
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len*2-overlap;j++)
     {
     pospos=abs(hit_pos1[op[i]])+read_len-j-1;
     if((pospos>0) && (pospos<=refseq_len))
      {
      fprintf(pair_overlap2_file,"%c",complement_char(refseq[pospos]));
      }
     }
    fprintf(pair_overlap2_file,"\n");
 
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len;j++)
     {
     pospos=abs(hit_pos1[op[i]])+read_len-j-1;
     if((pospos>0) && (pospos<=refseq_len))
      {
      if(complement_char(refseq[pospos]) == tempseq1[j])
       fprintf(pair_overlap2_file," ");
      else
       fprintf(pair_overlap2_file,"*");
      }
     }
    fprintf(pair_overlap2_file,"\n");
    }
   //////////////////
   
   ///// $B%Z%"%j!<%I$NI=<((B
   fprintf(pair_overlap2_file,"%10d %10d %s\n%10d %10d %s\n",op[i],hit_pos1[op[i]],tempseq1,op[i]+n_pair,hit_pos2[op[i]],tempseq2);
   fprintf(pair_overlap2_file,"%10d            ",overlap);  // $B%*!<%P!<%i%C%WI}$NI=<((B
   if(overlap > 5)                                          // $B%*!<%P!<%i%C%WJ,$:$i$9(B
    {
    for(j=0;j<seqlen-overlap-1;j++)
     fprintf(pair_overlap2_file," ");
    }
   fprintf(pair_overlap2_file,"%s\n",temprev2);
 
   //////////////////
   if(hit_pos2[op[i]] > 0)                                     //$B!!%j!<%I$N;2>HG[Ns$rI=<(!!#2K\L\!!=gJ}8~(B
    {
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len*2-overlap;j++)
     {
     if(j<read_len-overlap)
      {
      fprintf(pair_overlap2_file," ");
      continue;
      }
     pospos=abs(hit_pos2[op[i]])+(read_len*2-overlap)-j-1;
     if((pospos>0) && (pospos<=refseq_len))
      {
      if(complement_char(refseq[pospos]) == temprev2[j-(read_len-overlap)])
       fprintf(pair_overlap2_file," ");
      else
       fprintf(pair_overlap2_file,"*");
      }
     }
    fprintf(pair_overlap2_file,"\n");
 
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len*2-overlap;j++)
     {
     pospos=abs(hit_pos2[op[i]])+(read_len*2-overlap)-j-1;
     if((pospos>0) && (pospos<=refseq_len))
      {
      fprintf(pair_overlap2_file,"%c",complement_char(refseq[pospos]));
      }
     }
    fprintf(pair_overlap2_file,"\n");
    }
   else
    {
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len*2-overlap;j++)
     {
     if(j<read_len-overlap)
      {
      fprintf(pair_overlap2_file," ");
      continue;
      }
     pospos=abs(hit_pos2[op[i]])-read_len+overlap+j;
     if((pospos>0) && (pospos<=refseq_len))
      {
      if(refseq[pospos] == temprev2[j-(read_len-overlap)])
       fprintf(pair_overlap2_file," ");
      else
       fprintf(pair_overlap2_file,"*");
      }
     }
    fprintf(pair_overlap2_file,"\n");
 
    fprintf(pair_overlap2_file,"                      ");
    for(j=0;j<read_len*2-overlap;j++)
     {
     pospos=abs(hit_pos2[op[i]])-read_len+overlap+j;
     if((pospos>0) && (pospos<=refseq_len))
      {
      fprintf(pair_overlap2_file,"%c",refseq[pospos]);
      }
     }
    fprintf(pair_overlap2_file,"\n");
    }
   ////////////////// MARK
 
   }
  fprintf(pair_overlap2_file,"==========================================================================\n");
  }
 ///////////////////////////////////////////////////////////////////////////////////////////// $B%Z%"%*!<%P!<%i%C%W#2(B .pol2 $B=*$o$j(B
  
 fprintf(pair_histo_file,"%12.7f\n",((float)n_less_than_1k_opositedir_pair)  / ((float) n_pair_map));
 fprintf(pair_histo_file,"%12.7f\n",((float)n_between_1k_5k_opositedir_pair) / ((float) n_pair_map));
 fprintf(pair_histo_file,"%12.7f\n",((float)n_over_5k_opositedir_pair)       / ((float) n_pair_map));
 fprintf(pair_histo_file,"%12.7f\n",((float)n_less_than_1k_samedir_pair)     / ((float) n_pair_map));
 fprintf(pair_histo_file,"%12.7f\n",((float)n_over_1k_samedir_pair)          / ((float) n_pair_map));
 
 /////////////////////////////////////////////////////////////////////////////////////////////v $B%8%c%s%/%7%g%s%/%i%9%?(B $B%Z%"%A%'%C%/(B July 2020  .jcp $B%U%!%$%k$K7k2L$r=PNO(B
 fprintf(junction_cluster_pair,"Entering Junction cluseter pair check\n");
 printf("Number of Junction cluster is %10d\n",num_jcs);
 printf("Number of READ PAIR        is %10d\n",n_pair);
 for(i=0;i<num_jcs;i++)                                                   // $B%8%c%s%/%7%g%s%/%i%9%?$N?t%k!<%W(B
  {
  if(jcs[i].num_hit == 1)                                                 // $B%_%9%^%C%A%3%s%;%s%5%9$N%R%C%H0LCV$,0l2U=j(B
   {
   if(strlen(jcs[i].consensus_seq_i2) >= consensus_length)                // $B%3%s%;%s%5%9%j!<%ID9$,ogCM$rD6$($F$$$l$P(B
    {
    if(jcs[i].n_true_member > 3)                                          // $B%a%s%P?t(B3$B0J>e$G$"$l$P(B
     {
     int tmtlen = 0;
     int tstlen = 0;
     int tqtlen = 0;
     int tptlen = 0;
     int tmtcnt = 0;
     int tstcnt = 0;
     int tqtcnt = 0;
     int tptcnt = 0;
     int mtlen = 0;
     int stlen = 0;
     int qtlen = 0;
     int ptlen = 0;
     int mtcnt = 0;
     int stcnt = 0;
     int qtcnt = 0;
     int ptcnt = 0;
     fprintf(junction_cluster_pair,"### JCS ID:%8d NumPair:%6d MM_start:%8d MM_HIT pos %10d:  HIT_TYPE %2d\n",i+1,jcs[i].n_member,jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].hit_flag[0]);
     for(j=0;j<jcs[i].n_member;j++)                                       // $B3F%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P?t%k!<%W(B
      {
      int stlen = 0;     // $B%^%C%ANN0h$ND9$5!!!!!!C;$$B&(B
      int stcnt = 0;     // $B%^%C%ANN0h$N%^%C%A?t!!C;$$B&(B
      int pflag = 0;
      char pc;                                                                                                      // $B%Z%"%j!<%I$,%8%c%s%/%7%g%s%j!<%I$N>l9g(Bpc=#$B$H$7$FI=<(!!$=$l0J30$O(Bpc=.
      if(read[pid(hit_id[jcs[i].hit_id[j]])].junction_likelyhood == 0)    // $B%j!<%I%Z%"$,%8%c%s%/%7%g%sE*$G$J$1$l$P(B .                                          
       pc = '.';
      else                                                                // $B%8%c%s%/%7%g%sE*$G$"$l$P(B # $B$r0u;z(B
       pc = '#';
      if(read[pid(hit_id[jcs[i].hit_id[j]])].pos == MAX_INT)              // $B%Z%"%j!<%I$,F1$8%l%U%!%l%s%9$K%^%C%W$5$l$F$$$J$1$l$P(B
       {
       fprintf(junction_cluster_pair," ID_pair %10d-%10d HPpair %8d-#NO MMSPosRead %5d HIT# PairIsJ: %c HIT_FLAG %2d\n",
                                hit_id[jcs[i].hit_id[j]],pid(hit_id[jcs[i].hit_id[j]]),                              // $BEv3:%j!<%I$H%Z%"$N%j!<%I(BID
                                hit_position[jcs[i].hit_id[j]],read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point,pc,jcs[i].hit_flag[j]); // $BEv3:%j!<%I$N%R%C%H0LCV(B
       }
      else                                                                // $B%Z%"%j!<%I$,F1$8%l%U%!%l%s%9$K%^%C%W$5$l$F$$$l$P(B
       {
       fprintf(junction_cluster_pair," ID_pair %10d-%10d HPpair %8d-%8d MMSPosRead %5d PairIsJ: %c HIT_FLAG %2d\n",
                                hit_id[jcs[i].hit_id[j]],pid(hit_id[jcs[i].hit_id[j]]),                              // $BEv3:%j!<%I$H%Z%"%j!<%I$N(BID
                                hit_position[jcs[i].hit_id[j]],read[pid(hit_id[jcs[i].hit_id[j]])].pos,read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point,pc,jcs[i].hit_flag[j]);       
                                                                                                                     // $BEv3:%j!<%I$H%Z%"%j!<%I$N%R%C%H0LCV(B + pc
       }

       if(hit_position[jcs[i].hit_id[j]] > 0)       // $B%8%c%s%/%7%g%s%j!<%I$,=gJ}8~%^%C%A(B
        {
        fprintf(junction_cluster_pair,"  + %8d ",hit_position[jcs[i].hit_id[j]]);
        for(k=hit_position[jcs[i].hit_id[j]];k<hit_position[jcs[i].hit_id[j]]+read_len;k++)          // $B%l%U%!%l%s%9(B $B%8%c%s%/%7%g%s%j!<%I%^%C%W0LCV(B
         {
         if(k<0)
          fprintf(junction_cluster_pair,".");
         else
          fprintf(junction_cluster_pair,"%c",refseq[k]);
         }
        fprintf(junction_cluster_pair,"\n");
        fprintf(junction_cluster_pair,"  +          ");
        for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
         fprintf(junction_cluster_pair,"%c",read[hit_id[jcs[i].hit_id[j]]].seq[k]);
        fprintf(junction_cluster_pair,"\n");

        int poss = hit_position[jcs[i].hit_id[j]];

        fprintf(junction_cluster_pair,"             ");
        for(k=0;k<read_len;k++)                                                                      // $B%^%C%A2U=jI=<((B
         {
         if(refseq[poss] == read[hit_id[jcs[i].hit_id[j]]].seq[k])
           fprintf(junction_cluster_pair,"*");
         else
           fprintf(junction_cluster_pair," ");
         poss ++;
         }
        fprintf(junction_cluster_pair,"\n");

        fprintf(junction_cluster_pair,"         ");
        for(k=0;k<abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point) + 4;k++)                  // $B%8%c%s%/%7%g%s%]%$%s%HI=<((B
         fprintf(junction_cluster_pair," ");
        if(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point > 0)
         fprintf(junction_cluster_pair,">\n");
        else
         fprintf(junction_cluster_pair,"<\n");

////////// 2020 Aug. 11      MARK1                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B
        mtlen=0;  // $B%^%C%ANN0h$ND9$5(B      $BD9$$B&(B
        mtcnt=0;  // $B%^%C%ANN0h$N%^%C%A?t(B  $BD9$$B&(B
        if(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point > 0)    // $B:8$,%^%C%A(B
         {
         poss = hit_position[jcs[i].hit_id[j]];
         for(k=0;k<read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point;k++)                                         // $B%^%C%A%+%&%s%H(B
          {
          mtlen ++;
          if(refseq[poss] == read[hit_id[jcs[i].hit_id[j]]].seq[k])
           {
           mtcnt ++;
           }
          poss ++;
          }
         fprintf(junction_cluster_pair,"&+++ %4d/%4d\n",mtcnt,mtlen);
         }
        else                                                           // $B1&$,%^%C%A(B
         {
         poss = hit_position[jcs[i].hit_id[j]] + abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point) + 1;
         for(k=abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point) + 1;k<read_len;k++)                          // $B%^%C%A%+%&%s%H(B
          {
          mtlen ++;
          if(refseq[poss] == read[hit_id[jcs[i].hit_id[j]]].seq[k])
           {
           mtcnt ++;
           }
          poss ++;
          }
         fprintf(junction_cluster_pair,"&++- %4d/%4d\n",mtcnt,mtlen);
         }
////////// 2020 Aug. 11      MARK1                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B
        

//......................................................................................             $B%8%c%s%/%7%g%s$NC;$$J}$NC<$N%^%C%W0LCV(B
        fprintf(junction_cluster_pair,"MM HIT POS    ");
        int from = abs(jcs[i].hit_pos[0]) - 150;
        for(k=from;k<=from+300;k++)                                                                 // $B%l%U%!%l%s%9(B
         {
         if((k < 0) || (k > refseq_len))
          fprintf(junction_cluster_pair,".");
         else
          fprintf(junction_cluster_pair,"%c",refseq[k]);
         }
        fprintf(junction_cluster_pair,"\n");

//        if(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point > 0)                             // $B%j!<%I(B
//        if(jcs[i].hit_pos[0] > 0)                                                               // $B%_%9%^%C%A%3%s%;%s%5%9$N%^%C%W$5$l$kJ}8~$,=gJ}8~(B
        int f1 = read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point / abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);  // f1 $B%_%9%^%C%A3+;OE@$N8~$-(B
        int f2 = jcs[i].hit_pos[0] / abs(jcs[i].hit_pos[0]);                                                                      // f2 $B%_%9%^%C%AG[Ns(Bhit$B0LCV$N8~$-(B

        if((f1*f2) > 0)        // $B8~$-$N@Q$,@5(B  $B%j!<%I=gJ}8~(B
         {
         int offset = 163 - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);
         fprintf(junction_cluster_pair,"+");
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          fprintf(junction_cluster_pair,"%c",read[hit_id[jcs[i].hit_id[j]]].seq[k]);
  //match 
         fprintf(junction_cluster_pair,"\n");
         fprintf(junction_cluster_pair,"+");
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          {
          if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
           fprintf(junction_cluster_pair,"*");
          else
           fprintf(junction_cluster_pair," ");
          }
         fprintf(junction_cluster_pair,"\n");


////////// 2020 Aug. 13      MARK2                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B
         if(f2 > 0)   // $B1&B&%^%C%A(B
          {
          for(k=abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);k<read_len;k++)
           {
           stlen ++;
           tstlen ++;
           if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*+++ %4d/%4d\n",stcnt,stlen);
          }
         else         // $B:8B&%^%C%A(B
          {
          for(k=0;k<=abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);k++)
           {
           stlen ++;
           tstlen ++;
           if(read[hit_id[jcs[i].hit_id[j]]].seq[k]  ==  refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*+-- %4d/%4d\n",stcnt,stlen);
          }
////////// 2020 Aug. 13      MARK2                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B

         }
        else                    // $B8~$-$N@Q$,Ii!!%j!<%IAjJd5U:?(B                                     // $B%_%9%^%C%A%3%s%;%s%5%9$N%^%C%W$5$l$kJ}8~$,5UJ}8~(B
         {
         fprintf(junction_cluster_pair,"-");
         int offset = 164 - (read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point));
         char rvcmp[512];
         rev_comp(rvcmp,read[hit_id[jcs[i].hit_id[j]]].seq);
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          fprintf(junction_cluster_pair,"%c",rvcmp[k]);

  //match         MARK
         fprintf(junction_cluster_pair,"\n");
         fprintf(junction_cluster_pair,"-");
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          {
          if(rvcmp[k] == refseq[abs(jcs[i].hit_pos[0])-(read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point))+k])
           fprintf(junction_cluster_pair,"*");
          else
           fprintf(junction_cluster_pair," ");
          }
         fprintf(junction_cluster_pair,"\n");

////////// 2020 Aug. 13      MARK2                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B
         if(f2 > 0)   // $B1&B&%^%C%A(B
          {
          for(k=read_len-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1;k<read_len;k++)
           {
           stlen ++;
           tstlen ++;
           if(rvcmp[k] == refseq[abs(jcs[i].hit_pos[0])-(read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point))+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*++- %4d/%4d\n",stcnt,stlen);
          }
         else         // $B:8B&%^%C%A(B
          {
          for(k=0;k<read_len-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);k++)
           {
           stlen ++;
           tstlen ++;
           if(rvcmp[k] == refseq[abs(jcs[i].hit_pos[0])-(read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point))+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*+-+ %4d/%4d\n",stcnt,stlen);
          }
////////// 2020 Aug. 13      MARK2                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B

         }

        fprintf(junction_cluster_pair,"\n");
        fprintf(junction_cluster_pair,"\n");
//......................................................................................             $B%8%c%s%/%7%g%s$NC;$$J}$NC<$N%^%C%W0LCV(B

        if(read[pid(hit_id[jcs[i].hit_id[j]])].pos != MAX_INT)              // $B%Z%"%j!<%I$,F1$8%l%U%!%l%s%9$K%^%C%W$5$l$F$$$J$1$l$P(B
         {      // PAIR_READ
         ptlen = 0;     // $B%^%C%ANN0h$ND9$5!!!!!!%Z%"%j!<%I(B
         ptcnt = 0;     // $B%^%C%ANN0h$N%^%C%A?t!!%Z%"%j!<%I(B

         fprintf(junction_cluster_pair," +  %8d ",read[pid(hit_id[jcs[i].hit_id[j]])].pos);
         for(k=abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos);k<abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)+read_len;k++)          // $B%l%U%!%l%s%9(B $B%Z%"%j!<%I%^%C%W0LCV(B
          {
          if(k<0)
           fprintf(junction_cluster_pair,".");
          else
           fprintf(junction_cluster_pair,"%c",refseq[k]);
          }
         fprintf(junction_cluster_pair,"\n");


         if(read[pid(hit_id[jcs[i].hit_id[j]])].pos > 0)        // $B%Z%"%j!<%I$N%^%C%WJ}8~%W%i%9(B
          {
          fprintf(junction_cluster_pair," ++          ");
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           fprintf(junction_cluster_pair,"%c",read[pid(hit_id[jcs[i].hit_id[j]])].seq[k]);
          fprintf(junction_cluster_pair,"\n");
// MARK
          fprintf(junction_cluster_pair," ++          ");
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           {
           ptlen ++;
           if(read[pid(hit_id[jcs[i].hit_id[j]])].seq[k] == refseq[k+abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)])
            {
            ptcnt ++;
            fprintf(junction_cluster_pair,"*");
            }
           else
            fprintf(junction_cluster_pair," ");
           }
          fprintf(junction_cluster_pair,"\n");
          fprintf(junction_cluster_pair,"$++ %4d %4d\n",ptcnt,ptlen);
// MARK
          }
         else                                                   // $B%Z%"%j!<%I$N%^%C%WJ}8~%^%$%J%9(B                                 
          {
          char rvcmp[512];
          rev_comp(rvcmp,read[pid(hit_id[jcs[i].hit_id[j]])].seq);
          fprintf(junction_cluster_pair," +-          ");  
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B 
           fprintf(junction_cluster_pair,"%c",rvcmp[k]);
          fprintf(junction_cluster_pair,"\n");
// MARK
          fprintf(junction_cluster_pair," +-          ");
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           {
           ptlen ++;
           if(rvcmp[k] == refseq[k+abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)])
            {
            ptcnt ++;
            fprintf(junction_cluster_pair,"*");
            }
           else
            fprintf(junction_cluster_pair," ");
           }
          fprintf(junction_cluster_pair,"\n");
          fprintf(junction_cluster_pair,"$+- %4d %4d\n",ptcnt,ptlen);
// MARK
          }
         }  // PAIR_READ
////////////////////////////////////////////CHECKPAIRENDPOSITION1 CPP1
        pflag = 0;
        //////////////////// Condition 1-A
        if((abs(hit_position[jcs[i].hit_id[j]] - abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos))< 500) && (read[pid(hit_id[jcs[i].hit_id[j]])].pos < 0))
         {
         pflag = 1;
         }
        else
         {
         //////////////////// Condition 1-B
         if(jcs[i].hit_pos[0] > 0)
          {
          if((abs(abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)-abs(jcs[i].hit_pos[0])) < 600) && (read[pid(hit_id[jcs[i].hit_id[j]])].pos < 0))
           {
           pflag = 1;
           }
          }
         //////////////////// Condition 1-C
         else
          {
          if((abs(abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos) - abs(jcs[i].hit_pos[0])) < 600) && (read[pid(hit_id[jcs[i].hit_id[j]])].pos > 0))
           {
           pflag = 1;
           }
          }
         }
        
        if(pflag == 0)
         {
         jcs[i].num_ireg_pair ++;
         fprintf(junction_cluster_pair,"&&&\n");
         }
////////////////////////////////////////////CHECKPAIRENDPOSITION1 CPP1
        }
       else   ////////////////////////////////////////$B%8%c%s%/%7%g%s%j!<%I$,5UJ}8~%^%C%A(B /////////////////////////////////////////////////////////////////////////////////////////
        {
        fprintf(junction_cluster_pair,"  + %8d ",hit_position[jcs[i].hit_id[j]]);
        for(k=abs(hit_position[jcs[i].hit_id[j]]);k<abs(hit_position[jcs[i].hit_id[j]])+read_len;k++)          // $B%l%U%!%l%s%9(B $B%8%c%s%/%7%g%s%j!<%I%^%C%W0LCV(B
         {
         if(k<0)
          fprintf(junction_cluster_pair,".");
         else
          fprintf(junction_cluster_pair,"%c",refseq[k]);
         }
        char rvcmp[512];
        rev_comp(rvcmp,read[hit_id[jcs[i].hit_id[j]]].seq);
        fprintf(junction_cluster_pair,"\n");
        fprintf(junction_cluster_pair,"  -          ");
        for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
         fprintf(junction_cluster_pair,"%c",rvcmp[k]);
//         fprintf(junction_cluster_pair,"%c",read[hit_id[jcs[i].hit_id[j]]].seq[k]);
        fprintf(junction_cluster_pair,"\n");

        int poss = abs(hit_position[jcs[i].hit_id[j]]);
        fprintf(junction_cluster_pair,"             ");
        for(k=0;k<read_len;k++)                                                                      // $B%^%C%A2U=jI=<((B
         {
         if(refseq[poss] == rvcmp[k])
           fprintf(junction_cluster_pair,"*");
         else
           fprintf(junction_cluster_pair," ");
         poss ++;
         }
        fprintf(junction_cluster_pair,"\n");

        fprintf(junction_cluster_pair,"         ");
        for(k=0;k<abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point) + 4;k++)                  // $B%8%c%s%/%7%g%s%]%$%s%HI=<((B
         fprintf(junction_cluster_pair," ");
        if(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point > 0)
         fprintf(junction_cluster_pair,">\n");
        else
         fprintf(junction_cluster_pair,"<\n");

////////// 2020 Aug. 11      MARK3                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B 
        mtlen=0;  // $B%^%C%ANN0h$ND9$5(B      $BD9$$B&(B 
        mtcnt=0;  // $B%^%C%ANN0h$N%^%C%A?t(B  $BD9$$B&(B 
        if(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point > 0)    // $B:8$,%^%C%A(B 
         {    
         poss = abs(hit_position[jcs[i].hit_id[j]]);
         for(k=0;k<read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point;k++)                                         // $B%^%C%A%+%&%s%H(B 
          {    
          mtlen ++;
//fprintf(junction_cluster_pair,"%c%c ",refseq[poss],rvcmp[k]);
          if(refseq[poss] == rvcmp[k])
           {
           mtcnt ++;
           }
          poss ++;
          }    
//fprintf(junction_cluster_pair,"\n");
         fprintf(junction_cluster_pair,"&-++ %4d/%4d\n",mtcnt,mtlen);
         }    
        else                                                           // $B1&$,%^%C%A(B 
         {    
         poss = abs(hit_position[jcs[i].hit_id[j]]) + abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point) + 1; 
         for(k=abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point) + 1;k<read_len;k++)                          // $B%^%C%A%+%&%s%H(B 
          {    
          mtlen ++;
          if(refseq[poss] == rvcmp[k])
           {
           mtcnt ++;
           }
          poss ++;
          }    
         fprintf(junction_cluster_pair,"&-+- %4d/%4d %4d\n",mtcnt,mtlen,read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);
         }    

////////// 2020 Aug. 11      MARK3                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B 

//......................................................................................             $B%8%c%s%/%7%g%s$NC;$$J}$NC<$N%^%C%W0LCV(B 
        fprintf(junction_cluster_pair,"MM HIT POS    ");  
        int from = abs(jcs[i].hit_pos[0]) - 150; 
        for(k=from;k<=from+300;k++)                                                                 // $B%l%U%!%l%s%9(B 
         {    
         if((k < 0) || (k > refseq_len))
          fprintf(junction_cluster_pair,".");
         else 
          fprintf(junction_cluster_pair,"%c",refseq[k]);
         }    
        fprintf(junction_cluster_pair,"\n");

//        if(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point > 0)                                 // $B%j!<%I(B 
//        if(jcs[i].hit_pos[0] > 0)                                                               // $B%_%9%^%C%A%3%s%;%s%5%9$N%^%C%W$5$l$kJ}8~$,=gJ}8~(B 
        int f1 = read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point / abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);
        int f2 = jcs[i].hit_pos[0] / abs(jcs[i].hit_pos[0]);
        if((f1*f2) > 0) 
         {    
         int offset = 163 - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);
         fprintf(junction_cluster_pair,"+");
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          fprintf(junction_cluster_pair,"%c",rvcmp[k]);
          //fprintf(junction_cluster_pair,"%c",read[hit_id[jcs[i].hit_id[j]]].seq[k]);
  //match 
         fprintf(junction_cluster_pair,"\n");
         fprintf(junction_cluster_pair,"+");
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          {
          //if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
          if(rvcmp[k] == refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
           fprintf(junction_cluster_pair,"*");
          else
           fprintf(junction_cluster_pair," ");
          }
         fprintf(junction_cluster_pair,"\n");


//         int stlen=0;  // $B%^%C%ANN0h$ND9$5(B      $BC;$$B&(B 
//         int stcnt=0;  // $B%^%C%ANN0h$N%^%C%A?t(B  $BC;$$B&(B 
////////// 2020 Aug. 13      MARK4                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B
         if(f2 > 0)   // $B1&B&%^%C%A(B
          {
          for(k=abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);k<read_len;k++)
           {
           stlen ++;
           tstlen ++;
           //if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
           if(rvcmp[k] == refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*-++ %4d/%4d\n",stcnt,stlen);
          }
         else         // $B:8B&%^%C%A(B
          {
          for(k=0;k<=abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);k++)
           {
           stlen ++;
           tstlen ++;
           if(rvcmp[k]  ==  refseq[abs(jcs[i].hit_pos[0])-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*--- %4d/%4d\n",stcnt,stlen);
          }
////////// 2020 Aug. 13      MARK4                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B

         }    
        else                                                                                    // $B%_%9%^%C%A%3%s%;%s%5%9$N%^%C%W$5$l$kJ}8~$,5UJ}8~(B 
         {    
         fprintf(junction_cluster_pair,"-");
         int offset = 164 - (read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point));
         char rvcmp[512];
         rev_comp(rvcmp,read[hit_id[jcs[i].hit_id[j]]].seq);
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          fprintf(junction_cluster_pair,"%c",read[hit_id[jcs[i].hit_id[j]]].seq[k]);
          //fprintf(junction_cluster_pair,"%c",rvcmp[k]);

  //match         MARK
         fprintf(junction_cluster_pair,"\n");
         fprintf(junction_cluster_pair,"-");
         for(k=1;k<offset;k++)
          fprintf(junction_cluster_pair," ");
         for(k=0;k<read_len;k++)
          {
          if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-(read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point))+k])
           fprintf(junction_cluster_pair,"*");
          else
           fprintf(junction_cluster_pair," ");
          }
         fprintf(junction_cluster_pair,"\n");


////////// 2020 Aug. 13      MARK4                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B
         if(f2 > 0)   // $B1&B&%^%C%A(B
          {
          for(k=read_len-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point)-1;k<read_len;k++)
           {
           stlen ++;
           tstlen ++;
           if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-(read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point))+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*-+- %4d/%4d \n",stcnt,stlen);
          }
         else         // $B:8B&%^%C%A(B
          {
          for(k=0;k<read_len-abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point);k++)
           {
           stlen ++;
           tstlen ++;
           if(read[hit_id[jcs[i].hit_id[j]]].seq[k] == refseq[abs(jcs[i].hit_pos[0])-(read_len - abs(read[hit_id[jcs[i].hit_id[j]]].mismatch_start_point))+k])
            {
            stcnt ++;
            tstcnt ++;
            }
           }
          fprintf(junction_cluster_pair,"*--+ %4d/%4d \n",stcnt,stlen);
          }
////////// 2020 Aug. 13      MARK4                           // $B%^%C%AItJ,%^%C%A$N%+%&%s%H(B

         }    

        ptlen = 0;     // $B%^%C%ANN0h$ND9$5!!!!!!%Z%"%j!<%I(B
        ptcnt = 0;     // $B%^%C%ANN0h$N%^%C%A?t!!%Z%"%j!<%I(B

        fprintf(junction_cluster_pair,"\n");
        fprintf(junction_cluster_pair,"\n");
//......................................................................................             $B%8%c%s%/%7%g%s$NC;$$J}$NC<$N%^%C%W0LCV(B 
             
        if(read[pid(hit_id[jcs[i].hit_id[j]])].pos != MAX_INT)              // $B%Z%"%j!<%I$,F1$8%l%U%!%l%s%9$K%^%C%W$5$l$F$$$J$1$l$P(B
         {         // PAIR READ Aug 17 2020
         fprintf(junction_cluster_pair," -  %8d ",read[pid(hit_id[jcs[i].hit_id[j]])].pos);
         for(k=abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos);k<abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)+read_len;k++)          // $B%l%U%!%l%s%9(B $B%Z%"%j!<%I%^%C%W0LCV(B 
          {    
          if(k<0)
           fprintf(junction_cluster_pair,".");
          else 
           fprintf(junction_cluster_pair,"%c",refseq[k]);
          }    
         fprintf(junction_cluster_pair,"\n");
 
 
         if(read[pid(hit_id[jcs[i].hit_id[j]])].pos > 0)        // $B%Z%"%j!<%I$N%^%C%WJ}8~%W%i%9(B
          {
          fprintf(junction_cluster_pair," -+          ");
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           fprintf(junction_cluster_pair,"%c",read[pid(hit_id[jcs[i].hit_id[j]])].seq[k]);
          fprintf(junction_cluster_pair,"\n");
 
// MARK
          fprintf(junction_cluster_pair," -+          ");
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           {
           ptlen ++;
           if(read[pid(hit_id[jcs[i].hit_id[j]])].seq[k] == refseq[k+abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)])
            {
            fprintf(junction_cluster_pair,"*");
            ptcnt ++;
            }
           else
            fprintf(junction_cluster_pair," ");
           }
          fprintf(junction_cluster_pair,"\n");
          fprintf(junction_cluster_pair,"$-+ %4d %4d\n",ptcnt,ptlen);
// MARK
          }
         else                                                   // $B%Z%"%j!<%I$N%^%C%WJ}8~%^%$%J%9(B    
          {
          char rvcmp[512];
          rev_comp(rvcmp,read[pid(hit_id[jcs[i].hit_id[j]])].seq);
          fprintf(junction_cluster_pair," --          "); 
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           fprintf(junction_cluster_pair,"%c",rvcmp[k]);
          fprintf(junction_cluster_pair,"\n");

// MARK
          fprintf(junction_cluster_pair," --          ");
          for(k=0;k<read_len;k++)                                                                      // $B%8%c%s%/%7%g%s(B $B=gJ}8~%^%C%A(B
           {
           ptlen ++;
           if(rvcmp[k] == refseq[k+abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)])
            {
            fprintf(junction_cluster_pair,"*");
            ptcnt ++;
            }
           else
            fprintf(junction_cluster_pair," ");
           }
          fprintf(junction_cluster_pair,"\n");
          fprintf(junction_cluster_pair,"$-- %4d %4d\n",ptcnt,ptlen);
// MARK
          }
         }       // PAIR_READ

////////////////////////////////////////////CHECKPAIRENDPOSITION2 CPP2
        pflag = 0; 
        //////////////////// Condition 2-A
        if((abs(abs(hit_position[jcs[i].hit_id[j]]) - abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos))< 500) && (read[pid(hit_id[jcs[i].hit_id[j]])].pos > 0))
         {    
         pflag = 1; 
         }    
        else 
         {    
         //////////////////// Condition 2-B
         if(jcs[i].hit_pos[0] > 0) 
          {    
          if((abs(abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos)-abs(jcs[i].hit_pos[0])) < 600) && (read[pid(hit_id[jcs[i].hit_id[j]])].pos < 0))
           {    
           pflag = 1; 
           }    
          }    
         //////////////////// Condition 2-C
         else 
          {    
          if((abs(abs(read[pid(hit_id[jcs[i].hit_id[j]])].pos) - abs(jcs[i].hit_pos[0])) < 600) && (read[pid(hit_id[jcs[i].hit_id[j]])].pos > 0))
           {    
           pflag = 1; 
           }    
          }    
         }    
             
        if(pflag == 0)
         {    
         jcs[i].num_ireg_pair ++;
         fprintf(junction_cluster_pair,"&&&\n");
         }    
////////////////////////////////////////////CHECKPAIRENDPOSITION1 CPP2 
        }     // $B%8%c%s%/%7%g%s%/%i%9%?$,5UJ}8~%^%C%A(B
       fprintf(junction_cluster_pair,"\n");
       fprintf(junction_cluster_pair,"\n");
 
       ///////////////////////////////////////////////// Aug 17 2020, J_SHORT$B$N%^%C%A$,0-$$%j!<%I$r%+%&%s%H(B
       if(stcnt <= stlen - 2)            // $BC;$$J}$N%8%c%s%/%7%g%s%^%C%A$,%_%9%^%C%A$r0l$D0J>e4^$`>l9g(B
        {
        jcs[i].n_exclude ++;
        }
       else
        {
        if(pflag == 0)                    // $B%Z%"%j!<%I$N0LCV$,ITE,@Z$J>l9g(B
         jcs[i].n_exclude ++;
        else
         {
         tqtlen += stlen;
         tqtcnt += stcnt;
         tmtlen += mtlen;
         tmtcnt += mtcnt;
         tptlen += ptlen;
         tptcnt += ptcnt;
         }
        }
       }
     jcs[i].tqtlen = tqtlen;
     jcs[i].tmtlen = tmtlen;
     jcs[i].tptlen = tptlen;
     jcs[i].tqtcnt = tqtcnt;
     jcs[i].tmtcnt = tmtcnt;
     jcs[i].tptcnt = tptcnt;

     fprintf(junction_cluster_pair,
      "### JCS ID:%8d NumPair:%6d  %6d MM_start:%8d MM_HIT pos %10d:  HIT_TYPE %2d \n",i+1,jcs[i].n_member,jcs[i].n_exclude,jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].hit_flag[0]);
     fprintf(junction_cluster_pair,"J_LONG%8d/%8d %8.3f J_SHORT%8d/%8d %8.3f J_QUAL_SHORT %8d %8d %8.3f J_TOTAL%8d/%8d %8.3f PAIR  %8d/%8d %8.3f  TOTAL %8d/%8d %8.3f %4d %4d\n",
                                    tmtcnt,tmtlen,(float)tmtcnt/(float)tmtlen*100.0,
                                    tstcnt,tstlen,(float)tstcnt/(float)tstlen*100.0,
                                    tqtcnt,tqtlen,(float)tqtcnt/(float)tqtlen*100.0,
                                    tmtcnt+tqtcnt,tmtlen+tqtlen,(float)(tmtcnt+tqtcnt)/(float)(tmtlen+tqtlen)*100.0,
                                    tptcnt,tptlen,(float)tptcnt/(float)tptlen*100.0,
                                    tmtcnt+tqtcnt+tptcnt,tmtlen+tqtlen+tptlen,(float)(tmtcnt+tqtcnt+tptcnt)/(float)(tmtlen+tqtlen+tptlen)*100.0,jcs[i].n_member-jcs[i].n_exclude,jcs[i].num_ireg_pair);
     printf("### JCS ID:%8d NumPair:%6d %6d MM_start:%8d MM_HIT pos %10d:  HIT_TYPE %2d   ",i+1,jcs[i].n_member,jcs[i].n_exclude,jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].hit_flag[0]);
     printf("J_LONG%8d/%8d %8.3f J_SHORT%8d/%8d %8.3f J_QUAL_SHORT %8d %8d %8.3f J_TOTAL%8d/%8d %8.3f PAIR  %8d/%8d %8.3f  TOTAL %8d/%8d %8.3f %4d %4d\n",
                                    tmtcnt,tmtlen,(float)tmtcnt/(float)tmtlen*100.0,
                                    tstcnt,tstlen,(float)tstcnt/(float)tstlen*100.0,
                                    tqtcnt,tqtlen,(float)tqtcnt/(float)tqtlen*100.0,
                                    tmtcnt+tqtcnt,tmtlen+tqtlen,(float)(tmtcnt+tqtcnt)/(float)(tmtlen+tqtlen)*100.0,
                                    tptcnt,tptlen,(float)tptcnt/(float)tptlen*100.0,
                                    tmtcnt+tqtcnt+tptcnt,tmtlen+tqtlen+tptlen,(float)(tmtcnt+tqtcnt+tptcnt)/(float)(tmtlen+tqtlen+tptlen)*100.0,jcs[i].n_member-jcs[i].n_exclude,jcs[i].num_ireg_pair);
     fprintf(junction_cluster_pair,"\n");
     fprintf(junction_cluster_pair,"\n");
     fprintf(junction_cluster_pair,"\n");
     fprintf(junction_cluster_pair,"\n");
     fprintf(junction_cluster_pair,"\n");
     atmtlen += tmtlen;
     atstlen += tstlen;
     atqtlen += tqtlen;
     atptlen += tptlen;
     atmtcnt += tmtcnt;
     atstcnt += tstcnt;
     atqtcnt += tqtcnt;
     atptcnt += tptcnt;
     }
    }
   }
  }     // num_jcs $B%k!<%W(B
 /////////////////////////////////////////////////////////////////////////////////////////////^ $B%8%c%s%/%7%g%s%/%i%9%?(B $B%Z%"%A%'%C%/(B July 2020  .jcp $B%U%!%$%k$K7k2L$r=PNO(B
 ////////////////////////////////////////////$BA4%8%c%s%/%7%g%s%/%i%9%?$G$N%5%^%j!<(B
/*
 printf("TOTAL: J_LONG:%10ld/%10ld %8.3f J_SHORT%10ld/%10ld %8.3f J_QUAL_SHORT %10ld %10ld %8.3f J_TOTAL%10ld/%10ld %8.3f PAIR  %10ld/%10ld %8.3f  TOTAL %10ld/%10ld %8.3f\n",
                                    atmtcnt,atmtlen,(float)atmtcnt/(float)atmtlen*100.0,
                                    atstcnt,atstlen,(float)atstcnt/(float)atstlen*100.0,
                                    atqtcnt,atqtlen,(float)atqtcnt/(float)atqtlen*100.0,
                                    atmtcnt+atqtcnt,atmtlen+atqtlen,(float)(atmtcnt+atqtcnt)/(float)(atmtlen+atqtlen)*100.0,
                                    atptcnt,atptlen,(float)atptcnt/(float)atptlen*100.0,
                                    atmtcnt+atqtcnt+atptcnt,atmtlen+atqtlen+atptlen,(float)(atmtcnt+atqtcnt+atptcnt)/(float)(atmtlen+atqtlen+atptlen)*100.0);
 fprintf(junction_cluster_pair,"TOTAL: J_LONG:%10ld/%10ld %8.3f J_SHORT%10ld/%10ld %8.3f J_QUAL_SHORT %10ld %10ld %8.3f J_TOTAL%10ld/%10ld %8.3f PAIR  %10ld/%10ld %8.3f  TOTAL %10ld/%10ld %8.3f\n",
                                    atmtcnt,atmtlen,(float)atmtcnt/(float)atmtlen*100.0,
                                    atstcnt,atstlen,(float)atstcnt/(float)atstlen*100.0,
                                    atqtcnt,atqtlen,(float)atqtcnt/(float)atqtlen*100.0,
                                    atmtcnt+atqtcnt,atmtlen+atqtlen,(float)(atmtcnt+atqtcnt)/(float)(atmtlen+atqtlen)*100.0,
                                    atptcnt,atptlen,(float)atptcnt/(float)atptlen*100.0,
                                    atmtcnt+atqtcnt+atptcnt,atmtlen+atqtlen+atptlen,(float)(atmtcnt+atqtcnt+atptcnt)/(float)(atmtlen+atqtlen+atptlen)*100.0);
*/
 ////////////////////////////////////////////$BA4%8%c%s%/%7%g%s%/%i%9%?$G$N%5%^%j!<(B

 }     /// excluded when so=SNP only option is set
else   // SNP $B%A%'%C%/(B  2020 July $B=);3$5$s%W%m%8%'%/%H(B
 {
////////////////////////////////////////v Print out snp file July 2020        -so snp_only $B%*%W%7%g%s!!!!(BSNP$B8uJd$r8!=P$9$k$?$a%l%U%!%l%s%93F0LCV$N%j!<%I$N(BATGC$B$N?t$rI=<((B
//                                                                           $B%_%9%^%C%A(B3$B0J2<$N%j!<%I$N$_$r8+$k(B
//                                                                           $BN>C<(B3$B1v4p0JFb$O8+$J$$(B
 for(i=0;i<refseq_len;i++)
  {
  float val = second_ratio(pos_A[i],pos_T[i],pos_G[i],pos_C[i],pos_Base[i]);
  if((val > 1.0) && (val <=2.0))
   fprintf(snp_file,"%10d %8d %8d %8d %8d %10d *\n",i+1,pos_A[i],pos_T[i],pos_G[i],pos_C[i],pos_Base[i]);
  else
   if((val > 2.0) && (val <= 4.0))
    fprintf(snp_file,"%10d %8d %8d %8d %8d %10d **\n",i+1,pos_A[i],pos_T[i],pos_G[i],pos_C[i],pos_Base[i]);
   else
    if((val > 4.0) && (val <= 8.0))
     fprintf(snp_file,"%10d %8d %8d %8d %8d %10d ***\n",i+1,pos_A[i],pos_T[i],pos_G[i],pos_C[i],pos_Base[i]);
    else
     if(val > 8.0)
      fprintf(snp_file,"%10d %8d %8d %8d %8d %10d ****\n",i+1,pos_A[i],pos_T[i],pos_G[i],pos_C[i],pos_Base[i]);
     else
      fprintf(snp_file,"%10d %8d %8d %8d %8d %10d\n",i+1,pos_A[i],pos_T[i],pos_G[i],pos_C[i],pos_Base[i]);
  }
 }
////////////////////////////////////////^ Print out snp file July 2020        -so snp_only $B%*%W%7%g%s!!!!(BSNP$B8uJd$r8!=P$9$k$?$a%l%U%!%l%s%93F0LCV$N%j!<%I$N(BATGC$B$N?t$rI=<((B

//////////////////////////////////////// 2020 Aug.15 pal,del,hr,ins,unk$B$N=PNO:G8e$K0\F0(B ($B%^%C%A%+%&%s%H>r7o$r%A%'%C%/$7$F$+$i!K(B .hmr$B$OL$BP1~(B
long int valid_junction_read = 0;
long int jread_hr = 0;
long int jread_del = 0;
long int jread_ins = 0;
long int jread_pal = 0;
long int jread_unk = 0;
long int jc_hr = 0;  
long int jc_del = 0;  
long int jc_ins = 0;  
long int jc_pal = 0;  
long int jc_unk = 0;  
long int jc_total = 0;  
atmtlen = 0;
atstlen = 0;
atqtlen = 0;
atptlen = 0;
atmtcnt = 0;
atstcnt = 0;
atqtcnt = 0;
atptcnt = 0;
for(i=0;i<num_jcs;i++)              // $B%8%c%s%/%7%g%s%/%i%9%?$N%k!<%W(B    // ~500$B9T$ND9$$%k!<%W(B
 {
 if(jcs[i].num_hit == 1)                                 // $B%8%c%s%/%7%g%s%/%i%9%?$N%3%s%;%s%5%9$,%2%N%`>e$I$3$+$K0l2U=j$@$1%R%C%H$7$F$$$l$P(B
  {
//  if(jcs[i].n_member > 3)                              // $B%8%c%s%/%7%g%s%/%i%9%?$N%a%s%P!<%8%c%s%/%7%g%s?t$,#30J>e$J$i(B
   if(strlen(jcs[i].consensus_seq_i2) >= consensus_length)   // $B%3%s%;%s%5%9$ND9$5$r(B -cl ## $B1v4p0J>e$H$9$k(B $B8|$_(B(-cd)$B$O%3%s%;%s%5%9$r@Z$k$H$-$K;H$C$F$$$k(B
    {
    if((jcs[i].n_true_member > 3) && ((((float)jcs[i].n_true_member)/((float)jcs[i].n_member)) > 0.5))
     {
     if(jcs[i].base_count != 0)                          // $BJ,Jl%A%'%C%/(B 0 $B$G$J$$(B
      {
      if((jcs[i].n_member - jcs[i].n_exclude) >= 3)      // Aug 19 2020 $B%8%c%s%/%7%g%s(B $B%A%'%C%/8e$N%a%s%P?t$,#30J>e(B
       {

       if((jcs[i].mm_start != -85220) && (jcs[i].mm_start != 94811))
        {
        atmtlen += jcs[i].tmtlen;
        atmtcnt += jcs[i].tmtcnt;
        atqtlen += jcs[i].tqtlen;
        atqtcnt += jcs[i].tqtcnt;
        atptlen += jcs[i].tptlen;
        atptcnt += jcs[i].tptcnt;

        mindiff = MAX_INT;                      // $BAH$_BX$(E@$,:G$b6a$$$b$N$rA*Br(B
        hitid = -1;
        flag  = 0; 
        for(j=0;j<jcs[i].num_hit;j++)
         {
         pos_diff = abs(abs(jcs[i].hit_pos[j]) - abs(jcs[i].mm_start));
         if((jcs[i].hit_flag[j] != 0) && (pos_diff < mindiff))
          {    
          mindiff = pos_diff;
          flag = jcs[i].hit_flag[j];           // $B$=$N%R%C%H$NAH49$N%?%$%W$r!"$3$N%8%c%s%/%7%g%s%/%i%9%?$NAH49%?%$%W$H7h$a$k(B 
          hitid = j;                           // hitid $B$K$=$N%R%C%H$N(BID$B$r5-O?(B 
          }    
         }
        valid_junction_read += (jcs[i].n_member - jcs[i].n_exclude);  // n_exclude $B$O%8%c%s%/%7%g%s%j!<%I$NC;$$B&$N%^%C%W>uBV!"$^$?$O!"%Z%"%j!<%I$N%^%C%W0LCV$GIT@09g$J$b$N$@$1<h$C$F$$$k(B
        switch (jcs[i].hit_flag[0])
         {
         case 1:  // pal
            fprintf(pal_file,"P %10d %10d %10d %s\n",abs(jcs[i].mm_start),abs(jcs[i].hit_pos[0]),jcs[i].n_true_member,jcs[i].homoseq);
            fprintf(arr_file,"P %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
            jread_pal += (jcs[i].n_member - jcs[i].n_exclude); 
            jc_pal ++;
            jc_total ++;
            break;
         case 2:  // del
            fprintf(del_file,"D %5d %10d %10d\n",abs(jcs[i].idlen),abs(jcs[i].mm_start),jcs[i].n_true_member);
            fprintf(arr_file,"D %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
            jread_del += (jcs[i].n_member - jcs[i].n_exclude); 
            jc_del ++;
            jc_total ++;
            break;
         case 3:  // hr
            fprintf(hr_file,"H %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].n_true_member,jcs[i].homoseq);
            fprintf(arr_file,"H %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
            jread_hr += (jcs[i].n_member - jcs[i].n_exclude); 
            jc_hr ++;
            jc_total ++;
           break;
         case 4:  // ins
            if(jcs[i].mm_start > 0)
             {
             fprintf(ins_file,"I %5d %10d %10d %s\n",abs(jcs[i].idlen),jcs[i].mm_start-1,jcs[i].n_true_member,jcs[i].homoseq);
             fprintf(arr_file,"I %10d %10d %10d %s\n",jcs[i].mm_start-1,jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
             jread_ins += (jcs[i].n_member - jcs[i].n_exclude); 
             }
            else
             {
             fprintf(ins_file,"I %5d %10d %10d %s\n",abs(jcs[i].idlen),abs(jcs[i].mm_start),jcs[i].n_true_member,jcs[i].homoseq);
             fprintf(arr_file,"I %10d %10d %10d %s\n",abs(jcs[i].mm_start),jcs[i].hit_pos[hitid],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
             jread_ins += (jcs[i].n_member - jcs[i].n_exclude); 
             }
            jc_ins ++;
            jc_total ++;
            break;
         default: // unk
            fprintf(unk_file,"U %10d %10d %10d\n",jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].n_true_member);            // $B$H$j$"$($:#18DL\$N%R%C%H$rI=<((B
            fprintf(arr_file,"U %10d %10d %10d %s\n",jcs[i].mm_start,jcs[i].hit_pos[0],jcs[i].n_true_member,jcs[i].homoseq);     //   .arr all rearrangement
            jread_unk += (jcs[i].n_member - jcs[i].n_exclude); 
            jc_unk ++;
            jc_total ++;
            break;
         }
        }

       }
      }
     }
    }
  }
 }

 printf("TOTAL: J_LONG:%10ld/%10ld %8.3f J_QUAL_SHORT %10ld %10ld %8.3f J_TOTAL%10ld/%10ld %8.3f PAIR  %10ld/%10ld %8.3f  TOTAL %10ld/%10ld %8.3f\n",
                                    atmtcnt,atmtlen,(float)atmtcnt/(float)atmtlen*100.0,
                                    atqtcnt,atqtlen,(float)atqtcnt/(float)atqtlen*100.0,
                                    atmtcnt+atqtcnt,atmtlen+atqtlen,(float)(atmtcnt+atqtcnt)/(float)(atmtlen+atqtlen)*100.0,
                                    atptcnt,atptlen,(float)atptcnt/(float)atptlen*100.0,
                                    atmtcnt+atqtcnt+atptcnt,atmtlen+atqtlen+atptlen,(float)(atmtcnt+atqtcnt+atptcnt)/(float)(atmtlen+atqtlen+atptlen)*100.0);
 fprintf(junction_cluster_pair,"TOTAL: J_LONG:%10ld/%10ld %8.3f J_QUAL_SHORT %10ld %10ld %8.3f J_TOTAL%10ld/%10ld %8.3f PAIR  %10ld/%10ld %8.3f  TOTAL %10ld/%10ld %8.3f\n",
                                    atmtcnt,atmtlen,(float)atmtcnt/(float)atmtlen*100.0,
                                    atqtcnt,atqtlen,(float)atqtcnt/(float)atqtlen*100.0,
                                    atmtcnt+atqtcnt,atmtlen+atqtlen,(float)(atmtcnt+atqtcnt)/(float)(atmtlen+atqtlen)*100.0,
                                    atptcnt,atptlen,(float)atptcnt/(float)atptlen*100.0,
                                    atmtcnt+atqtcnt+atptcnt,atmtlen+atqtlen+atptlen,(float)(atmtcnt+atqtcnt+atptcnt)/(float)(atmtlen+atqtlen+atptlen)*100.0);

printf("n_read_pal: %8ld n_read_del: %8ld n_read_ins %8ld n_read_hr %8ld n_read_unk: %8ld n_read_valid_junction: %8ld\n",jread_pal,jread_del,jread_ins,jread_hr,jread_unk,valid_junction_read);
printf("n_jc_pal: %8ld n_jc_del: %8ld n_jc_ins %8ld n_jc_hr %8ld n_jc_unk: %8ld n_jc_valid_junction: %8ld\n",jc_pal,jc_del,jc_ins,jc_hr,jc_unk,jc_total);
fprintf(junction_cluster_pair,"n_read_pal: %8ld n_read_del: %8ld n_read_ins %8ld n_read_hr %8ld n_read_unk: %8ld n_read_valid_junction: %8ld\n",jread_pal,jread_del,jread_ins,jread_hr,jread_unk,valid_junction_read);
fprintf(junction_cluster_pair,"n_jc_pal: %8ld n_jc_del: %8ld n_jc_ins %8ld n_jc_hr %8ld n_jc_unk: %8ld n_jc_valid_junction: %8ld\n",jc_pal,jc_del,jc_ins,jc_hr,jc_unk,jc_total);
}



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "comp_unk.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}
//////////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
FILE        *unk_list;
FILE        *unk_file;
FILE        *unk_out;
FILE        *unk_out2;
char        buff[512];
char        unk_out_flnm[512];
char        unk_out2_flnm[512];
int         n_files = 0;
int         n_lines = 0;
word_info   files[MAX_FILE];
unks_infos  unks[MAX_FILE];
int         pointer[MAX_FILE];
int         read_count[MAX_FILE];
double      bias_ratio[MAX_FILE];
int         min;
int         temp;
int         temp_min;
int         temp_order;
int         bias_flag = 1;
share_info  *scs;
int         n_scs   = 0;
int         max_scs = 0;
int         flag;

readargs(argc,argv);

printf("INPUT UNKOWN JUNCTION LIST FILES NAME IS: %s\n",arg1);   // $BFI$_9~$`%j%9%H%U%!%$%k3+$/(B
unk_list = fopen(arg1,"r");
if(unk_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

sprintf(unk_out_flnm,"%s.out",arg1);                             // $B=PNO%U%!%$%k3+$/(B out1
unk_out = fopen(unk_out_flnm,"w");
if(unk_out == NULL)
 {
 printf("Failed to open the output file %s\n",unk_out_flnm);
 exit(1);
 }

sprintf(unk_out2_flnm,"%s.out2",arg1);                           // $B=PNO%U%!%$%k3+$/(B out2
unk_out2 = fopen(unk_out2_flnm,"w");
if(unk_out2 == NULL)
 {
 printf("Failed to open the output file %s\n",unk_out2_flnm);
 exit(1);
 }

while(fgets(buff,512,unk_list))                                  // $BF~NO%j%9%H%U%!%$%kFI$`(B
 {
 sscanf(buff,"%s %d",files[n_files].word,&read_count[n_files]);  // $B%U%!%$%kL>$H%j!<%I?t(B  files[].word, read_count[]
// buff[strlen(buff)-1] = '\0';
// printf("%s\n",buff);
// strcpy(files[n_files].word,buff);
 n_files ++;
 }

//////////////////////////////////////////////////////
for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 if(read_count[i] == 0)                           // $BFI$_9~$s$@%j!<%I%+%&%s%H$K0l$D$G$b(B0$B$N$b$N$,$"$l$P(B              ///
  {                                                                                                                 ///
  bias_flag = 0;                                  // $B%j!<%I?t%P%$%"%9$O9MN8$7$J$$(B                                   ///
  }                                                                                                                 ///
 }                                                                                                                  ///

///////////////////////////////////////////////////// $B%j!<%I?t%P%$%"%9$NHfN((B bias_ratio[] $B$r7W;;(B
if(bias_flag == 1)                                                                                                  ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  {                                                                                                                 ///
  bias_ratio[i] = (double)read_count[i] / (double)read_count[0];                                                    ///
  }                                                                                                                 ///
 }                                                                                                                  ///
else                                                                                                                ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  bias_ratio[i] = 1.0;                                                                                              ///
 }                                                                                                                  ///

/////////////////////////////////////////////////////   $BF~NO%U%!%$%kL>!&%j!<%I?t!&%P%$%"%9HfN($N3NG'=PNO(B
for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 printf("%-55s %10d %10.5f\n",files[i].word,read_count[i],bias_ratio[i]*100.0);                                     ///
 }                                                                                                                  ///

//////////////////////////////////////////////////////

///////////////////////////////////////////////////// $B%j%9%H$KM-$kF~NO%U%!%$%k$r$9$Y$F3+$$$FFI$`(B
for(i=0;i<n_files;i++)
 {
 unk_file = fopen(files[i].word,"r");
 if(unk_file == NULL)
  {
  printf("Failed to open the input file %s\n",files[i].word);
  exit(1);
  }

 n_lines = 0;
 while(fgets(buff,512,unk_file))
  {
  n_lines ++;
  }
 unks[i].n_unk = n_lines;
 unks[i].uinf  = (unk_info *)malloc(sizeof(unk_info)*(n_lines + 2));
 
 rewind(unk_file);

 n_lines = 0;
 while(fgets(buff,512,unk_file))
  {
  unks[i].uinf[n_lines].start    = read_int(buff, 3,10);   // $B5/E@(B
  unks[i].uinf[n_lines].end      = read_int(buff,14,10);   // $B=*E@(B
  unks[i].uinf[n_lines].n_member = read_int(buff,25,10);   // $B%j!<%I?t(B

  if(abs(unks[i].uinf[n_lines].start) < abs(unks[i].uinf[n_lines].end))   // $B5/E@$H=*E@$rHf3S$7@dBPCM$N>/$J$$J}$r(Bleft
   {                                                                      // $B$b$&0lJ}$r(Bright $B$H$7$F$$$k!#(B
   unks[i].uinf[n_lines].left  = unks[i].uinf[n_lines].start;
   unks[i].uinf[n_lines].right = unks[i].uinf[n_lines].end;
   }
  else
   {
   unks[i].uinf[n_lines].right = unks[i].uinf[n_lines].start;
   unks[i].uinf[n_lines].left  = unks[i].uinf[n_lines].end;
   }
//  printf("%5d %8d %8d  %8d %8d %5d\n",i+1,unks[i].uinf[n_lines].start,unks[i].uinf[n_lines].end,
//             unks[i].uinf[n_lines].left,unks[i].uinf[n_lines].right,unks[i].uinf[n_lines].n_member);
  n_lines ++;
  }
// printf("%5d %s\n",n_lines,files[i].word);
 max_scs += n_lines;
 fclose(unk_file);
 pointer[i] = 0;
 }
///////////////////////////////////////////////////// $B%j%9%H$KM-$kF~NO%U%!%$%k$r$9$Y$F3+$$$FFI$`(B
scs = (share_info *)malloc(sizeof(share_info) * (max_scs +1));
if (scs == NULL)
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }
for(i=0;i<max_scs;i++)
 {
 scs[i].n_member = (int *)malloc(sizeof(int) * n_files);
 for(j=0;j<n_files;j++)
  scs[i].n_member[j] = 0;
 }

for(i=0;i<n_files;i++)
 {
 for(j=0;j<unks[i].n_unk;j++)
  {
  flag = 0;
  for(k=0;k<n_scs;k++)
   {
   if((unks[i].uinf[j].start == scs[k].from) && (unks[i].uinf[j].end == scs[k].to))
    {
    scs[k].n_member[i] = unks[i].uinf[j].n_member;
    flag = 1;
    break;
    }
   }
  if(flag == 0)  // $B?75,%(%s%H%j(B
   {
   scs[n_scs].from          = unks[i].uinf[j].start;
   scs[n_scs].to            = unks[i].uinf[j].end;
   scs[n_scs].n_member[i]   = unks[i].uinf[j].n_member;
   n_scs ++;
   }
  }
 }

for(i=0;i<n_scs;i++)
 {
 fprintf(unk_out,"%8d %8d ",scs[i].from,scs[i].to);
 fprintf(unk_out2,"%8d %8d ",scs[i].from,scs[i].to);
 for(j=0;j<n_files;j++)
  {
  fprintf(unk_out,"%8d ",scs[i].n_member[j]);
  fprintf(unk_out2,"%8.2f ",(double)scs[i].n_member[j]*bias_ratio[j]);
  }
 fprintf(unk_out,"\n");
 fprintf(unk_out2,"\n");
 }
printf("N_SCS = %10d\n",n_scs);

/*
for(i=0;i<n_files;i++)
 {
 for(j=0;j<unks[i].n_unk;j++)
  {
  if(unks[i].uinf[j].sum == unks[i].uinf[unks[i].order[j]].sum)
   printf("%8d %8d\n",unks[i].uinf[j].sum,unks[i].uinf[unks[i].order[j]].sum);
  else
   printf("%8d %8d#\n",unks[i].uinf[j].sum,unks[i].uinf[unks[i].order[j]].sum);
  }
 }


int end;
while(1)
 {
 min = MAX_INT;
 end = MAX_INT;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] < unks[i].n_unk)
   if(min > abs(unks[i].uinf[pointer[i]].left))
    {
    min = abs(unks[i].uinf[pointer[i]].left);
    end = abs(unks[i].uinf[pointer[i]].right);
    }
  }
 printf("MIN %d %d \n",min,end);
 fprintf(unk_out,"%d,%d,",min,end);
 fprintf(unk_out2,"%d,%d,",min,end);

 for(i=0;i<n_files;i++)
  {
  if(pointer[i] < unks[i].n_unk)
   {
   if(min == abs(unks[i].uinf[pointer[i]].left))
    {
//    printf("%2d %8d %8d %8d\n",i+1,unks[i].uinf[pointer[i]].left,unks[i].uinf[pointer[i]].right,
//                                unks[i].uinf[pointer[i]].n_member);
    printf("%2d %8d %8d %8d %10.2f\n",i+1,unks[i].uinf[pointer[i]].left,unks[i].uinf[pointer[i]].right,
                                unks[i].uinf[pointer[i]].n_member,
                                (double)unks[i].uinf[pointer[i]].n_member/bias_ratio[i]);
    fprintf(unk_out,"%d,",unks[i].uinf[pointer[i]].n_member);
    fprintf(unk_out2,"%.2f,",(double)unks[i].uinf[pointer[i]].n_member/bias_ratio[i]);
    pointer[i] ++;
    }
   else
    {
    fprintf(unk_out,"0,");
    fprintf(unk_out2,"0.0,");
    }
   }
  else
   {
   fprintf(unk_out,"0,");
   fprintf(unk_out2,"0.0,");
   }
  }
 
 fprintf(unk_out,"\n");
 fprintf(unk_out2,"\n");

 temp = 0;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] == unks[i].n_unk)
   temp ++;
  }
 if(temp == n_files)
  break;
 }
*/


/////////////////////////////////////////////////////////////////DONE READING FILES
}
/////////////////////////////////////////////////////////////////////////MAIN END

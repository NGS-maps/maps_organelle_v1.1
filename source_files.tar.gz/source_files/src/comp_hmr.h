#include <string.h>

#define MAX_INT     2147483647
#define MAX_SEQ_LEN        256

typedef struct word_info
 {
 char word[512];
 } word_info;

typedef struct hmr_info
 {
 int  L1,L2,R1,R2;
 int  n_member1,n_member2;
 int  seq_len;
 char seq[256];
 } hmr_info;

typedef struct hmrs_infos
 {
 int n_hmr;
 hmr_info *hinf;
 } hmrs_infos;

void readargs(int argc, char **argv);

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "comp_ins.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}
//////////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
FILE        *ins_list;
FILE        *ins_file;
FILE        *ins_out;
char        ins_out_flnm[512];
FILE        *ins_out2;                ///
char        ins_out2_flnm[512];       ///
char        buff[512];
char        iseq[512];
int         n_files = 0;
int         n_lines = 0;
word_info   files[MAX_FILE];
ins_infos   inss[MAX_FILE];
int         read_count[MAX_FILE];     ///
double      bias_ratio[MAX_FILE];     ///
int         pointer[MAX_FILE];
int         min;
int         nins;
int         temp;
int         temp_min;
int         temp_order;
int         bias_flag = 1;            ///

readargs(argc,argv);

printf("INPUT PALINDROME LIST FILES NAME IS: %s\n",arg1);
ins_list = fopen(arg1,"r");
if(ins_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

sprintf(ins_out_flnm,"%s.out",arg1);
ins_out = fopen(ins_out_flnm,"w");
if(ins_out == NULL)
 {
 printf("Failed to open the output file %s\n",ins_out_flnm);
 exit(1);
 }

sprintf(ins_out2_flnm,"%s.out2",arg1);                            ///
ins_out2 = fopen(ins_out2_flnm,"w");                              ///
if(ins_out2 == NULL)                                              ///
 {                                                                ///
 printf("Failed to open the output file %s\n",ins_out2_flnm);     ///
 exit(1);                                                         ///
 }                                                                ///

while(fgets(buff,512,ins_list))
 {
 sscanf(buff,"%s %d",files[n_files].word,&read_count[n_files]);   ///
// buff[strlen(buff)-1] = '\0';                                   ///
// printf("%s\n",buff);
// strcpy(files[n_files].word,buff);                              ///
 n_files ++;
 }

///////////////////////////////////////////////////////////////////////////

for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 if(read_count[i] == 0)                           // $BFI$_9~$s$@%j!<%I%+%&%s%H$K0l$D$G$b(B0$B$N$b$N$,$"$l$P(B              ///
  {                                                                                                                 ///
  bias_flag = 0;                                  // $B%j!<%I?t%P%$%"%9$O9MN8$7$J$$(B                                   ///
  }                                                                                                                 ///
 }                                                                                                                  ///

if(bias_flag == 1)                                                                                                  ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  {                                                                                                                 ///
  bias_ratio[i] = (double)read_count[i] / (double)read_count[0];                                                    ///
  }                                                                                                                 ///
 }                                                                                                                  ///
else                                                                                                                ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  bias_ratio[i] = 1.0;                                                                                              ///
 }                                                                                                                  ///

for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 printf("%-55s %10d %10.5f\n",files[i].word,read_count[i],bias_ratio[i]*100.0);                                     ///
 }                                                                                                                  ///

///////////////////////////////////////////////////////////////////////////
for(i=0;i<n_files;i++)
 {
 ins_file = fopen(files[i].word,"r");
 if(ins_file == NULL)
  {
  printf("Failed to open the input file %s\n",files[i].word);
  exit(1);
  }

 n_lines = 0;
 while(fgets(buff,512,ins_file))
  {
  n_lines ++;
  }
 inss[i].n_ins = n_lines;
 inss[i].iinf  = (ins_info *)malloc(sizeof(ins_info)*(n_lines + 2));
 
 rewind(ins_file);

 n_lines = 0;
 while(fgets(buff,512,ins_file))
  {
  inss[i].iinf[n_lines].n_ins    = read_int(buff, 2, 6);
  inss[i].iinf[n_lines].start    = read_int(buff, 9,10);
  inss[i].iinf[n_lines].n_member = read_int(buff,20,10);
  strcpy(inss[i].iinf[n_lines].seq,&buff[30]);
  inss[i].iinf[n_lines].seq[strlen(inss[i].iinf[n_lines].seq)-1] = '\0';
//  printf("%8d %8d %5d\n",inss[i].iinf[n_lines].start,inss[i].iinf[n_lines].n_ins,inss[i].iinf[n_lines].n_member);
  n_lines ++;
  }
 printf("%5d %s\n",n_lines,files[i].word);
 fclose(ins_file);
 pointer[i] = 0;
 }

/*
for(i=0;i<n_files;i++)
 {
 for(j=0;j<inss[i].n_ins;j++)
  {
  if(inss[i].iinf[j].sum == inss[i].iinf[inss[i].order[j]].sum)
   printf("%8d %8d\n",inss[i].iinf[j].sum,inss[i].iinf[inss[i].order[j]].sum);
  else
   printf("%8d %8d#\n",inss[i].iinf[j].sum,inss[i].iinf[inss[i].order[j]].sum);
  }
 }
*/

while(1)
 {
 min = MAX_INT;
 nins = MAX_INT;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] < inss[i].n_ins)
   if(min > inss[i].iinf[pointer[i]].start)
    {
    min = inss[i].iinf[pointer[i]].start;
    nins= inss[i].iinf[pointer[i]].n_ins;
    strcpy(iseq,inss[i].iinf[pointer[i]].seq);
    }
  }
 printf("MIN %d\n",min);
 fprintf(ins_out,"%d,%d,%s,",min,nins,iseq);
 fprintf(ins_out2,"%d,%d,%s,",min,nins,iseq);

 for(i=0;i<n_files;i++)
  {
  if(pointer[i] < inss[i].n_ins)
   {
   if(min == inss[i].iinf[pointer[i]].start)
    {
//    printf("%2d %8d %8d %8d %s\n",i+1,inss[i].iinf[pointer[i]].start,inss[i].iinf[pointer[i]].n_ins,
//                                inss[i].iinf[pointer[i]].n_member,inss[i].iinf[pointer[i]].seq);
    printf("%2d %8d %8d %8d %10.2f %s\n",i+1,inss[i].iinf[pointer[i]].start,inss[i].iinf[pointer[i]].n_ins,    ///
                                inss[i].iinf[pointer[i]].n_member,
                                (double)inss[i].iinf[pointer[i]].n_member/bias_ratio[i],                       ///
                                inss[i].iinf[pointer[i]].seq);               ///
    fprintf(ins_out,"%d,",inss[i].iinf[pointer[i]].n_member);
    fprintf(ins_out2,"%.2f,",(double)inss[i].iinf[pointer[i]].n_member/bias_ratio[i]);                             ///                                 
    pointer[i] ++;
    }
   else
    {
    fprintf(ins_out,"0,");
    fprintf(ins_out2,"0.0,");
    }
   }
  else
   {
   fprintf(ins_out,"0,");
   fprintf(ins_out2,"0.0,");
   }
  }
 fprintf(ins_out,"\n");
 fprintf(ins_out2,"\n");

 temp = 0;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] == inss[i].n_ins)
   temp ++;
  }
 if(temp == n_files)
  break;
 }

/////////////////////////////////////////////////////////////////DONE READING FILES
}
/////////////////////////////////////////////////////////////////////////MAIN END

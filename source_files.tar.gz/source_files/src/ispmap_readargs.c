#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "ispmap.h"

char arg1[256];
char arg2[256];
extern int map_out;
extern int mmmpop;
extern int bit_exact;
extern int comp_cyan;
extern int left_caption;
extern int tag_count;
extern int show_pop;
extern int gene_pop;
extern int use_multihit;
extern int ps_out;
extern int jobname;
extern int show_quality;
extern int read_gb;
extern int read_ge;
extern int rmap_out;
extern int hmap_out;
extern int no_histo_bar;
extern int chop_limit;
extern int show_exon;
extern int edge_check;
extern int edge_check2;
extern int win_size;
extern int quality_edge;
extern int pop_every_bp;
extern int no_gene_caption;
extern double height_scale;
extern int base_per_pixel;
extern char job_name[];
extern double bit_width;
extern double bit_height;
extern double w_width;
extern double w_height;
extern double g_width;
extern double g_height;
extern double max_page_height;
extern double thresh_page_height;
extern char genbank_flnm[];
extern int log_scale;
extern double first_scale;
extern double secnd_scale;
extern double third_scale;
extern double first_depth;
extern double secnd_depth;
extern double third_depth;
extern int  ggc_marker;
extern int  mismatchcolor;
extern int  mismatchcolor2;
extern int  ec_ratio;
extern int  offset;
extern float  quality_edge_threshold;
extern int ps_from;
extern int ps_to;
extern int  show_av_qual;
extern int  show_mm_ratio;
extern int  input_is_sam;


void errorm(int en);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;
int flag = 0;
char tempchar[80];

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {
  if((argv[arg][1] == 'm') && (argv[arg][2] == 'a') &&(argv[arg][3] == 'p'))    // -map: output text map   refference.fasta.map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    map_out  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'm') &&(argv[arg][3] == 'c') && (argv[arg][4] == '1'))    // -mmc1: mismatch different color
   {
   if(argv[arg][5] != '\0')
    errorm(1);
   else
    {
    mismatchcolor  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'm') &&(argv[arg][3] == 'c') && (argv[arg][4] == '2'))    // -mmc2: mismatch different color
   {
   if(argv[arg][5] != '\0')
    errorm(1);
   else
    {
    mismatchcolor2  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'm') &&(argv[arg][3] == 'm') && (argv[arg][4] == 'p'))    // -mmmp: match mismatch ratio population count 
   {
   if(argv[arg][5] != '\0')
    errorm(1);
   else
    {
    mmmpop  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'n') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'c'))    // -ngc: no gene caption
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    no_gene_caption  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 'a') &&(argv[arg][3] == 'm'))    // -sam: input read format is sam
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    input_is_sam  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'n') && (argv[arg][2] == 'h') &&(argv[arg][3] == 'b'))    // -nhb: no histogram bar
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    no_histo_bar  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'l') && (argv[arg][2] == 'o') && (argv[arg][3] == 'g'))    // -log: log_scale for histogram type output
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    log_scale  = 1;
    }
   continue;
   }


  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') &&(argv[arg][3] == 'b'))    // -job jobname : specify smap run by jobname
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    jobname  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(job_name,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'b'))    // -rgb genbank_flnm : read genbank file and show gene info on the map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_gb  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(genbank_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'r') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'e'))    // -rge genbank_flnm : read eukariote genbank file and show gene info on the map
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    read_ge  = 1;

    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(genbank_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'b') && (argv[arg][2] == 'w'))    // -bw ##       : bitwise display  take bit_size as an arguement
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    bit_exact  = 1;
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(tempchar,argv[arg]);
    bit_width  = atof(tempchar);
    bit_height = atof(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 'w') && (argv[arg][2] == 'i') && (argv[arg][3] == 'n'))    // -win ##    : windows
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(tempchar,argv[arg]);
    win_size  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'e') && (argv[arg][3] == 'b'))    // -peb ##    : population every bp Ishikawa-san special
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(tempchar,argv[arg]);
    pop_every_bp  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 'e') && (argv[arg][2] == 'c') && (argv[arg][3] == 'r'))    // -ecr ##    : edge check ratio
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(tempchar,argv[arg]);
    ec_ratio  = atoi(tempchar);
    }
   continue;
   }


  if((argv[arg][1] == 'l') && (argv[arg][2] == 'c'))    // -lc: Display sequence position at the left side of the screen
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    left_caption  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'n') && (argv[arg][2] == 'p'))    // -np: no postscript output
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    ps_out  = 0;
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 's'))    // -ps: PostScript Output (no display on screen)
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    ps_out  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'q') && (argv[arg][2] == 'e'))    // -qe: Quality Edge
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    quality_edge  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'g') && (argv[arg][2] == 'g') &&(argv[arg][3] == 'c'))    // -ggc: GGC/GCC mark
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    ggc_marker  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'e') && (argv[arg][2] == 'c'))    // -ec: edge_check
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    edge_check  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'e') && (argv[arg][2] == '2'))    // -e2: edge_check2
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    edge_check2  = 1;
    }
   continue;
   }


  if((argv[arg][1] == 's') && (argv[arg][2] == 'x'))    // -sx: show exon with -rge
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    show_exon  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'h') && (argv[arg][2] == 'd'))    // -hd ##  : histogram type Population Display, ## = basepair per pixel
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    rmap_out  = 0;
    hmap_out  = 1;
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    base_per_pixel  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 'q') && (argv[arg][2] == 'o'))    // -qo ##  : quality offset 33(sanger) or 64(illumina)
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    offset  = atoi(tempchar);
    if(offset == 33)
     quality_edge_threshold = 20.0;
    else
     quality_edge_threshold = 40.0;
    }
   continue;
   }

  if((argv[arg][1] == 'd') && (argv[arg][2] == 's'))    // -ds ## : height_scale for histo gram type display
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(2);
    strcpy(tempchar,argv[arg]);
    height_scale  = (double)atof(tempchar);
printf("HEIGHT_SCALE %f\n",height_scale);
    }
   continue;
   }

  if((argv[arg][1] == 'c') && (argv[arg][2] == 'h') && (argv[arg][3] == 'o') && (argv[arg][4] == 'p')) // -chop ## height limit for histgram
   {
   if(argv[arg][5] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    chop_limit  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'f') && (argv[arg][3] == 'r') ) // -pfr ## postscript page from
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    ps_from  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 't') && (argv[arg][3] == 'o') ) // -pto ## postscript page to
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    ps_to  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 'a') && (argv[arg][3] == 'q') ) // -saq show average quality 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    show_av_qual  = atoi(tempchar);
    }
   continue;
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 'm') && (argv[arg][3] == 'r') ) // -smr show mismatch ratioy 
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    arg ++;
    if(argv[arg][0] == '-')
     errorm(3);
    strcpy(tempchar,argv[arg]);
    show_mm_ratio  = atoi(tempchar);
    }
   continue;
   }



  if((argv[arg][1] == 's') && (argv[arg][2] == 'p'))    // -sp: Show population
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    show_pop  = 1;
    }
   continue;
   }


  if((argv[arg][1] == 'g') && (argv[arg][2] == 'p'))    // -gp: print gene population
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    gene_pop  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'g') && (argv[arg][2] == '2'))    // -g2: print gene population
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    gene_pop  = 2;
    }
   continue;
   }

  if((argv[arg][1] == 't') && (argv[arg][2] == 'a') && (argv[arg][3] == 'g'))    // -tag:  tagcount population
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    tag_count  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 't') && (argv[arg][2] == 'g') && (argv[arg][3] == '2'))    // -tg2:  tagcount population
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    tag_count  = 2;
    }
   continue;
   }

  if((argv[arg][1] == 'c') && (argv[arg][2] == 'c'))    // -cc: Display complementary sequence with cyan color 
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    comp_cyan  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 'q'))    // -sq: Display read quality as heat map
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    show_quality  = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'h'))    // -mh: Use multihit info (more than one hit for a read)
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    use_multihit  = 1;
    }
   continue;
   }


  if((argv[arg][1] == '1') && (argv[arg][2] == '7') )    // -17 : change window size so that it fits in 17 inch monitor
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    w_width  = 1920;
    w_height = 1100;
    g_width  = 1900;
    g_height = 1050;
    max_page_height = 1050;
    thresh_page_height = 1050;
    }
   continue;
   }
  if((argv[arg][1] == 'd') && (argv[arg][2] == '7') )    // -d7 : change window size so that it fits in 17 inch monitor with double height
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    w_width  = 1920;
    w_height = 3000;
    g_width  = 1900;
    g_height = 2900;
    max_page_height = 2900;
    thresh_page_height = 2900;
    }
   continue;
   }
  if((argv[arg][1] == 'd') && (argv[arg][2] == 'd') )    // -dd : dual display
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    w_width  = 5100;
    w_height = 1550;
    g_width  = 5000;
    g_height = 1500;
    max_page_height = 1500;
    thresh_page_height = 1500;
    }
   continue;
   }
  if((argv[arg][1] == 'd') && (argv[arg][2] == 'h') )    // -dh : dual height
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    w_width  = 2550;
    w_height = 3100;
    g_width  = 2500;
    g_height = 3000;
    max_page_height = 3000;
    thresh_page_height = 3000;
    }
   continue;
   }
  if((argv[arg][1] == 'q') && (argv[arg][2] == 'h') )    // -qh : dual height
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    w_width  = 2550;
    w_height = 11100;
    g_width  = 2500;
    g_height = 11000;
    max_page_height = 11000;
    thresh_page_height = 11000;
    }
   continue;
   }
  if((argv[arg][1] == 'p') && (argv[arg][2] == 'r') && (argv[arg][3] == 'j'))    // -dd : dual display
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    w_width  = 1100;
    w_height =  840;
    g_width  = 1050;
    g_height =  820;
    max_page_height = 820;
    thresh_page_height = 820;
    }
   continue;
   }
//  if(argv[arg][1] == 'r')                                        // -r number (such as -r 5) as round cycle
//   arg ++;
//  if(argv[arg][1] == 'r')                                        // -r number (such as -r 5) as round cycle
//   {
//   arg ++;
//   n_round = atoi(argv[arg]);
//   }
  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference fasta file name
   strcpy(arg1,argv[arg]);
   }
  else
   {                                             // read second argument without - as the read fastaq file name
   strcpy(arg2,argv[arg]);
   }
  flag ++;
  if(flag >= 3)
   errorm(2);
  }
 }
}

void errorm(int en)
 {
 printf("ERROR %d\n",en);
 printf("Usage:   dmap [-options] reference.fasta read_sequences.fastaq\n");
 printf("                            .fasta(reference sequence) and .fastaq/.fq (sequencer reads) as input   \n");
 printf("Options:           -map  : generate a text map file as reference.fasta.map (default : not generate)\n");
 printf("                   -job  : jobname : specify smap run by jobname (suffix of query file)\n");
 printf("                   -rgb  : genbank_flnm : read genbank file and display gene info on the map\n");
 printf("                   -rge  : genbank_flnm : read genbank file(or list of gb files) and display gene info on the map\n");
 printf("                   -sx   : show_exon : show exon (splicing info) with -rge option\n");
 printf("                   -ngc  : no gene caption with -rgb\n");
 printf("                   -bw # : display bitwise (pixel by pixel) graphics. May take a while to redraw\n");
 printf("                   -hd # : histogram type display. # = basepair per pixel\n");
 printf("                   -ds # : height scale for histgram type display\n");
 printf("                   -log  : log scale for histogram type display \n");
 printf("                   -cc   : display complement sequence with cyan color\n");
 printf("                   -mmc  : differenciate mismatch color G:green C:cyan T:thimine A:adenine\n");
 printf("                   -ec   : check edge_criteria \n");
 printf("                   -qe   : check quality edge\n");
 printf("                   -qo  #: set quality offset quality_edge_threshold Illumina 64 40.0, SRA-sanger 33 20.0\n");
 printf("                   -ecr #: edge check ratio: mismatch ratio(percent) of reads for one direction\n");
 printf("                   -sp   : display population of complement/ordered hits. Oshima-san special, require -map.\n");
 printf("                   -sq   : show_quality now works with -np only.\n");
 printf("                   -nhb  : NOT display histogram bar for -hd and -sp.\n");
 printf("                   -win #: window_size for sp\n");
 printf("                   -ps   : postscript output, no display on screen.\n");
 printf("                   -gp   : generates gene population file\n");
 printf("                   -np   : no postscript output\n");
 printf("                   -psfr #: start page postscript output\n");
 printf("                   -psto #: end   page postscript output\n");
 printf("                   -peb #: population (tag count) for every ## bp, for IMC tool in Ogasawara Lab.\n");
 printf("                   -lc   : display sequence position at the left side of the screen.\n");
 printf("                   -mh   : use multi-hit info (more than one hit position per read)\n");
 printf("                   -17   : change the display size so that it fits in 17 inch monitor\n");
 printf("                   -d7   : change the display size so that it fits in 17 inch monitor with doubled height\n");
 printf("                   -dd   : change the display size so that it fits in dual 30 inch monitor\n");
 printf("                   -dh   : the display height is doubled. need to scrole but can show thick map \n");
 printf("                   -prj  : change the display size so that it fits in our projector 1152x864\n");
 printf("                                                                                   \n");
 printf("As the window on the display shows, shift-left_crick to proceed and cntl-left_crick to go back pages.\n");
 exit(1);
 }

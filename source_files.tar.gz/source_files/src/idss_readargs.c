#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern char arg1[];
extern int  index_len;
extern int  min_ids_len;


void errorm(int en);

void readargs(int argc, char **argv)
{
int i;
int temp;
int arg;
int flag = 0;

if(argc==1)
 {
 errorm(0);
 }

for(arg=1;arg<argc;arg++)
 {
 if(argv[arg][0] == '-')
  {
  if(argv[arg][1] == 'm')                                        // -m minimum length for identical sequence
   {
   if(argv[arg][2] == '\0')
    {
    arg ++;
    min_ids_len = atoi(argv[arg]);
    printf("MINIMUM_IDS_LENGTH %d\n",min_ids_len);
    continue;
    }
   }
  if(argv[arg][1] == 'i')                                        // -i index size
   {
   if(argv[arg][2] == '\0')
    {
    arg ++;
    index_len = atoi(argv[arg]);
    printf("INDEX SIZE         %d\n",index_len);
    continue;
    }
   }
/*
  if(argv[arg][1] == 'k')                                        // -k number (such as -a 25) as kmer size
   {
   if(argv[arg][2] == '\0')
    {
    arg ++;
    kmer_length = atoi(argv[arg]);
    printf("INDEX_LENGTH %d\n",index_length);
    if((kmer_length %2) == 0)
     {
     printf("###########################################################\n");
     printf("### !!!WARNING!!! YOU HAVE SPECIFIED K AS EVEN NUMBER!! ###\n");
     printf("###########################################################\n");
     }
    continue;
    }
   }
  if(argv[arg][1] == 'a')                                        // -a number (such as -a 4) as number of thread (multithread)
   {
   if(argv[arg][2] == '\0')
    {
    arg ++;
    n_thread = atoi(argv[arg]);
    printf("NTHREAD %d\n",n_thread);
    continue;
    }
   }

  if((argv[arg][1] == 'e') && (argv[arg][2] == 'a') && (argv[arg][3] == 'c'))              // -eac  output edge as contigs
   {
   if(argv[arg][4] == '\0')
    {
    edge_as_contig = 1;
    printf("OUTPUT EDGES as CONTIG fasta\n");
    continue;
    }
   }

  if((argv[arg][1] == 'o') && (argv[arg][2] == 'm') && (argv[arg][3] == 'p'))              // -omp  only multiple edge
   {
   if(argv[arg][4] == '\0')
    {
    only_multiple_edge = 1;
    printf("OUTPUT MULTIPLE EDGES ONLY\n");
    continue;
    }
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'r') && (argv[arg][3] == 'c'))              // -prc  print edge as contigs to standard output

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'r') && (argv[arg][3] == 'c'))              // -prc  print edge as contigs to standard output
   {
   if(argv[arg][4] == '\0')
    {
    print_contig = 1;
    printf("PRINT EDGES as CONTIG \n");
    continue;
    }
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'r') && (argv[arg][3] == 'h'))              // -prh  print hits
   {
   if(argv[arg][4] == '\0')
    {
    print_hits = 1;
    printf("PRINT HITS \n");
    continue;
    }
   }

  if((argv[arg][1] == 'c') && (argv[arg][2] == 's') && (argv[arg][3] == 'b'))              // -csb  chop short branch
   {
   if(argv[arg][4] == '\0')
    {
    chop_short_branch = 1;
    printf("chop_short_branch\n");
    continue;
    }
   }

  if((argv[arg][1] == 'l') && (argv[arg][2] == 't') && (argv[arg][3] == 's'))              // -lts  list terminal sequences 
   {
   if(argv[arg][4] == '\0')
    {
    list_terminal_sequences = 1;
    printf("LIST TERMINAL SEQUENCES\n");
    continue;
    }
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 't') && (argv[arg][3] == 's'))              // -lts  list terminal sequences 
   {
   if(argv[arg][4] == '\0')
    {
    show_terminal_sequences = 1;
    printf("SHOW TERMINAL SEQUENCES\n");
    continue;
    }
   }

  if((argv[arg][1] == 's') && (argv[arg][2] == 'n') && (argv[arg][3] == 'e'))              // -sne  show node edge
   {
   if(argv[arg][4] == '\0')
    {
    show_node_edge = 1;
    printf("Show node and edge list on Standard output\n");
    continue;
    }
   }


  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') && (argv[arg][3] == 'b'))             // -job jobname          reference.fasta.jobname.###
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    with_jobname = 1;
    arg ++;
    strcpy(jobname,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'e') && (argv[arg][3] == '1'))             // -pe1 pair end 1 filename          PAIR END INFORMATION 1
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    pe1 = 1;
    arg ++;
    strcpy(read1_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'e') && (argv[arg][3] == '2'))             // -pe2 pair end 2 filename          PAIR END INFORMATION 2
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    pe2 = 1;
    arg ++;
    strcpy(read2_flnm,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'p') && (argv[arg][2] == 'd'))                                        // -pd #          paired end estimated distance
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    arg ++;
    pair_end_distance = atoi(argv[arg]);
    printf("PAIR END ESTIMATED DISTANCE\n",pair_end_distance);
    }
   continue;
   }

  if((argv[arg][1] == 'k') && (argv[arg][2] == 'o') && (argv[arg][3] == 'u') &&(argv[arg][4] == 't'))  // -kout  output kmer list file $$$.kmr
   {
   if(argv[arg][5] != '\0')
    errorm(1);
   else
    {
    kmer_out = 1;
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'a'))                                        // -ma #          minimum appearance kmer 
   {
   if(argv[arg][3] != '\0')
    errorm(1);
   else
    {
    arg ++;
    min_appearrance = atoi(argv[arg]);
    printf("MIN APPEARANCE KMER %6d\n",min_appearrance);
    }
   continue;
   }

  if((argv[arg][1] == 'c') && (argv[arg][2] == 's') && (argv[arg][3] == 'b') && (argv[arg][4] == 'l')) // -csbl #    chop short branch length
   {
   if(argv[arg][5] != '\0')
    errorm(1);
   else
    {
    arg ++;
    csb_length = atoi(argv[arg]);
    printf("Chop short branch shorter than %3d\n",csb_length);
    }
   continue;
   }

  /////////////////////////////////////////////////////////
  if((argv[arg][1] == 'm') && (argv[arg][2] == 'o'))              // -mo  min_overlap �V�[�h�쐬���ɍ��y�A��g�ނ̂ɕK�v�Ƃ���I�[�o�[���b�v���@default=25
   {
   arg ++;
   min_overlap = atoi(argv[arg]);
   printf("MIN_OVERLAP %d\n",min_overlap);
   continue;
   } 

  if((argv[arg][1] == 'm') && (argv[arg][2] == 's') && (argv[arg][3] == 'l'))              // -msl  min_seed_len   �V�[�h�Œᒷ�@default=50
   {
   arg ++;
   min_seed_len = atoi(argv[arg]);
   printf("MIN_SEED_LEN %d\n",min_seed_len);
   continue;
   }

  if((argv[arg][1] == 'j') && (argv[arg][2] == 'o') && (argv[arg][3] == 'b'))             // -job jobname          reference.fasta.jobname.###
   {
   if(argv[arg][4] != '\0')
    errorm(1);
   else
    {
    jobname = 1;
    arg ++;
    strcpy(job_name,argv[arg]);
    }
   continue;
   }

  if((argv[arg][1] == 'm') && (argv[arg][2] == 'w'))              // -mw number (such as -a 200) as width of map (text) with -map option
   {
   arg ++;
   map_out_width = atoi(argv[arg]);
   printf("MAP_OUT_WIDTH %d\n",map_out_width);
   continue;
   }
  if(argv[arg][1] == 'r')                                        // -r number (such as -r 5) as round cycle
   {
   arg ++;
   n_round = atoi(argv[arg]);
   printf("NROUND %d\n",n_round);
   continue;
   }
  /////////////////////////////////////////////////////////
*/
  }
 else
  {
  if(flag == 0)
   {                                             // read first argument without - as the reference fasta file name
   strcpy(arg1,argv[arg]);
   }
  flag ++;
  if(flag >= 2)
   errorm(2);
  }
 }
}

void errorm(int en)
 {
 printf("ERROR %d\n",en);
 printf("Usage:   idss [-options] input_sequence.fasta  \n");
 printf("Options:      -m    #   : 16 : minimum length for identical string\n");
 printf("              -i    #   :  8 : index length\n");
 exit(1);
 }

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "ispmap.h"
#define MAX_SEGMENT 500

extern char genbank_flnm[];
extern int  n_gene;
extern int  n_CDS;
extern int  n_tRNA;
extern int  n_mRNA;
extern int  n_tmRNA;
extern int  n_rRNA;
extern int  n_miscRNA;
extern int  n_misc_feature;
extern int  n_STS;
extern int  n_pseudo;
extern genbank_info *gbs;
extern int *n_gene_variants;
extern int *n_mRNAs;
extern int *n_miscRNAs;
extern int *n_CDSs;
extern int *n_STSs;
extern int  n_chromosomes;
extern chromosome_info *chromosomes;

char tempchar[100000];
int froms[MAX_SEGMENT];
int tos[MAX_SEGMENT];
word_info segments[MAX_SEGMENT];
int n_seg;
int n_ceg;

int read_from(char *str);

int read_to(char *str);

int read_complement(char *str);

int count_segment(char *buff)
 {
 int i,j;
 int flag;
 char tempc[10000];
 char tmpc[100];
 int n_segg=0;
//printf("##%s\n",buff);
 if(strchr(buff,'('))
  {
  strcpy(tempc,strrchr(buff,'(')+1);
  *strchr(tempc,')') = '\0';
  }
 else 
  strcpy(tempc,buff);
//printf("#$%s\n",tempc);

 for(i=0;i<strlen(tempc);i++)
  if(tempc[i] == ',')
   n_segg ++;
 
 n_segg = 0;
 while(1)
  {
  strcpy(segments[n_segg].word,tempc);
  flag = -1;
  for(i=0;i<strlen(segments[n_segg].word);i++)
   {
   if(segments[n_segg].word[i] == ',')
    {
    flag = i;
    break;
    }
   }
  if(flag != -1)
   {
   strcpy(tempc,&segments[n_segg].word[flag]+1);
   segments[n_segg].word[flag] = '\0';
   n_segg++;
   }
  else
   {
   break;
   }
  }
 n_segg++;

 for(i=0;i<n_segg;i++)
  {
  if(strchr(segments[i].word,'.'))
   {
   strcpy(tmpc,segments[i].word);
   *strchr(tmpc,'.') = '\0';
   if((tmpc[0] == '<') || (tmpc[0] == '>'))
    strcpy(tmpc,&tmpc[1]);
   froms[i] = atoi(tmpc);
   strcpy(tmpc,strrchr(segments[i].word,'.')+1);
   if((tmpc[0] == '<') || (tmpc[0] == '>'))
    strcpy(tmpc,&tmpc[1]);
   tos[i] = atoi(tmpc);
   }
  else                                      // no ".." single number: first and last are same
   {
   strcpy(tmpc,segments[i].word);
   if((tmpc[0] == '<') || (tmpc[0] == '>'))
    strcpy(tmpc,&tmpc[1]);
   froms[i] = atoi(tmpc);
   tos[i] = atoi(tmpc);
   }
//printf("#%d_%s %d-%d\n",i+1,segments[i].word,froms[i],tos[i]);
  }
 return 1;
 }

char *extract_tab(int nth,char *buff)
{
int i,j,k;
int point;
int count;
int flag = 0;

strcpy(tempchar,buff);
count = 1;
flag = 0;
if(nth >= 2)
 {
 for(i=0;i<strlen(tempchar);i++)
  {
  if(tempchar[i] == '\t')
   {
   count ++;
   if(count == nth)
    {
    flag = 1;
    break;
    }
   }
  }
 if(flag == 1)
  strcpy(tempchar,&tempchar[i+1]);
 else
  {
  tempchar[0] = '\0';
  return tempchar;
  }
 }

for(i=0;i<=strlen(tempchar);i++)
 {
 if((tempchar[i] == '\n') || (tempchar[i] == '\t') ||(tempchar[i] == '\0'))
  {
  tempchar[i] = '\0';
  break;
  }
 }
return tempchar;
}

void read_genbank_e(void)
{
int i,j,k;
int cc;
int nsegg;
int cmrna,ccds;
int format_sign = 0;
char buff[100000];
char buff2[100000];
FILE *genbank_list_file;
FILE *genbank_file;
word_info genbank_flnms[MAX_CHROMOSOME];
int file_exist[MAX_CHROMOSOME];

for(i=0;i<MAX_CHROMOSOME;i++)
 file_exist[i] = 1;

if(!(genbank_list_file = fopen(genbank_flnm,"r")))
 {
 printf("Failed to open input genbank list file: %s\n",genbank_flnm);
 exit(1);
 }

fgets(buff,500,genbank_list_file);
if(strncmp(buff,"GENBANK",7)==0)
 {
 printf("Input gene information files are in GENBANK format\n");
 format_sign = 1;
 }
if(strncmp(buff,"TBL",3)==0)
 {
 printf("Input gene information files are in TBL format\n");
 format_sign = 2;
 }
if(format_sign == 0)
 {
 printf("ERROR: Gene table format could not be recognized\n");
 printf("The first line of the list file for -rge should be GENBANK or TBL\n");
 exit(0);
 }

cc=0;
while(fgets(buff,500,genbank_list_file))
 {
 strcpy(genbank_flnms[cc].word,buff);
 genbank_flnms[cc].word[strlen(genbank_flnms[cc].word)-1] = '\0';
 cc++;
 }

if(cc != n_chromosomes)
 {
 printf("Number of chromosomes in FASTA file(%d) and gene information file(%d) do not match.\n",n_chromosomes,cc);
 exit(1);
 }

fclose(genbank_list_file);

n_gene = -1;
for(i=0;i<n_chromosomes;i++)
 {
 if(!(genbank_file = fopen(genbank_flnms[i].word,"r")))
  {
  printf("Failed to open input genbank file: %s for %d'th chromosome\n",genbank_flnms[i].word,i+1);
  file_exist[i] = 0;
  continue;
//  exit(1);
  }

 if(format_sign == 1)                              // GENBANK format
  {
  while(fgets(buff,500,genbank_file))
   {
   if(strncmp(buff,"     gene",9) == 0)
    n_gene ++;
   if(strncmp(buff,"     CDS",8) == 0)
    {
    n_CDSs[n_gene] ++;
    n_CDS ++;
    }
   if(strncmp(buff,"     mRNA",9) == 0)
    {
    n_mRNAs[n_gene] ++;
    n_mRNA ++;
    }
   if(strncmp(buff,"     tRNA",9) == 0)
    n_tRNA ++;
   if(strncmp(buff,"     tmRNA",10) == 0)
    n_tmRNA ++;
   if(strncmp(buff,"     rRNA",9) == 0)
    n_rRNA ++;
   if(strncmp(buff,"     misc_RNA",13) == 0)
    n_miscRNAs[n_gene] ++;
   if(strncmp(buff,"     STS",8) == 0)
    n_STSs[n_gene] ++;
   if(strncmp(buff,"     misc_feature",17) == 0)
    n_misc_feature ++;
   if(n_gene > MAX_GENE)
    {
    printf("TOO MANY GENES IN GENBANK FILE %d\n",n_gene);
    }
   }
  }

 if(format_sign == 2)                                // TXT format
  {
  while(fgets(buff,90000,genbank_file))
   {
   if(strncmp("gene",extract_tab(3,buff),4) == 0)
    {
    n_gene ++;
    }
   if(strncmp("CDS",extract_tab(3,buff),4) == 0)
    {
    n_CDSs[n_gene]++;
    n_CDS ++;
    }
   if(strncmp("mRNA",extract_tab(3,buff),4) == 0)
    {
    n_mRNAs[n_gene] ++;
    n_mRNA ++;
    }
   if(strncmp("tRNA",extract_tab(3,buff),4) == 0)
    n_tRNA ++;
   if(strncmp("rRNA",extract_tab(3,buff),4) == 0)
    n_rRNA ++;
   if(strncmp("misc_feature",extract_tab(3,buff),12) == 0)
    n_misc_feature ++;
   if(strncmp("misc_RNA",extract_tab(3,buff),8) == 0)
    n_miscRNA ++;
   if(strncmp("pseudo",extract_tab(3,buff),4) == 0)
    n_pseudo ++;
   }
  }

 fclose(genbank_file);
 }
n_gene ++;
printf("n_gene = %5d n_CDS = %5d n_mRNA = %5d  n_tRNA = %5d n_rRNA = %5d n_miscRNA = %5d n_pseudo = %5d n_misc_feature %5d\n",
       n_gene,n_CDS,n_mRNA,n_tRNA,n_rRNA,n_miscRNA,n_pseudo,n_misc_feature);
gbs = (genbank_info *)malloc(sizeof(genbank_info)*(n_gene+100));
for(i=0;i<n_gene+2;i++)
 {
 gbs[i].n_mrna = n_mRNAs[i];
 gbs[i].n_cds  = n_CDSs[i];
 gbs[i].mrnas  = (splice_info *)malloc(sizeof(splice_info)*(n_mRNAs[i]+1));
 gbs[i].cdss   = (splice_info *)malloc(sizeof(splice_info)*(n_CDSs[i]+1));
 }

cc = -1;
for(i=0;i<n_chromosomes;i++)
 {
 if(file_exist[i] == 0)
  continue;
 if(!(genbank_file = fopen(genbank_flnms[i].word,"r")))
  {
  printf("Failed to open input genbank file: %s\n",genbank_flnms[i].word);
  exit(1);
  }

 if(format_sign == 2)
  {
  while(fgets(buff,90000,genbank_file))
   {
   if(strncmp("gene",extract_tab(3,buff),4) == 0)
    {
    cc ++;
    if(atoi(extract_tab(1,buff)) < atoi(extract_tab(2,buff)))
     {
     gbs[cc].from = atoi(extract_tab(1,buff));
     gbs[cc].to = atoi(extract_tab(2,buff));
     gbs[cc].complement = 0;
     }
    else
     {
     gbs[cc].to = atoi(extract_tab(1,buff));
     gbs[cc].from = atoi(extract_tab(2,buff));
     gbs[cc].complement = 1;
     }
    gbs[cc].chr_id       = i;
    fgets(buff,90000,genbank_file);
    strcpy(gbs[cc].locus_tag,extract_tab(5,buff));
    cmrna = 0;
    ccds  = 0;
    }
   if(strncmp("mRNA",extract_tab(3,buff),4) == 0)
    {
    n_seg = 0;
    if(atoi(extract_tab(1,buff)) < atoi(extract_tab(2,buff)))
     {
     froms[n_seg] = atoi(extract_tab(1,buff));
     tos[n_seg] = atoi(extract_tab(2,buff));
     }
    else
     {
     froms[n_seg] = atoi(extract_tab(2,buff));
     tos[n_seg] = atoi(extract_tab(1,buff));
     }
    n_seg ++;
    while(fgets(buff,90000,genbank_file))
     {
     if(atoi(extract_tab(1,buff)) == 0)
      {
      gbs[cc].mrnas[cmrna].n_segment = n_seg;
      gbs[cc].mrnas[cmrna].froms = (int *)malloc(sizeof(int)*(n_seg));
      gbs[cc].mrnas[cmrna].tos   = (int *)malloc(sizeof(int)*(n_seg));
      for(j=0;j<n_seg;j++)
       {
       gbs[cc].mrnas[cmrna].froms[j] = froms[j];
       gbs[cc].mrnas[cmrna].tos[j]   = tos[j];
       }
      cmrna ++;
      break;
      }
     else
      {
      if(atoi(extract_tab(1,buff)) < atoi(extract_tab(2,buff)))
       {
       froms[n_seg] = atoi(extract_tab(1,buff));
       tos[n_seg] = atoi(extract_tab(2,buff));
       }
      else
       {
       froms[n_seg] = atoi(extract_tab(2,buff));
       tos[n_seg] = atoi(extract_tab(1,buff));
       }
      n_seg ++;
      }
     }
    gbs[cc].type = 1;
    }
   if(strncmp("CDS",extract_tab(3,buff),4) == 0)
    {

    n_ceg = 0;
    if(atoi(extract_tab(1,buff)) < atoi(extract_tab(2,buff)))
     {
     froms[n_ceg] = atoi(extract_tab(1,buff));
     tos[n_ceg] = atoi(extract_tab(2,buff));
     }
    else
     {
     froms[n_ceg] = atoi(extract_tab(2,buff));
     tos[n_ceg] = atoi(extract_tab(1,buff));
     }
    n_ceg ++;
    while(fgets(buff,90000,genbank_file))
     {
     if(atoi(extract_tab(1,buff)) == 0)
      {
      gbs[cc].cdss[ccds].n_segment = n_ceg;
      gbs[cc].cdss[ccds].froms = (int *)malloc(sizeof(int)*(n_ceg));
      gbs[cc].cdss[ccds].tos   = (int *)malloc(sizeof(int)*(n_ceg));
      for(j=0;j<n_ceg;j++)
       {
       gbs[cc].cdss[ccds].froms[j] = froms[j];
       gbs[cc].cdss[ccds].tos[j]   = tos[j];
       }
      ccds ++;
      break;
      }
     else
      {
      if(atoi(extract_tab(1,buff)) < atoi(extract_tab(2,buff)))
       {
       froms[n_ceg] = atoi(extract_tab(1,buff));
       tos[n_ceg] = atoi(extract_tab(2,buff));
       }
      else
       {
       froms[n_ceg] = atoi(extract_tab(2,buff));
       tos[n_ceg] = atoi(extract_tab(1,buff));
       }
      n_ceg ++;
      }
     }
    gbs[cc].type = 1;
    }
   if(strncmp("tRNA",extract_tab(3,buff),4) == 0)
    gbs[cc].type = 2;
   if(strncmp("rRNA",extract_tab(3,buff),4) == 0)
    gbs[cc].type = 3;
   if(strncmp("snoRNA",extract_tab(3,buff),4) == 0)
    gbs[cc].type = 4;
   if(strncmp("misc_RNA",extract_tab(3,buff),8) == 0)
    gbs[cc].type = 5;
   if(strncmp("misc_feature",extract_tab(3,buff),12) == 0)
    gbs[cc].type = 6;

   }
  }

 if(format_sign == 1)
  {
  while(fgets(buff,500,genbank_file))
   {
   if(strncmp(buff,"     gene",9) == 0)
    {
    if(!(strstr(buff,"join")))
     {
     cc++;
     gbs[cc].from         = read_from(buff);
     gbs[cc].to           = read_to(buff);
     gbs[cc].complement   = read_complement(buff);
     gbs[cc].chr_id       = i;
 //printf("%3d %10d %10d %10d\n",gbs[cc].chr_id,gbs[cc].from,gbs[cc].to,gbs[cc].complement);
     }
    else                       // gene��join�ō\������Ă���ꍇ�i�A���r�̃~�g�R���h���A�ƃN�����v���X�g�Ȃǁj�b�菈�u
     {
     cc++;
     gbs[cc].from         = 0;
     gbs[cc].to           = 0;
     gbs[cc].complement   = 0;
     gbs[cc].chr_id       = i;
     }
    ccds  = 0;
    cmrna = 0;
    }
//////////////////////////////////////////////////////////
//MARK
   if(strncmp(buff,"     CDS",8) == 0)
    {
    strcpy(buff2,&buff[21]);   
    while(fgets(buff,500,genbank_file))
     {
     if(strncmp(buff,"                     /",22)==0)
      {
      buff2[strlen(buff2)-1] = '\0';

      nsegg = count_segment(buff2);
      gbs[cc].cdss[ccds].n_segment = nsegg;
      gbs[cc].cdss[ccds].froms = (int *)malloc(sizeof(int)*nsegg);
      gbs[cc].cdss[ccds].tos   = (int *)malloc(sizeof(int)*nsegg);
      for(j=0;j<nsegg;j++)
       {
       gbs[cc].cdss[ccds].froms[j] = froms[j];
       gbs[cc].cdss[ccds].tos[j]   = tos[j];
       }

      break;
      }
     else
      {
      strcpy(&buff2[strlen(buff2)-1],&buff[21]);   
      }
     }

//printf("%s\n",buff2);
    ccds ++;
    gbs[cc].type = 1;
    strcpy(gbs[cc].type_char,"CDS");
    }
//////////////////////////////////////////////////////////
   if(strncmp(buff,"     mRNA",9) == 0)
    {
    strcpy(buff2,&buff[21]);   
    while(fgets(buff,500,genbank_file))
     {
     if(strncmp(buff,"                     /",22)==0)
      {
      buff2[strlen(buff2)-1] = '\0';


      break;
      }
     else
      {
      strcpy(&buff2[strlen(buff2)-1],&buff[21]);   
      }
     }

//printf("%s\n",buff2);
    cmrna ++;
    gbs[cc].type = 1;
    strcpy(gbs[cc].type_char,"mRNA");
    }
//////////////////////////////////////////////////////////

   if(strncmp(buff,"     tRNA",9) == 0)
    {
    gbs[cc].type = 2;
    strcpy(gbs[cc].type_char,"tRNA");
    }
   if(strncmp(buff,"     tmRNA",10) == 0)
    {
    gbs[cc].type = 5;
    strcpy(gbs[cc].type_char,"tmRNA");
    }
   if(strncmp(buff,"     rRNA",9) == 0)
    {
    gbs[cc].type = 3;
    strcpy(gbs[cc].type_char,"rRNA");
    }
   if(strncmp(buff,"     misc_RNA",13) == 0)
    {
    gbs[cc].type = 5;
    strcpy(gbs[cc].type_char,"misc_RNA");
    }
   if(strstr(buff,"/product="))
    {
    strcpy(gbs[cc].product_name,strstr(buff,"=")+2);
    gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
    if(gbs[cc].product_name[strlen(gbs[cc].product_name)-1] != '"')
     {
     fgets(buff,500,genbank_file);
     strcat(gbs[cc].product_name,buff+21);
     gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
     }
    gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
    }
   if(strstr(buff,"/gene="))
    {
    strcpy(gbs[cc].gene_name,strstr(buff,"=")+2);
    gbs[cc].gene_name[strlen(gbs[cc].gene_name)-2] = '\0';
    }
   if(strstr(buff,"/pseudo"))
    {
    strcpy(gbs[cc].type_char,"pseudo");
    strcpy(gbs[cc].product_name,"pseudo gene");
    gbs[cc].type = 6;
    }
 
   if(strstr(buff,"/product="))
    {
    strcpy(gbs[cc].product_name,strstr(buff,"=")+2);
    gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
    if(gbs[cc].product_name[strlen(gbs[cc].product_name)-1] != '"')
     {
     fgets(buff,500,genbank_file);
     strcat(gbs[cc].product_name,buff+21);
     gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
     }
    gbs[cc].product_name[strlen(gbs[cc].product_name)-1] = '\0';
    }
   if(strncmp(buff,"                     /gene=",27) == 0)
    {
    strcpy(gbs[cc].gene_name,strstr(buff,"=")+2);
    gbs[cc].gene_name[strlen(gbs[cc].gene_name)-2] = '\0';
    }
   if(strncmp(buff,"                     /locus_tag=",32) == 0)
    {
    strcpy(gbs[cc].locus_tag,strstr(buff,"=")+2);
    gbs[cc].locus_tag[strlen(gbs[cc].locus_tag)-2] = '\0';
    }
   }
  }

 fclose(genbank_file);
 }

for(i=0;i<n_gene;i++)
 {
 gbs[i].intensity = 0;
 gbs[i].tag_count = 0;
 }

/////////////////////////////////////////////////////////////////////////// PRINT SPLICING INFO IN GENE FILE
//for(i=0;i<n_gene;i++)
// {
// printf("mRNA %s %5d\n",gbs[i].locus_tag,gbs[i].n_mrna);
// for(j=0;j<gbs[i].n_mrna;j++)
//  {
//  printf("  %5d \n",gbs[i].mrnas[j].n_segment);
//  for(k=0;k<gbs[i].mrnas[j].n_segment;k++)
//   {
//   printf("    %5d %5d\n",gbs[i].mrnas[j].froms[k],gbs[i].mrnas[j].tos[k]);
//   }
//  }
// printf("CDS  %s %5d\n",gbs[i].locus_tag,gbs[i].n_cds);
// for(j=0;j<gbs[i].n_cds;j++)
//  {
//  printf("  %5d \n",gbs[i].cdss[j].n_segment);
//  for(k=0;k<gbs[i].cdss[j].n_segment;k++)
//   {
//   printf("    %5d %5d\n",gbs[i].cdss[j].froms[k],gbs[i].cdss[j].tos[k]);
//   }
//  }
// }
///////////////////////////////////////////////////////////////////////////
}

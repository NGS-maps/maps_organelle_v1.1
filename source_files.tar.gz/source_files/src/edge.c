 
if(edge_check == 1) 
 {
double average_depth     =  0.0;
int window_width         =   40;
int print_width          =   70;
int max_less_window_pop  =   60;
int min_more_window_pop  =  300;
int min_edge_pop         =   40;

double max_less_ratio    =  0.020;
double min_more_ratio    =  0.10;

double min_pos_ratio     =  0.10;

//double tall_ratio1 =0.09;
double tall_ratio1 =0.05;
double tall_ratio2 =0.05;
double tall_ratio3 =0.15;
double tall_ratio4 =0.15;

int left_pop =0;
int left_tot =0;
double left_ratio =0.0;
int right_pop=0;
int right_tot=0;
double right_ratio =0.0;
double point_ratio =0.0;
double region_depth = 0.0;
int na,nt,ng,nc;
int left_tall  = 0;
int right_tall = 0;
int n_edge = 0;

int n_fw_poss=0;
int n_bw_poss=0;
int fw_poss[MAX_POSS];
int bw_poss[MAX_POSS];
average_depth = ((double)(num_hit) / (double) refseq_len)*(double)query_len;
 printf("EDGE_CHECK  average_depth = %10.5f num_hit%5d query_len%5d refseq_len %8d\n",average_depth,num_hit,query_len,refseq_len);

 for(i=0+window_width+50;i<refseq_len-window_width-50;i++)
  {
  left_pop =0;
  left_tot =0;
  right_pop=0;
  right_tot=0;
  left_tall =0;
  right_tall =0;
  for(j=-window_width;j<0;j++)
   {
//   if(((double)func_position_hits_f_mismatch(i+j)) > (average_depth * tall_ratio1))
//   if(((double)func_position_hits_f_mismatch(i+j)) > (region_depth * tall_ratio3))
//    left_tall  ++;
//   fprintf(edge_file,"%5d %8.4f %8.4f\n",func_position_hits_f_mismatch(i+j),average_depth,tall_ratio1);


   left_pop  += func_position_hits_f_mismatch(i+j);
   left_tot  += func_position_hits_f_mismatch(i+j);
   left_tot  += func_position_hits_f_match(i+j);
   }
  left_ratio = (double)left_pop / (double)left_tot;
  for(j=1;j<=window_width;j++)
   {
//   if(((double)func_position_hits_f_mismatch(i+j)) > (average_depth * tall_ratio1))
//   if(((double)func_position_hits_f_mismatch(i+j)) > (region_depth * tall_ratio3))
//    right_tall  ++;

   right_pop += func_position_hits_f_mismatch(i+j);
   right_tot += func_position_hits_f_mismatch(i+j);
   right_tot += func_position_hits_f_match(i+j);
   }
  right_ratio = (double)right_pop / (double)right_tot;

  region_depth = (double)(right_tot + left_tot) / (double)(window_width * 2);

  point_ratio = (double)func_position_hits_f_mismatch(i)/ (double)(func_position_hits_f_match(i)+ func_position_hits_f_mismatch(i));
  
  for(j=-window_width;j<0;j++)
   if(((double)func_position_hits_f_mismatch(i+j)) > (region_depth * tall_ratio3))
    left_tall  ++;
  for(j=1;j<=window_width;j++)
   if(((double)func_position_hits_f_mismatch(i+j)) > (region_depth * tall_ratio3))
    right_tall  ++;

//  if((position_hits[i].f_mismatch > min_edge_pop) && (left_pop < max_less_window_pop) && (right_pop > min_more_window_pop))
//  if((region_depth > average_depth * 0.4) && (left_ratio < max_less_ratio) && (right_ratio > min_more_ratio) && (point_ratio > min_pos_ratio) && (region_depth < average_depth * 2.0))
//  if((region_depth > (average_depth * 0.2)) && ((region_depth < average_depth * 2.0)) && (left_tall == 0) && (right_tall >= 5) && ((double)func_position_hits_f_mismatch(i) > (average_depth * tall_ratio2)))
  if((region_depth > (average_depth * 0.2)) && ((region_depth < average_depth * 2.0)) && (left_tall == 0) && (right_tall >= 5) && ((double)func_position_hits_f_mismatch(i) > (region_depth * tall_ratio4)))
   {
   n_edge++;
//   na=0;nt=0;nc=0;ng=0;
   fprintf(edge_file,"FW:%10d ",i+1);
   for(j=-print_width;j<=print_width;j++)
    {
//    if(refseq[i+j] == 'A')  na++;
//    if(refseq[i+j] == 'T')  nt++;
//    if(refseq[i+j] == 'G')  ng++;
//    if(refseq[i+j] == 'C')  nc++;
    fprintf(edge_file,"%c",refseq[i+j]);
    if(j==-1)
     fprintf(edge_file," ");
    }
   fprintf(edge_file,"   ");
   fprintf(edge_file,"edge_pop:%5d less_pop:%5d more_pop:%5d LEFT_RATIO %10.4f RIGHT_RATIO %10.4f REGION_DEPTH %10.4f POSITION_RATIO %10.4f LEFT_TALL %5d RIGHT_TALL %5d AVE_DEPTH %10.4f\n",
                func_position_hits_f_mismatch(i),left_pop,right_pop,left_ratio,right_ratio,region_depth,point_ratio,left_tall,right_tall,average_depth);
   fw_poss[n_fw_poss++] = i;
   if(n_fw_poss > MAX_POSS)
    {
    printf("number of edge exceeded MAX_POSS %d\n",n_fw_poss);
    exit(1);
    }
   fflush(edge_file);

   //////////////////////////////////////////////// COUNT FW_BEFORE[] ///////////
//   for(j=0;j<=print_width;j++)
//    {
//printf("I=%d\n",i);
    for(k=i-query_len+1;k<=i;k++)
     {
     if((k<0) || (k>refseq_len))
      continue;
     for(l=0;l<position_hits[k].n_hit;l++)
      {
      if(position_hits[k].hits[l] >= 0)
       {
       for(m=i;m<k+query_len;m++)
        {
        if(qs[position_hits[k].hits[l]].seq[m-k-1] != refseq[m-1])
         {
//printf("M=%5d K=%5d L=%5d REF= %c QUERY = %c\n",m,k,l,refseq[m-1],qs[position_hits[k].hits[l]].seq[m-k-1]);
         fw_before[0]++;
         if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-2])
          fw_before[1]++;
         else
          if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-3])
           fw_before[2]++;
          else
           if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-4])
            fw_before[3]++;
           else
            if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-5])
             fw_before[4]++;
            else
             if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-6])
              fw_before[5]++;
             else
              if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-7])
               fw_before[6]++;
              else
               if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-8])
                fw_before[7]++;
               else
                if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-9])
                 fw_before[8]++;
                else
                 if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-10])
                  fw_before[9]++;
                 else
                  if(qs[position_hits[k].hits[l]].seq[m-k-1] == refseq[m-11])
                   fw_before[10]++;
                  else
                   fw_before[11]++;
         }
        }
       }
      }
     }
//    }
   //////////////////////////////////////////////// COUNT FW_BEFORE[] ///////////
   }
  }
printf("EC_1_COMPLETE %6d\n",n_edge);
printf("FW_TOTAL        = %10d\n",fw_before[0]);
printf("FW_ONE_BEFORE   = %10d\n",fw_before[1]);
printf("FW_TWO_BEFORE   = %10d\n",fw_before[2]);
printf("FW_THREE_BEFORE = %10d\n",fw_before[3]);
printf("FW_FOUR_BEFORE  = %10d\n",fw_before[4]);
printf("FW_FIVE_BEFORE  = %10d\n",fw_before[5]);
printf("FW_SIX _BEFORE  = %10d\n",fw_before[6]);
printf("FW_SEVEN_BEFORE = %10d\n",fw_before[7]);
printf("FW_EIGHT_BEFORE = %10d\n",fw_before[8]);
printf("FW_NINE_BEFORE  = %10d\n",fw_before[9]);
printf("FW_TEN _BEFORE  = %10d\n",fw_before[10]);
printf("FW_MORE_BEFORE  = %10d\n",fw_before[11]);
fprintf(edge_file,"FW_TOTAL        = %10d\n",fw_before[0]);
fprintf(edge_file,"FW_ONE_BEFORE   = %10d\n",fw_before[1]);
fprintf(edge_file,"FW_TWO_BEFORE   = %10d\n",fw_before[2]);
fprintf(edge_file,"FW_THREE_BEFORE = %10d\n",fw_before[3]);
fprintf(edge_file,"FW_FOUR_BEFORE  = %10d\n",fw_before[4]);
fprintf(edge_file,"FW_FIVE_BEFORE  = %10d\n",fw_before[5]);
fprintf(edge_file,"FW_SIX _BEFORE  = %10d\n",fw_before[6]);
fprintf(edge_file,"FW_SEVEN_BEFORE = %10d\n",fw_before[7]);
fprintf(edge_file,"FW_EIGHT_BEFORE = %10d\n",fw_before[8]);
fprintf(edge_file,"FW_NINE_BEFORE  = %10d\n",fw_before[9]);
fprintf(edge_file,"FW_TEN _BEFORE  = %10d\n",fw_before[10]);
fprintf(edge_file,"FW_MORE_BEFORE  = %10d\n",fw_before[11]);

n_edge = 0;
 for(i=0+window_width+50;i<refseq_len-window_width-50;i++)
  {
  left_pop =0;
  right_pop=0;
  left_tot =0;
  right_tot=0;
  left_tall =0;
  right_tall =0;
  for(j=-window_width;j<0;j++)
   {
//   if(((double)func_position_hits_r_mismatch(i+j)) > (average_depth * tall_ratio1))
//    left_tall  ++;

   left_pop  += func_position_hits_r_mismatch(i+j);
   left_tot  += func_position_hits_r_mismatch(i+j);
   left_tot  += func_position_hits_r_match(i+j);
   }
  left_ratio = (double)left_pop / (double)left_tot;
  for(j=1;j<=window_width;j++)
   {
//   if(((double)func_position_hits_r_mismatch(i+j)) > (average_depth * tall_ratio1))
//    right_tall  ++;

   right_pop += func_position_hits_r_mismatch(i+j);
   right_tot += func_position_hits_r_mismatch(i+j);
   right_tot += func_position_hits_r_match(i+j);
   }
  right_ratio = (double)right_pop / (double)right_tot;
  region_depth = (double)(right_tot + left_tot) / (double)(window_width * 2);

  point_ratio = (double)func_position_hits_r_mismatch(i)/ (double)(func_position_hits_r_match(i)+ func_position_hits_r_mismatch(i));

  for(j=-window_width;j<0;j++)
   if(((double)func_position_hits_r_mismatch(i+j)) > (region_depth * tall_ratio3))
    left_tall  ++;
  for(j=1;j<=window_width;j++)
   if(((double)func_position_hits_r_mismatch(i+j)) > (region_depth * tall_ratio3))
    right_tall  ++;

//  if((position_hits[i].r_mismatch > min_edge_pop) && (right_pop < max_less_window_pop) && (left_pop > min_more_window_pop))
//  if((region_depth > average_depth * 0.3) && (right_ratio < max_less_ratio) && (left_ratio > min_more_ratio) && (point_ratio > min_pos_ratio) && (region_depth < average_depth * 2.0))
//  if((region_depth > (average_depth * 0.2)) && (region_depth < (average_depth * 2.0)) && (left_tall >= 5) && (right_tall == 0) && ((double)func_position_hits_r_mismatch(i)> (average_depth * tall_ratio2)))
  if((region_depth > (average_depth * 0.2)) && (region_depth < (average_depth * 2.0)) && (left_tall >= 5) && (right_tall == 0) && ((double)func_position_hits_r_mismatch(i)> (region_depth * tall_ratio4)))
   {
   n_edge ++;
   fprintf(edge_file,"BW:%10d ",i+1);
//   na=0;nt=0;nc=0;ng=0;
   for(j=-print_width;j<=print_width;j++)
    {
//    if(refseq[i+j] == 'A')  na++;
//    if(refseq[i+j] == 'T')  nt++;
//    if(refseq[i+j] == 'G')  ng++;
//    if(refseq[i+j] == 'C')  nc++;
    fprintf(edge_file,"%c",refseq[i+j]);
    if(j==0)
     fprintf(edge_file," ");
    }
   fprintf(edge_file,"   ");
   fprintf(edge_file,"edge_pop:%5d less_pop:%5d more_pop:%5d region_depth %10.4f average_depth %10.4f left_tall %5d right_tall %5d\n",
           func_position_hits_r_mismatch(i),right_pop,left_pop,region_depth,average_depth,left_tall,right_tall);
   bw_poss[n_bw_poss++] = i;
  if(n_bw_poss > MAX_POSS)
   {
   printf("number of edge exceeded MAX_POSS %d\n",n_bw_poss);
   exit(1);
   }
   fflush(edge_file);

   //////////////////////////////////////////////// COUNT BW_BEFORE[] ///////////
//   for(j=0;j<=print_width;j++)
//    {
    for(k=i-query_len+1;k<=i;k++)
     {
     if((k<0) || (k>refseq_len))
      continue;
     for(l=0;l<position_hits[k].n_hit;l++)
      {
      if(position_hits[k].hits[l] < 0)
       {
//       for(m=i;m<k+query_len;m++)
       for(m=i;m>k;m--)
        {
//        if((qs_ceq(abs(position_hits[k].hits[l]),m-k) != refseq[m]) &&
//           (qs_ceq(abs(position_hits[k].hits[l]),m-k) != 'N'))
        if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1) != refseq[m-1])
         {
//printf("I=%5d M=%5d K=%5d L=%5d REF= %c QUERY = %c\n",i,m,k,l,refseq[m-1],qs_ceq(abs(position_hits[k].hits[l]),m-k-1));
         bw_before[0]++;
         if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m])
          bw_before[1]++;
         else
          if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+1])
           bw_before[2]++;
          else
           if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+2])
            bw_before[3]++;
           else
            if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+3])
             bw_before[4]++;
            else
             if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+4])
              bw_before[5]++;
             else
              if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+5])
               bw_before[6]++;
              else
               if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+6])
                bw_before[7]++;
               else
                if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+7])
                 bw_before[8]++;
                else
                 if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+8])
                  bw_before[9]++;
                 else
                  if(qs_ceq(abs(position_hits[k].hits[l]),m-k-1)  == refseq[m+9])
                   bw_before[10]++;
                  else
                   bw_before[11]++;
         }
        }
       }
      }
     }
//    }
   //////////////////////////////////////////////// COUNT FW_BEFORE[] ///////////
   }
  }
printf("EC_2_COMPLETE %6d\n",n_edge);
 
printf("BW_TOTAL        = %10d\n",bw_before[0]);
printf("BW_ONE_BEFORE   = %10d\n",bw_before[1]);
printf("BW_TWO_BEFORE   = %10d\n",bw_before[2]);
printf("BW_THREE_BEFORE = %10d\n",bw_before[3]);
printf("BW_FOUR_BEFORE  = %10d\n",bw_before[4]);
printf("BW_FIVE_BEFORE  = %10d\n",bw_before[5]);
printf("BW_SIX_BEFORE   = %10d\n",bw_before[6]);
printf("BW_SEVEN_BEFORE = %10d\n",bw_before[7]);
printf("BW_EIGHT_BEFORE = %10d\n",bw_before[8]);
printf("BW_NINE_BEFORE  = %10d\n",bw_before[9]);
printf("BW_TEN _BEFORE  = %10d\n",bw_before[10]);
printf("BW_MORE_BEFORE  = %10d\n",bw_before[11]);
fprintf(edge_file,"BW_TOTAL        = %10d\n",bw_before[0]);
fprintf(edge_file,"BW_ONE_BEFORE   = %10d\n",bw_before[1]);
fprintf(edge_file,"BW_TWO_BEFORE   = %10d\n",bw_before[2]);
fprintf(edge_file,"BW_THREE_BEFORE = %10d\n",bw_before[3]);
fprintf(edge_file,"BW_FOUR_BEFORE  = %10d\n",bw_before[4]);
fprintf(edge_file,"BW_FIVE_BEFORE  = %10d\n",bw_before[5]);
fprintf(edge_file,"BW_SIX_BEFORE   = %10d\n",bw_before[6]);
fprintf(edge_file,"BW_SEVEN_BEFORe = %10d\n",bw_before[7]);
fprintf(edge_file,"BW_EIGHT_BEFORE = %10d\n",bw_before[8]);
fprintf(edge_file,"BW_NINE_BEFORE  = %10d\n",bw_before[9]);
fprintf(edge_file,"BW_TEN _BEFORE  = %10d\n",bw_before[10]);
fprintf(edge_file,"BW_MORE_BEFORE  = %10d\n",bw_before[11]);

printf("FB_TOTAL        = %10d  \n",fw_before[0]+bw_before[0]);
printf("FB_ONE_BEFORE   = %10d  %8.4f\n",fw_before[1]+bw_before[1],  (double)(fw_before[1]+bw_before[1])/(double)(fw_before[0]+bw_before[0]));
printf("FB_TWO_BEFORE   = %10d  %8.4f\n",fw_before[2]+bw_before[2],  (double)(fw_before[2]+bw_before[2])/(double)(fw_before[0]+bw_before[0]));
printf("FB_THREE_BEFORE = %10d  %8.4f\n",fw_before[3]+bw_before[3],  (double)(fw_before[3]+bw_before[3])/(double)(fw_before[0]+bw_before[0]));
printf("FB_FOUR_BEFORE  = %10d  %8.4f\n",fw_before[4]+bw_before[4],  (double)(fw_before[4]+bw_before[4])/(double)(fw_before[0]+bw_before[0]));
printf("FB_FIVE_BEFORE  = %10d  %8.4f\n",fw_before[5]+bw_before[5],  (double)(fw_before[5]+bw_before[5])/(double)(fw_before[0]+bw_before[0]));
printf("FB_SIX_BEFORE   = %10d  %8.4f\n",fw_before[6]+bw_before[6],  (double)(fw_before[6]+bw_before[6])/(double)(fw_before[0]+bw_before[0]));
printf("FB_SEVEN_BEFORE = %10d  %8.4f\n",fw_before[7]+bw_before[7],  (double)(fw_before[7]+bw_before[7])/(double)(fw_before[0]+bw_before[0]));
printf("FB_EIGHT_BEFORE = %10d  %8.4f\n",fw_before[8]+bw_before[8],  (double)(fw_before[8]+bw_before[8])/(double)(fw_before[0]+bw_before[0]));
printf("FB_NINE_BEFORE  = %10d  %8.4f\n",fw_before[9]+bw_before[9],  (double)(fw_before[9]+bw_before[9])/(double)(fw_before[0]+bw_before[0]));
printf("FB_TEN _BEFORE  = %10d  %8.4f\n",fw_before[10]+bw_before[10],(double)(fw_before[10]+bw_before[10])/(double)(fw_before[0]+bw_before[0]));
printf("FB_MORE_BEFORE  = %10d  %8.4f\n",fw_before[11]+bw_before[11],(double)(fw_before[11]+bw_before[11])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_TOTAL        = %10d  \n",fw_before[0]+bw_before[0]);
fprintf(edge_file,"FB_ONE_BEFORE   = %10d  %8.4f\n",fw_before[1]+bw_before[1],  (double)(fw_before[1]+bw_before[1])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_TWO_BEFORE   = %10d  %8.4f\n",fw_before[2]+bw_before[2],  (double)(fw_before[2]+bw_before[2])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_THREE_BEFORE = %10d  %8.4f\n",fw_before[3]+bw_before[3],  (double)(fw_before[3]+bw_before[3])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_FOUR_BEFORE  = %10d  %8.4f\n",fw_before[4]+bw_before[4],  (double)(fw_before[4]+bw_before[4])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_FIVE_BEFORE  = %10d  %8.4f\n",fw_before[5]+bw_before[5],  (double)(fw_before[5]+bw_before[5])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_SIX_BEFORE   = %10d  %8.4f\n",fw_before[6]+bw_before[6],  (double)(fw_before[6]+bw_before[6])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_SEVEN_BEFORe = %10d  %8.4f\n",fw_before[7]+bw_before[7],  (double)(fw_before[7]+bw_before[7])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_EIGHT_BEFORE = %10d  %8.4f\n",fw_before[8]+bw_before[8],  (double)(fw_before[8]+bw_before[8])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_NINE_BEFORE  = %10d  %8.4f\n",fw_before[9]+bw_before[9],  (double)(fw_before[9]+bw_before[9])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_TEN _BEFORE  = %10d  %8.4f\n",fw_before[10]+bw_before[10],(double)(fw_before[10]+bw_before[10])/(double)(fw_before[0]+bw_before[0]));
fprintf(edge_file,"FB_MORE_BEFORE  = %10d  %8.4f\n",fw_before[11]+bw_before[11],(double)(fw_before[11]+bw_before[11])/(double)(fw_before[0]+bw_before[0]));

 /*
 printf("EDGE_CHECK\n");
int window_width         =   50;
int print_width          =   50;
int max_less_window_pop  =  200;
int min_more_window_pop  =  600;
int min_edge_pop         =   90;
int left_pop =0;
int right_pop=0;
int na,nt,ng,nc;
int temp_val;

 for(i=0+window_width+10;i<refseq_len-window_width-10;i++)
  {
  left_pop =0;
  right_pop=0;
  temp_val = func_position_hits_f_mismatch(i);
  for(j=-window_width;j<0;j++)
   left_pop  += func_position_hits_f_mismatch(i+j);
  for(j=0;j<=window_width;j++)
   right_pop += func_position_hits_f_mismatch(i+j);
  if((temp_val > min_edge_pop) && (left_pop < max_less_window_pop) && (right_pop > min_more_window_pop))
   {
   na=0;nt=0;nc=0;ng=0;
   for(j=-print_width;j<=print_width*3;j++)
    {
    if(refseq[i+j] == 'A')  na++;
    if(refseq[i+j] == 'T')  nt++;
    if(refseq[i+j] == 'G')  ng++;
    if(refseq[i+j] == 'C')  nc++;
    printf("%c",refseq[i+j]);
    if(j==-1)
     printf(" ");
    }
   printf("   ");
   printf("FORWARD  WINDOW POSITION %10d    edge_pop:%5d less_pop:%5d more_pop:%5d A:%3d T:%3d G:%3d C:%3d\n",
                i+1,temp_val,left_pop,right_pop,na,nt,ng,nc);
   }
  }

 for(i=0+window_width+10;i<refseq_len-window_width-10;i++)
  {
  left_pop =0;
  right_pop=0;
  temp_val = func_position_hits_r_mismatch(i);
  for(j=-window_width;j<=0;j++)
   left_pop  += func_position_hits_r_mismatch(i+j);
  for(j=1;j<=window_width;j++)
   right_pop  += func_position_hits_r_mismatch(i+j);
  if((temp_val> min_edge_pop) && (right_pop < max_less_window_pop) && (left_pop > min_more_window_pop))
   {
   na=0;nt=0;nc=0;ng=0;
   for(j=-print_width;j<=print_width;j++)
    {
    if(refseq[i+j] == 'A')  na++;
    if(refseq[i+j] == 'T')  nt++;
    if(refseq[i+j] == 'G')  ng++;
    if(refseq[i+j] == 'C')  nc++;
    printf("%c",refseq[i+j]);
    if(j==0)
     printf(" ");
    }
   printf("   ");
   printf("BACKWARD WINDOW POSITION %10d    edge_pop:%5d less_pop:%5d more_pop:%5d A:%3d T:%3d G:%3d C:%3d\n",
           i+1,temp_val,right_pop,left_pop,na,nt,ng,nc);
   }
  }
 */
 }

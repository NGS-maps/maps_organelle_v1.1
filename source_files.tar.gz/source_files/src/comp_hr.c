#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include "comp_hr.h"
#define BUFLEN   512
#define MAX_FILE 100

/////////////////////////////
char arg1[256];
char arg2[256];
/////////////////////////////

/////////////////////////////
int read_int (char *str,int start,int width)   // ## Function read_int $BJ8;zNs$+$i?tCM$r<h$k(B
{
  char buf[BUFLEN+1];

  if (width > BUFLEN)
    width = BUFLEN;
  strncpy (buf, &str[start-1], width);
  buf[width] = '\0';
  return atoi (buf);
}
//////////////////////////////////////////////////FUNCTION DEFINITION $B4X?tDj5A(B

//////////////////////////////////////////////////////////////////////////MAIN
int main(int argc, char **argv)
{
int         i,j,k,l,m,n;
FILE        *hr_list;
FILE        *hr_file;
FILE        *hr_out;
FILE        *hr_out2;
char        buff[512];
char        hr_out_flnm[512];
char        hr_out2_flnm[512];
int         n_files = 0;
int         n_lines = 0;
word_info   files[MAX_FILE];
hrs_infos   hrs[MAX_FILE];
int         pointer[MAX_FILE];
int         read_count[MAX_FILE];
double      bias_ratio[MAX_FILE];
int         min;
int         temp;
int         temp_min;
int         temp_order;
int         bias_flag = 1;
share_info  *scs;
int         n_scs   = 0;
int         max_scs = 0;
int         flag;
int         d1,d2,d3;
char        ds[BUFLEN];

readargs(argc,argv);

printf("INPUT UNKOWN JUNCTION LIST FILES NAME IS: %s\n",arg1);   // $BFI$_9~$`%j%9%H%U%!%$%k3+$/(B
hr_list = fopen(arg1,"r");
if(hr_list == NULL)
 {
 printf("Failed to open the input file %s\n",arg1);
 exit(1);
 }

sprintf(hr_out_flnm,"%s.out",arg1);                             // $B=PNO%U%!%$%k3+$/(B out1
hr_out = fopen(hr_out_flnm,"w");
if(hr_out == NULL)
 {
 printf("Failed to open the output file %s\n",hr_out_flnm);
 exit(1);
 }

sprintf(hr_out2_flnm,"%s.out2",arg1);                           // $B=PNO%U%!%$%k3+$/(B out2
hr_out2 = fopen(hr_out2_flnm,"w");
if(hr_out2 == NULL)
 {
 printf("Failed to open the output file %s\n",hr_out2_flnm);
 exit(1);
 }

while(fgets(buff,512,hr_list))                                  // $BF~NO%j%9%H%U%!%$%kFI$`(B
 {
 sscanf(buff,"%s %d",files[n_files].word,&read_count[n_files]);  // $B%U%!%$%kL>$H%j!<%I?t(B  files[].word, read_count[]
// buff[strlen(buff)-1] = '\0';
// printf("%s\n",buff);
// strcpy(files[n_files].word,buff);
 n_files ++;
 }

//////////////////////////////////////////////////////
for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 if(read_count[i] == 0)                           // $BFI$_9~$s$@%j!<%I%+%&%s%H$K0l$D$G$b(B0$B$N$b$N$,$"$l$P(B              ///
  {                                                                                                                 ///
  bias_flag = 0;                                  // $B%j!<%I?t%P%$%"%9$O9MN8$7$J$$(B                                   ///
  }                                                                                                                 ///
 }                                                                                                                  ///

///////////////////////////////////////////////////// $B%j!<%I?t%P%$%"%9$NHfN((B bias_ratio[] $B$r7W;;(B
if(bias_flag == 1)                                                                                                  ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  {                                                                                                                 ///
  bias_ratio[i] = (double)read_count[i] / (double)read_count[0];                                                    ///
  }                                                                                                                 ///
 }                                                                                                                  ///
else                                                                                                                ///
 {                                                                                                                  ///
 for(i=0;i<n_files;i++)                                                                                             ///
  bias_ratio[i] = 1.0;                                                                                              ///
 }                                                                                                                  ///

/////////////////////////////////////////////////////   $BF~NO%U%!%$%kL>!&%j!<%I?t!&%P%$%"%9HfN($N3NG'=PNO(B
for(i=0;i<n_files;i++)                                                                                              ///
 {                                                                                                                  ///
 printf("%-55s %10d %10.5f\n",files[i].word,read_count[i],bias_ratio[i]*100.0);                                     ///
 }                                                                                                                  ///

//////////////////////////////////////////////////////

///////////////////////////////////////////////////// $B%j%9%H$KM-$kF~NO%U%!%$%k$r$9$Y$F3+$$$FFI$`(B
for(i=0;i<n_files;i++)
 {
 hr_file = fopen(files[i].word,"r");
 if(hr_file == NULL)
  {
  printf("Failed to open the input file %s\n",files[i].word);
  exit(1);
  }

 n_lines = 0;
 while(fgets(buff,512,hr_file))
  {
  n_lines ++;
  }
 hrs[i].n_hr = n_lines;
 hrs[i].hinf  = (hr_info *)malloc(sizeof(hr_info)*(n_lines + 2));
 
 rewind(hr_file);

 n_lines = 0;
 while(fgets(buff,512,hr_file))
  {
  hrs[i].hinf[n_lines].start    = read_int(buff, 3,10);   // $B5/E@(B
  hrs[i].hinf[n_lines].end      = read_int(buff,14,10);   // $B=*E@(B
  hrs[i].hinf[n_lines].n_member = read_int(buff,25,10);   // $B%j!<%I?t(B
  sscanf(buff,"%s %d %d %d %s",ds,&d1,&d2,&d3,hrs[i].hinf[n_lines].sequence);

  if(abs(hrs[i].hinf[n_lines].start) < abs(hrs[i].hinf[n_lines].end))   // $B5/E@$H=*E@$rHf3S$7@dBPCM$N>/$J$$J}$r(Bleft
   {                                                                      // $B$b$&0lJ}$r(Bright $B$H$7$F$$$k!#(B
   hrs[i].hinf[n_lines].left  = hrs[i].hinf[n_lines].start;
   hrs[i].hinf[n_lines].right = hrs[i].hinf[n_lines].end;
   }
  else
   {
   hrs[i].hinf[n_lines].right = hrs[i].hinf[n_lines].start;
   hrs[i].hinf[n_lines].left  = hrs[i].hinf[n_lines].end;
   }
//  printf("%5d %8d %8d  %8d %8d %5d\n",i+1,hrs[i].hinf[n_lines].start,hrs[i].hinf[n_lines].end,
//             hrs[i].hinf[n_lines].left,hrs[i].hinf[n_lines].right,hrs[i].hinf[n_lines].n_member);
  n_lines ++;
  }
// printf("%5d %s\n",n_lines,files[i].word);
 max_scs += n_lines;
 fclose(hr_file);
 pointer[i] = 0;
 }
///////////////////////////////////////////////////// $B%j%9%H$KM-$kF~NO%U%!%$%k$r$9$Y$F3+$$$FFI$`(B
scs = (share_info *)malloc(sizeof(share_info) * (max_scs +1));
if (scs == NULL)
 {
 printf("Failed to allocate memory\n");
 exit(1);
 }
for(i=0;i<max_scs;i++)
 {
 scs[i].n_member = (int *)malloc(sizeof(int) * n_files);
 for(j=0;j<n_files;j++)
  scs[i].n_member[j] = 0;
 }

for(i=0;i<n_files;i++)
 {
 for(j=0;j<hrs[i].n_hr;j++)
  {
  flag = 0;
  for(k=0;k<n_scs;k++)
   {
   if((hrs[i].hinf[j].start == scs[k].from) && (hrs[i].hinf[j].end == scs[k].to))
    {
    scs[k].n_member[i] = hrs[i].hinf[j].n_member;
    flag = 1;
    break;
    }
   }
  if(flag == 0)  // $B?75,%(%s%H%j(B
   {
   scs[n_scs].from          = hrs[i].hinf[j].start;
   scs[n_scs].to            = hrs[i].hinf[j].end;
   scs[n_scs].n_member[i]   = hrs[i].hinf[j].n_member;
   strcpy(scs[n_scs].sequence,hrs[i].hinf[j].sequence);
   n_scs ++;
   }
  }
 }

for(i=0;i<n_scs;i++)
 {
 fprintf(hr_out,"%8d %8d ",scs[i].from,scs[i].to);
 fprintf(hr_out2,"%8d %8d ",scs[i].from,scs[i].to);
 for(j=0;j<n_files;j++)
  {
  fprintf(hr_out,"%8d ",scs[i].n_member[j]);
  fprintf(hr_out2,"%8.2f ",(double)scs[i].n_member[j]*bias_ratio[j]);
  }
 fprintf(hr_out," %s\n",scs[i].sequence);
 fprintf(hr_out2," %s\n",scs[i].sequence);
 }
printf("N_SCS = %10d\n",n_scs);

/*
for(i=0;i<n_files;i++)
 {
 for(j=0;j<hrs[i].n_hr;j++)
  {
  if(hrs[i].hinf[j].sum == hrs[i].hinf[hrs[i].order[j]].sum)
   printf("%8d %8d\n",hrs[i].hinf[j].sum,hrs[i].hinf[hrs[i].order[j]].sum);
  else
   printf("%8d %8d#\n",hrs[i].hinf[j].sum,hrs[i].hinf[hrs[i].order[j]].sum);
  }
 }


int end;
while(1)
 {
 min = MAX_INT;
 end = MAX_INT;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] < hrs[i].n_hr)
   if(min > abs(hrs[i].hinf[pointer[i]].left))
    {
    min = abs(hrs[i].hinf[pointer[i]].left);
    end = abs(hrs[i].hinf[pointer[i]].right);
    }
  }
 printf("MIN %d %d \n",min,end);
 fprintf(hrs_out,"%d,%d,",min,end);
 fprintf(hrs_out2,"%d,%d,",min,end);

 for(i=0;i<n_files;i++)
  {
  if(pointer[i] < hrs[i].n_unk)
   {
   if(min == abs(hrs[i].hinf[pointer[i]].left))
    {
//    printf("%2d %8d %8d %8d\n",i+1,hrs[i].hinf[pointer[i]].left,hrs[i].hinf[pointer[i]].right,
//                                hrs[i].hinf[pointer[i]].n_member);
    printf("%2d %8d %8d %8d %10.2f\n",i+1,hrs[i].hinf[pointer[i]].left,hrs[i].hinf[pointer[i]].right,
                                hrs[i].hinf[pointer[i]].n_member,
                                (double)hrs[i].hinf[pointer[i]].n_member/bias_ratio[i]);
    fprintf(hr_out,"%d,",hrs[i].hinf[pointer[i]].n_member);
    fprintf(hr_out2,"%.2f,",(double)hrs[i].hinf[pointer[i]].n_member/bias_ratio[i]);
    pointer[i] ++;
    }
   else
    {
    fprintf(hr_out,"0,");
    fprintf(hr_out2,"0.0,");
    }
   }
  else
   {
   fprintf(hr_out,"0,");
   fprintf(hr_out2,"0.0,");
   }
  }
 
 fprintf(unk_out,"\n");
 fprintf(unk_out2,"\n");

 temp = 0;
 for(i=0;i<n_files;i++)
  {
  if(pointer[i] == unks[i].n_unk)
   temp ++;
  }
 if(temp == n_files)
  break;
 }
*/


/////////////////////////////////////////////////////////////////DONE READING FILES
}
/////////////////////////////////////////////////////////////////////////MAIN END

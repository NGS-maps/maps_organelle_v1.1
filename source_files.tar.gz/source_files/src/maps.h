#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_QUERY_LEN       300
#define MAX_INDEX_LEN        18
#define MAX_INDEX_SIZE    10000
#define MAX_QUERY     600000000
#define MAX_INT      2147483647
#define MIN_INT     -2147483648
#define MAX_BOX            2600
#define MAX_ROUND           100
#define MAX_THREAD_NUM      128

//////////////////////////////////////////////////////////////////////////構造体宣言 

typedef struct query_info            //////////////////////////////////// リード情報
 {
 char *seq;                          // READ SEQUENCE    // リードの配列
 int  length;                        // READ LENGTH      // リードの長さ
///// int  num_n;                         // Number of N      // Nの数
 int  depth;                         // Depth            // マップ時の深さ位置
 } query_info;

typedef struct position_hit_info     /////////////////////////////////// 各ゲノム位置でのヒット情報
 {
 int n_hit;                          // その位置でのヒット数
 int *hits;                          // ヒットしたリードのID
 int *boxs;                          // マップ時の深さ位置
 } position_hit_info;

typedef struct index_list            /////////////////////////////////// インデックスリスト
 {
 int n_pos;                          // ヒット位置の数
 int *pos;                           // ヒット位置のリスト
 } index_list;

typedef struct hit_position_info     /////////////////////////////////// マルチヒット時のリスト形式ヒット位置
 {
 int hit_chromosome;                 // ヒットしたクロモソーム番号
 int hit_position;                   // ヒット位置
 int hit_score;
 struct hit_position_info *pointer;  // 次のヒット位置リストへのポインタ
 } hit_position_info;

typedef struct _threaad_arg          ///////////////////////////////////  スレッド用構造体
 {
 int thread_no;
 int round_num;
 int *tnum_hit;
 int *tchange_hit;
 } thread_arg_t;

typedef struct splice_info           ////////////////////////////////// スプライシング情報 
 {
 int n_segment;          // Number of segments // イントロンの数
 int *froms;             // Start point of the i'th segment
 int *tos;               // End point of the i'th segment
 } splice_info;

typedef struct chromosome_info       /////////////////////////////////// クロモソーム情報 マルチレファレンス用
 {
 int cyclic_flag;                    // サイクリックフラッグ 0:cyclic,1:linear
 char fasta_flnm[256];               // ファスタファイル名
 char gb_flnm[256];                  // ジェンバンクファイル名
 int length;                         // 塩基長
 char *refseq;                       // 配列
 char title[1024];                   // ファスタのタイトル
 index_list *ils;                    // インデックスリスト（染色体ごとに保持）
 position_hit_info *position_hits;   // 各ゲノム位置でのヒット情報

// hit_position__info **hit_positions;
///////////////////// GENBANK INFO   // 染色体ごとにGENBANK情報を保持 
/*
 int from;
 int to;
 int chr_id;
 int n_mrna;
 splice_info *mrnas;
 int n_cds;
 splice_info *cdss;
 int complement;
 char gene_name[20];
 char product_name[80];
 char locus_tag[20];
 char note[80];
 int type;               //   1:CDS, 2:tRNA, 3:rRNA, 4:misc_RNA, 5:tmRNA, 6:misc_feature
 char type_char[10];
 int intensity;
 int tag_count;
 int pre_tag_count;
 int pre_intensity;
*/
 //////////////////// GENBANK INFO
 } chromosome_info;                   // 染色体情報終わり 

///////////////////////////////////////////////////////////////////////関数プロトタイプ 
void readargs(int argc, char **argv);
